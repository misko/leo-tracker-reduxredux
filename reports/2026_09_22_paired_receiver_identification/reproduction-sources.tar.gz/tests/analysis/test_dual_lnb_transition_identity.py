from tools.research_dual_lnb_transition_identity import candidate_transition_score, score_track

MODEL = {"response_vector_enu": [2.0, 0.0, 0.0], "transition_residual_scale_db": 0.2}


def _row():
    pairs = [{"proxy_db": value} for value in (-2.0, 0.0, 2.0)]
    return {
        "session_id": "s",
        "tracklet_id": "t",
        "receiver_id": 0,
        "channel": 1,
        "edge": "lower",
        "start_utc_ns": 1,
        "pass_key": "p",
        "pairs": pairs,
        "candidates": [
            {
                "number": 1,
                "evaluation_rms_hz": 100.0,
                "state": "scored",
                "enu": [[-1, 0, 0], [0, 0, 0], [1, 0, 0]],
            },
            {
                "number": 2,
                "evaluation_rms_hz": 110.0,
                "state": "scored",
                "enu": [[1, 0, 0], [0, 0, 0], [-1, 0, 0]],
            },
        ],
    }


def test_transition_score_is_invariant_to_static_response_and_direction_levels():
    response = [-2.0, 0.0, 2.0]
    first = candidate_transition_score({"enu": [[-1, 0, 0], [0, 0, 0], [1, 0, 0]]}, response, MODEL)
    second = candidate_transition_score(
        {"enu": [[9, 4, 1], [10, 4, 1], [11, 4, 1]]}, [value + 13 for value in response], MODEL
    )
    assert first == second
    assert first["rms_db"] == 0.0


def test_combined_rule_changes_only_weak_doppler_with_absolute_runner_fit():
    row = _row()
    swapped = {**MODEL, "response_vector_enu": [-2.0, 0.0, 0.0]}
    result = score_track(row, [swapped] * 6, confirmatory=True)
    assert result["transition"]["ordering"] == "rank2"
    assert result["combined_diagnostic"]["candidate_changed_from_doppler"] is True
    row["candidates"][1]["evaluation_rms_hz"] = 400.0
    result = score_track(row, [swapped] * 6, confirmatory=True)
    assert result["doppler"]["stratum"] == "clear"
    assert result["combined_diagnostic"]["candidate_changed_from_doppler"] is False


def test_missing_pairs_is_unsupported_and_never_an_identity_rejection():
    row = _row()
    row["pairs"] = row["pairs"][:2]
    result = score_track(row, [MODEL] * 3, confirmatory=False)
    assert result["state"] == "unsupported"
    assert result["missing_or_mismatch_rejects_identity"] is False

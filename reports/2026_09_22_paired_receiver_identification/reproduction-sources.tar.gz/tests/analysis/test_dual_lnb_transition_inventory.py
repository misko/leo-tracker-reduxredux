import pytest

from tools.summarize_dual_lnb_transitions import summarize


def document(values):
    pairs = [
        dict(
            rx0_tracklet_id="left",
            rx1_tracklet_id="right",
            visit_index=i,
            utc_ns=i * 1_000_000_000,
            proxy_db=value,
        )
        for i, value in enumerate(values)
    ]
    return dict(
        window_start_utc_ns=0,
        window_end_utc_ns=100_000_000_000,
        tracks=[dict(session_id="session", pairs=pairs), dict(session_id="session", pairs=pairs)],
    )


def test_duplicate_receiver_views_are_counted_once():
    result = summarize(document([3, 3, 2, 0, -2, -3, -3]))
    assert result["unique_pair_observations"] == 7
    assert result["counts"] == {"rx0-to-rx1-proxy-dominance": 1}


def test_mapping_swap_reverses_label_and_short_support_stays_unknown():
    assert (
        summarize(document([-3, -3, -2, 0, 2, 3, 3]))["rows"][0]["status"]
        == "rx1-to-rx0-proxy-dominance"
    )
    assert summarize(document([3, -3]))["rows"][0]["status"] == "insufficient-span-or-visits"


def test_conflicting_duplicates_fail_instead_of_double_counting():
    d = document([2, 1, -2])
    d["tracks"][1]["pairs"] = [dict(p) for p in d["tracks"][0]["pairs"]]
    d["tracks"][1]["pairs"][0]["proxy_db"] = 99
    with pytest.raises(ValueError, match="conflicting"):
        summarize(d)

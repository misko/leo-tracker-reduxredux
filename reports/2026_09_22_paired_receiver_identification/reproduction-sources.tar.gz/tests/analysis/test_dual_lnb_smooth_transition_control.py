import numpy as np
import pytest

from tools.audit_dual_lnb_smooth_transition_control import resample_profile


def points(times, values):
    return [dict(utc_ns=t, proxy_db=v) for t, v in zip(times, values, strict=True)]


def test_smooth_control_preserves_direction_without_wrapped_discontinuity():
    target = points([0, 10, 20, 30, 40], [0] * 5)
    donor = points([100, 120, 140], [-3, 0, 3])
    result = resample_profile(target, donor)
    np.testing.assert_allclose(result, [-3, -1.5, 0, 1.5, 3])
    assert np.all(np.diff(result) > 0)


def test_constant_time_profile_is_not_a_valid_donor():
    with pytest.raises(ValueError, match="positive time span"):
        resample_profile(points([0, 10], [0, 1]), points([1, 1], [2, 3]))

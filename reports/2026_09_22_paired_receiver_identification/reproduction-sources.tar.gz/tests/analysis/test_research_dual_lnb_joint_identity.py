from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pytest

PATH = Path(__file__).parents[2] / "tools" / "research_dual_lnb_joint_identity.py"
SPEC = importlib.util.spec_from_file_location("joint_identity", PATH)
assert SPEC and SPEC.loader
tool = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(tool)


def test_shared_visit_partition_and_equal_visit_weighting() -> None:
    rows = [
        {"visit_index": 0, "receiver_id": 0, "cfo_hz": 10.0},
        {"visit_index": 0, "receiver_id": 1, "cfo_hz": 110.0},
        {"visit_index": 1, "receiver_id": 0, "cfo_hz": 20.0},
        {"visit_index": 1, "receiver_id": 1, "cfo_hz": 120.0},
        {"visit_index": 2, "receiver_id": 0, "cfo_hz": 31.0},
        {"visit_index": 2, "receiver_id": 1, "cfo_hz": 131.0},
    ]
    prediction = np.asarray([0.0, 0.0, 10.0, 10.0, 20.0, 20.0])
    result = tool.score_predictions(rows, {0.0: prediction}, {0, 1})
    assert result["offset_hz_by_receiver"] == {"0": 10.0, "1": 110.0}
    assert result["evaluation_equal_visit_rms_hz"] == 1.0


def test_partition_is_order_independent_and_has_heldout() -> None:
    a = tool.visit_partition([4, 3, 2, 1, 0], "seed")
    b = tool.visit_partition([0, 1, 2, 3, 4], "seed")
    assert a == b
    assert 0 < len(a) < 5


def test_ranking_is_training_only_when_evaluation_winner_differs() -> None:
    candidates = [
        {
            "number": 2,
            "state": "scored",
            "joint": {"training_equal_visit_rms_hz": 1.0, "evaluation_equal_visit_rms_hz": 9.0},
        },
        {
            "number": 1,
            "state": "scored",
            "joint": {"training_equal_visit_rms_hz": 2.0, "evaluation_equal_visit_rms_hz": 1.0},
        },
    ]
    assert tool.ranked_numbers(candidates, ("joint", "training_equal_visit_rms_hz")) == [2, 1]
    assert tool.ranked_numbers(candidates, ("joint", "evaluation_equal_visit_rms_hz")) == [1, 2]


def test_offset_minimizes_equal_visit_objective_with_uneven_rows() -> None:
    rows = [
        {"visit_index": 0, "receiver_id": 0, "cfo_hz": 0.0},
        {"visit_index": 0, "receiver_id": 0, "cfo_hz": 0.0},
        {"visit_index": 0, "receiver_id": 1, "cfo_hz": 30.0},
        {"visit_index": 1, "receiver_id": 0, "cfo_hz": 20.0},
        {"visit_index": 2, "receiver_id": 0, "cfo_hz": 10.0},
        {"visit_index": 2, "receiver_id": 1, "cfo_hz": 40.0},
    ]
    result = tool.score_predictions(rows, {0.0: np.zeros(6)}, {0, 1})
    # RX0: (0/3 + 0/3 + 20) / (1/3 + 1/3 + 1) = 12 Hz.
    assert result["offset_hz_by_receiver"]["0"] == pytest.approx(12.0)
    assert result["offset_hz_by_receiver"]["1"] == 30.0

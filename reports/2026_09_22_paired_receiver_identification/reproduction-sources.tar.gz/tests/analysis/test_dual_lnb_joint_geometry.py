from tools.summarize_dual_lnb_joint_geometry import summarize


def test_geometry_matches_catalogue_numbers_not_receiver_rank():
    pair = dict(
        session_id="s",
        rx0_tracklet_id="left",
        rx1_tracklet_id="right",
        review_agreement="different-leader",
        joint_best_number=20,
        joint_runner_up_number=10,
        candidates=[dict(number=n, state="scored", joint={}) for n in (10, 20)],
    )
    geometry = dict(
        tracks=[
            dict(
                session_id="s",
                tracklet_id="left",
                state="scored",
                candidates=[dict(number=10), dict(number=20)],
                transition=dict(ordering="rank2"),
                confirmatory_later_session=True,
            ),
            dict(
                session_id="s",
                tracklet_id="right",
                state="scored",
                candidates=[dict(number=20), dict(number=10)],
                transition=dict(ordering="rank1"),
                confirmatory_later_session=True,
            ),
        ]
    )
    out = summarize(dict(results=[pair]), geometry)["rows"][0]
    assert out["geometry_evidence"] == "supports-joint-leader"
    assert out["joint_best_id"] == 20
    assert not out["identity_claimed"]
    geometry["tracks"][0]["transition"]["ordering"] = "rank1"
    out = summarize(dict(results=[pair]), geometry)["rows"][0]
    assert out["geometry_evidence"] == "mixed"
    assert not out["geometry_rejects_candidate"]

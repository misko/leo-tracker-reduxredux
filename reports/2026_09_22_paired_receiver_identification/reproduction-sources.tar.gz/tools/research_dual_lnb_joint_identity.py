#!/usr/bin/env python3
"""Rescore exact RX0/RX1 track pairs with a common causal identity protocol.

This research-only audit fits a shared integer-second TLE time shift and one
constant CFO offset per receiver.  Train/evaluation membership is assigned by
visit, and the joint loss gives each visit unit weight regardless of whether
one or both receivers observed it.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
from research_dual_lnb_full_corpus import read_document, tracking_input

from leo.analysis.persistent_hop_trajectory import reconstruct_persistent_hop_trajectories
from leo.analysis.research.formal_orbit import doppler_hz
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.frames import (
    geodetic_to_ecef_km,
    greenwich_mean_sidereal_time_rad,
    julian_day_from_utc_ns,
    teme_to_ecef,
)
from leo.sky.propagation import parse_element_sets

SCHEMA = "org.leo.research.dual-lnb-joint-identity/v1"
SITE = {"latitude_deg": 37.858988, "longitude_deg": -122.478103, "altitude_m": -29.0}
TAUS = tuple(float(x) for x in range(-5, 6))


def _read(path: Path) -> dict[str, Any]:
    data = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(data)


def visit_partition(visits: list[int], seed_text: str, fraction: float = 0.6) -> set[int]:
    """Deterministic response-free randomized partition shared across receivers."""
    ordered = sorted(
        set(visits), key=lambda v: hashlib.sha256(f"{seed_text}:{v}".encode()).digest()
    )
    if len(ordered) < 2:
        return set(ordered)
    count = min(max(round(fraction * len(ordered)), 1), len(ordered) - 1)
    return set(ordered[:count])


def score_predictions(
    rows: list[dict[str, Any]], predictions: dict[float, np.ndarray], training_visits: set[int]
) -> dict[str, Any]:
    """Profile RX constants on training and score visits with equal total weight."""
    y = np.asarray([r["cfo_hz"] for r in rows], float)
    receiver = np.asarray([r["receiver_id"] for r in rows], int)
    visit = np.asarray([r["visit_index"] for r in rows], int)
    train = np.asarray([v in training_visits for v in visit], bool)
    if not np.any(train) or np.all(train):
        raise ValueError("both training and evaluation visits are required")
    best = None
    for tau, prediction in predictions.items():
        offsets = {}
        residual = np.empty(len(rows), float)
        usable = True
        for rx in sorted(set(receiver)):
            fit = train & (receiver == rx)
            if not np.any(fit):
                usable = False
                break
            # The objective first averages rows within visit, then visits.  A
            # row therefore carries reciprocal weight equal to its visit's
            # total row count, including the other receiver when present.
            visit_size = {v: int(np.sum(train & (visit == v))) for v in set(visit[train])}
            weights = np.asarray([1.0 / visit_size[v] for v in visit[fit]], float)
            offsets[int(rx)] = float(np.average(y[fit] - prediction[fit], weights=weights))
            residual[receiver == rx] = (
                y[receiver == rx] - prediction[receiver == rx] - offsets[int(rx)]
            )
        if not usable:
            continue

        def equal_visit_rms(mask: np.ndarray, residual=residual) -> float:
            losses = [
                float(np.mean(residual[mask & (visit == v)] ** 2)) for v in sorted(set(visit[mask]))
            ]
            return float(np.sqrt(np.mean(losses)))

        item = {
            "tau_s": tau,
            "offset_hz_by_receiver": {str(k): v for k, v in offsets.items()},
            "training_equal_visit_rms_hz": equal_visit_rms(train),
            "evaluation_equal_visit_rms_hz": equal_visit_rms(~train),
        }
        if (
            best is None
            or item["training_equal_visit_rms_hz"] < best["training_equal_visit_rms_hz"]
        ):
            best = item
    if best is None:
        raise ValueError("no tau has training support on every receiver")
    return best


def ranked_numbers(candidates: list[dict[str, Any]], score_path: tuple[str, ...]) -> list[int]:
    """Rank only by a declared score, with catalogue number as a stable tie break."""
    scored = [x for x in candidates if x.get("state") == "scored"]

    def key(item: dict[str, Any]) -> tuple[float, int]:
        value: Any = item
        for part in score_path:
            value = value[part]
        return float(value), int(item["number"])

    return [int(x["number"]) for x in sorted(scored, key=key)]


def _prediction(
    catalogue, number: int, utc_ns: np.ndarray, tau_s: float, *, capture_ns: int
) -> np.ndarray:
    numbers = list(catalogue.satellite_numbers)
    if number not in numbers:
        raise ValueError("candidate-absent-from-causal-snapshot")
    i = numbers.index(number)
    if int(catalogue.element_epoch_utc_ns()[i]) >= capture_ns:
        raise ValueError("candidate-element-epoch-not-before-capture")
    jd, fraction = julian_day_from_utc_ns(utc_ns + round(tau_s * 1e9))
    error, position, velocity = catalogue.satellites[i].sgp4_array(jd, fraction)
    if np.any(error):
        raise ValueError("candidate-propagation-failed")
    position, velocity = teme_to_ecef(
        position, velocity, greenwich_mean_sidereal_time_rad(jd, fraction)
    )
    receiver = geodetic_to_ecef_km(SITE["latitude_deg"], SITE["longitude_deg"], SITE["altitude_m"])
    return np.asarray(doppler_hz(receiver, position, velocity), float)


def _session_rows(document: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    candidates = project_scanner_candidates(tracking_input(document["source"]))
    by_id = {str(x.candidate_id): x for x in candidates}
    trajectories = reconstruct_persistent_hop_trajectories(candidates)
    result: dict[str, list[dict[str, Any]]] = {}
    for track in trajectories.tracklets:
        result[str(track.tracklet_id)] = [
            {
                "utc_ns": int(by_id[str(p.candidate_id)].support_center_utc_ns),
                "visit_index": int(by_id[str(p.candidate_id)].visit_index),
                "receiver_id": int(by_id[str(p.candidate_id)].receiver_id),
                "cfo_hz": float(p.normalized_dealiased_cfo_hz),
            }
            for p in track.points
        ]
    return result


def analyze(args: argparse.Namespace) -> dict[str, Any]:
    continuity = _read(args.continuity)
    eligible = [x for x in continuity["links"] if int(x["distinct_paired_visits"]) >= 3]
    by_session: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for link in eligible:
        by_session[str(link["session_id"])].append(link)
    sources = {p.stem.removesuffix(".json"): p for p in args.source_cache.glob("*.json.gz")}
    archive = TleArchiveReader(args.tle_archive)
    references = {x.digest: x for x in archive.list_snapshots()}
    catalogues: dict[str, Any] = {}
    results = []
    diagnostics: defaultdict[str, int] = defaultdict(int)
    for session_id in sorted(by_session):
        path = sources.get(session_id)
        if path is None:
            diagnostics["missing_source"] += len(by_session[session_id])
            continue
        document = read_document(path)
        snapshot = document["tracking"]["original_tle_snapshot"]
        capture_ns = int(document["source"]["timing"]["first_sample_estimate_utc_ns"])
        if int(snapshot["collected_utc_ns"]) >= capture_ns:
            raise ValueError("noncausal snapshot")
        digest = str(snapshot["digest"])
        if digest not in references:
            raise ValueError(f"snapshot absent from archive: {digest}")
        if digest not in catalogues:
            catalogues[digest] = parse_element_sets(archive.read(references[digest]))
        catalogue = catalogues[digest]
        tracks = _session_rows(document)
        for link in by_session[session_id]:
            ids = [str(link["rx0_tracklet_id"]), str(link["rx1_tracklet_id"])]
            if any(x not in tracks for x in ids):
                diagnostics["missing_reconstructed_track"] += 1
                continue
            rows = tracks[ids[0]] + tracks[ids[1]]
            union = sorted(
                {
                    int(c["number"])
                    for side in ("rx0_candidates", "rx1_candidates")
                    for c in link[side]
                    if c.get("state") == "scored"
                }
            )
            visits = [int(x["visit_index"]) for x in rows]
            training = visit_partition(visits, f"{session_id}:{ids[0]}:{ids[1]}:joint-v1")
            utc = np.asarray([x["utc_ns"] for x in rows], np.int64)
            candidate_results = []
            for number in union:
                try:
                    predictions = {
                        tau: _prediction(catalogue, number, utc, tau, capture_ns=capture_ns)
                        for tau in TAUS
                    }
                    joint = score_predictions(rows, predictions, training)
                    singles = {}
                    for rx in (0, 1):
                        indexes = np.asarray([x["receiver_id"] == rx for x in rows], bool)
                        subrows = [x for x in rows if x["receiver_id"] == rx]
                        singles[str(rx)] = score_predictions(
                            subrows, {t: p[indexes] for t, p in predictions.items()}, training
                        )
                    candidate_results.append(
                        {"number": number, "state": "scored", "joint": joint, "individual": singles}
                    )
                except ValueError as exc:
                    candidate_results.append({"number": number, "state": str(exc)})
            joint_training_rank = ranked_numbers(
                candidate_results, ("joint", "training_equal_visit_rms_hz")
            )
            joint_evaluation_rank = ranked_numbers(
                candidate_results, ("joint", "evaluation_equal_visit_rms_hz")
            )
            individual_training_rank = {
                str(rx): ranked_numbers(
                    candidate_results,
                    ("individual", str(rx), "training_equal_visit_rms_hz"),
                )
                for rx in (0, 1)
            }
            individual_evaluation_rank = {
                str(rx): ranked_numbers(
                    candidate_results,
                    ("individual", str(rx), "evaluation_equal_visit_rms_hz"),
                )
                for rx in (0, 1)
            }
            results.append(
                {
                    "session_id": session_id,
                    "rx0_tracklet_id": ids[0],
                    "rx1_tracklet_id": ids[1],
                    "review_agreement": link["review_agreement"],
                    "distinct_paired_visits": link["distinct_paired_visits"],
                    "rx0_stored_top_id": link["rx0_candidates"][0]["number"]
                    if link["rx0_candidates"]
                    else None,
                    "rx1_stored_top_id": link["rx1_candidates"][0]["number"]
                    if link["rx1_candidates"]
                    else None,
                    "training_visits": sorted(training),
                    "evaluation_visits": sorted(set(visits) - training),
                    "candidate_union": union,
                    "candidates": candidate_results,
                    "joint_state": (
                        "scored"
                        if joint_training_rank
                        else "unsupported-empty-candidate-union"
                        if not union
                        else "unsupported-no-causal-scored-candidate"
                    ),
                    "joint_best_number": joint_training_rank[0] if joint_training_rank else None,
                    "joint_runner_up_number": joint_training_rank[1]
                    if len(joint_training_rank) > 1
                    else None,
                    "joint_training_rank": joint_training_rank,
                    "joint_evaluation_rank_diagnostic": joint_evaluation_rank,
                    "individual_training_rank": individual_training_rank,
                    "individual_evaluation_rank_diagnostic": individual_evaluation_rank,
                }
            )
    return {
        "schema": SCHEMA,
        "protocol": {
            "site": SITE,
            "tau_grid_s": list(TAUS),
            "candidate_set": "union-of-stored-top-two",
            "partition": "deterministic-randomized-by-visit-60-percent-training",
            "nuisance": "shared-tau-and-separate-per-receiver-constant-offsets-fit-on-training",
            "joint_loss": "equal-visit RMS; average simultaneous RX squared residuals within visit",
            "evaluation": "randomized held observations in same tracks; no time-holdout claim",
            "tle": "each scan original snapshot, snapshot and element epochs strictly causal",
        },
        "input_links": len(continuity["links"]),
        "eligible_links": len(eligible),
        "results": results,
        "diagnostics": dict(diagnostics),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--continuity", type=Path, required=True)
    parser.add_argument("--source-cache", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "eligible": result["eligible_links"],
                "completed": len(result["results"]),
                "diagnostics": result["diagnostics"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

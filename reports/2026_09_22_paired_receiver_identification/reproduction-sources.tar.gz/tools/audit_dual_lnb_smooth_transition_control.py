"""Swap complete smooth response profiles, retaining each candidate's sky path."""

import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from research_dual_lnb_transition_identity import candidate_transition_score


def resample_profile(points, donor):
    def values(rows):
        ordered = sorted(rows, key=lambda p: p["utc_ns"])
        t = np.array([p["utc_ns"] for p in ordered], dtype=np.int64)
        if t[-1] <= t[0]:
            raise ValueError("response profile needs positive time span")
        t = (t - t[0]).astype(float) / (int(t[-1]) - int(t[0]))
        return t, np.array([p["proxy_db"] for p in ordered], float)

    t, _ = values(points)
    dt, dy = values(donor)
    return np.interp(t, dt, dy)


def analyze(source, scored, trials=100):
    byid = {(r["session_id"], r["tracklet_id"]): r for r in source["tracks"]}
    targets = []
    donors = defaultdict(dict)
    for row in scored["tracks"]:
        if row["state"] != "scored" or not row["confirmatory_later_session"]:
            continue
        raw = byid[row["session_id"], row["tracklet_id"]]
        if any(
            raw["pairs"][i]["utc_ns"] > raw["pairs"][i + 1]["utc_ns"]
            for i in range(len(raw["pairs"]) - 1)
        ):
            raise ValueError("candidate directions require chronological source pairs")
        lane = (raw["channel"], raw["edge"])
        targets.append(raw)
        previous = donors[lane].get(raw["pass_key"])
        if previous is None or len(raw["pairs"]) > len(previous["pairs"]):
            donors[lane][raw["pass_key"]] = raw
    model = {
        "response_vector_enu": scored["calibration"]["nominal_response_vector_enu"],
        "transition_residual_scale_db": 1.0,
    }
    eligible = [r for r in targets if len(donors[(r["channel"], r["edge"])]) > 1]

    def favors(row, response):
        result = [
            candidate_transition_score(c, response, model)["rms_db"] for c in row["candidates"][:2]
        ]
        return result[0] < result[1]

    actual = sum(favors(r, np.array([p["proxy_db"] for p in r["pairs"]])) for r in eligible)
    rng = np.random.default_rng(2026092207)
    counts = []
    for _ in range(trials):
        # One random donor fraction per pass is shared across lanes/receivers.
        choices = {r["pass_key"]: float(rng.random()) for r in eligible}
        wins = 0
        for row in eligible:
            bank = donors[(row["channel"], row["edge"])]
            keys = sorted(k for k in bank if k != row["pass_key"])
            donor = bank[keys[min(int(choices[row["pass_key"]] * len(keys)), len(keys) - 1)]]
            wins += favors(row, resample_profile(row["pairs"], donor["pairs"]))
        counts.append(int(wins))
    return {
        "eligible_tracks": len(eligible),
        "later_scored_tracks": len(targets),
        "actual_nominal_rank1_favored": int(actual),
        "smooth_donor_trial_counts": counts,
        "trial_count_min_median_max": np.percentile(counts, [0, 50, 100]).tolist(),
        "trials_at_least_actual": sum(c >= actual for c in counts),
        "interpretation": (
            "Smooth whole-profile donor sensitivity, not an exchangeable statistical null "
            "or identity-error probability. Donor normalized-time resampling changes "
            "speed/amplitude; shared pass draw preserves partial correlations, "
            "not all source dependence."
        ),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--scores", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    raw = a.input.read_bytes()
    if a.input.suffix == ".gz":
        raw = gzip.decompress(raw)
    result = analyze(json.loads(raw), json.loads(a.scores.read_text()))
    a.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "smooth_donor_trial_counts"}))


if __name__ == "__main__":
    main()

"""Render training-selected joint candidate residuals from saved scores."""

import argparse
import gzip
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    a = parser.parse_args()
    raw = a.input.read_bytes()
    if a.input.suffix == ".gz":
        raw = gzip.decompress(raw)
    data = json.loads(raw)
    values = []
    for pair in data["results"]:
        candidates = {c["number"]: c for c in pair["candidates"] if c["state"] == "scored"}
        best, runner = pair["joint_best_number"], pair["joint_runner_up_number"]
        if best is None or runner is None:
            continue
        individual = np.mean(
            [
                candidates[pair["individual_training_rank"][str(rx)][0]]["individual"][str(rx)][
                    "evaluation_equal_visit_rms_hz"
                ]
                for rx in (0, 1)
            ]
        )
        values.append(
            [
                candidates[best]["joint"]["evaluation_equal_visit_rms_hz"],
                candidates[runner]["joint"]["evaluation_equal_visit_rms_hz"],
                individual,
            ]
        )
    x = np.asarray(values)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), layout="constrained")
    axes[0].scatter(x[:, 0], x[:, 1], s=10, alpha=0.5)
    axes[1].scatter(x[:, 2], x[:, 0], s=10, alpha=0.5)
    for ax in axes:
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.grid(alpha=0.2)
        lower = min(ax.get_xlim()[0], ax.get_ylim()[0])
        upper = max(ax.get_xlim()[1], ax.get_ylim()[1])
        ax.plot([lower, upper], [lower, upper], "k--", lw=1)
    axes[0].set(
        xlabel="Joint training leader: evaluation RMS (Hz)",
        ylabel="Joint training runner: evaluation RMS (Hz)",
    )
    axes[1].set(
        xlabel="Mean of individual winners’ evaluation RMS (Hz)",
        ylabel="Joint winner evaluation RMS (Hz)",
    )
    fig.suptitle(
        "Paired-receiver candidate scores — randomized evaluation\n"
        "Right panel compares different aggregate statistics; not an accuracy metric"
    )
    a.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.output, dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Paired-RX directional-transition diagnostic for frozen NORAD candidates.

The response is RX0/RX1 GLRT-margin dB.  Both response and candidate ENU are
demeaned within each track/pass, so the fit measures response change rather
than static level.  Outputs are descriptive research diagnostics, never
identity probabilities.  Missing detections and response mismatch never reject
an identity.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
from research_dual_lnb_identity_controls import _score_candidate as _level_candidate_score
from research_dual_lnb_identity_controls import fit_calibration_models

OLD_FREEZE_UTC_NS = 1789999014000000000
EXPECTED_COMPLETE_SCANS = 75
EXPECTED_PENDING_SCANS = 2
EXPECTED_TRACKS = 2948
MINIMUM_PAIRED_POINTS = 3


def _session_starts(source: dict[str, Any]) -> dict[str, int]:
    starts: dict[str, int] = {}
    for row in source["tracks"]:
        key = str(row["session_id"])
        starts[key] = min(starts.get(key, int(row["start_utc_ns"])), int(row["start_utc_ns"]))
    return starts


def _groups(
    points: list[dict[str, Any]], sessions: set[str]
) -> dict[tuple[str, int], list[dict[str, Any]]]:
    grouped: dict[tuple[str, int], list[dict[str, Any]]] = defaultdict(list)
    for point in points:
        if str(point["session_id"]) in sessions and math.isfinite(float(point["proxy_db"])):
            grouped[(str(point["session_id"]), int(point["number"]))].append(point)
    return {
        key: sorted(rows, key=lambda row: (int(row["utc_ns"]), str(row["pair_id"])))
        for key, rows in grouped.items()
        if len(rows) >= MINIMUM_PAIRED_POINTS
    }


def _transition_arrays(rows: list[dict[str, Any]]) -> tuple[np.ndarray, np.ndarray]:
    enu = np.asarray([row["enu"] for row in rows], dtype=float)
    response = np.asarray([row["proxy_db"] for row in rows], dtype=float)
    if enu.shape != (len(rows), 3) or not np.all(np.isfinite(enu)):
        raise ValueError("calibration ENU must be finite three-vectors")
    return enu - np.mean(enu, axis=0), response - np.mean(response)


def _fit_transition(
    grouped: dict[tuple[str, int], list[dict[str, Any]]], sampled: list[tuple[str, int]]
) -> dict[str, Any] | None:
    design, response, weights = [], [], []
    for key in sampled:
        # Remove the mean separately inside each RF lane.  A lane offset must
        # not masquerade as directional change when one pass spans lanes.
        lanes: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
        for row in grouped[key]:
            lanes[(int(row["channel"]), str(row["edge"]))].append(row)
        usable = [rows for rows in lanes.values() if len(rows) >= MINIMUM_PAIRED_POINTS]
        for rows in usable:
            x, y = _transition_arrays(rows)
            design.extend(x[:, :2])
            response.extend(y)
            weights.extend([1.0 / (len(usable) * len(y))] * len(y))
    if len(design) < 3:
        return None
    x, y, weight = np.asarray(design), np.asarray(response), np.asarray(weights)
    root = np.sqrt(weight)
    beta, _, rank, _ = np.linalg.lstsq(x * root[:, None], y * root, rcond=None)
    if rank < 2:
        return None
    residual = y - x @ beta
    scale = float(np.sqrt(np.sum(weight * residual**2) / np.sum(weight)))
    if not math.isfinite(scale) or scale <= 0:
        return None
    return {
        "response_vector_enu": [float(beta[0]), float(beta[1]), 0.0],
        "transition_residual_scale_db": scale,
        "response_heading_deg": float(np.degrees(np.arctan2(beta[0], beta[1])) % 360),
    }


def fit_transition_models(
    points: list[dict[str, Any]],
    starts: dict[str, int],
    *,
    cutoff_utc_ns: int,
    bootstrap_trials: int,
    seed: int = 20260922,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    early = {session for session, start in starts.items() if start < cutoff_utc_ns}
    grouped = _groups(points, early)
    keys = sorted(grouped)
    if len(keys) < 4:
        raise ValueError("insufficient early calibration passes")
    nominal = _fit_transition(grouped, keys)
    if nominal is None:
        raise ValueError("transition calibration design is rank deficient")
    nominal["model_id"] = "nominal"
    models = [nominal]
    rng = np.random.default_rng(seed)
    attempts = 0
    while len(models) <= bootstrap_trials and attempts < bootstrap_trials * 20:
        attempts += 1
        sampled = [keys[index] for index in rng.integers(0, len(keys), len(keys))]
        model = _fit_transition(grouped, sampled)
        if model is not None:
            model["model_id"] = f"whole-pass-bootstrap-{len(models):03d}"
            models.append(model)
    if len(models) <= bootstrap_trials:
        raise ValueError("could not construct requested transition bootstraps")
    vectors = np.asarray([model["response_vector_enu"] for model in models[1:]])
    return models, {
        "cutoff_utc_ns": cutoff_utc_ns,
        "early_complete_sessions": len(early),
        "calibration_passes": len(keys),
        "calibration_points": sum(len(rows) for rows in grouped.values()),
        "bootstrap_trials": bootstrap_trials,
        "nominal_response_vector_enu": nominal["response_vector_enu"],
        "response_heading_deg_q05_median_q95": np.quantile(
            [model["response_heading_deg"] for model in models[1:]], [0.05, 0.5, 0.95]
        ).tolist(),
        "response_vector_en_q05_q95": np.quantile(vectors[:, :2], [0.05, 0.95], axis=0).tolist(),
        "receiver_mapping_hypotheses": {
            "canonical": "response = RX0/RX1 dB",
            "swapped": "RX1/RX0 dB; mirrored vector, identical candidate scores",
            "resolved": False,
        },
        "orientation": "globally learned empirical EN sensitivity; no mechanical boresight claim",
    }


def fit_time_trend(
    points: list[dict[str, Any]], starts: dict[str, int], *, cutoff_utc_ns: int
) -> dict[str, float]:
    """Candidate-independent monotonic time control, fitted on the same early lanes."""
    early = {session for session, start in starts.items() if start < cutoff_utc_ns}
    grouped = _groups(points, early)
    design, response, weights = [], [], []
    for pass_rows in grouped.values():
        lanes: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
        for row in pass_rows:
            lanes[(int(row["channel"]), str(row["edge"]))].append(row)
        usable = [rows for rows in lanes.values() if len(rows) >= MINIMUM_PAIRED_POINTS]
        for rows in usable:
            seconds = np.asarray([row["utc_ns"] for row in rows], dtype=float) / 1e9
            y = np.asarray([row["proxy_db"] for row in rows], dtype=float)
            design.extend(seconds - np.mean(seconds))
            response.extend(y - np.mean(y))
            weights.extend([1.0 / (len(usable) * len(rows))] * len(rows))
    x, y, weight = np.asarray(design), np.asarray(response), np.asarray(weights)
    slope = float(np.sum(weight * x * y) / np.sum(weight * x * x))
    residual = y - slope * x
    return {
        "slope_db_per_s": slope,
        "residual_scale_db": float(np.sqrt(np.sum(weight * residual**2) / np.sum(weight))),
    }


def candidate_transition_score(
    candidate: dict[str, Any], response: np.ndarray, model: dict[str, Any], *, roll: int = 0
) -> dict[str, float] | None:
    response = np.asarray(response, dtype=float)
    enu = np.asarray(candidate.get("enu", []), dtype=float)
    if (
        enu.shape != (response.size, 3)
        or response.size < MINIMUM_PAIRED_POINTS
        or not np.all(np.isfinite(enu))
    ):
        return None
    y = response - np.mean(response)
    if roll:
        y = np.roll(y, roll)
    x = enu - np.mean(enu, axis=0)
    residual = y - x @ np.asarray(model["response_vector_enu"], dtype=float)
    return {
        "rms_db": float(np.sqrt(np.mean(residual**2))),
        "normalized_rms": float(
            np.sqrt(np.mean(residual**2)) / model["transition_residual_scale_db"]
        ),
    }


def _level_scores(row: dict[str, Any], model: dict[str, Any] | None) -> list[float] | None:
    """Original frozen early-session global level-geometry diagnostic."""
    if model is None:
        return None
    response = np.asarray([pair["proxy_db"] for pair in row.get("pairs", [])], dtype=float)
    if response.size < MINIMUM_PAIRED_POINTS:
        return None
    scores = []
    for candidate in row.get("candidates", [])[:2]:
        score = _level_candidate_score(
            candidate, response, (int(row["channel"]), str(row["edge"])), model
        )
        if score is None:
            return None
        scores.append(float(score["rms_db"]))
    return scores if len(scores) == 2 else None


def score_track(
    row: dict[str, Any],
    models: list[dict[str, Any]],
    *,
    confirmatory: bool,
    level_model: dict[str, Any] | None = None,
    time_model: dict[str, float] | None = None,
) -> dict[str, Any]:
    candidates = row.get("candidates", [])[:2]
    base = {
        key: row[key]
        for key in (
            "session_id",
            "tracklet_id",
            "receiver_id",
            "channel",
            "edge",
            "start_utc_ns",
            "pass_key",
        )
    }
    base.update(
        {
            "confirmatory_later_session": confirmatory,
            "visibility_status": "unobstructed-visibility-unknown",
            "missing_or_mismatch_rejects_identity": False,
            "paired_point_count": len(row.get("pairs", [])),
        }
    )
    if len(candidates) < 2:
        return {**base, "state": "unsupported", "reason": "fewer-than-two-candidates"}
    base["candidates"] = [
        {"number": int(c["number"]), "doppler_evaluation_rms_hz": c.get("evaluation_rms_hz")}
        for c in candidates
    ]
    if len(row.get("pairs", [])) < MINIMUM_PAIRED_POINTS:
        return {**base, "state": "unsupported", "reason": "fewer-than-three-paired-points"}
    if any(candidate.get("state") != "scored" for candidate in candidates):
        return {**base, "state": "unsupported", "reason": "candidate-orbit-not-scored"}
    response = np.asarray([pair["proxy_db"] for pair in row["pairs"]], dtype=float)
    all_scores: list[list[dict[str, float]]] = []
    for model in models:
        scores = [
            candidate_transition_score(candidate, response, model) for candidate in candidates
        ]
        if any(score is None for score in scores):
            return {**base, "state": "unsupported", "reason": "candidate-geometry-shape-mismatch"}
        all_scores.append(scores)  # type: ignore[arg-type]
    differences = np.asarray([scores[1]["rms_db"] - scores[0]["rms_db"] for scores in all_scores])
    q05, median, q95 = np.quantile(differences[1:], [0.05, 0.5, 0.95])
    if q05 > 0:
        transition_order = "rank1"
    elif q95 < 0:
        transition_order = "rank2"
    else:
        transition_order = "uncertain"
    r1, r2 = (float(candidates[i]["evaluation_rms_hz"]) for i in range(2))
    ratio = r2 / max(r1, 1e-12)
    doppler_stratum = "weak" if ratio < 1.5 else ("intermediate" if ratio < 3 else "clear")
    runner_absolute_fit = all_scores[0][1]["normalized_rms"] <= 1.0
    combined = "retain-doppler-rank1"
    if doppler_stratum == "weak" and transition_order == "rank2" and runner_absolute_fit:
        combined = "research-tiebreak-rank2"
    level = _level_scores(row, level_model)
    time_control = None
    if time_model is not None:
        seconds = np.asarray([pair["utc_ns"] for pair in row["pairs"]], dtype=float) / 1e9
        seconds -= np.mean(seconds)
        centered = response - np.mean(response)
        time_rms = float(np.sqrt(np.mean((centered - time_model["slope_db_per_s"] * seconds) ** 2)))
        best_transition_rms = min(all_scores[0][0]["rms_db"], all_scores[0][1]["rms_db"])
        time_control = {
            "rms_db": time_rms,
            "best_candidate_transition_rms_db": best_transition_rms,
            "geometry_beats_time_trend": best_transition_rms < time_rms,
        }
    return {
        **base,
        "state": "scored",
        "doppler": {
            "ordering": "rank1",
            "rms_ratio_rank2_over_rank1": ratio,
            "stratum": doppler_stratum,
        },
        "original_level_geometry": None
        if level is None
        else {
            "rank1_rms_db": level[0],
            "rank2_rms_db": level[1],
            "ordering": "rank1" if level[0] < level[1] else "rank2",
        },
        "transition": {
            "rank1_nominal": all_scores[0][0],
            "rank2_nominal": all_scores[0][1],
            "runner_minus_rank1_rms_db_nominal": float(differences[0]),
            "runner_minus_rank1_rms_db_q05_median_q95": [float(q05), float(median), float(q95)],
            "ordering": transition_order,
        },
        "candidate_independent_time_trend": time_control,
        "combined_diagnostic": {
            "ordering": combined,
            "candidate_changed_from_doppler": combined == "research-tiebreak-rank2",
            "rule": (
                "change only weak Doppler when bootstraps favor rank2 "
                "and rank2 nominal transition RMS <= calibration scale"
            ),
        },
    }


def transition_nulls(
    source_rows: list[dict[str, Any]],
    scored: list[dict[str, Any]],
    model: dict[str, Any],
    *,
    trials: int,
    seed: int = 2026092201,
) -> list[dict[str, int]]:
    """Circularly shift whole response tracks; trajectory and serial correlation stay intact."""
    source = {(row["session_id"], row["tracklet_id"]): row for row in source_rows}
    rng = np.random.default_rng(seed)
    output = []
    for trial in range(trials):
        wins, usable = 0, 0
        pass_roll: dict[str, float] = {}
        for result in scored:
            row = source[(result["session_id"], result["tracklet_id"])]
            n = len(row["pairs"])
            if n < MINIMUM_PAIRED_POINTS:
                continue
            fraction = pass_roll.setdefault(result["pass_key"], float(rng.random()))
            roll = 1 + int(fraction * (n - 1))
            response = np.asarray([pair["proxy_db"] for pair in row["pairs"]], dtype=float)
            scores = [
                candidate_transition_score(candidate, response, model, roll=roll)
                for candidate in row["candidates"][:2]
            ]
            if any(score is None for score in scores):
                continue
            usable += 1
            wins += int(scores[0]["rms_db"] < scores[1]["rms_db"])  # type: ignore[index]
        output.append({"trial": trial, "rank1_favored_tracks": wins, "scored_tracks": usable})
    return output


def analyze(
    source: dict[str, Any],
    *,
    cutoff_utc_ns: int = OLD_FREEZE_UTC_NS,
    bootstrap_trials: int = 100,
    null_trials: int = 100,
) -> dict[str, Any]:
    if len(source["tracks"]) != EXPECTED_TRACKS:
        raise ValueError(f"frozen track inventory changed: {len(source['tracks'])}")
    starts = _session_starts(source)
    if len(starts) != EXPECTED_COMPLETE_SCANS:
        raise ValueError(f"frozen complete-scan inventory changed: {len(starts)}")
    models, calibration = fit_transition_models(
        source["calibration_points"],
        starts,
        cutoff_utc_ns=cutoff_utc_ns,
        bootstrap_trials=bootstrap_trials,
    )
    time_model = fit_time_trend(source["calibration_points"], starts, cutoff_utc_ns=cutoff_utc_ns)
    level_models, _ = fit_calibration_models(
        source["calibration_points"],
        cutoff_utc_ns=cutoff_utc_ns,
        bootstrap_trials=1,
        session_start_utc_ns=starts,
    )
    rows = [
        score_track(
            row,
            models,
            confirmatory=starts[str(row["session_id"])] >= cutoff_utc_ns,
            level_model=level_models[0],
            time_model=time_model,
        )
        for row in source["tracks"]
    ]
    scored = [row for row in rows if row["state"] == "scored"]
    late = [row for row in scored if row["confirmatory_later_session"]]
    nulls = transition_nulls(source["tracks"], late, models[0], trials=null_trials)
    actual = sum(row["transition"]["ordering"] == "rank1" for row in late)
    nominal_actual = sum(
        row["transition"]["rank1_nominal"]["rms_db"] < row["transition"]["rank2_nominal"]["rms_db"]
        for row in late
    )
    changes = [row for row in late if row["combined_diagnostic"]["candidate_changed_from_doppler"]]
    return {
        "schema": "org.leo.research.dual-lnb-transition-identity/v1",
        "protocol": {
            "retrospective_design_with_implementation_review": True,
            "window_start_utc_ns": source["window_start_utc_ns"],
            "window_end_utc_ns": source["window_end_utc_ns"],
            "calibration_cutoff_utc_ns": cutoff_utc_ns,
            "calibration": (
                "whole early sessions; clear persisted Doppler leaders; "
                "within-pass-and-RF-lane demeaned RX ratio and ENU"
            ),
            "validation": "later sessions; no chronological Doppler review split",
            "decision_use": "conditional corroboration/tiebreak; no independent likelihood product",
        },
        "coverage": {
            "frozen_scan_documents": EXPECTED_COMPLETE_SCANS + EXPECTED_PENDING_SCANS,
            "complete_scans": len(starts),
            "pending_without_source_payload": EXPECTED_PENDING_SCANS,
            "persisted_tracks": len(rows),
            "scored_tracks": len(scored),
            "later_scored_tracks": len(late),
            "unsupported_reasons": dict(Counter(row.get("reason", "scored") for row in rows)),
        },
        "calibration": {**calibration, "candidate_independent_time_trend": time_model},
        "comparisons_later": {
            "doppler_rank1_tracks": len(late),
            "level_geometry_rank1_tracks": sum(
                row["original_level_geometry"]
                and row["original_level_geometry"]["ordering"] == "rank1"
                for row in late
            ),
            "transition_rank1_tracks": actual,
            "transition_rank2_tracks": sum(
                row["transition"]["ordering"] == "rank2" for row in late
            ),
            "transition_uncertain_tracks": sum(
                row["transition"]["ordering"] == "uncertain" for row in late
            ),
            "candidate_geometry_beats_time_trend_tracks": sum(
                row["candidate_independent_time_trend"]["geometry_beats_time_trend"] for row in late
            ),
            "combined_candidate_changes": len(changes),
            "changed_candidates": [
                {
                    "session_id": row["session_id"],
                    "tracklet_id": row["tracklet_id"],
                    "from": row["candidates"][0]["number"],
                    "to": row["candidates"][1]["number"],
                }
                for row in changes
            ],
        },
        "later_circular_shift_nulls": nulls,
        "null_comparison": {
            "actual_nominal_transition_rank1_tracks": nominal_actual,
            "statistic": "nominal model rank1 RMS less than rank2 RMS in both actual and controls",
            "plus_one_upper_tail_fraction": (
                1 + sum(row["rank1_favored_tracks"] >= nominal_actual for row in nulls)
            )
            / (len(nulls) + 1),
            "interpretation": (
                "Circular-wrap sensitivity only. Rolling monotonic sequences creates "
                "discontinuities, so this trial fraction is not a calibrated significance "
                "or false-identification probability; see smooth donor control."
            ),
        },
        "tracks": rows,
        "limitations": [
            "calibration labels are Doppler leaders, not independent identity truth",
            "direction site differs about 1.29 km from the persisted Doppler-review observer site",
            "physical RX-to-LNB mapping, boresight, obstruction, and visibility remain unresolved",
            "missingness/response mismatch alone never rejects Starlink or NORAD identity",
            "Doppler and response share detections; no independent likelihood product",
        ],
    }


def render(output: dict[str, Any], output_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    late = [
        row
        for row in output["tracks"]
        if row["state"] == "scored" and row["confirmatory_later_session"]
    ]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), constrained_layout=True)
    axes[0].scatter(
        [row["doppler"]["rms_ratio_rank2_over_rank1"] for row in late],
        [row["transition"]["runner_minus_rank1_rms_db_q05_median_q95"][1] for row in late],
        s=18,
        alpha=0.6,
    )
    axes[0].axhline(0, color="black", lw=1)
    axes[0].axvline(1.5, color="black", ls="--", lw=1)
    axes[0].set(
        xscale="log",
        xlabel="Doppler RMS ratio (rank 2 / rank 1)",
        ylabel="Transition RMS difference (rank 2 - rank 1), dB",
    )
    null = [row["rank1_favored_tracks"] for row in output["later_circular_shift_nulls"]]
    axes[1].hist(null, bins="auto", color="0.6")
    axes[1].axvline(
        output["null_comparison"]["actual_nominal_transition_rank1_tracks"], color="C1", lw=2
    )
    axes[1].set(xlabel="Later tracks favoring Doppler rank 1", ylabel="Circular-shift trials")
    fig.suptitle("Paired-RX directional transition diagnostic (later sessions)")
    fig.savefig(output_dir / "transition-diagnostic.png", dpi=170)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-trials", type=int, default=100)
    parser.add_argument("--null-trials", type=int, default=100)
    args = parser.parse_args()
    opener = gzip.open if args.input.suffix == ".gz" else open
    with opener(args.input, "rt") as handle:
        source = json.load(handle)
    output = analyze(source, bootstrap_trials=args.bootstrap_trials, null_trials=args.null_trials)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "scoring.json").write_text(
        json.dumps(output, indent=2, allow_nan=False) + "\n"
    )
    render(output, args.output_dir)
    print(
        json.dumps(
            {
                "coverage": output["coverage"],
                "comparisons_later": output["comparisons_later"],
                "null_comparison": output["null_comparison"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

"""Join joint Doppler selections with geometry corroboration, without multiplying evidence."""

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


def summarize(joint, geometry):
    lookup = {(r["session_id"], r["tracklet_id"]): r for r in geometry["tracks"]}
    rows = []
    for pair in joint["results"]:
        best, runner = pair.get("joint_best_number"), pair.get("joint_runner_up_number")
        candidates = {c["number"]: c for c in pair["candidates"] if c["state"] == "scored"}
        b = candidates.get(best, {}).get("joint", {})
        r = candidates.get(runner, {}).get("joint", {})
        supports = []
        later = []
        for side in ("rx0_tracklet_id", "rx1_tracklet_id"):
            g = lookup.get((pair["session_id"], pair[side]), {})
            later.append(bool(g.get("confirmatory_later_session")))
            ids = [c["number"] for c in g.get("candidates", [])]
            if g.get("state") != "scored" or best not in ids or runner not in ids:
                supports.append("unsupported")
                continue
            order = g["transition"]["ordering"]
            if order == "uncertain":
                supports.append("uncertain")
                continue
            winner = ids[0 if order == "rank1" else 1]
            supports.append("supports-joint-leader" if winner == best else "supports-joint-runner")
        definite = {s for s in supports if s.startswith("supports-")}
        outcome = (
            next(iter(definite))
            if len(definite) == 1
            else ("mixed" if definite else "unsupported-or-uncertain")
        )
        rows.append(
            dict(
                session_id=pair["session_id"],
                rx0_tracklet_id=pair["rx0_tracklet_id"],
                rx1_tracklet_id=pair["rx1_tracklet_id"],
                review_agreement=pair["review_agreement"],
                rx0_stored_id=pair.get("rx0_stored_top_id"),
                rx1_stored_id=pair.get("rx1_stored_top_id"),
                joint_best_id=best,
                joint_runner_id=runner,
                joint_best_train_rms_hz=b.get("training_equal_visit_rms_hz"),
                joint_best_evaluation_rms_hz=b.get("evaluation_equal_visit_rms_hz"),
                joint_runner_train_rms_hz=r.get("training_equal_visit_rms_hz"),
                joint_runner_evaluation_rms_hz=r.get("evaluation_equal_visit_rms_hz"),
                shared_tau_s=b.get("tau_s"),
                later_session=all(later),
                rx0_geometry=supports[0],
                rx1_geometry=supports[1],
                geometry_evidence=outcome,
                identity_claimed=False,
                geometry_rejects_candidate=False,
            )
        )
    return {
        "rows": rows,
        "pair_groups": len(rows),
        "geometry_counts": dict(Counter(r["geometry_evidence"] for r in rows)),
        "later_geometry_counts": dict(
            Counter(r["geometry_evidence"] for r in rows if r["later_session"])
        ),
        "policy": (
            "Joint candidate selected on fitting Doppler only. Geometry is conditional "
            "corroboration, not a probability, independent vote, or mismatch veto. "
            "A supportive side is labeled even if the other is unsupported; "
            "inspect per-side columns."
        ),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--joint", type=Path, required=True)
    p.add_argument("--geometry", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    out = summarize(json.loads(a.joint.read_text()), json.loads(a.geometry.read_text()))
    a.output.write_text(json.dumps(out, indent=2) + "\n")
    with a.output.with_suffix(".csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=list(out["rows"][0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(out["rows"])
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}))


if __name__ == "__main__":
    main()

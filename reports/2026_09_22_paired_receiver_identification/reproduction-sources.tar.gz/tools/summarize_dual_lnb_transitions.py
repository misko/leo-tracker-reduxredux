"""Descriptive overlap-response inventory; detection order is not a sky direction."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter
from pathlib import Path

import numpy as np


def summarize(document):
    groups = {}
    for track in document["tracks"]:
        for point in track["pairs"]:
            key = (track["session_id"], point["rx0_tracklet_id"], point["rx1_tracklet_id"])
            points = groups.setdefault(key, {})
            identity = (int(point["visit_index"]), int(point["utc_ns"]))
            if identity in points and points[identity] != point:
                raise ValueError("conflicting duplicate receiver-pair observation")
            points[identity] = point
    rows = []
    for (session, rx0, rx1), points in sorted(groups.items()):
        ordered = sorted(points.values(), key=lambda p: p["utc_ns"])
        y = np.array([p["proxy_db"] for p in ordered], float)
        t = np.array([p["utc_ns"] for p in ordered], dtype=np.int64)
        visits = len(set(p["visit_index"] for p in ordered))
        span = (int(t[-1]) - int(t[0])) / 1e9
        third = max(1, len(y) // 3)
        early, late = float(np.median(y[:third])), float(np.median(y[-third:]))
        status = "insufficient-span-or-visits"
        if visits >= 5 and span >= 5:
            if early > 1 and late < -1:
                status = "rx0-to-rx1-proxy-dominance"
            elif early < -1 and late > 1:
                status = "rx1-to-rx0-proxy-dominance"
            else:
                status = "no-two-sided-proxy-crossover"
        rows.append(
            dict(
                session_id=session,
                rx0_tracklet_id=rx0,
                rx1_tracklet_id=rx1,
                paired_points=len(y),
                distinct_visits=visits,
                overlap_span_s=span,
                first_utc_ns=int(t[0]),
                last_utc_ns=int(t[-1]),
                early_median_proxy_db=early,
                late_median_proxy_db=late,
                proxy_change_db=late - early,
                status=status,
            )
        )
    return dict(
        window_start_utc_ns=document["window_start_utc_ns"],
        window_end_utc_ns=document["window_end_utc_ns"],
        unique_pair_groups=len(rows),
        unique_pair_observations=sum(r["paired_points"] for r in rows),
        counts=dict(Counter(r["status"] for r in rows)),
        interpretation=(
            "GLRT proxy dominance only; not calibrated power, beam centre crossing, "
            "sky direction or NORAD proof; obstruction/gain unknown; no identity rejection"
        ),
        thresholds=dict(minimum_visits=5, minimum_span_s=5, dominance_threshold_db=1),
        rows=rows,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--plot", type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    if args.input.suffix == ".gz":
        raw = gzip.decompress(raw)
    result = summarize(json.loads(raw))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    if args.plot:
        render(result, args.plot)
    print(json.dumps({k: v for k, v in result.items() if k != "rows"}))


def render(result, output):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), layout="constrained")
    groups = [
        ("rx1-to-rx0-proxy-dominance", "RX1 → RX0 proxy crossover", "#117733"),
        ("rx0-to-rx1-proxy-dominance", "RX0 → RX1 proxy crossover", "#332288"),
        ("no-two-sided-proxy-crossover", "No two-sided crossover", "#888888"),
        ("insufficient-span-or-visits", "Insufficient overlap", "#CC6677"),
    ]
    for status, label, color in groups:
        rows = [r for r in result["rows"] if r["status"] == status]
        axes[0].scatter(
            [r["early_median_proxy_db"] for r in rows],
            [r["late_median_proxy_db"] for r in rows],
            s=12,
            alpha=0.6,
            color=color,
            label=f"{label} ({len(rows)})",
        )
        axes[1].scatter(
            [r["overlap_span_s"] for r in rows],
            [r["proxy_change_db"] for r in rows],
            s=12,
            alpha=0.6,
            color=color,
        )
    for boundary in [-1, 1]:
        axes[0].axvline(boundary, color="black", lw=0.7, ls=":")
        axes[0].axhline(boundary, color="black", lw=0.7, ls=":")
    axes[0].set(
        xlabel="First-third median RX0/RX1 proxy (dB)",
        ylabel="Last-third median RX0/RX1 proxy (dB)",
    )
    axes[0].legend(fontsize=8)
    axes[1].set(xlabel="Paired overlap duration (s)", ylabel="Late minus early proxy (dB)")
    axes[1].axhline(0, color="black", lw=0.7)
    for ax in axes:
        ax.grid(alpha=0.2)
    fig.suptitle(
        "Frozen eight-hour paired response transitions\n"
        "One point per receiver-track pair; proxy crossover is not a calibrated sky direction"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    main()

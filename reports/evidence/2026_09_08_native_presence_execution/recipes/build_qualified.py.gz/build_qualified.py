"""Build execution variants locally; read ARM compiler/sysroot, never deploy."""
import json
from pathlib import Path
from tools.native_presence import build_dwell_presence, build_worker
from tools.presence_fftw import fftw_options

root = Path('/tmp/leo-presence-runtime-opt.eAHUlj/qualified')
root.mkdir(exist_ok=False)
protocol = json.loads(Path('config/analysis/arm-presence-native-tone-ci16-v1.json').read_text())
flags = tuple(protocol['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{k}={v}' for k, v in protocol['variants'][0]['defines'].items()
) + ('-DLEO_PRESENCE_DIFFERENTIAL_CI16=1', '-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1')
desktop = fftw_options(Path('/tmp/leo-presence-fftw.nLw4v6/install'))
arm = fftw_options(Path('/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr'), runtime_rpath=False)
compiler = '/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc'
for name, cache, magnitude in [('baseline', 0, 0), ('cache', 1, 0), ('magnitude', 1, 1)]:
    variant = flags + (f'-DLEO_PRESENCE_PRECOMPUTE={cache}', f'-DLEO_PRESENCE_BOUNDED_MAGNITUDE={magnitude}')
    print(build_dwell_presence(root / f'{name}-builtin.so', cflags=variant), flush=True)
    if name == 'baseline':
        continue
    print(build_dwell_presence(root / f'final-{name}.so', cflags=variant+desktop['cflags'],
          ldflags=desktop['ldflags'], dependencies=desktop['dependencies']), flush=True)
    print(build_dwell_presence(root / f'sanitize-{name}', executable=True,
          cflags=variant+('-fsanitize=address,undefined', '-fno-omit-frame-pointer')), flush=True)
    print(build_worker(root / f'worker-{name}-arm', compiler=compiler,
          cflags=variant+('-mcpu=cortex-a9', '-mfpu=neon', '-mfloat-abi=hard')+arm['cflags'],
          ldflags=arm['ldflags'], dependencies=arm['dependencies']), flush=True)

"""Retain bounded numerical execution evidence, never IQ or executable binaries."""
import ctypes as ct
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

import numpy as np

from tools.benchmark_presence_execution import differences, numerical
from tools.presence_dwell import NativeDwell, unpack
from tools.qualify_native_presence import digest, write_json

repo = Path.cwd()
source = Path('/tmp/leo-presence-runtime-opt.eAHUlj')
qualified = source / 'qualified'
out = repo / 'reports/evidence/2026_09_08_native_presence_execution'
out.mkdir(parents=True, exist_ok=False)
artifacts = {}


def retain(path, name, compress=False):
    raw = path.read_bytes()
    destination = out / (name + ('.gz' if compress else ''))
    destination.parent.mkdir(parents=True, exist_ok=True)
    if compress:
        with destination.open('xb') as stream:
            stream.write(gzip.compress(raw, mtime=0))
    else:
        shutil.copyfile(path, destination)
    artifacts[str(destination.relative_to(out))] = dict(
        source=str(path), sha256=digest(destination), original_sha256=hashlib.sha256(raw).hexdigest(),
        original_bytes=len(raw), retained_bytes=destination.stat().st_size)


for name in ('freeze.json', 'summary.json', 'results.json'):
    retain(qualified / 'paired' / name, 'paired/' + name, name == 'results.json')
for name in ('freeze.json', 'summary.json', 'sanitizer-results.json', 'setup-results.json'):
    retain(qualified / 'execution-qualification' / name, 'qualification/' + name,
           name.endswith('results.json'))
for path in sorted(qualified.glob('*.build.json')):
    identity = json.loads(path.read_text())
    binary = qualified / path.name.removesuffix('.build.json')
    assert digest(binary) == identity['binary_sha256']
    for relative, expected in identity['sources_sha256'].items():
        assert digest(repo / relative) == expected, relative
    retain(path, 'builds/' + path.name)
baseline = json.loads((source / 'baseline.so.build.json').read_text())
assert digest(source / 'baseline.so') == baseline['binary_sha256']
for relative, expected in baseline['sources_sha256'].items():
    original = subprocess.check_output(['git', 'show', f'fa467153:{relative}'])
    assert hashlib.sha256(original).hexdigest() == expected, relative
retain(source / 'baseline.so.build.json', 'builds/baseline-original.so.build.json')
for name in ('regression-qualified.xml', 'execution-extrema-fixed-tests.xml'):
    retain(source / name, name)
suite = ET.parse(source / 'regression-qualified.xml').getroot().find('testsuite')
assert (suite.get('tests'), suite.get('errors'), suite.get('failures'), suite.get('skipped')) == ('475', '0', '0', '0')
for name in ('regression.xml', 'execution-extrema-tests.xml'):
    retain(source / name, 'rejected/' + name, True)
for name in ('freeze.json', 'summary.json', 'sanitizer-results.json', 'qualify_execution_rejected.py'):
    retain(source / 'execution-qualification-v2' / name, 'rejected/cross-backend/' + name,
           name.endswith('results.json') or name.endswith('.py'))
for name in ('freeze.json', 'sanitizer-results.json', 'qualify_execution_rejected.py'):
    retain(source / 'execution-qualification' / name, 'rejected/harness/' + name,
           name.endswith('results.json') or name.endswith('.py'))
for name in ('freeze.json', 'summary.json', 'results.json'):
    retain(source / 'paired-final' / name, 'rejected/unrestricted-magnitude/' + name,
           name == 'results.json')
for name in ('build_qualified.py', 'qualify_execution.py', 'save_evidence.py'):
    retain(source / name, 'recipes/' + name)

rows = json.loads((qualified / 'paired/results.json').read_text())
numerical_audit = {}
for name in ('baseline', 'cache', 'magnitude'):
    numerical_audit[name] = dict(
        executions=len(rows), exact_numerical_matches=sum(
            numerical(r['variants'][name]) == numerical(r['variants']['baseline']) for r in rows),
        tolerance_mismatches=sum(bool(r['mismatches'][name]) for r in rows))
assert numerical_audit['cache']['exact_numerical_matches'] == len(rows) == 480
assert all(v['tolerance_mismatches'] == 0 for v in numerical_audit.values())

helpers = Path('/tmp/pytest-of-mouse9911/pytest-current/presence-execution0').resolve()
apis = {name: ct.CDLL(str(helpers / f'{name}-helper.so')) for name in ('baseline', 'cache')}
for api in apis.values():
    api.test_execution_bytes.argtypes = [ct.c_uint32]
    api.test_execution_bytes.restype = ct.c_size_t
allocation = {str(rate): dict(
    changed_allocation_bytes={name: api.test_execution_bytes(rate) for name, api in apis.items()},
    saved_per_edge_bytes=apis['baseline'].test_execution_bytes(rate)-apis['cache'].test_execution_bytes(rate),
) for rate in (2500000, 5000000)}

# Retain the baseline-only cross-backend mismatch, and require both accepted
# variants to match their own backend. No tolerance is relaxed for this input.
stress = []
for rate in (2500000, 5000000):
    for edge in ('lower', 'upper'):
        iq = np.empty((rate // 50 * 6, 2), dtype=np.int16)
        iq[::2], iq[1::2] = [-32768, 32767], [32767, -32768]
        outputs = {}
        for name, path in [('baseline_fftw', source / 'baseline.so'),
                           ('baseline_builtin', qualified / 'baseline-builtin.so'),
                           ('cache_builtin', qualified / 'cache-builtin.so'),
                           ('magnitude_builtin', qualified / 'magnitude-builtin.so'),
                           ('cache_fftw', qualified / 'final-cache.so'),
                           ('magnitude_fftw', qualified / 'final-magnitude.so')]:
            with NativeDwell(path, rate, edge, 512) as native:
                outputs[name] = numerical(unpack(native.run(iq, maximum=6, seeded=False)))
        parity = {name: differences(outputs['baseline_' + name.split('_')[1]], value)
                  for name, value in outputs.items() if not name.startswith('baseline_')}
        assert not any(parity.values()), parity
        stress.append(dict(rate_hz=rate, edge=edge, outputs=outputs, same_backend_mismatches=parity,
                           baseline_cross_backend_mismatches=differences(outputs['baseline_builtin'], outputs['baseline_fftw'])))
write_json(out / 'audit.json', dict(numerical=numerical_audit, allocation=allocation, full_scale_stress=stress))
artifacts['audit.json'] = dict(sha256=digest(out / 'audit.json'))
write_json(out / 'receipt.json', dict(
    scope='offline execution optimization; not ARM timing, detection qualification or live duty',
    implementation_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    baseline_commit=subprocess.check_output(['git', 'rev-parse', 'fa467153'], text=True).strip(),
    checks=dict(regressions=475, focused_execution_tests=51, sanitizer_processes=32,
                sanitizer_dwell_executions=64, sanitizer_confirmations=384,
                saved_distinct_dwells=96, paired_variant_comparisons=960,
                tolerance_mismatches=0, compiler_arm_artifacts=2),
    limits=['RX1 only; unchanged search and IQ', 'precompute default on; bounded magnitude default off',
            'No new RF, deployment, FPGA/kernel/flashed firmware or remote branch changes',
            'ARM host-key verification pending; no ARM execution for these artifacts',
            'Cross-backend fractional timing stress differences remain; tolerances unchanged'],
    commands=dict(
        environment='PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. OPENBLAS_NUM_THREADS=1 FFTW_PREFIX=/tmp/leo-presence-fftw.nLw4v6/install',
        python='/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin/python',
        build=str(source / 'build_qualified.py'), qualification=str(source / 'qualify_execution.py'),
        benchmark='-m tools.benchmark_presence_execution /tmp/leo-native-presence-holdout-v1-20260908 /tmp/leo-presence-runtime-opt.eAHUlj/qualified/paired --library baseline=/tmp/leo-presence-runtime-opt.eAHUlj/baseline.so --library cache=/tmp/leo-presence-runtime-opt.eAHUlj/qualified/final-cache.so --library magnitude=/tmp/leo-presence-runtime-opt.eAHUlj/qualified/final-magnitude.so --repeats 5',
        pytest='-m pytest -q tests/analysis/test_native_presence_execution.py tests/analysis/test_native_presence.py tests/analysis/test_presence_dwell.py tests/analysis/test_native_presence_ci16_fold.py tests/analysis/test_native_presence_ci16_lag.py tests/analysis/test_native_presence_fftw.py tests/analysis/test_native_presence_differential.py tests/scanner/test_native_presence_dwell_worker.py tests/scanner/test_glrt_frame_result.py --junitxml=/tmp/leo-presence-runtime-opt.eAHUlj/regression-qualified.xml'),
    artifacts=artifacts))
print(json.dumps(dict(output=str(out), numerical=numerical_audit, allocation=allocation), indent=2))

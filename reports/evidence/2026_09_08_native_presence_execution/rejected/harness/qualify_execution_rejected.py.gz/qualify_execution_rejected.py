"""Bounded saved/synthetic-IQ sanitizer and C-only setup checks; no radio access."""
import ctypes as ct
import json
import os
from pathlib import Path
import subprocess
import time

import numpy as np

from leo.analysis.starlink.templates import qin_edge_pilot_frame
from tools.benchmark_presence_execution import differences, numerical, digest_bytes
from tools.evaluate_presence_window_rank import load_dwells
from tools.native_presence import array, pointer, write_templates
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_window_rank import write_rank_probe
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_controls import generate

ROOT = Path('/tmp/leo-presence-runtime-opt.eAHUlj')
SOURCE = Path('/tmp/leo-native-presence-holdout-v1-20260908')
OUT = ROOT / 'execution-qualification'


def subset(expected, actual):
    if isinstance(actual, dict):
        return {k: subset(expected[k], v) for k, v in actual.items()}
    if isinstance(actual, list):
        if len(expected) != len(actual):
            raise ValueError('result array length mismatch')
        return [subset(a, b) for a, b in zip(expected, actual, strict=True)]
    return expected


def main():
    OUT.mkdir(exist_ok=False)
    identities = {p.name: digest(p) for p in (
        ROOT / 'baseline.so', ROOT / 'final-cache.so', ROOT / 'final-magnitude.so',
        ROOT / 'sanitize-cache', ROOT / 'sanitize-magnitude',
    )}
    frozen = {
        'scope': 'execution/memory safety only; not detector or live-duty qualification',
        'script_sha256': digest(Path(__file__)), 'artifacts': identities,
        'source': str(SOURCE),
        'source_inputs_sha256': digest(SOURCE / 'inputs.json'),
        'source_results_sha256': digest(SOURCE / 'results.json'),
        'variants': ['cache', 'magnitude'], 'sanitizer_backend': 'builtin FFT',
        'comparison_backend': 'FFTW', 'repeats': 2, 'confirmations': 6,
        'rtol': 1e-9, 'atol': 1e-10, 'setup_repeats': 25,
    }
    write_json(OUT / 'freeze.json', frozen)
    cases = []
    for rate in (2500000, 5000000):
        templates = OUT / f'{rate}.templates'
        write_templates(templates, rate)
        for edge in ('lower', 'upper'):
            signal, _ = generate(rate, edge, 779, 'pilot_plus_tone', 3)
            extrema = np.empty_like(signal)
            extrema[::2] = [-32768, 32767]
            extrema[1::2] = [32767, -32768]
            for kind, iq in [('pilot_plus_tone', signal), ('zero', np.zeros_like(signal)),
                             ('extrema', extrema)]:
                cases.append((rate, edge, kind, iq, 2**64 - 1 - len(iq)))
    seen = set()
    for metadata, iq in load_dwells(SOURCE):
        geometry = metadata['rate_hz'], metadata['edge']
        if geometry not in seen:
            seen.add(geometry)
            cases.append((*geometry, 'saved', iq, 9007199254741011))
        if len(seen) == 4:
            break
    if len(seen) != 4:
        raise ValueError('saved-IQ geometry incomplete')
    runs, errors = [], []
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for rate, edge, kind, iq, counter in cases:
        before = digest_bytes(iq.tobytes())
        probe = OUT / f'{rate}-{edge}-{kind}.rank'
        write_rank_probe(probe, iq, rate, edge, counter)
        for name in ('cache', 'magnitude'):
            with NativeDwell(ROOT / f'final-{name}.so', rate, edge, 512) as native:
                expected = numerical(unpack(native.run(iq, maximum=6, seeded=False)))
                expected_screens = numerical(unpack(native.screens()))
            command = [str(ROOT / f'sanitize-{name}'), str(probe),
                       str(OUT / f'{rate}.templates'), '512', '6', 'blind', '2']
            started = time.monotonic()
            process = subprocess.run(command, capture_output=True, text=True, env=env, timeout=50)
            record = dict(variant=name, rate_hz=rate, edge=edge, kind=kind,
                          counter=str(counter), iq_sha256=before, command=command,
                          returncode=process.returncode, stderr=process.stderr,
                          elapsed_s=time.monotonic()-started, stdout=process.stdout,
                          mismatches=[])
            runs.append(record)
            try:
                if process.returncode or process.stderr:
                    raise ValueError('nonzero exit or sanitizer stderr')
                outputs = [json.loads(line) for line in process.stdout.splitlines()]
                if len(outputs) != 2:
                    raise ValueError('incomplete sanitizer output')
                for iteration, output in enumerate(outputs):
                    if (output['counter'] != str(counter) or output['iteration'] != iteration
                            or output['rate_hz'] != rate or output['edge'] != int(edge == 'upper')
                            or output['confirmation_count'] != 6):
                        raise ValueError('identity or coverage mismatch')
                    actual = numerical({k: v for k, v in output.items() if k in expected})
                    record['mismatches'] += differences(subset(expected, actual), actual)
                    actual_screens = numerical(output['screen_diagnostics'])
                    record['mismatches'] += differences(expected_screens, actual_screens, 'screens')
                if record['mismatches']:
                    raise ValueError('numerical parity mismatch')
                if digest_bytes(iq.tobytes()) != before:
                    raise ValueError('IQ changed')
            except (ValueError, KeyError, TypeError) as exc:
                errors.append(dict(case=f'{rate}-{edge}-{kind}-{name}', error=str(exc)))
            write_json(OUT / 'sanitizer-results.json', dict(runs=runs, errors=errors))
            print(f'{len(runs)}/32 sanitizer processes; {len(errors)} failures', flush=True)
    # Prepare templates and ctypes signatures outside all setup timing intervals.
    setup = []
    for rate in (2500000, 5000000):
        for edge in ('lower', 'upper'):
            exact, control = [array(qin_edge_pilot_frame(rate, edge, symbol_roll=k)) for k in (0, 17)]
            APIs = {}
            for name, path in [('baseline', 'baseline.so'), ('cache', 'final-cache.so'),
                               ('magnitude', 'final-magnitude.so')]:
                with NativeDwell(ROOT / path, rate, edge, 512) as native:
                    APIs[name] = native.library
            for repeat in range(25):
                names = list(APIs) if repeat % 2 == 0 else list(reversed(APIs))
                for name in names:
                    api = APIs[name]
                    cpu, wall = time.process_time_ns(), time.perf_counter_ns()
                    workspace = api.leo_presence_dwell_create(
                        rate, pointer(exact), pointer(control), len(exact), 512)
                    cpu_ms = (time.process_time_ns() - cpu) / 1e6
                    wall_ms = (time.perf_counter_ns() - wall) / 1e6
                    if not workspace:
                        raise ValueError('setup failed')
                    api.leo_presence_dwell_destroy(ct.c_void_p(workspace))
                    setup.append(dict(variant=name, rate_hz=rate, edge=edge, repeat=repeat,
                                      cpu_ms=cpu_ms, wall_ms=wall_ms))
    write_json(OUT / 'setup-results.json', setup)
    if identities != {name: digest(ROOT / name) for name in identities}:
        raise ValueError('artifact changed during execution')
    if frozen['script_sha256'] != digest(Path(__file__)):
        raise ValueError('script changed during execution')
    summary = dict(sanitizer_processes=len(runs), sanitizer_errors=errors,
                   successful_dwell_executions=(len(runs)-len(errors))*2,
                   setup_scope='C create call after template preparation; warm process/allocator; destroy excluded',
                   setup_cpu_p50_ms={})
    for rate in (2500000, 5000000):
        summary['setup_cpu_p50_ms'][str(rate)] = {
            name: float(np.median([r['cpu_ms'] for r in setup
                                   if r['rate_hz'] == rate and r['variant'] == name]))
            for name in ('baseline', 'cache', 'magnitude')}
    write_json(OUT / 'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

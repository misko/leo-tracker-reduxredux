"""Archive bounded non-IQ test evidence and exact implementation identities."""

from __future__ import annotations

import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

RAW = Path(__file__).parent
LEO = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
PPU = Path("/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host")
LIBIIO = Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration")
DEST = LEO / "reports/evidence/2026_09_09_adaptive_recording"
FILES = (
    "src/leo/radio/adaptive_hop_mapping.py",
    "src/leo/scanner/adaptive_hop.py",
    "src/leo/scanner/adaptive_hop_application.py",
    "src/leo/scanner/adaptive_hop_ports.py",
    "src/leo/storage/adaptive_hop.py",
    "src/leo/storage/adaptive_hop_capture.py",
    "src/leo/storage/adaptive_hop_queue.py",
    "tests/scanner/adaptive_hop_fixtures.py",
    "tests/scanner/test_adaptive_hop_contracts.py",
    "tests/scanner/test_adaptive_hop_application.py",
    "tests/storage/test_adaptive_hop_store.py",
    "tests/storage/test_adaptive_hop_queue.py",
    "tests/radio/test_adaptive_hop_network.py",
)


def sha(payload):
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def run(cwd, command):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=60)
    return dict(command=command, cwd=str(cwd), returncode=result.returncode,
                stdout=result.stdout, stderr=result.stderr)


def main():
    final_names = ("leo-merged-main.xml", "ppu-merged-main.xml", "network-release-candidate.xml")
    for name in final_names:
        suite = ET.parse(RAW / name).getroot().find("testsuite")
        assert suite is not None and int(suite.attrib["failures"]) == 0 and int(suite.attrib["errors"]) == 0, name
    DEST.mkdir(parents=True, exist_ok=False)
    records = []
    for path in sorted(RAW.iterdir()):
        if path.suffix not in (".xml", ".py"):
            continue
        payload = path.read_bytes()
        assert len(payload) < 8 * 1024 * 1024
        compressed = gzip.compress(payload, mtime=0)
        target = DEST / (path.name + ".gz")
        target.write_bytes(compressed)
        record = dict(path=target.name, bytes=len(payload), sha256=sha(payload), compressed_sha256=sha(compressed))
        if path.suffix == ".xml":
            suite = ET.fromstring(payload).find("testsuite")
            record["suite"] = dict(suite.attrib)
            record["cases"] = [dict(name=case.attrib["name"], time=case.attrib.get("time"),
                properties={p.attrib["name"]: p.attrib["value"] for p in case.findall("properties/property")})
                for case in suite.findall("testcase") if case.find("properties") is not None]
        records.append(record)
    commands = []
    for root in (LEO, PPU, LIBIIO):
        for command in (["git", "status", "--short"], ["git", "rev-parse", "HEAD"],
                        ["git", "diff", "--check"]):
            commands.append(run(root, command))
    venv = Path("/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin")
    commands.append(run(LEO, [str(venv / "ruff"), "check", *FILES]))
    commands.append(run(LEO, [str(venv / "python"), "-m", "mypy", "--python-version=3.12",
                             "--follow-imports=silent", *[p for p in FILES if p.startswith("src/")]]))
    commands.append(run(PPU, [str(venv / "ruff"), "check", "src/pluto_plus/adaptive_hop_client.py", "tests/test_iio_adaptive_hop.py"]))
    commands.append(run(PPU, [str(venv / "python"), "-m", "mypy", "--python-version=3.12", "--follow-imports=silent", "--strict", "src/pluto_plus/adaptive_hop_client.py"]))
    assert all(record["returncode"] == 0 for record in commands), commands
    source_hashes = {"leo:" + name: sha((LEO / name).read_bytes()) for name in FILES}
    source_hashes.update({"ppu:" + name: sha((PPU / name).read_bytes()) for name in (
        "src/pluto_plus/adaptive_hop_client.py", "tests/test_iio_adaptive_hop.py")})
    server = Path("/tmp/leo-adaptive-provider.nZDbhN/adaptive-positive/iiod/test_scanner_glrt_network_server")
    index = dict(schema_version=1, scope="offline adaptive contracts, capture/storage, TCP mapping and early cancellation",
                 excludes=["live RF", "ARM throughput qualification", "detector sensitivity qualification", "production deployment"],
                 final_receipts=final_names, artifacts=records, source_hashes=source_hashes,
                 commands=commands, server=dict(path=str(server), sha256=sha(server.read_bytes())))
    (DEST / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    print(json.dumps({"evidence":str(DEST), "artifacts":len(records), "final_receipts":final_names}))


if __name__ == "__main__":
    main()

"""Verify installed canary host paths through release/public PPU ports; no radio."""
import dataclasses
import hashlib
import inspect
import json
from pathlib import Path
import runpy
import sys

repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
release = Path(sys.prefix).parent
metadata = runpy.run_path(str(repo / "deploy/scripts/validate-release-metadata"))
paths = metadata["_metadata_runtime_inventory"](release, expected_profile="scanner-glrt")
published = runpy.run_path(str(repo / "deploy/scripts/validate-published-release"))
# Actual isolated subprocess, with ambient loader overrides scrubbed by the
# existing published-release validator. No root sealing/deployment is claimed.
published["validate_metadata_runtime"](Path(sys.executable))
from pluto_plus.hardware.preflight import verify_metadata_runtime

runtime = verify_metadata_runtime(expected_abi=3)
import iio

assert runtime.source_commit == metadata["SCANNER_GLRT_LIBIIO_SOURCE_COMMIT"]
assert runtime.native_libiio_sha256 == "a09b77cf0c0101204163abae8c90a6abc170199ee61836c5133dc3194569df3e"
methods = {}
for name in ("cancel_metadata_session", "metadata_status_raw", "drain_metadata"):
    methods[name] = str(inspect.signature(getattr(iio.MetadataBuffer, name)))
output = dict(passed=True, radio_accessed=False, scope="real installed canary host runtime, not root-sealed production release",
              runtime=dataclasses.asdict(runtime), methods=methods,
              release_inventory=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths])
with (Path(__file__).parent / "installed-host.json").open("x") as stream:
    json.dump(output, stream, indent=2)
    stream.write("\n")
print(json.dumps(output, indent=2))

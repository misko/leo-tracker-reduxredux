"""Archive explicit non-secret test, implementation and reconciliation evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
destination = repo / "reports/evidence/2026_09_09_scanner_release_runtime"
destination.mkdir(parents=True, exist_ok=False)
files = [(root / name, name) for name in (
    "before.xml", "metadata-after.xml", "deploy-after.xml", "deploy-all.xml",
    "ppu-main-reconciliation.xml", "verify_installed_host.py", "installed-host.json",
    "archive_checkpoint.py")]
files.extend((repo / name, "source/" + name) for name in (
    "deploy/scripts/stage-production-release", "deploy/scripts/validate-release-metadata",
    "tests/deploy/test_release_metadata.py", "tests/deploy/test_scanner_runtime_staging.py"))
artifacts = []
tests = []
for source, relative in files:
    assert source.is_file() and not source.is_symlink()
    raw = source.read_bytes()
    if source.suffix == ".xml":
        suites = list(ET.fromstring(raw).iter("testsuite"))
        counts = {key: sum(int(s.get(key, "0")) for s in suites)
                  for key in ("tests", "failures", "errors", "skipped")}
        assert not counts["errors"] and not counts["skipped"]
        if source.name == "before.xml":
            assert counts["failures"] == 5
        else:
            assert not counts["failures"]
        tests.append(dict(source=relative, **counts))
    compressed = gzip.compress(raw, mtime=0)
    archive = destination / (relative + ".gz")
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open("xb") as stream:
        stream.write(compressed)
    artifacts.append(dict(source=str(source), archive=str(archive.relative_to(destination)),
                          bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                          archive_sha256=hashlib.sha256(compressed).hexdigest()))
repositories = {}
for name, path, remote in (
    ("leo", repo, "origin/main"),
    ("ppu", Path("/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host"), "origin/main"),
    ("libiio", Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration"), "origin/master")):
    def git(*args):
        return subprocess.check_output(("git", "-C", str(path), *args), text=True).strip()
    repositories[name] = dict(head=git("rev-parse", "HEAD"), remote_ref=remote,
                              remote_revision=git("rev-parse", remote), status=git("status", "--short"))
document = dict(schema="org.leo.research.scanner-release-runtime-checkpoint/v1",
                artifacts=artifacts, tests=tests, repositories=repositories,
                radio_accessed=False, production_changed=False, remote_pushed=False,
                full_release_staging_executed=False,
                warning="Focused test runs overlap deploy-all; do not sum them as independent checks")
with (destination / "index.json").open("x") as stream:
    json.dump(document, stream, indent=2)
    stream.write("\n")
for item in artifacts:
    compressed = (destination / item["archive"]).read_bytes()
    assert hashlib.sha256(compressed).hexdigest() == item["archive_sha256"]
    assert hashlib.sha256(gzip.decompress(compressed)).hexdigest() == item["sha256"]
print(json.dumps(dict(archives=len(artifacts), tests=tests), indent=2))

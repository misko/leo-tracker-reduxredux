"""ASan/UBSan provider+SDK check; numerical worker/FFTW are not instrumented."""
import json
import os
import subprocess
from pathlib import Path

from tools.native_presence import build_scanner_glrt_port

out = Path(__file__).parent
flags = ('-fsanitize=address,undefined', '-fno-omit-frame-pointer')
sdk = build_scanner_glrt_port(out / 'sdk-sanitized.so', cflags=flags)
receipt = json.loads((out / 'positive-only-v1-protection-ON-configure-pressure-injection.json').read_text())
command = list(receipt['command'])
build = out / 'sanitized'
command[command.index('-B') + 1] = str(build)
command = [f'-DIIOD_SCANNER_GLRT_LIBRARY={sdk}' if arg.startswith('-DIIOD_SCANNER_GLRT_LIBRARY=')
           else arg for arg in command]
command += ['-DCMAKE_C_FLAGS=' + ' '.join(flags),
            '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
env = os.environ.copy()
env.update(ASAN_OPTIONS='detect_leaks=1:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
for rate in (2500000, 5000000):
    for edge in ('lower', 'upper'):
        env[f'SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}'] = str(out / f'synthetic-pilot-{rate}-{edge}.ci16')
for stage, cmd in (
    ('configure', command),
    ('compile', ['cmake', '--build', str(build), '--target', 'test_scanner_glrt_provider', '-j', '2']),
    ('provider', [str(build / 'iiod/test_scanner_glrt_provider')]),
):
    run = subprocess.run(cmd, capture_output=True, text=True, timeout=180, env=env)
    result = dict(stage=stage, command=cmd, status=run.returncode,
                  stdout=run.stdout, stderr=run.stderr,
                  sanitizer_scope='SDK and provider; not numerical worker or FFTW')
    (out / f'sanitized-{stage}.json').write_text(json.dumps(result, indent=2) + '\n')
    print(stage, run.returncode, flush=True)
    if run.returncode:
        print(run.stdout[-6000:], run.stderr[-6000:])
        raise SystemExit(run.returncode)

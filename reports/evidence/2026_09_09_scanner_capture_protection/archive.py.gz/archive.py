"""Publish hash-checked build/test receipts only; never radio IQ or credentials."""
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
raw = Path(__file__).parent
target = root / 'reports/evidence/2026_09_09_scanner_capture_protection'
target.mkdir(parents=True, exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expected = {'sdk-policy-tests.xml': 637, 'contracts-host-tests.xml': 241,
            'provider-config-tests.xml': 23, 'protected-network-tests.xml': 16}
for name, count in expected.items():
    suites = ET.parse(raw / name).getroot().findall('testsuite')
    assert sum(int(s.attrib['tests']) for s in suites) == count
    assert all(int(s.attrib[k]) == 0 for s in suites for k in ('errors', 'failures', 'skipped'))
for name in ('sdk.so', 'worker', 'libleo-scanner-glrt-arm.so', 'sdk-sanitized.so'):
    receipt = json.loads((raw / f'{name}.build.json').read_text())
    assert sha(raw / name) == receipt['binary_sha256']
    for source, digest in receipt['sources_sha256'].items():
        assert sha(root / source) == digest, source
build = json.loads((raw / 'build-results.json').read_text())
assert len(build['receipts']) == 12 and all(r['status'] == 0 for r in build['receipts'])
for source, digest in build['sources_sha256'].items():
    # Documentation appended after qualification does not affect a binary.
    if not source.endswith('.md'):
        assert sha(Path(source)) == digest, source
for stage in ('configure', 'compile', 'provider'):
    assert json.loads((raw / f'sanitized-{stage}.json').read_text())['status'] == 0

artifacts = []
for path in sorted([*raw.glob('*.json'), *raw.glob('*.xml'), *raw.glob('*.py')]):
    data = path.read_bytes()
    destination = target / (path.name + '.gz')
    with destination.open('xb') as stream:
        stream.write(gzip.compress(data, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == data
    artifacts.append({'source_name': path.name, 'file': destination.name,
                      'source_sha256': hashlib.sha256(data).hexdigest(),
                      'compressed_sha256': sha(destination), 'source_bytes': len(data)})
state = {}
for name, repo in (
    ('leo', root),
    ('libiio', Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')),
    ('ppu', Path('/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host')),
):
    state[name] = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
                   'status': subprocess.check_output(['git', 'status', '--short'], cwd=repo, text=True)}
index = {'schema': 'org.leo.research.capture-protection-evidence/v1',
         'scope': 'Desktop SDK/provider/synthetic TCP tests and ARM SDK cross-build; no RF or deployment',
         'tests': expected, 'state_before_checkpoint_commit': state, 'artifacts': artifacts}
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'artifacts': len(artifacts), 'tests': expected, 'directory': str(target)}))

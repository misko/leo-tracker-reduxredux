"""Bounded desktop userspace qualification; no RF, install or external mutation."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from tools.native_presence import ROOT, build_scanner_glrt_port, build_worker, write_templates
from tools.qualify_presence_dwell_controls import generate

out = Path(__file__).parent
libiio = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
spf = Path('/home/mouse9911/gits/plutosdr-fw-metadata-gain-timeline-v8')
config = json.loads((ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json').read_text())
flags = tuple(config['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
) + tuple(f'-DLEO_PRESENCE_{name}=1' for name in (
    'DIFFERENTIAL_CI16', 'RANK_HYBRID_PROJECTION', 'RANK_AMPLITUDE_WEIGHTED',
    'GLRT_SYMBOL_DIVERSITY', 'BOUNDED_MAGNITUDE', 'CONDITIONED_BLOCK_ROTATION',
    'ENERGY_SUPPORT', 'ENERGY_SYMBOL_SUPPORT',
))
sdk, worker = out / 'sdk.so', out / 'worker'
suffix = next((arg.split('=', 1)[1] for arg in sys.argv if arg.startswith('--label=')),
              '-retry' if '--resume' in sys.argv else '')
if suffix:
    for artifact in (sdk, worker):
        receipt = json.loads(artifact.with_name(artifact.name + '.build.json').read_text())
        assert hashlib.sha256(artifact.read_bytes()).hexdigest() == receipt['binary_sha256']
        for name, sha in receipt['sources_sha256'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
else:
    build_scanner_glrt_port(sdk)
    build_worker(worker, cflags=flags)
    worker.chmod(0o755)
fixture_env = os.environ.copy()
for rate in (2500000, 5000000):
    path = out / f'templates-{rate}'
    if not suffix:
        write_templates(path, rate)
        path.chmod(0o600)
    for edge in ('lower', 'upper'):
        pilot, _ = generate(rate, edge, 91, 'pilot', 4)
        path = out / f'synthetic-pilot-{rate}-{edge}.ci16'
        if path.exists():
            assert path.read_bytes() == pilot.tobytes()
        else:
            path.write_bytes(pilot.tobytes())
        fixture_env[f'SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}'] = str(path)
extra = [libiio / 'iiod/spf-tandem-session.c', libiio / 'iiod/spf-tandem-metadata.c']
extra += [spf / name for name in (
    'spf_gain_read.c', 'spf_gain_sampler.c', 'spf_rssi_read.c',
    'spf_radio_frame_v3.c', 'spf_thread_join.c'
)]

def source_hashes():
    paths = [libiio / name for name in subprocess.check_output(
        ['git', 'ls-files'], cwd=libiio, text=True).splitlines()]
    paths += [p for p in spf.iterdir() if p.suffix in ('.c', '.h')]
    paths += [Path(__file__)]
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in paths if p.is_file()}

before = source_hashes()
common = [
    'cmake', '-S', str(libiio), '-DCMAKE_BUILD_TYPE=Debug', '-DWITH_TESTS=ON',
    '-DWITH_IIOD=ON', '-DWITH_XML_BACKEND=ON', '-DWITH_NETWORK_BACKEND=ON',
    '-DWITH_LOCAL_BACKEND=ON', '-DWITH_USB_BACKEND=OFF', '-DWITH_SERIAL_BACKEND=OFF',
    '-DWITH_AIO=OFF', '-DWITH_ZSTD=OFF', '-DWITH_IIOD_SERIAL=OFF', '-DWITH_IIOD_USBD=OFF',
    '-DWITH_DOC=OFF', '-DWITH_MAN=OFF', '-DWITH_SYSTEMD=OFF', '-DHAVE_DNS_SD=OFF',
    f'-DIIOD_BUFFER_METADATA_PROVIDER={libiio}/iiod/spf-buffer-metadata.c',
    f'-DIIOD_BUFFER_METADATA_INCLUDE_DIRS={spf};/home/mouse9911/gits/plutosdr-fw/linux/usr/include',
    '-DIIOD_BUFFER_METADATA_PROVIDER_EXTRA_SOURCES=' + ';'.join(map(str, extra)),
    f'-DIIOD_BUFFER_PERSISTENT_HOP_DEVICE_PROVIDER={libiio}/iiod/spf-hop-device-userspace.c',
    f'-DIIOD_SCANNER_GLRT_LIBRARY={sdk}',
    f'-DIIOD_SCANNER_GLRT_INCLUDE_DIR={ROOT}/src/leo/scanner/native_presence',
    f'-DIIOD_SCANNER_GLRT_WORKER_PATH={worker}',
    f'-DIIOD_SCANNER_GLRT_TEMPLATES_2500000={out}/templates-2500000',
    f'-DIIOD_SCANNER_GLRT_TEMPLATES_5000000={out}/templates-5000000',
    '-DIIOD_SCANNER_GLRT_ALGORITHM_SHA256=' + '12' * 32,
    '-DIIOD_SCANNER_GLRT_CONFIGURATION_SHA256=' + '34' * 32,
]
receipts = []
for mode in ('unqualified-evidence', 'positive-only-v1'):
    for protection in ('OFF', 'ON'):
        label = f'{mode}-protection-{protection}'
        build = out / label
        command = common + ['-B', str(build), f'-DIIOD_SCANNER_GLRT_MODE={mode}',
                           f'-DIIOD_SCANNER_GLRT_CAPTURE_PROTECTION={protection}']
        if mode == 'positive-only-v1':
            command += ['-DIIOD_SCANNER_GLRT_MINIMUM_EXACT_SCORE=0.175',
                        '-DIIOD_SCANNER_GLRT_MINIMUM_MARGIN=0.025',
                        '-DIIOD_SCANNER_ADAPTIVE_HOP=ON']
        for stage, cmd in (
            ('configure', command),
            ('compile', ['cmake', '--build', str(build), '--target', 'iiod',
                         'test_scanner_glrt_provider', 'test_scanner_glrt_network_server', '-j', '2']),
            ('provider', [str(build / 'iiod/test_scanner_glrt_provider')]),
        ):
            run = subprocess.run(cmd, capture_output=True, text=True, timeout=180, env=fixture_env)
            receipt = dict(label=label, stage=stage, command=cmd, status=run.returncode,
                           stdout=run.stdout, stderr=run.stderr)
            (out / f'{label}-{stage}{suffix}.json').write_text(json.dumps(receipt, indent=2) + '\n')
            receipts.append(receipt)
            print(label, stage, run.returncode, flush=True)
            if run.returncode:
                print(run.stdout[-6000:], run.stderr[-6000:])
                raise SystemExit(run.returncode)
assert before == source_hashes(), 'provider or fixture sources changed during qualification'
(out / 'build-results.json').write_text(json.dumps({
    'receipts': receipts, 'sources_sha256': before,
    'sdk_sha256': hashlib.sha256(sdk.read_bytes()).hexdigest(),
    'worker_sha256': hashlib.sha256(worker.read_bytes()).hexdigest(),
}, indent=2) + '\n')

"""Audit and describe the frozen RF split; no new scoring or tuning."""
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from tools.evaluate_native_presence_budgets import associated
from tools.evaluate_presence_dwell_holdout import compare, summarize, validate
from tools.native_presence import ROOT
from tools.presence_decision_challenge import passing
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
source = root / 'evaluation'
out = ROOT / 'reports/evidence/2026_09_09_scanner_rf_dwell_holdout'
figures = ROOT / 'reports/figures/2026_09_09_scanner_rf_dwell_holdout'
assert not out.exists() and not figures.exists()
freeze = json.loads((source / 'freeze.json').read_text())
protocol = freeze['protocol']
indices = validate(protocol)
rows = [json.loads(line) for line in (source / 'results.jsonl').read_text().splitlines()]
expected = [(s['session_id'], i) for s in protocol['sessions'] for i in indices]
assert [(r['session_id'], r['visit']) for r in rows] == expected
assert summarize(rows) == json.loads((source / 'summary.json').read_text())
assert digest(ROOT / 'config/analysis/arm-presence-dwell-rf-holdout-v1.json') == freeze['protocol_sha256']
assert digest(ROOT / protocol['detector_protocol']) == freeze['detector_protocol_sha256']
assert digest(source / 'native.so') == freeze['library_sha256']
for name, sha in {**freeze['reference_sources_sha256'], **freeze['build']['sources_sha256']}.items():
    assert digest(ROOT / name) == sha, name
suite = ET.parse(root / 'tests.xml').getroot().find('testsuite')
assert all(suite.attrib[k] == '0' for k in ('errors','failures','skipped'))
derived = []
for row in rows:
    assert row['rx'] == 1 and row['manifest_sha256'] == freeze['source_manifests'][row['session_id']]
    iq = source / row['iq_file']
    assert iq.parent == source and iq.stat().st_size == row['rate_hz'] * 120 // 1000 * 4
    assert digest(iq) == row['iq_sha256']
    assert compare(row['native'], row['reference'], row['rate_hz'], protocol) == row['comparison']
    confirmation = row['native']['confirmations'][0]
    candidates = passing(confirmation['candidates'][:confirmation['candidate_count']], protocol['policy'])
    window = row['comparison']['selected_window']
    matches = []
    for other, reference in enumerate(row['reference']):
        for candidate in candidates:
            for ref in reference:
                if ref['margin'] < protocol['reference_margin']:
                    continue
                # Only within-dwell local epochs become floats, never counters.
                actual = dict(candidate, epoch=candidate['epoch'] + window * row['rate_hz']//50)
                expected_ref = dict(ref, epoch_sample=ref['epoch_sample'] + other * row['rate_hz']//50)
                if associated(actual, expected_ref, row['rate_hz'], protocol['association']):
                    matches.append(other)
    derived.append(dict(session_id=row['session_id'], visit=row['visit'], rate_hz=row['rate_hz'],
        **row['comparison'], matched_within_dwell=bool(matches), matched_windows=sorted(set(matches))))

groups = {}
for rate in (2500000,5000000):
    part = [r for r in derived if r['rate_hz'] == rate]
    groups[str(rate)] = dict(dwells=len(part), reference_supported=sum(r['reference_any'] for r in part),
        flag_on_reference=sum(r['reference_any'] and r['detected'] for r in part),
        within_dwell_association=sum(r['matched_within_dwell'] for r in part),
        same_window_association=sum(r['matched_selected'] for r in part),
        flags_without_reference=sum(r['detected'] and not r['reference_any'] for r in part),
        unassociated_flags=sum(r['detected'] and not r['matched_within_dwell'] for r in part),
        evaluated_misses=sum(r['evaluated_miss_on_reference'] for r in part),
        unknowns_on_reference=sum(r['unknown_on_reference'] for r in part))
out.mkdir()
figures.mkdir()
write_json(out / 'derived.json', dict(groups=groups, rows=derived,
    interpretation='Within-dwell associations are additional descriptive checks at the existing 8 kHz / 2 us bounds; not IDs or independent truth.'))

fig, axes = plt.subplots(1, 2, figsize=(11,4.5), sharey=True, layout='constrained')
for ax, rate in zip(axes, (2500000,5000000), strict=True):
    g = groups[str(rate)]
    keys = ['reference_supported','flag_on_reference','within_dwell_association','same_window_association']
    values = [g[k] for k in keys]
    bars = ax.bar(range(4), values, color=['#777777','#24758e','#408774','#83aea1'])
    ax.bar_label(bars, padding=3)
    ax.set_xticks(range(4), ['Full GLRT\nsupport','Lightweight\nflag','Association\nany slice','Association\nsame slice'], fontsize=9)
    ax.set_title(f'{rate/1e6:g} MS/s: 96 previously unopened dwells')
    ax.set_ylim(0,100)
    ax.grid(axis='y', alpha=.15)
axes[0].set_ylabel('Number of 120 ms dwells')
fig.suptitle('Frozen saved-RF holdout: one RX, one ranked confirmation\nA flag is not necessarily an association; reference-negative RF is unresolved', fontsize=12)
quality = figures / 'reference-relative-quality.png'
fig.savefig(quality,dpi=160)
plt.close(fig)

failures = [r for r in rows if r['comparison']['reference_any'] and not r['comparison']['detected']]
fig, ax = plt.subplots(figsize=(10,4), layout='constrained')
for i, row in enumerate(failures):
    refs = row['comparison']['reference_windows']
    ax.scatter([k*20+10 for k in refs], [i]*len(refs), color='#408774', s=100, marker='s',
               label='Full GLRT support' if i == 0 else None)
    ax.scatter([row['comparison']['selected_window']*20+10], [i], color='#a63535', s=110, marker='x',
               label='Lightweight selected slice' if i == 0 else None)
labels = [f"{r['rate_hz']/1e6:g} MS/s · {r['session_id'][-4:]} · visit {r['visit']} · "
          + ('unknown' if r['comparison']['outcome'] == 0 else 'evaluated miss') for r in failures]
ax.set_yticks(range(len(failures)), labels, fontsize=9)
ax.set_xticks(range(0,121,20))
ax.set_xlim(0,120)
ax.set_ylim(-.8,len(failures)-.2)
ax.grid(alpha=.15)
ax.set_xlabel('Time within the original 120 ms dwell (ms; markers at slice centres)')
ax.legend(loc='upper center',bbox_to_anchor=(.5,1.19),ncols=2,fontsize=9)
fig.suptitle('The six reference-supported dwells without a lightweight flag\nFive evaluated misses select another slice; one fractional result remains unknown',fontsize=12)
failure = figures / 'missed-dwell-window-selection.png'
fig.savefig(failure,dpi=160)
plt.close(fig)

artifacts = {}
selected = [root/'analyze.py', root/'tests.xml', source/'freeze.json', source/'results.jsonl',
            source/'summary.json', source/'native.so.build.json']
for path in selected:
    relative = str(path.relative_to(root)) + '.gz'
    target = out / relative
    target.parent.mkdir(exist_ok=True,parents=True)
    data = path.read_bytes()
    with target.open('xb') as stream:
        stream.write(gzip.compress(data,compresslevel=9,mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    artifacts[relative] = dict(sha256=digest(target), original_sha256=digest(path), original_bytes=len(data))
write_json(out/'index.json',dict(schema='org.leo.research.scanner-rf-dwell-holdout-evidence/v1',
    artifacts=artifacts, original_iq_retained_at=str(source), original_iq_files=192,
    original_iq_committed=False, new_rf=False, thresholds_changed=False,
    figures=[dict(path=str(p.relative_to(ROOT)),sha256=digest(p)) for p in (quality,failure)],
    derived_sha256=digest(out/'derived.json'), tests=int(suite.attrib['tests']),
    freeze_state=freeze['state'], runtime_qualification=False, satellite_truth=False))
print(json.dumps(groups,indent=2))

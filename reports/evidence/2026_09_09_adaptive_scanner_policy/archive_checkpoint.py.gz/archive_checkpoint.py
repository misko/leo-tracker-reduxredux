"""Retain compact generated evidence; no IQ, executables or radio operations."""
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

raw = Path(__file__).parent
leo = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
repos = {
    'leo': leo,
    'libiio': Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration'),
    'ppu': Path('/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host'),
}
destination = leo / 'reports/evidence/2026_09_09_adaptive_scanner_policy'
destination.mkdir(parents=True, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
artifacts = {}
for source in sorted([*raw.glob('*.json'), *raw.glob('*.xml'), *raw.glob('*.py')]):
    data = source.read_bytes()
    name = source.name + '.gz'
    target = destination / name
    target.write_bytes(gzip.compress(data, mtime=0))
    artifacts[name] = dict(sha256=sha(target), original_sha256=sha(source), original_bytes=len(data))
tests = {}
for name in ('portable-final.xml', 'all-native-variants.xml', 'positive-native-host.xml',
             'network-unqualified-evidence.xml', 'network-positive-only-v1.xml',
             'configure.xml', 'configure-fixed.xml', 'web.xml', 'ppu.xml'):
    root = ET.parse(raw / name).getroot()
    suites = [root] if root.tag == 'testsuite' else list(root.findall('testsuite'))
    tests[name] = {k: sum(int(s.get(k, '0')) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
for artifact in (raw / 'sdk.so', raw / 'worker'):
    built = json.loads(artifact.with_name(artifact.name + '.build.json').read_text())
    assert sha(artifact) == built['binary_sha256']
    for name, expected in built['sources_sha256'].items():
        assert sha(leo / name) == expected, name
revisions = {name: subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
             for name, repo in repos.items()}
receipt = {
    'scope': 'Implemented policy and positive-only transport, adaptive hopping/deployment incomplete',
    'date_utc': '2026-09-09', 'revisions': revisions, 'tests': tests,
    'binary_sha256': {name: sha(raw / name) for name in ('sdk.so', 'worker', 'adaptive-asan', 'adaptive-arm')},
    'provider_sha256': {mode: sha(raw / mode / 'iiod/test_scanner_glrt_provider')
                        for mode in ('unqualified-evidence', 'positive-only-v1')},
    'network_server_sha256': {mode: sha(raw / mode / 'iiod/test_scanner_glrt_network_server')
                              for mode in ('unqualified-evidence', 'positive-only-v1')},
    'sanitizer_observed_result': {'rates': 2, 'activity_masks': 256, 'choices': 1280000,
                                'exit_status': 0, 'diagnostics': []},
    'arm': 'cross-compiled only; no target execution or radio access',
    'rf_collected': False, 'deployed': False, 'remotely_merged': False,
    'limitations': [
        'Positive-policy thresholds are wired but not newly independently scientifically qualified.',
        'Actual positive signals through SDK/PPU and zero-RX1 loopback transport are separate lanes.',
        'Full network spans use accelerated synthetic counters, not 300 seconds of live RF or ARM load.',
        'Adaptive policy is not yet connected to versioned hop execution or recording contracts.',
        'No live duty/IRQ/network workload, adaptive trajectory benefit or deployment pass is claimed.',
        'Build receipts retain missing optional Avahi, exact SDK link correction and invalid configure fixture attempts.',
        'Existing web canvas, chunk-size and dependency deprecation warnings remain visible.',
    ],
    'artifacts': artifacts,
}
(destination / 'index.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'destination': str(destination), 'artifacts': len(artifacts), 'tests': tests, 'revisions': revisions}, indent=2))

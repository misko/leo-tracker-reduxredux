"""Audit exact protected package and preserve non-payload/non-secret evidence."""
import gzip
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

from pluto_plus.userspace_iiod_bundle import load_iiod_companion_bundle
from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_shadow import verify

root = Path(__file__).parent
out = ROOT / 'reports/evidence/2026_09_09_scanner_protected_package'
assert not out.exists()
release = root / 'release'
receipt = json.loads((root / 'receipt.json').read_text())
bundle = load_iiod_companion_bundle(release / 'bundle.json')
assert digest(release / 'iiod') == bundle.daemon_sha256
assert bundle.manifest_sha256 == receipt['manifest_sha256']
for field in ('build_inputs','libiio_sources'):
    for path, expected in receipt[field].items():
        assert digest(Path(path)) == expected, path
for name in ('algorithm','configuration'):
    assert digest(release / f'{name}.json') == receipt[f'{name}_sha256']
end = json.loads((root / 'arm-check/end.json').read_text())
assert end == dict(scratch_retained=None,daemon_retained=False,bundle_retained=False,
                  cleanup_errors=[],credentials_removed=True,recipe_unchanged=True)
freeze = json.loads((root / 'arm-check/freeze.json').read_text())
assert digest(root / 'run_package_arm.py') == freeze['recipe_sha256']
summary = json.loads((root / 'arm-check/summary.json').read_text())
assert summary['system_libraries_unchanged'] and not summary['iiod_listener_started']
assert len(summary['runs']) == 6
for index, (rate, traced, duration, injected) in enumerate(freeze['order']):
    label = f'{index}-{rate}-trace{int(traced)}'
    raw = root / f'arm-check/{label}.jsonl'
    reference = Path('/tmp/leo-integrated-feedback.p7e840/retained-workload') / f'{rate}.manifest.json'
    checked = verify(raw.read_text(), json.loads(reference.read_text()), duration, jitter_ms=40,
        algorithm_sha256=freeze['algorithm_sha256'], configuration_sha256=freeze['configuration_sha256'],
        capture_protection=True,pressure_smoke=injected)
    original = json.loads(raw.with_suffix('.verification.json').read_text())
    assert original['raw_sha256'] == digest(raw)
    assert all(original[k] == v for k,v in checked.items())
    assert original['traced'] == traced
    assert not checked['protection_stats']['disabled']
    if not injected:
        assert checked['all_checks_computed']
tests = {}
for name, filename in [('leo','leo-tests-final.xml'),('protection','protection-tests.xml'),
                       ('ppu','ppu-tests.xml'),('fixture','shadow-fixture-fix-tests.xml')]:
    suite = ET.parse(root/filename).getroot().find('testsuite')
    tests[name] = {k:int(suite.attrib[k]) for k in ('tests','errors','failures','skipped')}
    assert all(tests[name][k] == 0 for k in ('errors','failures','skipped'))
out.mkdir(parents=True)
selected = [p for p in root.iterdir() if p.is_file() and p.suffix in ('.py','.json','.xml')]
selected += [release / name for name in ('algorithm.json','configuration.json','bundle.json',
              'worker.build.json','libleo-scanner-glrt.so.build.json')]
selected += [p for p in (root / 'arm-check').rglob('*')
             if p.is_file() and p.suffix in ('.json','.jsonl') and 'credentials' not in p.parts]
artifacts = {}
for path in sorted(selected):
    relative = str(path.relative_to(root)) + '.gz'
    target = out / relative
    target.parent.mkdir(exist_ok=True,parents=True)
    raw = path.read_bytes()
    with target.open('xb') as stream:
        stream.write(gzip.compress(raw,compresslevel=9,mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[relative] = dict(sha256=digest(target),original_sha256=digest(path),original_bytes=len(raw))
revisions = {name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()
             for name,path in [('leo',ROOT),('libiio',ROOT.parent/'libiio-arm-glrt-frame-integration'),
                               ('ppu',ROOT.parent/'pluto-plus-utils-arm-glrt-host')]}
write_json(out/'index.json',dict(schema='org.leo.research.scanner-protected-package-evidence/v1',
    artifacts=artifacts, tests=tests, revisions=revisions, manifest_sha256=bundle.manifest_sha256,
    algorithm_sha256=receipt['algorithm_sha256'],configuration_sha256=receipt['configuration_sha256'],
    results=sum(r['results'] for r in summary['runs']),
    computed_results=sum(r['computed_results'] for r in summary['runs']),
    deployed=False, remotely_merged=False, live_rf=False, installed_files_unchanged=True,
    no_listener_started=True, complete_streaming_package_qualified=False, cleanup=end,
    local_release=str(release),scope='Exact package ARM loader and protected saved-IQ SDK/queue/scheduler execution; not IIO/IRQ/network duty'))
print(json.dumps(dict(artifacts=len(artifacts),tests=tests,results=sum(r['results'] for r in summary['runs'])),indent=2))

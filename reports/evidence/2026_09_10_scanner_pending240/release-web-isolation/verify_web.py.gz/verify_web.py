"""Run unchanged release web checks without a sibling historical reports tree."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
WEB = Path("/home/mouse9911/gits/leo-tracker-5m-presence/web")
scratch = OUT / "web"
shutil.copytree(WEB, scratch, ignore=shutil.ignore_patterns("node_modules", "dist"))
(scratch / "node_modules").symlink_to(WEB / "node_modules", target_is_directory=True)
assert not (OUT / "reports").exists()
command = ["npm", "--prefix", str(scratch), "run", "qualify:release", "--",
           "--outDir", str(OUT / "web-dist")]
result = subprocess.run(command, capture_output=True, text=True, timeout=120)
(OUT / "web.log").write_text(result.stdout + result.stderr)
receipt = dict(command=command, exit_code=result.returncode, sibling_reports_absent=True,
               manifest_sha256=hashlib.sha256((scratch / "report-assets.manifest.json").read_bytes()).hexdigest(),
               compiled_index_exists=(OUT / "web-dist/index.html").is_file())
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(result.stdout[-2500:])
if result.returncode:
    print(result.stderr[-4500:])
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)

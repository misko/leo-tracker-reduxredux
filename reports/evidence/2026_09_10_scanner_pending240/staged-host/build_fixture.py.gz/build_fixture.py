"""Matching 240 ms provider build for staged-host localhost checks; no RF."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

OUT = Path(__file__).resolve().parent
PRIOR = Path("/tmp/leo-pending240.nd2ckj")
REPO = Path("/home/mouse9911/gits/leo-tracker-5m-presence")
spec = importlib.util.spec_from_file_location("provider_recipe", PRIOR / "run_provider.py")
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
recipe.DEST = OUT


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name in ("sdk.so", "worker"):
    build = json.loads((PRIOR / (name + ".build.json")).read_bytes())
    assert sha(PRIOR / name) == build["binary_sha256"]
    for source, expected in build["sources_sha256"].items():
        assert sha(REPO / source) == expected, source
    shutil.copyfile(PRIOR / name, OUT / name)
    (OUT / name).chmod(0o755 if name == "worker" else 0o644)
    shutil.copyfile(PRIOR / (name + ".build.json"), OUT / (name + ".build.json"))
for rate in (2500000, 5000000):
    for suffix in (".templates", "-lower.ci16", "-upper.ci16"):
        source, target = PRIOR / (str(rate) + suffix), OUT / (str(rate) + suffix)
        shutil.copyfile(source, target)
        target.chmod(0o644)
recipe.case("fair")

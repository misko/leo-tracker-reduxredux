"""Exercise the sealed host package against a localhost-only provider fixture."""
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
RESULTS = OUT / "staged-results"
REPO = Path("/home/mouse9911/gits/leo-tracker-5m-presence")
RELEASE = Path("/opt/leo-tracker/releases/5b71a533cae5e7875e2ca0337372e266bf5683c5")
assert Path(sys.prefix).resolve() == RELEASE / ".venv"
assert not os.environ.get("LEO_DATABASE_URL")
assert not os.environ.get("LD_LIBRARY_PATH")

# Match the production adapter's public preload sequence before pylibiio or
# pyadi import. A bare import would otherwise select ambient system libiio.
from pluto_plus.hardware.preflight import verify_metadata_runtime
runtime = verify_metadata_runtime(3)
import iio
import leo
import pluto_plus
import pytest

modules = {m.__name__: str(Path(m.__file__).resolve()) for m in (iio, leo, pluto_plus)}
assert all(Path(p).is_relative_to(RELEASE / ".venv") for p in modules.values())
original_context = iio.Context


def localhost_only(uri, *args, **kwargs):
    assert isinstance(uri, str) and uri.startswith("ip:127.0.0.1:"), uri
    assert uri.removeprefix("ip:127.0.0.1:").isdecimal(), uri
    return original_context(uri, *args, **kwargs)


iio.Context = localhost_only
os.environ["SCANNER_GLRT_NETWORK_SERVER"] = str(OUT / "fair/iiod/test_scanner_glrt_network_server")
os.environ["SCANNER_GLRT_SERVER_LIBRARY_PATH"] = str(OUT / "fair")
os.environ["SCANNER_GLRT_TEST_MODE"] = "positive-only-v1"
sys.path.insert(0, str(REPO))
tests = ["tests/radio/test_scanner_glrt_network.py", "tests/radio/test_adaptive_hop_network.py",
         "tests/radio/test_adaptive_hop_scheduled_network.py"]
command = ["-q", "-p", "no:cacheprovider", *tests,
           "--basetemp=" + str(RESULTS / "pytest"),
           "--junitxml=" + str(RESULTS / "network.xml")]
definition = dict(
    scope="Sealed host Python/PPU/libiio; matching desktop 240 ms provider; localhost synthetic IQ only",
    staged_release=str(RELEASE), modules=modules, metadata_runtime=dataclasses.asdict(runtime),
    test_hashes={p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in tests},
    loopback_fixture_identities="12/34 repeated digests; not the production ARM bundle identity",
    command=command, new_rf=False, firmware_changed=False,
)
with (RESULTS / "definition.json").open("x") as stream:
    json.dump(definition, stream, indent=2)
    stream.write("\n")
started = time.monotonic()
status = pytest.main(command)
assert dataclasses.asdict(verify_metadata_runtime(3)) == definition["metadata_runtime"]
with (RESULTS / "result.json").open("x") as stream:
    json.dump(dict(exit_code=int(status), elapsed_seconds=time.monotonic() - started,
                   package_paths_unchanged=True, no_radio_context=True), stream, indent=2)
    stream.write("\n")
raise SystemExit(status)

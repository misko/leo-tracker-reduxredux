"""Actual 240 ms fair provider qualification: synthetic IQ and localhost only, no RF."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from tools.native_presence import ROOT, NATIVE, build_scanner_glrt_port, build_worker, write_templates
from tools.qualify_presence_dwell_controls import generate

DEST = Path(__file__).resolve().parent
LIBIIO = Path('/home/mouse9911/gits/libiio-scanner-cooperative-provider')
METADATA = Path('/home/mouse9911/gits/plutosdr-fw-metadata-gain-timeline-v8')


def run(command, log, **kwargs):
    with log.open('x') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, **kwargs)
    if result.returncode:
        print(log.read_text()[-12000:], flush=True)
        raise RuntimeError(f'{command[0]} failed ({result.returncode}); {log}')


def prepare():
    build_scanner_glrt_port(DEST / 'sdk.so')
    build_scanner_glrt_port(DEST / 'sdk-asan.so', cflags=(
        '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-g', '-O1'))
    config = json.loads((ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json').read_text())
    flags = tuple(config['common_flags']) + tuple(
        f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
    ) + tuple(f'-DLEO_PRESENCE_{name}=1' for name in (
        'DIFFERENTIAL_CI16', 'RANK_HYBRID_PROJECTION', 'GLRT_SYMBOL_DIVERSITY',
        'RANK_AMPLITUDE_WEIGHTED', 'BOUNDED_MAGNITUDE', 'CONDITIONED_BLOCK_ROTATION',
        'ENERGY_SUPPORT', 'ENERGY_SYMBOL_SUPPORT'))
    build_worker(DEST / 'worker', cflags=flags).chmod(0o755)
    wrapper = LIBIIO / 'tests/scanner-glrt-worker-delay.c'
    build_worker(DEST / 'worker-delayed', cflags=(*flags, '-I', str(NATIVE)),
                 ldflags=(str(wrapper), '-Wl,--wrap=leo_presence_dwell_run_ci16'),
                 dependencies=(wrapper,)).chmod(0o755)
    for rate in (2500000, 5000000):
        write_templates(DEST / f'{rate}.templates', rate)
        (DEST / f'{rate}.templates').chmod(0o600)
        for edge in ('lower', 'upper'):
            iq, _ = generate(rate, edge, 92851, 'pilot', 0)
            with (DEST / f'{rate}-{edge}.ci16').open('xb') as output:
                output.write(iq.astype('<i2', copy=False).tobytes())
    print('Prepared matching LP03 SDKs/workers and synthetic IQ', flush=True)


def case(name):
    assert name in ('off', 'fair', 'delayed', 'asan')
    build = DEST / name
    delayed = name in ('delayed', 'asan')
    sdk = DEST / ('sdk-asan.so' if name == 'asan' else 'sdk.so')
    worker = DEST / ('worker-delayed' if delayed else 'worker')
    options = [
        '-DWITH_TESTS=ON', '-DWITH_IIOD=ON', '-DWITH_XML_BACKEND=ON',
        '-DWITH_LOCAL_BACKEND=ON', '-DWITH_USB_BACKEND=OFF', '-DWITH_SERIAL_BACKEND=OFF',
        '-DHAVE_DNS_SD=OFF', '-DWITH_AIO=OFF', '-DWITH_ZSTD=OFF', '-DWITH_DOC=OFF',
        '-DWITH_MAN=OFF', '-DIIOD_SCANNER_GLRT_MODE=positive-only-v1',
        '-DIIOD_SCANNER_GLRT_MINIMUM_EXACT_SCORE=0.175',
        '-DIIOD_SCANNER_GLRT_MINIMUM_MARGIN=0.025', '-DIIOD_SCANNER_ADAPTIVE_HOP=ON',
        '-DIIOD_SCANNER_GLRT_CAPTURE_PROTECTION=ON',
        '-DIIOD_SCANNER_GLRT_COOPERATIVE_SKIPS=ON',
        f'-DIIOD_SCANNER_GLRT_FAIR_ADMISSION={"OFF" if name == "off" else "ON"}',
        f'-DIIOD_SCANNER_GLRT_MAXIMUM_PENDING_AGE_MS={120 if name == "off" else 240}',
        f'-DIIOD_BUFFER_METADATA_PROVIDER={LIBIIO}/iiod/spf-buffer-metadata.c',
        f'-DIIOD_BUFFER_PERSISTENT_HOP_DEVICE_PROVIDER={LIBIIO}/iiod/spf-hop-device-userspace.c',
        f'-DIIOD_BUFFER_METADATA_INCLUDE_DIRS={METADATA};/home/mouse9911/gits/plutosdr-fw/linux/usr/include',
        '-DIIOD_BUFFER_METADATA_PROVIDER_EXTRA_SOURCES=' + ';'.join(map(str, (
            LIBIIO / 'iiod/spf-tandem-session.c', LIBIIO / 'iiod/spf-tandem-metadata.c',
            *(METADATA / source for source in ('spf_gain_read.c', 'spf_gain_sampler.c',
                'spf_rssi_read.c', 'spf_radio_frame_v3.c', 'spf_thread_join.c'))))),
        f'-DIIOD_SCANNER_GLRT_LIBRARY={sdk}',
        f'-DIIOD_SCANNER_GLRT_INCLUDE_DIR={ROOT}/src/leo/scanner/native_presence',
        f'-DIIOD_SCANNER_GLRT_WORKER_PATH={worker}',
        f'-DIIOD_SCANNER_GLRT_TEMPLATES_2500000={DEST}/2500000.templates',
        f'-DIIOD_SCANNER_GLRT_TEMPLATES_5000000={DEST}/5000000.templates',
        '-DIIOD_SCANNER_GLRT_ALGORITHM_SHA256=' + '12' * 32,
        '-DIIOD_SCANNER_GLRT_CONFIGURATION_SHA256=' + '34' * 32,
    ]
    if name == 'asan':
        options += ['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer -g',
                    '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(['cmake', '-S', str(LIBIIO), '-B', str(build), *options], DEST / f'{name}-configure.log', timeout=60)
    targets = ('test_spf_hop_adaptive_native', 'test_spf_hop_adaptive_policy', 'test_scanner_glrt_provider')
    run(['cmake', '--build', str(build), '-j4', '--target', 'iiod',
         'test_scanner_glrt_network_server', *targets], DEST / f'{name}-build.log', timeout=120)
    print(f'{name}: real provider/daemon build passed', flush=True)
    env = os.environ.copy()
    for rate in (2500000, 5000000):
        for edge in ('lower', 'upper'):
            env[f'SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}'] = str(DEST / f'{rate}-{edge}.ci16')
    env['ASAN_OPTIONS'] = 'detect_leaks=1:halt_on_error=1'
    env['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
    if delayed:
        env['SPF_EXPECT_FAIR_SHEDDING'] = '1'
    for target in targets:
        run([str(build / 'iiod' / target)], DEST / f'{name}-{target}.log', timeout=100, env=env)
        print(f'{name}: {target} passed', flush=True)
    files = [sdk, worker, build / 'iiod/test_scanner_glrt_provider', build / 'iiod/iiod',
             build / 'iiod/test_scanner_glrt_network_server']
    receipt = {'case': name, 'passed': True, 'synthetic_iq_only': True,
        'deliberate_worker_sleep_ms': 170 if delayed else 0,
        'leo_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'libiio_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=LIBIIO, text=True).strip(),
        'libiio_diff': subprocess.check_output(['git', 'diff'], cwd=LIBIIO, text=True),
        'test_wrapper_sha256': hashlib.sha256((LIBIIO / 'tests/scanner-glrt-worker-delay.c').read_bytes()).hexdigest(),
        'artifacts': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        'sanitizer_scope': 'SDK, provider and policy; isolated numerical worker unsanitized' if name == 'asan' else None}
    with (DEST / f'{name}-receipt.json').open('x') as output:
        json.dump(receipt, output, indent=2)
        output.write('\n')


if __name__ == '__main__':
    prepare() if sys.argv[1] == 'prepare' else case(sys.argv[1])


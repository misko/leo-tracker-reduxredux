"""Bounded real-ARM synthetic provider test; no RF, daemon stop or firmware writes."""
import dataclasses
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import uuid

from pluto_plus.radio_lock import acquire_radio_lock
from pluto_plus.userspace_iiod import PinnedPasswordSshIiodTransport
from pluto_plus.userspace_iiod_bundle import IiodBundleFile, IiodCompanionBundle, load_iiod_companion_bundle

sys.path.insert(0, "/home/mouse9911/.local/state/pluto-plus-utils/r18-restore-2r2t.VHHdCU")
from operate import ROOT as MAINTENANCE, HOST, SERIAL, PRECHECK, network, transport, usb

out = Path(__file__).resolve().parent
base = load_iiod_companion_bundle(out / "release/bundle.json")
additions = [("test-scanner-provider", out / "build/iiod/test_scanner_glrt_provider", True)]
for rate in (2500000, 5000000):
    for edge in ("lower", "upper"):
        additions.append((f"pilot-{rate}-{edge}.ci16",
                          Path(f"/tmp/leo-pending240.nd2ckj/{rate}-{edge}.ci16"), False))
files = list(base.files)
for name, path, executable in additions:
    data = path.read_bytes()
    files.append(IiodBundleFile(name, hashlib.sha256(data).hexdigest(), executable, data))
identity = dict(remote_directory=base.remote_directory, daemon_sha256=base.daemon_sha256,
                daemon_bytes=base.daemon_bytes,
                files=[dict(name=f.name, sha256=f.sha256, bytes=len(f.payload), executable=f.executable)
                       for f in files])
manifest = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
bundle = IiodCompanionBundle(base.remote_directory, manifest, base.daemon_sha256,
                             base.daemon_bytes, tuple(files))
readelf = "/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-readelf"
dynamic = subprocess.check_output([readelf, "-d", str(additions[0][1])], text=True)
assert f"[{base.remote_directory}]" in dynamic
owner = uuid.uuid4().hex
credentials = Path("/srv/bulk/leo/scanner-live-20260909.WXLlWn/credentials")

def save(name, value):
    with (out / (name + ".json")).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")

def stable(link):
    text = link.run("sh -s", stdin=PRECHECK + rb"""
echo STOCK_PID $(pidof iiod)
for pid in $(pidof iiod); do
  readlink /proc/$pid/exe
  awk '{print $22}' /proc/$pid/stat
done
""", timeout_s=15)
    assert all(":22 " in line for line in text.splitlines() if "ESTABLISHED" in line)
    return text

with acquire_radio_lock(SERIAL):
    before_usb = usb()
    network_identity = network()
    link = transport()
    before = stable(link)
    stage = PinnedPasswordSshIiodTransport(
        host=HOST, expected_serial=SERIAL,
        known_hosts_file=MAINTENANCE / "known_hosts",
        password_file=credentials / "scanner-iiod-ssh-password",
    )
    assert stage.attest_radio_serial() == SERIAL
    save("arm-preflight", dict(usb=before_usb, network=dataclasses.asdict(network_identity),
                                remote=before, fixture_bundle=identity, owner=owner))
    staged = False
    try:
        stage.stage_companions(bundle, owner)
        staged = True
        usb()
        print("ARM fixture staged and every companion hash verified; installed daemon untouched", flush=True)
        root = base.remote_directory
        script = "set -eu\n"
        script += f'test "$(cat {root}/owner)" = {owner}\n'
        for rate in (2500000, 5000000):
            for edge in ("lower", "upper"):
                script += f"export SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}={root}/pilot-{rate}-{edge}.ci16\n"
        script += "ulimit -t 100\n"
        script += f"{root}/test-scanner-provider\n"
        result = link.run("sh -s", stdin=script.encode(), timeout_s=105)
        save("arm-provider-result", dict(output=result, fixture_manifest_sha256=manifest))
        assert "both rates, real worker, delayed events, terminal drain and exact-gap tests passed" in result
        print("ARM provider test completed successfully", flush=True)
    except Exception as exc:
        save("arm-provider-failure", dict(error=type(exc).__name__, message=str(exc)))
        raise
    finally:
        if staged:
            stage.verify_companions(bundle, owner)
            stage.cleanup_companions(bundle, owner)
        after = stable(link)
        before_stock = before[before.index("STOCK_PID"):]
        after_stock = after[after.index("STOCK_PID"):]
        assert before_stock == after_stock, "installed daemon identity changed"
        assert usb()["device_number"] == before_usb["device_number"]
        save("arm-postflight", dict(remote=after, companions_removed=staged,
                                     installed_daemon_unchanged=True, new_rf=False,
                                     firmware_changed=False))
        print("Owned temporary files removed; idle buffers and unchanged installed daemon verified", flush=True)

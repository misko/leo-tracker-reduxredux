"""Prepare all 96 frozen real RX1 dwells for exact-algorithm ARM timing; no RF."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from tools.native_presence import ROOT, build_dwell_presence
from tools.presence_fftw import fftw_options
from tools.qualify_presence_dwell_worker import FIELDS
from tools.qualify_presence_worker import compare_values

OUT = Path(__file__).resolve().parent
SOURCE = Path("/tmp/leo-dwell-worker-20260908-vg66yo9u")
RELEASE = Path("/tmp/leo-pending240-arm.X6O6Kw/release")
HOST = Path("/home/mouse9911/gits/plutosdr-fw/buildroot/output/host")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def candidate_fields(result):
    return [{k: c[k] for k in FIELDS} for c in result["confirmations"][0]["candidates"]]


def verify(result, record):
    assert result["rate_hz"] == record["rate_hz"]
    assert result["counter"] == str(record["counter"])
    assert result["edge"] == int(record["edge"] == "upper")
    assert result["confirmation_count"] == 1
    assert result["confirmation_window_mask"] == record["expected"]["confirmation_window_mask"]
    got, expected = candidate_fields(result), record["expected"]["candidates"]
    assert len(got) == len(expected)
    for a, b in zip(got, expected, strict=True):
        compare_values(a, b)
    compare_values(result["nuisances"][0], record["expected"]["nuisance"], nuisance=True)
    assert result["rank"]["order"] == record["expected"]["rank"]["order"]
    return any(c["fractional_complete"] and c["exact_score"] >= .175 and c["margin"] >= .025
               for c in got)


def main():
    algorithm = json.loads((RELEASE / "algorithm.json").read_bytes())
    bundle = json.loads((RELEASE / "bundle.json").read_bytes())
    flags = tuple(algorithm["native_defines"])
    armfftw = fftw_options(HOST / "arm-buildroot-linux-gnueabihf/sysroot/usr", runtime_rpath=False)
    assert sha(armfftw["dependencies"][1].read_bytes()) == algorithm["fftw_sha256"]
    arm = build_dwell_presence(
        OUT / "arm-dwell-replay", executable=True,
        compiler=str(HOST / "bin/arm-linux-gnueabihf-gcc"),
        cflags=flags + ("-mcpu=cortex-a9", "-mfpu=neon", "-mfloat-abi=hard") + armfftw["cflags"],
        ldflags=armfftw["ldflags"] + (f"-Wl,--disable-new-dtags,-rpath,{bundle['remote_directory']}",),
        dependencies=armfftw["dependencies"],
    )
    desktop_fftw = fftw_options(Path("/tmp/leo-presence-fftw.nLw4v6/install"))
    desktop = build_dwell_presence(OUT / "desktop-dwell-replay", executable=True,
        cflags=flags + desktop_fftw["cflags"], ldflags=desktop_fftw["ldflags"],
        dependencies=desktop_fftw["dependencies"])
    frozen = json.loads((SOURCE / "2500000/manifest.json").read_bytes())
    legacy_flags = tuple(arg for arg in frozen["reference_build"]["command"]
                         if arg.startswith("-D") and arg != "-DLEO_PRESENCE_FFTW=1")
    legacy = build_dwell_presence(OUT / "legacy-dwell-replay", executable=True,
        cflags=legacy_flags + desktop_fftw["cflags"], ldflags=desktop_fftw["ldflags"],
        dependencies=desktop_fftw["dependencies"])
    # Compare analysis source bytes against the exact already-qualified worker.
    worker_build = json.loads((RELEASE / "worker.build.json").read_bytes())
    arm_build = json.loads((OUT / "arm-dwell-replay.build.json").read_bytes())
    analysis_sources = {k: v for k, v in worker_build["sources_sha256"].items()
                        if k.startswith("src/leo/analysis/")}
    assert analysis_sources and all(arm_build["sources_sha256"].get(k) == v
                                    for k, v in analysis_sources.items())
    rows, source_hashes = [], {}
    for rate in (2500000, 5000000):
        origin = SOURCE / str(rate)
        manifest_path, pack_path = origin / "manifest.json", origin / "dwells.pack"
        manifest = json.loads(manifest_path.read_bytes())
        data = pack_path.read_bytes()
        source_hashes[str(manifest_path)] = sha(manifest_path.read_bytes())
        source_hashes[str(pack_path)] = sha(data)
        assert sha(data) == manifest["pack_sha256"]
        magic, recorded_rate, count = struct.unpack("<4sII", data[:12])
        assert (magic, recorded_rate, count) == (b"LDP1", rate, 48)
        samples, cursor = rate * 120 // 1000, 12
        templates = (RELEASE / f"templates-{rate}.bin").read_bytes()
        assert sha(templates) == manifest["templates_sha256"]
        tag, template_rate, n = struct.unpack("<4sII", templates[:12])
        assert (tag, template_rate, n) == (b"LPT1", rate, (rate + 375) // 750)
        for index, record in enumerate(manifest["records"]):
            counter, visit, edge, channel = struct.unpack("<QQII", data[cursor:cursor + 24])
            assert (counter, visit, edge, channel) == (
                int(record["counter"]), record["visit"], int(record["edge"] == "upper"), record["channel"])
            assert record["rx"] == 1 and record["rate_hz"] == rate
            cursor += 24
            iq = data[cursor:cursor + samples * 4]
            assert len(iq) == samples * 4
            cursor += len(iq)
            exact = templates[12 + 2 * edge * n * 16:12 + (2 * edge + 1) * n * 16]
            payload = struct.pack("<4sIIIIQ", b"LRK1", rate, edge, samples, 2, counter) + exact + iq
            filename = f"real-{rate}-{index:02}.rank"
            with (OUT / filename).open("xb") as stream:
                stream.write(payload)
            process = subprocess.run([str(desktop), str(OUT / filename),
                str(RELEASE / f"templates-{rate}.bin"), "512", "1", "blind", "1"],
                text=True, capture_output=True, timeout=45)
            assert process.returncode == 0, process.stderr
            result = json.loads(process.stdout)
            previous = subprocess.run([str(legacy), str(OUT / filename),
                str(RELEASE / f"templates-{rate}.bin"), "512", "1", "blind", "1"],
                text=True, capture_output=True, timeout=45)
            assert previous.returncode == 0, previous.stderr
            previous_result = json.loads(previous.stdout)
            old_passed = verify(previous_result, record)
            expected = dict(
                candidates=candidate_fields(result),
                confirmation_window_mask=result["confirmation_window_mask"],
                nuisance=result["nuisances"][0], rank=result["rank"],
            )
            current_record = dict(record, expected=expected)
            passed = verify(result, current_record)
            rows.append(dict(filename=filename, sha256=sha(payload), iq_sha256=sha(iq),
                             metadata=current_record, frozen_metadata=record,
                             desktop_result=result, legacy_result=previous_result,
                             positive_gate=passed, legacy_positive_gate=old_passed))
        assert cursor == len(data)
        print(f"Validated all 48 frozen {rate} Hz dwells against their prior numerical references", flush=True)
    save(OUT / "prepared.json", dict(
        scope="All 96 frozen real RX1 dwells, no selection on detector output; direct numerical timing, not streaming",
        rows=rows, source_sha256=source_hashes, source_script_sha256=sha(Path(__file__).read_bytes()),
        worker_algorithm_sha256=sha((RELEASE / "algorithm.json").read_bytes()),
        analysis_source_agreement=True, desktop_sha256=sha(desktop.read_bytes()), arm_sha256=sha(arm.read_bytes()),
    ))
    print(json.dumps(dict(dwells=len(rows), qualified_positive=sum(r["positive_gate"] for r in rows))), flush=True)


if __name__ == "__main__":
    main()


"""Bounded direct numerical replay of all 96 saved RX1 dwells on the USB-attested ARM."""
import hashlib
import json
from pathlib import Path
import sys
import uuid

from pluto_plus.radio_lock import acquire_radio_lock
from pluto_plus.userspace_iiod import PinnedPasswordSshIiodTransport
from pluto_plus.userspace_iiod_bundle import IiodBundleFile, IiodCompanionBundle, load_iiod_companion_bundle

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare import verify

sys.path.insert(0, "/home/mouse9911/.local/state/pluto-plus-utils/r18-restore-2r2t.VHHdCU")
from operate import ROOT as MAINTENANCE, HOST, SERIAL, PRECHECK, network, transport, usb

OUT = Path(__file__).resolve().parent
RELEASE = Path("/tmp/leo-pending240-arm.X6O6Kw/release")
base = load_iiod_companion_bundle(RELEASE / "bundle.json")
prepared = json.loads((OUT / "prepared.json").read_bytes())
assert len(prepared["rows"]) == 96
arm = (OUT / "arm-dwell-replay").read_bytes()
assert hashlib.sha256(arm).hexdigest() == prepared["arm_sha256"]
credentials = Path("/srv/bulk/leo/scanner-live-20260909.WXLlWn/credentials")


def save(name, value):
    with (OUT / (name + ".json")).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def stable(link):
    output = link.run("sh -s", stdin=PRECHECK + rb"""
echo STOCK_PID $(pidof iiod)
for pid in $(pidof iiod); do
  readlink /proc/$pid/exe
  awk '{print $22}' /proc/$pid/stat
done
""", timeout_s=15)
    assert all(":22 " in line for line in output.splitlines() if "ESTABLISHED" in line)
    return output


results = []
with acquire_radio_lock(SERIAL):
    before_usb = usb()
    assert network().serial == SERIAL
    link = transport()
    before = stable(link)
    stage = PinnedPasswordSshIiodTransport(
        host=HOST, expected_serial=SERIAL,
        known_hosts_file=MAINTENANCE / "known_hosts",
        password_file=credentials / "scanner-iiod-ssh-password",
    )
    assert stage.attest_radio_serial() == SERIAL
    save("arm-preflight", dict(host=HOST, serial=SERIAL, usb=before_usb, remote=before))
    try:
        for first in range(0, 96, 6):
            batch = prepared["rows"][first:first + 6]
            files = list(base.files) + [IiodBundleFile("dwell-replay", prepared["arm_sha256"], True, arm)]
            for item in batch:
                data = (OUT / item["filename"]).read_bytes()
                assert hashlib.sha256(data).hexdigest() == item["sha256"]
                files.append(IiodBundleFile(item["filename"], item["sha256"], False, data))
            identity = [dict(name=f.name, bytes=len(f.payload), sha256=f.sha256, executable=f.executable)
                        for f in files]
            manifest_hash = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
            bundle = IiodCompanionBundle(base.remote_directory, manifest_hash, base.daemon_sha256,
                                         base.daemon_bytes, tuple(files))
            owner = uuid.uuid4().hex
            staged = False
            try:
                assert usb()["device_number"] == before_usb["device_number"]
                stage.stage_companions(bundle, owner)
                staged = True
                root = base.remote_directory
                script = f'set -eu\ntest "$(cat {root}/owner)" = {owner}\nulimit -t 25\n'
                for item in batch:
                    rate = item["metadata"]["rate_hz"]
                    script += f"{root}/dwell-replay {root}/{item['filename']} {root}/templates-{rate}.bin 512 1 blind 3\n"
                output = link.run("sh -s", stdin=script.encode(), timeout_s=45)
                save(f"arm-batch-{first // 6:02}", dict(output=output, files=identity,
                     manifest_sha256=manifest_hash, first=first, owner=owner))
                rows = [json.loads(line) for line in output.splitlines() if line.startswith("{")]
                assert len(rows) == len(batch) * 3
                for offset, row in enumerate(rows):
                    item = batch[offset // 3]
                    assert row["iteration"] == offset % 3
                    assert verify(row, item["metadata"]) == item["positive_gate"]
                    results.append(dict(filename=item["filename"], result=row))
                print(f"ARM: verified {first + 6}/96 real dwells, three executions each", flush=True)
            finally:
                if staged:
                    stage.verify_companions(bundle, owner)
                    stage.cleanup_companions(bundle, owner)
    except Exception as exc:
        save("arm-failure", dict(error=type(exc).__name__, message=str(exc), verified_executions=len(results)))
        raise
    finally:
        after = stable(link)
        assert before[before.index("STOCK_PID"):] == after[after.index("STOCK_PID"):]
        assert usb()["device_number"] == before_usb["device_number"]
        save("arm-postflight", dict(remote=after, installed_daemon_unchanged=True,
                                     new_rf=False, firmware_changed=False))
    save("arm-results", dict(results=results, completed=True, original_dwells=96,
                              executions=len(results), all_candidates_match_desktop=True,
                              prepared_sha256=hashlib.sha256((OUT / "prepared.json").read_bytes()).hexdigest(),
                              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                              scope="Direct numerical timing on real ARM with saved IQ; not streaming duty or RF recall"))
    print("All 288 ARM executions match the current desktop algorithm; stock daemon untouched", flush=True)

"""Diagnostic-only pytest hook: retain exact numerical replay outputs, no RF."""
import hashlib
import json
import os
from pathlib import Path

import pytest

OUT = Path(__file__).resolve().parent


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    outcome = yield
    if "positive_runs" not in item.funcargs:
        return
    manifest, outputs = item.funcargs["positive_runs"]
    if manifest["rate_hz"] != 5000000:
        return
    root = OUT / str(os.getpid())
    root.mkdir(exist_ok=True)
    with (root / "manifest.json").open("w") as stream:
        json.dump(manifest, stream)
    for (delay, jitter), output in outputs.items():
        with (root / f"replay-{delay}-{jitter}.jsonl").open("w") as stream:
            stream.write(output)
    binaries = item.funcargs["workload"][:4]
    with (root / "identity.json").open("w") as stream:
        json.dump({str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in binaries}, stream)
    with (root / "outcome.json").open("w") as stream:
        json.dump({"node": item.nodeid, "failed": outcome.excinfo is not None}, stream)

"""Bounded eight-way replay diagnostic using saved synthetic fixtures; no RF."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess

from leo.contracts.scanner_glrt_frame import decode_frame
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE, verify

OUT = Path(__file__).resolve().parent
BUILD = OUT / "pytest/glrt-sdk-replay0"
manifest = json.loads((OUT / "3324228/manifest.json").read_bytes())
output = OUT / "parallel-replay"
output.mkdir()


def run(index):
    command = [str(BUILD / "parent/sdk-replay"), str(BUILD / "worker"),
               str(BUILD / "5000000.templates"), str(BUILD / "5000000.pack"),
               "968", "2", "40", "1", "12" * 32, "34" * 32, POSITIVE_PROFILE]
    process = subprocess.run(command, text=True, capture_output=True, timeout=20)
    (output / f"{index:02}.jsonl").write_text(process.stdout)
    result = dict(index=index, exit_code=process.returncode, stderr=process.stderr)
    try:
        result["verified"] = verify(process.stdout, manifest, 968, delay_blocks=2,
                                    jitter_ms=40, enabled=True, positive_feedback=True)
        result["passed"] = process.returncode == 0 and not process.stderr
    except Exception as exc:
        result.update(passed=False, error=str(exc))
    rows = [json.loads(line) for line in process.stdout.splitlines()]
    result["records"] = [dict(visit=r.visit, verdict=r.verdict, reason=r.reason,
                               search_window_mask=r.search_window_mask)
        for row in rows if row["kind"] == "frame"
        for r in decode_frame(bytes.fromhex(row["hex"])).results]
    blocks = [r for r in rows if r["kind"] == "block"]
    result["maximum_delivery_lateness_ms"] = max(r["arrival_ms"] - r["requested_ms"] for r in blocks)
    return result


with ThreadPoolExecutor(max_workers=8) as pool:
    results = list(pool.map(run, range(32)))
(output / "receipt.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(dict(runs=32, passed=sum(r["passed"] for r in results),
                     failures=[r for r in results if not r["passed"]]), indent=2))

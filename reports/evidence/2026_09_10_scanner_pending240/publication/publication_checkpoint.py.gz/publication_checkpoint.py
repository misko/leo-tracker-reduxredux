"""Read-only publication/selector snapshot; does not activate any release."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
REPO = Path("/home/mouse9911/gits/leo-tracker-5m-presence")
REVISION = "5b71a533cae5e7875e2ca0337372e266bf5683c5"
RELEASE = Path("/opt/leo-tracker/releases") / REVISION


def run(*command):
    return subprocess.check_output(command, text=True).strip()


paths = run("sudo", "-n", str(REPO / "deploy/scripts/validate-scanner-glrt-bundle"),
            str(RELEASE), "--paths").splitlines()
assert len(paths) == 12
hashes = run("sudo", "-n", "sha256sum", *paths).splitlines()
assets = {}
for line, path in zip(hashes, paths, strict=True):
    observed = line.split()[0]
    relative = Path(path).relative_to(RELEASE)
    assert observed == hashlib.sha256((REPO / relative).read_bytes()).hexdigest()
    assets[str(relative)] = observed
result = dict(
    observed_at=datetime.now(timezone.utc).isoformat(), staged_revision=REVISION,
    scope="Immutable userspace release staged and revalidated; not activated or RF-qualified",
    runtime_assets_sha256=assets,
    metadata_sha256=run("sudo", "-n", "sha256sum",
                       f"/opt/leo-tracker/release-metadata/{REVISION}.txt").split()[0],
    selectors={name: str((Path("/opt/leo-tracker") / name).resolve())
               for name in ("current", "current-api", "current-worker", "current-acquisition")},
    acquisition_service=run("sudo", "-n", "systemctl", "is-active", "leo-acquisition.service"),
    remote_refs=run("git", "-C", str(REPO), "ls-remote", "origin", "refs/heads/main",
                    "refs/heads/codex/scanner-5m-cooperative-skips"),
    no_activation=True, new_rf=False, firmware_changed=False,
)
assert result["selectors"]["current-acquisition"].endswith("c60438c5fd096e884a0c523a73097299d1a2f5ba")
with (OUT / "release-publication-checkpoint.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result, indent=2))

"""Copy bounded public qualification evidence; never change sealed sources."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
REPO = Path("/home/mouse9911/gits/leo-tracker-5m-presence")
REVISION = "a37f5e926dd45f4e0f8470ffc6dbc807ad8c90aa"
STAGED = Path("/opt/leo-tracker/releases") / REVISION
EVIDENCE = Path("/srv/bulk/leo/qualification/release")


def run(*args):
    return subprocess.check_output(args, timeout=30)


def read(path):
    return run("sudo", "-n", "-u", "leo", "/usr/bin/cat", str(path))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(payload)


for variant, run_id in (
    ("failed", "scanner-5b71a533-20260910-no-rf"),
    ("corrected", "scanner-a37f5e92-20260910-no-rf"),
):
    source = EVIDENCE / run_id
    payload = read(source / "receipt.json")
    receipt = json.loads(payload)
    assert receipt["status"] in {"passed", "failed"}
    preserve(OUT / variant / "receipt.json", payload)
    for entry in receipt["evidence"]:
        relative = Path(entry["relative_path"])
        assert not relative.is_absolute() and ".." not in relative.parts
        # Logs, JUnit/JSON summaries and the definition suffice; no browser
        # traces, generated IQ, binaries or arbitrary nested attachments.
        allowed = (
            relative == Path("definition.json")
            or len(relative.parts) == 2
            and relative.parts[0] in {"logs", "results"}
            and relative.suffix in {".json", ".xml", ".log", ".txt"}
        )
        if not allowed:
            continue
        assert entry["bytes"] < 16 * 1024 * 1024
        data = read(source / relative)
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"]
        preserve(OUT / variant / relative, data)

selectors = {
    name: str((Path("/opt/leo-tracker") / name).resolve(strict=True))
    for name in ("current", "current-acquisition", "current-api", "current-worker")
}
assert all(not path.endswith(REVISION) for path in selectors.values())
schemas = run("sudo", "-n", "-u", "leo", "psql", "-d", "leo_qualification", "-Atc",
    "SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' "
    "AND nspname <> 'information_schema' ORDER BY nspname;").decode().splitlines()
assert schemas == ["public"]
assets = run("git", "-C", str(REPO), "ls-tree", "-r", "--name-only", REVISION,
             "runtime/scanner-glrt").decode().splitlines()
assert len(assets) == 12
hashes = {name: sha(read(STAGED / name)) for name in assets}
for name, expected in hashes.items():
    assert expected == sha((REPO / name).read_bytes())
runtime_delta = run("git", "-C", str(REPO), "diff", "--name-only",
    "5b71a533cae5e7875e2ca0337372e266bf5683c5", REVISION,
    "src", "runtime", "deploy", "pyproject.toml", "uv.lock").decode().splitlines()
assert not runtime_delta
metadata = read(Path("/opt/leo-tracker/release-metadata") / (REVISION + ".txt"))
checkpoint = dict(
    staged_revision=REVISION,
    no_activation=True,
    new_rf=False,
    firmware_changed=False,
    acquisition_service=run("systemctl", "is-active", "leo-acquisition.service").decode().strip(),
    selectors=selectors,
    qualification_database_final_schemas=schemas,
    runtime_assets_sha256=hashes,
    metadata_sha256=sha(metadata),
    runtime_delta_from_staged_loopback_revision=runtime_delta,
    source_script_sha256=sha(Path(__file__).read_bytes()),
)
assert checkpoint["acquisition_service"] == "active"
preserve(OUT / "checkpoint.json", (json.dumps(checkpoint, indent=2) + "\n").encode())
print(json.dumps(checkpoint, indent=2))

"""Retain exact requalification and read-only operational observations."""
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

OUT = Path(__file__).resolve().parent
RUN = Path('/srv/bulk/leo/qualification/release/scanner-40de667b-20260910-no-rf')
REVISION = '40de667bc8fb98b99d2b343cb19f9045193d7b86'


def command(*args):
    return subprocess.check_output(args, timeout=30)


def read(path):
    return command('sudo', '-n', '-u', 'leo', '/usr/bin/cat', str(path))


def save(name, payload):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(payload)


raw = read(RUN / 'receipt.json')
receipt = json.loads(raw)
assert receipt['passed'] and receipt['git_revision'] == REVISION
save('receipt.json', raw)
allowed = {'definition.json', 'results/web-build.json', 'results/browser-e2e.json'}
allowed.update(row['log_relative_path'] for row in receipt['commands'])
for item in receipt['evidence']:
    if item['relative_path'] not in allowed:
        continue
    payload = read(RUN / item['relative_path'])
    assert len(payload) == item['bytes']
    assert hashlib.sha256(payload).hexdigest() == item['sha256']
    save(item['relative_path'], payload)
with urllib.request.urlopen('http://192.168.1.142:8090/api/v1/acquisition-queue?limit=10', timeout=10) as response:
    queue = json.load(response)
control = json.loads(read(Path('/srv/bulk/leo/control/capture-authority-v1.json')))
checkpoint = dict(
    staged_revision=REVISION,
    integrated_main='732f1cdf0a6a1e3180b5ca5ebb4a2b5cb51873be',
    acquisition_release=str(Path('/opt/leo-tracker/current-acquisition').resolve()),
    acquisition_active=command('systemctl', 'is-active', 'leo-acquisition.service').decode().strip(),
    capture_control={key: control[key] for key in ('generation', 'desired_state', 'observed_state')},
    queue=queue,
    approved_rf_seconds=1500,
    rf_seconds_used=0,
    new_rf=False,
    firmware_changed=False,
    production_changed=False,
    blocker='Both production radios are scheduled every 180 s; a 300 s canary needs maintenance permission. Scanner SSH host-key mismatch also requires identity verification and trust-pin refresh.',
)
schemas = command('sudo','-n','-u','leo','psql','-d','leo_qualification','-Atc',
    "SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%' AND nspname <> 'information_schema' ORDER BY nspname;").decode().splitlines()
assert schemas == ['public']
checkpoint['qualification_database_final_schemas'] = schemas
save('checkpoint.json', (json.dumps(checkpoint, indent=2) + '\n').encode())
print(json.dumps({'qualified_revision': REVISION, 'passed': True, 'rf_seconds_used': 0}))

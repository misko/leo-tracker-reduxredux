"""Bounded saved-IQ SDK/queue/scheduler replay on exact idle spare; no RF."""
import json
from pathlib import Path
import re
import shlex
import time

from access import SERIAL, idle, recorded, system_hashes, call, transfer
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE
from tools.qualify_scanner_glrt_shadow import verify

root = Path(__file__).parent
out = root / "runs"
out.mkdir(exist_ok=False)
assets = json.loads((root / "assets/payload.json").read_text())
paths = {name:Path(row["path"]) for name,row in assets.items()}
payload = {name:row["sha256"] for name,row in assets.items()}
assert all(digest(p) == payload[name] for name,p in paths.items())
configuration = json.loads((root / "assets/freeze.json").read_text())
order = [(5000000,4840), (2500000,4840), (5000000,300000), (2500000,300000)]
freeze = dict(recipe_sha256=digest(Path(__file__)), access_sha256=digest(root / "access.py"),
    pin_sha256=digest(root / "known_hosts"), payload_sha256=payload, serial=SERIAL,
    address="192.168.1.14", order=order, delay_blocks=2, jitter_ms=40,
    algorithm_sha256=configuration["algorithm_sha256"], configuration_sha256=configuration["configuration_sha256"],
    live_rf=False, firmware_changed=False, full_package=False,
    scheduling="nice 10, inherited affinity; sequential rates, no IIO/network production workload")
write_json(out / "freeze.json", freeze)
scratch = None
checks, cleanup_errors = [], []


def verify_payload(label):
    inventory = recorded(out, label+"-inventory", "ls -1A " + shlex.quote(scratch))
    assert set(inventory.splitlines()) == set(paths)
    hashes = recorded(out, label+"-hashes", "sha256sum " + " ".join(
        shlex.quote(f"{scratch}/{name}") for name in paths))
    assert {Path(line.split()[1]).name:line.split()[0] for line in hashes.splitlines()} == payload


try:
    with acquire_radio_lock(SERIAL):
        try:
            idle(out, "preflight")
            original_system = system_hashes(out, "system-before")
            scratch = recorded(out, "scratch", "mktemp -d /tmp/leo-threaded-bench.XXXXXX").strip()
            assert re.fullmatch(r"/tmp/leo-threaded-bench\.[A-Za-z0-9]{6}", scratch)
            write_json(out / "owned-scratch.json", dict(path=scratch, expected_files=payload))
            for name,path in paths.items():
                result = transfer([path], f"{scratch}/{name}")
                write_json(out / f"transfer-{name}.json", dict(returncode=result.returncode,
                    stderr=result.stderr, source_sha256=payload[name], remote=f"{scratch}/{name}"))
                assert result.returncode == 0, name
            recorded(out, "private-modes", f"chmod 700 {scratch}/sdk-replay {scratch}/worker\n"
                f"chmod 600 {scratch}/2500000.templates {scratch}/5000000.templates")
            verify_payload("payload-initial")
            for index,(rate,duration) in enumerate(order):
                idle(out, f"before-{index}")
                label = f"{index}-{rate}-{duration}"
                argv = [f"{scratch}/sdk-replay", f"{scratch}/worker", f"{scratch}/{rate}.templates",
                        f"{scratch}/{rate}.pack", str(duration), "2", "40", "1",
                        freeze["algorithm_sha256"], freeze["configuration_sha256"], POSITIVE_PROFILE]
                command = f"exec env LD_LIBRARY_PATH={shlex.quote(scratch)} nice -n 10 " + shlex.join(argv)
                print(f"START {label}: ARM saved-IQ real SDK/queue/scheduler", flush=True)
                began = time.monotonic()
                result = call(command, timeout=duration/1000+30)
                write_json(out / f"{label}.execution.json", dict(command=command, returncode=result.returncode,
                    stderr=result.stderr, elapsed_s=time.monotonic()-began))
                with (out / f"{label}.jsonl").open("x") as output:
                    output.write(result.stdout)
                assert result.returncode == 0 and not result.stderr, f"remote failure {label}: {result.stderr[-500:]}"
                manifest = json.loads((Path(configuration["previous_root"]) / f"retained-workload/{rate}.manifest.json").read_text())
                checked = verify(result.stdout, manifest, duration, jitter_ms=40,
                    algorithm_sha256=freeze["algorithm_sha256"], configuration_sha256=freeze["configuration_sha256"])
                checked["raw_sha256"] = digest(out / f"{label}.jsonl")
                write_json(out / f"{label}.verification.json", checked)
                checks.append(checked)
                print(json.dumps({k:checked[k] for k in ("rate_hz","duration_ms","results","observations",
                    "choices","policy_model_matched","worker_wall_ms","callback_wall_ms",
                    "feedback_age_at_decision_ms")}), flush=True)
            idle(out, "postflight")
            assert original_system == system_hashes(out, "system-after")
            assert all(digest(p) == payload[name] for name,p in paths.items())
            write_json(out / "summary.json", dict(checks=checks, system_libraries_unchanged=True,
                inputs_unchanged=True, firmware_changed=False, new_rf=False, live_duty_qualified=False))
        finally:
            if scratch is not None:
                try:
                    # Never remove scratch if identity/idle/exact inventory fails.
                    idle(out, "cleanup-precondition")
                    verify_payload("payload-final")
                    recorded(out, "cleanup-files", "rm " + " ".join(shlex.quote(f"{scratch}/{name}") for name in paths))
                    recorded(out, "cleanup-directory", "rmdir " + shlex.quote(scratch))
                    scratch = None
                except BaseException as error:
                    cleanup_errors.append(str(error))
finally:
    write_json(out / "end.json", dict(remote_scratch_retained=scratch, cleanup_errors=cleanup_errors,
        recipe_unchanged=freeze["recipe_sha256"] == digest(Path(__file__))))

"""Exact serial/USB/LAN and pinned-this-boot identity, with idle/ownership gates."""
import json
from pathlib import Path

from preflight import lan_access, SERIAL
from arm_access import recorded, system_hashes
from pluto_plus.inventory import scan_local_usb_plutos
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import write_json

call, transfer = lan_access.call, lan_access.transfer


def idle(out, label):
    devices = [d for d in scan_local_usb_plutos() if d.serial == SERIAL]
    assert len(devices) == 1 and devices[0].usb_path == "/sys/bus/usb/devices/5-1"
    write_json(out / f"{label}-usb.json", [d.model_dump(mode="json") for d in devices])
    assert recorded(out, label+"-serial", "cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber").strip() == SERIAL
    assert recorded(out, label+"-mac", "cat /sys/class/net/eth0/address").strip() == "00:0a:35:00:01:22"
    assert "192.168.1.14/" in recorded(out, label+"-eth0", "ip -4 addr show dev eth0")
    assert recorded(out, label+"-buffers", "cat /sys/bus/iio/devices/iio:device*/buffer/enable").split() == ["0", "0"]
    network = recorded(out, label+"-network", "netstat -nt")
    assert all(":22 " in line and "192.168.1.142:" in line
               for line in network.splitlines() if line.startswith("tcp"))
    processes = recorded(out, label+"-processes", "ps")
    assert not any("/tmp/" in line and ("sdk-replay" in line or "/worker" in line
                   or "ppu-iiod-" in line or "/parent" in line) for line in processes.splitlines())
    return recorded(out, label+"-resources", "cat /proc/loadavg\ncat /proc/meminfo\ndf -Pk /tmp")


if __name__ == "__main__":
    out = Path(__file__).parent / "current-boot-preflight"
    out.mkdir(exist_ok=False)
    with acquire_radio_lock(SERIAL):
        idle(out, "identity")
        system_hashes(out, "system")
    print(json.dumps(dict(serial=SERIAL, address="192.168.1.14", idle=True,
        historical_mac_changed=True, boot_mac="00:0a:35:00:01:22", new_rf=False)), flush=True)

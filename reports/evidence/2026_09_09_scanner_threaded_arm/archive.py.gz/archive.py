"""Verify and archive bounded ARM replay receipts; render measured timing."""
import gzip
import json
from pathlib import Path
import subprocess

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from leo.contracts.scanner_glrt_frame import decode_frame
from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import BASE
from tools.qualify_scanner_glrt_shadow import verify

source = Path(__file__).parent
previous = Path("/tmp/leo-integrated-feedback.p7e840")
out = ROOT / "reports/evidence/2026_09_09_scanner_threaded_arm"
figures = ROOT / "reports/figures/2026_09_09_scanner_threaded_arm"
assert not out.exists() and not figures.exists()
end = json.loads((source / "runs/end.json").read_text())
assert end == dict(remote_scratch_retained=None, cleanup_errors=[], recipe_unchanged=True)
summary = json.loads((source / "runs/summary.json").read_text())
assert summary["system_libraries_unchanged"] and summary["inputs_unchanged"]
freeze = json.loads((source / "runs/freeze.json").read_text())
assert digest(source / "run.py") == freeze["recipe_sha256"]
assert digest(source / "access.py") == freeze["access_sha256"]
assert digest(source / "known_hosts") == freeze["pin_sha256"]
payload = json.loads((source / "assets/payload.json").read_text())
for name, row in payload.items():
    assert digest(Path(row["path"])) == row["sha256"] == freeze["payload_sha256"][name]
builds = [source / "assets/worker.build.json", previous / "arm/sdk-replay.build.json",
          previous / "arm/libleo-scanner-glrt.so.build.json"]
for path in builds:
    receipt = json.loads(path.read_text())
    assert digest(path.with_name(path.name.removesuffix(".build.json"))) == receipt["binary_sha256"]
    for field in ("sources_sha256", "dependencies_sha256"):
        for name, value in receipt.get(field, {}).items():
            assert digest(ROOT / name) == value, name

derived = []
for i, (rate, duration) in enumerate(freeze["order"]):
    raw = source / f"runs/{i}-{rate}-{duration}.jsonl"
    manifest = json.loads((previous / f"retained-workload/{rate}.manifest.json").read_text())
    checked = verify(raw.read_text(), manifest, duration, jitter_ms=40,
                     algorithm_sha256=freeze["algorithm_sha256"], configuration_sha256=freeze["configuration_sha256"])
    checked["raw_sha256"] = digest(raw)
    assert checked == json.loads(raw.with_suffix(".verification.json").read_text())
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    frames = [r for row in rows if row["kind"]=="frame" for r in decode_frame(bytes.fromhex(row["hex"])).results]
    blocks = [r for r in rows if r["kind"]=="block"]
    derived.append(dict(rate_hz=rate, duration_ms=duration, setup_ms=rows[0]["setup_ms"],
        elapsed_ms=rows[-1]["elapsed_ms"], worker_wall_mean_ms=float(np.mean([r.wall_ms for r in frames])),
        worker_cpu_mean_ms=float(np.mean([r.cpu_ms for r in frames])),
        callback_wall_mean_ms=float(np.mean([r["callback_wall_ms"] for r in blocks])),
        worker_wall_over_121ms=sum(r.wall_ms>121 for r in frames),
        callback_wall_fraction=sum(r["callback_wall_ms"] for r in blocks)/(duration),
        scope="Descriptive paced saved-IQ timing; not RF duty or isolated whole-system CPU"))

out.mkdir()
figures.mkdir()
fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True, sharey=True, layout="constrained")
for ax, rate, index, color in zip(axes, (2500000,5000000), (3,2), ("#24758e", "#b65a27"), strict=True):
    raw = source / f"runs/{index}-{rate}-300000.jsonl"
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    records = [r for row in rows if row["kind"]=="frame" for r in decode_frame(bytes.fromhex(row["hex"])).results]
    assert len(records)==2479
    x = [(r.valid_end-BASE)/rate for r in records]
    y = [r.wall_ms for r in records]
    ax.scatter(x, y, s=4, alpha=.25, color=color)
    ax.axhline(121, color="#ad3131", linestyle="--", linewidth=1, label="121 ms modeled job period")
    ax.axhline(100, color="#666666", linestyle=":", linewidth=1, label="100 ms development target")
    ax.set_title(f"{rate/1e6:g} MS/s: worker p99 {np.quantile(y,.99):.2f} ms; max {max(y):.2f} ms", loc="left", fontsize=11)
    ax.set_ylabel("Worker wall time (ms)")
    ax.grid(alpha=.15)
axes[0].legend(loc="lower right", fontsize=8)
axes[-1].set_xlabel("Modeled source time (s); 16 saved RX1 dwells repeated")
axes[-1].set_xlim(0,300)
axes[-1].set_ylim(bottom=0)
fig.suptitle("Actual ARM: SDK + feedback queue + scheduler-thread replay\nNo live RF/IIO load; compute time is not lost capture duty", fontsize=12)
figure = figures / "worker-timing-300s.png"
fig.savefig(figure, dpi=160)
plt.close(fig)
write_json(out / "derived-timing.json", derived)

artifacts = {}
files = [p for p in source.rglob("*") if p.is_file() and p.suffix in
         (".py", ".json", ".jsonl", ".log", ".stderr")]
for path in sorted(files):
    relative = str(path.relative_to(source)) + ".gz"
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    with target.open("xb") as output:
        output.write(gzip.compress(raw, compresslevel=9, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[relative] = dict(sha256=digest(target), original_sha256=digest(path), original_bytes=len(raw), source=str(path))
# Exact reused SDK/scheduler receipts, under an unignored directory name.
for path in builds[1:]:
    relative = "reused-arm/" + path.name + ".gz"
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    with target.open("xb") as output:
        output.write(gzip.compress(raw, compresslevel=9, mtime=0))
    artifacts[relative] = dict(sha256=digest(target), original_sha256=digest(path), original_bytes=len(raw), source=str(path))
write_json(out / "index.json", dict(schema="org.leo.research.threaded-arm-checkpoint/v1",
    implementation_commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
    serial=freeze["serial"], address=freeze["address"], arm_executed=True,
    new_rf=False, full_package=False, firmware_changed=False, remotely_merged=False,
    deployed=False, independent_holdout=False, artifacts=artifacts,
    derived_sha256=digest(out / "derived-timing.json"),
    figure=dict(path=str(figure.relative_to(ROOT)), sha256=digest(figure)),
    prior_desktop_index_sha256=digest(ROOT / "reports/evidence/2026_09_09_scanner_threaded_shadow/index.json")))
print(json.dumps(dict(artifacts=len(artifacts), figure=str(figure), derived=derived), indent=2))

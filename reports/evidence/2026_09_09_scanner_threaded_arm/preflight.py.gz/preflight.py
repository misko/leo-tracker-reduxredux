"""User-approved rotating key; pin this boot and verify the exact idle spare."""
import sys
from pathlib import Path
import subprocess

sys.path[:0] = ["/tmp/leo-presence-symbol-support.b0iza3SZ", "/tmp/leo-presence-holdout.8JIL7Y"]
import lan_access
from arm_access import SERIAL, idle, system_hashes
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import digest, write_json

ROOT = Path(__file__).parent
lan_access.OPTIONS = [v.replace("/tmp/leo-presence-holdout.8JIL7Y/known_hosts", str(ROOT / "known_hosts"))
                      for v in lan_access.OPTIONS]

if __name__ == "__main__":
    out = ROOT / "preflight"
    out.mkdir(exist_ok=False)
    fingerprint = subprocess.check_output(["ssh-keygen", "-lf", str(ROOT / "known_hosts")], text=True)
    write_json(out / "key-acceptance.json", dict(
        authorization="User: ssh key changes on each reboot, its fine",
        scope="Only intended spare 192.168.1.14; strict pin for this boot",
        fingerprint=fingerprint.strip(), known_hosts_sha256=digest(ROOT / "known_hosts")))
    with acquire_radio_lock(SERIAL):
        idle(out, "identity")
        system_hashes(out, "system")
    print("Exact USB/LAN serial, MAC, address, idle buffers and ownership verified", flush=True)

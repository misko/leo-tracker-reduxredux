"""One read-only snapshot of our exact remote processes; no sampling loop."""
import json
from pathlib import Path
import re
import sys

from access import recorded

root = Path(__file__).parent
label = sys.argv[1]
assert re.fullmatch(r"[a-z0-9-]+", label)
scratch = json.loads((root / "runs/owned-scratch.json").read_text())["path"]
assert re.fullmatch(r"/tmp/leo-threaded-bench\.[A-Za-z0-9]{6}", scratch)
out = root / "snapshots"
out.mkdir(exist_ok=True)
# Only emit status for executable paths belonging to this run, never cmdline
# or environment. /proc is read-only; no affinity/governor/priority writes.
command = f"""for task_pid in $(pidof sdk-replay worker); do
task_exe=$(readlink /proc/$task_pid/exe)
case "$task_exe" in
{scratch}/sdk-replay|{scratch}/worker)
printf '%s\\n' "$task_exe"
cat /proc/$task_pid/status
cat /proc/$task_pid/stat
;;
esac
done
cat /proc/loadavg
cat /proc/meminfo
cat /proc/cpuinfo
for clock_path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq; do
if test -r "$clock_path"; then cat "$clock_path"; fi
done
"""
recorded(out, label, command)
print("Read-only process/CPU/memory snapshot retained: " + label, flush=True)

"""Build the same frozen numerical worker for Cortex-A9; no radio IO."""
import json
from pathlib import Path

from tools.native_presence import ROOT, build_worker
from tools.presence_fftw import fftw_options
from tools.qualify_native_presence import digest, write_json

out = Path(__file__).parent / "assets"
out.mkdir(exist_ok=False)
previous = Path("/tmp/leo-integrated-feedback.p7e840")
flags = tuple(json.loads((previous / "workload/freeze.json").read_text())["flags"])
compiler = "/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc"
fftw = fftw_options(Path("/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr"), runtime_rpath=False)
worker = build_worker(out / "worker", compiler=compiler,
                      cflags=flags+("-mcpu=cortex-a9", "-mfpu=neon", "-mfloat-abi=hard")+fftw["cflags"],
                      ldflags=fftw["ldflags"], dependencies=fftw["dependencies"])
worker.chmod(0o700)
paths = {"worker": worker}
for name in ("sdk-replay", "libleo-scanner-glrt.so"):
    path = previous / "arm" / name
    receipt = json.loads(path.with_name(name+".build.json").read_text())
    assert digest(path) == receipt["binary_sha256"]
    for p, sha in receipt["sources_sha256"].items():
        assert digest(ROOT / p) == sha, p
    paths[name] = path
for rate in (2500000, 5000000):
    manifest = json.loads((previous / f"retained-workload/{rate}.manifest.json").read_text())
    for suffix in ("pack", "templates"):
        path = previous / f"retained-workload/{rate}.{suffix}"
        assert digest(path) == manifest[f"{suffix}_sha256"]
        paths[path.name] = path
paths["libfftw3.so.3"] = Path(next(p for p in fftw["dependencies"] if ".so" in str(p)))
write_json(out / "payload.json", {name:dict(path=str(path), sha256=digest(path)) for name,path in paths.items()})
write_json(out / "freeze.json", dict(recipe_sha256=digest(Path(__file__)), previous_root=str(previous),
    numerical_flags=flags, configuration_sha256=digest(previous / "retained-workload/freeze.json"),
    algorithm_sha256=digest(worker), new_rf=False, full_package=False,
    intended_runs_ms=[4840,300000], rates_hz=[2500000,5000000], jitter_ms=40, delay_blocks=2))
print("Prepared current ARM worker and pinned SDK/scheduler/positive-rich saved IQ", flush=True)

"""Freeze explicit packaging/test receipts; no credentials or duplicated native payloads."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
destination = repo / "reports/evidence/2026_09_09_scanner_bundle_release"
destination.mkdir(parents=True, exist_ok=False)
files = [(root / name, name) for name in (
    "bundle-tests.xml", "deploy-all.xml", "deploy-final.xml", "source-audit.json",
    "audit_candidate_sources.py", "verify_local_companions_before.py", "verify_local_companions.py",
    "local-attempt2/local-companions.json", "archive_checkpoint.py")]
original = Path("/tmp/leo-scanner-source-pressure-bundle.6V1rnV/release")
files.extend((original / name, "original-build/" + name) for name in (
    "worker.build.json", "libleo-scanner-glrt.so.build.json"))
files.extend((repo / name, "source/" + name) for name in (
    ".gitignore", "config/ops-components.json", "deploy/scripts/validate-scanner-glrt-bundle",
    "deploy/scripts/stage-production-release", "deploy/scripts/validate-published-release",
    "deploy/scripts/validate-release-metadata", "tests/deploy/test_scanner_glrt_bundle.py",
    "tests/deploy/test_release_metadata.py", "tests/deploy/test_ops_front_door.py"))
artifacts, tests = [], []
for source, name in files:
    assert source.is_file() and not source.is_symlink()
    raw = source.read_bytes()
    if source.suffix == ".xml":
        suites = list(ET.fromstring(raw).iter("testsuite"))
        counts = {key: sum(int(s.get(key, "0")) for s in suites)
                  for key in ("tests", "failures", "errors", "skipped")}
        assert counts["tests"] and not any(counts[key] for key in ("failures", "errors", "skipped"))
        tests.append(dict(source=name, **counts))
    compressed = gzip.compress(raw, mtime=0)
    target = destination / (name + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(compressed)
    artifacts.append(dict(source=str(source), archive=str(target.relative_to(destination)), bytes=len(raw),
                          sha256=hashlib.sha256(raw).hexdigest(),
                          archive_sha256=hashlib.sha256(compressed).hexdigest()))
patch = subprocess.check_output(("git", "-C", str(repo), "diff", "--binary"))
with (destination / "tracked-changes.patch.gz").open("xb") as stream:
    stream.write(gzip.compress(patch, mtime=0))
document = dict(schema="org.leo.research.scanner-bundle-release-checkpoint/v1", artifacts=artifacts,
                tests=tests, scope="same-byte release packaging and local tests; no RF/ARM execution or remote promotion",
                original_bundle_manifest_sha256="19c3650480a8386b12384b0f9a0c5d49e237b04ad98f474d3e703d3f820ddd7c",
                original_build_reproducibility="namespace embeds in binaries; no bit-reproducible cross-build claim",
                initial_local_harness_failure="documentation-range IP rejected before staging; fixture corrected without weakening the transport contract",
                licenses={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sorted((repo / "docs/dependencies/scanner-glrt-licenses").iterdir())},
                overlapping_test_runs=True, tracked_patch_sha256=hashlib.sha256(patch).hexdigest())
with (destination / "index.json").open("x") as stream:
    json.dump(document, stream, indent=2)
    stream.write("\n")
for item in artifacts:
    compressed = (destination / item["archive"]).read_bytes()
    assert hashlib.sha256(compressed).hexdigest() == item["archive_sha256"]
    assert hashlib.sha256(gzip.decompress(compressed)).hexdigest() == item["sha256"]
print(json.dumps(dict(archives=len(artifacts), tests=tests), indent=2))

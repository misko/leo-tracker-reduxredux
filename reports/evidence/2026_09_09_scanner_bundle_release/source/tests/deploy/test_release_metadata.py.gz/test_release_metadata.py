from __future__ import annotations

import hashlib
import json
import os
import runpy
import shutil
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parents[2]
VALIDATOR = PROJECT_ROOT / "deploy" / "scripts" / "validate-release-metadata"
GLOBALS = runpy.run_path(str(VALIDATOR))
REVISION = "f" * 40


def test_production_runtime_identity_is_persistent_hop_libiio() -> None:
    assert GLOBALS["PRODUCTION_METADATA_ABI"] == 3
    assert GLOBALS["PRODUCTION_LIBIIO_SOURCE_COMMIT"] == "f6c450eada95ce99fe8756ebc244bfcf6ddcc72a"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _published(
    tmp_path: Path,
    *,
    revision: str = REVISION,
    uv_bytes: bytes = b"uv-binary",
    runtime_source: str | None = None,
    scanner_bundle: bool = False,
) -> tuple[Path, Path]:
    root = tmp_path / "leo-tracker"
    release = root / "releases" / revision
    metadata = root / "release-metadata" / f"{revision}.txt"
    tooling = release / ".release-tools/uv"
    python = tmp_path / "system-bin/python3.14"
    (release / "web").mkdir(parents=True)
    metadata.parent.mkdir()
    tooling.parent.mkdir()
    python.parent.mkdir()
    tooling.write_bytes(uv_bytes)
    source_identity = release / ".leo-release-source.json"
    tree = "e" * 40
    source_identity.write_text(
        f'{{"schema":"org.leo.release-source/v1","revision":"{revision}","tree":"{tree}"}}\n'
    )
    python.write_text("#!/bin/sh\nprintf '3.14\\n'\n")
    python.chmod(0o755)
    (release / "uv.lock").write_text("python-lock\n")
    (release / "web/package-lock.json").write_text("node-lock\n")
    scanner_iiod = release / "runtime/scanner-iiod/iiod"
    scanner_iiod_provenance = release / "runtime/scanner-iiod/provenance.json"
    scanner_iiod.parent.mkdir(parents=True)
    scanner_iiod.write_bytes(b"reviewed scanner iiod fixture")
    scanner_iiod_provenance.write_text('{"schema":"fixture"}\n')
    native = release / ".venv/lib/libiio.so.0.25"
    binding = release / ".venv/lib/python3.14/site-packages/iio.py"
    receipt = release / ".venv/share/pluto-plus-utils/metadata-runtime.json"
    native.parent.mkdir(parents=True)
    binding.parent.mkdir(parents=True)
    receipt.parent.mkdir(parents=True)
    native.write_bytes(b"metadata libiio ABI 3")
    binding.write_text("# patched pylibiio\n")
    receipt.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "metadata_abi": 3,
                "source_commit": runtime_source or GLOBALS["PRODUCTION_LIBIIO_SOURCE_COMMIT"],
                "native_libiio_path": str(native),
                "pylibiio_path": str(binding),
            }
        )
    )
    paths = (
        python,
        tooling,
        source_identity,
        release / "uv.lock",
        release / "web/package-lock.json",
        scanner_iiod,
        scanner_iiod_provenance,
        receipt,
        native,
        binding,
    )
    if scanner_bundle:
        destination = release / "runtime/scanner-glrt"
        shutil.copytree(PROJECT_ROOT / "runtime/scanner-glrt", destination)
        names = (
            "bundle.json",
            "algorithm.json",
            "configuration.json",
            "iiod",
            "worker",
            "libleo-scanner-glrt.so",
            "libfftw3.so.3",
            "libiio.so.0",
            "libxml2.so.2",
            "libz.so.1",
            "templates-2500000.bin",
            "templates-5000000.bin",
        )
        for name in names:
            (destination / name).chmod(0o550 if name in ("iiod", "worker") else 0o440)
        paths += tuple(destination / name for name in names)
    metadata.write_text(
        f"revision={revision}\n"
        f"python={python}\n"
        "python_version=3.14\n" + "".join(f"{_sha256(path)}  {path}\n" for path in paths)
    )
    metadata.chmod(0o440)
    for path in (release, *release.rglob("*")):
        if not path.is_symlink():
            path.chmod(path.stat().st_mode & ~0o022)
    return release, metadata


def _validate(release: Path, metadata: Path, *, revision: str = REVISION, **kwargs: object) -> None:
    GLOBALS["validate"](
        release,
        metadata,
        revision,
        expected_uid=os.getuid(),
        expected_gid=os.getgid(),
        expected_python_prefix=release.parents[2] / "system-bin",
        expected_python_uid=os.getuid(),
        **kwargs,
    )


def test_external_metadata_seals_exact_immutable_tree(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    _validate(release, metadata)


@pytest.mark.parametrize("runtime", (None, "a1088b61de3c57762cfed5533e1baf8076a7b726"))
def test_bundle_inventory_is_sealed_independently_of_runtime_selection(
    tmp_path: Path, runtime: str | None
) -> None:
    release, metadata = _published(tmp_path, runtime_source=runtime, scanner_bundle=True)
    _validate(release, metadata)
    assert len(metadata.read_text().splitlines()) == 25


def test_bundle_cannot_be_added_without_sealing_its_inventory(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path, scanner_bundle=True)
    metadata.chmod(0o640)
    metadata.write_text("\n".join(metadata.read_text().splitlines()[:13]) + "\n")
    metadata.chmod(0o440)
    with pytest.raises(ValueError, match="cardinality"):
        _validate(release, metadata)


def test_resealed_modified_bundle_is_not_the_reviewed_candidate(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path, scanner_bundle=True)
    worker = release / "runtime/scanner-glrt/worker"
    old = _sha256(worker)
    worker.chmod(0o750)
    worker.write_bytes(b"changed worker")
    worker.chmod(0o550)
    metadata.chmod(0o640)
    metadata.write_text(metadata.read_text().replace(old, _sha256(worker)))
    metadata.chmod(0o440)
    with pytest.raises(ValueError, match="payload digest/size mismatch"):
        _validate(release, metadata)


SCANNER_GLRT_SOURCE = "a1088b61de3c57762cfed5533e1baf8076a7b726"


def test_scanner_runtime_is_an_exact_additional_identity_not_a_new_default(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path, runtime_source=SCANNER_GLRT_SOURCE)
    _validate(release, metadata)
    _validate(release, metadata, expected_runtime_profile="scanner-glrt")
    with pytest.raises(ValueError, match="requested runtime profile"):
        _validate(release, metadata, expected_runtime_profile="persistent-hop")
    assert GLOBALS["PRODUCTION_LIBIIO_SOURCE_COMMIT"] == "f6c450eada95ce99fe8756ebc244bfcf6ddcc72a"


def test_scanner_opt_in_cannot_reuse_a_legacy_runtime_release(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    _validate(release, metadata, expected_runtime_profile="persistent-hop")
    with pytest.raises(ValueError, match="requested runtime profile"):
        _validate(release, metadata, expected_runtime_profile="scanner-glrt")


def test_unknown_runtime_profile_is_rejected(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    with pytest.raises(ValueError, match="unknown runtime profile"):
        _validate(release, metadata, expected_runtime_profile="anything-abi3")


@pytest.mark.parametrize("source", ("0" * 40, "4323b93a17ff2a0e8954fc5ffd9367a40540bebe"))
def test_other_native_revisions_are_rejected_even_when_metadata_is_sealed(
    tmp_path: Path, source: str
) -> None:
    release, metadata = _published(tmp_path, runtime_source=source)
    with pytest.raises(ValueError, match="production ABI 3 runtime"):
        _validate(release, metadata)


def test_scanner_native_bytes_remain_sealed(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path, runtime_source=SCANNER_GLRT_SOURCE)
    (release / ".venv/lib/libiio.so.0.25").write_bytes(b"different native runtime")
    with pytest.raises(ValueError, match="digest does not verify"):
        _validate(release, metadata)


def test_scanner_receipt_relabel_cannot_change_a_sealed_release(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    receipt = release / ".venv/share/pluto-plus-utils/metadata-runtime.json"
    document = json.loads(receipt.read_text())
    document["source_commit"] = SCANNER_GLRT_SOURCE
    receipt.write_text(json.dumps(document))
    with pytest.raises(ValueError, match="digest does not verify"):
        _validate(release, metadata, expected_runtime_profile="scanner-glrt")


def test_metadata_digest_tamper_fails(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    (release / "uv.lock").chmod(0o640)
    (release / "uv.lock").write_text("changed\n")
    (release / "uv.lock").chmod(0o440)
    with pytest.raises(ValueError, match="digest does not verify"):
        _validate(release, metadata)


def test_metadata_native_runtime_tamper_fails(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    native = release / ".venv/lib/libiio.so.0.25"
    native.chmod(0o640)
    native.write_bytes(b"changed metadata runtime")
    native.chmod(0o440)
    with pytest.raises(ValueError, match="digest does not verify"):
        _validate(release, metadata)


@pytest.mark.parametrize(
    "source_commit",
    (
        "1e5002702f3033f5bc741da315dfe5d5558ef394",
        "f72a72602e4ac0173bc7dd5842d831007baa3582",
    ),
)
def test_prior_runtime_identity_is_rejected_even_with_matching_file_hashes(
    tmp_path: Path, source_commit: str
) -> None:
    release, metadata = _published(tmp_path)
    receipt = release / ".venv/share/pluto-plus-utils/metadata-runtime.json"
    document = json.loads(receipt.read_text())
    document["source_commit"] = source_commit
    receipt.chmod(0o640)
    receipt.write_text(json.dumps(document))
    receipt.chmod(0o440)
    with pytest.raises(ValueError, match="production ABI 3 runtime"):
        _validate(release, metadata)


def test_metadata_python_version_mismatch_fails(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    metadata.chmod(0o640)
    metadata.write_text(metadata.read_text().replace("python_version=3.14", "python_version=3.12"))
    metadata.chmod(0o440)

    with pytest.raises(ValueError, match="path and observed version"):
        _validate(release, metadata)


def test_metadata_python_executable_replacement_fails(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    python = release.parents[2] / "system-bin/python3.14"
    python.write_text("#!/bin/sh\nprintf '3.14\\n'\n# replacement\n")

    with pytest.raises(ValueError, match="digest does not verify"):
        _validate(release, metadata)


def test_later_stage_with_different_uv_does_not_invalidate_older_release(
    tmp_path: Path,
) -> None:
    revision_a = "a" * 40
    revision_b = "b" * 40
    release_a, metadata_a = _published(tmp_path / "a", revision=revision_a, uv_bytes=b"uv-a")
    release_b, metadata_b = _published(tmp_path / "b", revision=revision_b, uv_bytes=b"uv-b")

    _validate(release_b, metadata_b, revision=revision_b)
    _validate(release_a, metadata_a, revision=revision_a)


def test_incomplete_and_validation_failed_markers_fail_closed(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    incomplete = release / ".leo-release-incomplete"
    incomplete.write_text("")
    incomplete.chmod(0o440)
    with pytest.raises(ValueError, match="incomplete marker"):
        _validate(release, metadata)
    metadata_temp = metadata.parent / f".{REVISION}.fixture.tmp"
    metadata.rename(metadata_temp)
    _validate(release, metadata_temp, allow_incomplete=True)
    metadata_temp.rename(metadata)

    incomplete.unlink()
    failed = release / ".leo-release-validation-failed"
    failed.write_text("")
    failed.chmod(0o440)
    with pytest.raises(ValueError, match="validation-failed"):
        _validate(release, metadata)


def test_group_writable_release_entry_fails(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    artifact = release / "uv.lock"
    artifact.chmod(0o460)
    with pytest.raises(ValueError, match="group/other writable"):
        _validate(release, metadata)


def test_release_tree_qnap_symlink_fails_without_target_access(tmp_path: Path) -> None:
    release, metadata = _published(tmp_path)
    (release / "forbidden-link").symlink_to("/mnt/qnap01/must-not-be-opened")
    with pytest.raises(ValueError, match="beneath QNAP"):
        _validate(release, metadata)

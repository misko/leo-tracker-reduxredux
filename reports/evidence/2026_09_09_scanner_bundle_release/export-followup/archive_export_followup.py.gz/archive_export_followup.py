"""Retain the permission/export correction separately from the first frozen snapshot."""
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
evidence = repo / "reports/evidence/2026_09_09_scanner_bundle_release"
files = [(root / name, name) for name in (
    "verify_git_export_before.py", "verify_git_export.py", "deploy-after-export.xml",
    "deploy-qualified-export.xml", "archive_export_followup.py")]
files += [(repo / name, "source/" + name) for name in (
    "deploy/scripts/stage-production-release", "tests/deploy/test_systemd_templates.py",
    "tests/deploy/test_scanner_glrt_bundle.py")]
artifacts = []
for source, name in files:
    raw = source.read_bytes()
    if source.suffix == ".xml":
        suites = list(ET.fromstring(raw).iter("testsuite"))
        assert not any(int(s.get(key, "0")) for s in suites for key in ("failures", "errors", "skipped"))
    compressed = gzip.compress(raw, mtime=0)
    archive = evidence / "export-followup" / (name + ".gz")
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open("xb") as stream:
        stream.write(compressed)
    artifacts.append(dict(source=str(source), archive=str(archive.relative_to(evidence)),
                          bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                          archive_sha256=hashlib.sha256(compressed).hexdigest()))
result = dict(schema="org.leo.research.scanner-bundle-export-followup/v1", artifacts=artifacts,
              git_export_receipt="git-export.json",
              git_export_receipt_sha256=hashlib.sha256((evidence / "git-export.json").read_bytes()).hexdigest(),
              failure="Initial archive fixture directory was group-writable; pre-seal validator refused it",
              correction="Explicit git tar.umask=0027 and actual GNU-tar export; no trust checks relaxed",
              final_deployment_tests=282, radio_accessed=False, full_release_build=False)
with (evidence / "export-followup.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
for entry in artifacts:
    raw = (evidence / entry["archive"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == entry["archive_sha256"]
    assert hashlib.sha256(gzip.decompress(raw)).hexdigest() == entry["sha256"]
print(json.dumps(dict(verified_archives=len(artifacts), deployment_tests=282)))

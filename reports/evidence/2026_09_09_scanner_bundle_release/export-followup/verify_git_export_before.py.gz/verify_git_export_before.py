"""Verify exact staged Git-object packaging in a separate disposable filesystem tree."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
tree = subprocess.check_output(("git", "-C", str(repo), "write-tree"), text=True).strip()
archive = subprocess.check_output(("git", "-C", str(repo), "archive", "--format=tar", tree,
                                   "runtime/scanner-glrt", "deploy/scripts/validate-scanner-glrt-bundle",
                                   "docs/dependencies/scanner-glrt-licenses"))
export = root / "git-export"
export.mkdir(mode=0o700)
with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as stream:
    stream.extractall(export, filter="data")
completed = subprocess.run((sys.executable, str(export / "deploy/scripts/validate-scanner-glrt-bundle"),
                            str(export), "--staged"), check=True, capture_output=True, text=True)
observed = json.loads(completed.stdout)
assert observed == {"present": True, "files": 12, "executed": False}
assert {p.name for p in (export / "runtime/scanner-glrt").iterdir()} == {
    p.name for p in (repo / "runtime/scanner-glrt").iterdir()}
for source in (repo / "runtime/scanner-glrt").iterdir():
    assert source.read_bytes() == (export / "runtime/scanner-glrt" / source.name).read_bytes()
result = dict(passed=True, staged_git_tree=tree, tar_sha256=hashlib.sha256(archive).hexdigest(),
              observed=observed, radio_accessed=False, arm_executed=False,
              full_release_build=False, source=str(repo), export=str(export),
              limitation="Git-object asset export only, not full dependency installation, web build or root-sealed release staging")
evidence = repo / "reports/evidence/2026_09_09_scanner_bundle_release"
with (evidence / "git-export.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result, indent=2))

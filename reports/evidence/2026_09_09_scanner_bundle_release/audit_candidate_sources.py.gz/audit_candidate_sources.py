"""Check unchanged candidate build inputs and packaged bytes; never rebuild or run ARM."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
repo = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
original = Path("/tmp/leo-scanner-source-pressure-bundle.6V1rnV/release")
packaged = repo / "runtime/scanner-glrt"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

artifacts = []
for path in sorted(packaged.iterdir()):
    assert path.is_file() and not path.is_symlink()
    assert path.read_bytes() == (original / path.name).read_bytes()
    artifacts.append(dict(name=path.name, bytes=path.stat().st_size, sha256=sha(path)))
counts = {}
for name in ("worker", "libleo-scanner-glrt.so"):
    document = json.loads((original / (name + ".build.json")).read_text())
    assert sha(packaged / name) == document["binary_sha256"]
    for relative, digest in document["sources_sha256"].items():
        assert sha(repo / relative) == digest, relative
    for path, digest in document.get("dependencies_sha256", {}).items():
        assert sha(Path(path)) == digest, path
    counts[name] = len(document["sources_sha256"])
algorithm = json.loads((original / "algorithm.json").read_text())
for path, digest in algorithm["provider_sources_sha256"].items():
    assert sha(Path(path)) == digest, path
counts["provider"] = len(algorithm["provider_sources_sha256"])
libiio = Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration")
assert not subprocess.check_output(("git", "-C", str(libiio), "status", "--porcelain"), text=True).strip()
provider_revision = subprocess.check_output(("git", "-C", str(libiio), "rev-parse", "HEAD"), text=True).strip()
assert provider_revision == "4323b93a17ff2a0e8954fc5ffd9367a40540bebe"
result = dict(passed=True, packaged_files=artifacts, current_source_hash_counts=counts,
              provider_revision=provider_revision, rebuilt=False, arm_executed=False,
              qualification="same tested bytes; no new RF or bit-reproducible cross-build claim")
with (root / "source-audit.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(passed=True, source_hash_counts=counts, files=len(artifacts)), indent=2))

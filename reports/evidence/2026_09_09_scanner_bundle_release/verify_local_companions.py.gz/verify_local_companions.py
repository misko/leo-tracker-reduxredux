"""Run real PPU companion shell operations locally with the exact staged bytes.

No SSH subprocess, radio, daemon execution, or firmware command is permitted.
Only the test directory and expected local uid substitute for the ARM namespace.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from pluto_plus.userspace_iiod import PinnedPasswordSshIiodTransport, SshCommandResult, UserspaceIiodLifecycleError
from pluto_plus.userspace_iiod_bundle import load_iiod_companion_bundle

root = Path(__file__).resolve().parent / "local-attempt2"
root.mkdir(mode=0o700)
manifest = Path("/home/mouse9911/gits/leo-tracker-arm-presence/runtime/scanner-glrt/bundle.json")
bundle = load_iiod_companion_bundle(manifest)
namespace = root / "local-companions"
assert not namespace.exists()
host = "192.168.1.18"  # Required protocol shape only; LocalRunner never executes SSH.
token = "9" * 32
known, password = root / "fixture-known-hosts", root / "fixture-password"
for path, value in ((known, f"{host} ssh-ed25519 AAAATEST\n"), (password, "synthetic-not-a-secret\n")):
    with path.open("x") as stream:
        stream.write(value)
    path.chmod(0o600)
sentinel = root / "unrelated-sentinel"
with sentinel.open("x") as stream:
    stream.write("preserve\n")


class LocalRunner:
    calls = 0

    def run(self, argv, *, stdin, timeout_s):
        assert argv[0] == "sshpass" and argv[-2] == f"root@{host}"
        assert "StrictHostKeyChecking=yes" in argv
        assert bundle.remote_directory in argv[-1]
        command = argv[-1].replace(bundle.remote_directory, str(namespace))
        if stdin is not None and stdin.startswith(b"set -eu\n"):
            stdin = stdin.replace(b"'drwx------:0'", f"'drwx------:{os.geteuid()}'".encode())
            stdin = stdin.replace(b"'-rw-------:1:0'", f"'-rw-------:1:{os.geteuid()}'".encode())
            stdin = stdin.replace(b'"$permissions:1:0"', f'"$permissions:1:{os.geteuid()}"'.encode())
        result = subprocess.run(("/bin/sh", "-c", command), input=stdin,
                                capture_output=True, timeout=timeout_s, check=False)
        self.calls += 1
        return SshCommandResult(result.returncode, result.stdout, result.stderr)


runner = LocalRunner()
transport = PinnedPasswordSshIiodTransport(host=host, expected_serial="1040007c4a94000211000b009186843ef2",
                                         known_hosts_file=known, password_file=password, runner=runner)
transport.stage_companions(bundle, token)
assert {p.name for p in namespace.iterdir()} == {"owner", *(f.name for f in bundle.files)}
for item in bundle.files:
    path = namespace / item.name
    assert path.read_bytes() == item.payload
    assert path.stat().st_mode & 0o777 == (0o700 if item.executable else 0o600)
transport.verify_companions(bundle, token)
worker = namespace / "worker"
original = worker.read_bytes()
worker.write_bytes(b"X" * len(original))
try:
    transport.cleanup_companions(bundle, token)
except UserspaceIiodLifecycleError:
    pass
else:
    raise AssertionError("tampered bundle cleanup was not refused")
assert worker.exists()
worker.write_bytes(original)
worker.chmod(0o700)
transport.verify_companions(bundle, token)
transport.cleanup_companions(bundle, token)
transport.cleanup_companions(bundle, token)
assert not namespace.exists() and sentinel.read_text() == "preserve\n"
result = dict(passed=True, scope="actual PPU shell operations on local fixture filesystem; not target BusyBox/ARM execution",
              radio_accessed=False, ssh_executed=False, arm_code_executed=False,
              manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
              companions=len(bundle.files), companion_bytes=sum(len(f.payload) for f in bundle.files),
              shell_calls=runner.calls, tampered_cleanup_refused=True,
              owned_namespace_removed=True, unrelated_sentinel_preserved=True)
with (root / "local-companions.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result, indent=2))

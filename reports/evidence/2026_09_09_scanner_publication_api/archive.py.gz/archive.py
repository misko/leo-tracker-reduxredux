"""Archive bounded localhost qualification receipts, never IQ or executables."""
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

out = Path(__file__).resolve().parent
root = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
destination = root / 'reports/evidence/2026_09_09_scanner_publication_api'

def sha(data):
    return hashlib.sha256(data).hexdigest()

network = ET.parse(out / 'network-publication-retry.xml').getroot()
regression = ET.parse(out / 'regression.xml').getroot()
for tree, count in ((network, 12), (regression, 68)):
    cases = tree.findall('.//testcase')
    assert len(cases) == count
    assert not tree.findall('.//failure') + tree.findall('.//error') + tree.findall('.//skipped')
cases = []
for case in network.findall('.//testcase'):
    properties = {item.attrib['name']: item.attrib['value']
                  for item in case.findall('./properties/property')}
    assert properties['published_recording_http_verified'] == 'True'
    cases.append(dict(name=case.attrib['name'], seconds=case.attrib['time'], properties=properties))
web = json.loads((out / 'web.json').read_bytes())
assert web['success'] and web['numPassedTests'] == web['numTotalTests'] == 69
assert web['numFailedTests'] == web['numPendingTests'] == 0
changed = {}
for name, digest in json.loads((out / 'source-freeze.json').read_bytes()).items():
    current = sha(Path(name).read_bytes())
    if current != digest:
        changed[name] = dict(before=digest, after=current)
assert set(changed) <= {
    str(out / 'build.py'), str(root / 'tests/radio/test_adaptive_hop_scheduled_network.py')
}
for name in ('sdk.so', 'worker'):
    receipt = json.loads((out / (name + '.build.json')).read_bytes())
    assert receipt['binary_sha256'] == sha((out / name).read_bytes())
    for source, digest in receipt['sources_sha256'].items():
        assert sha((root / source).read_bytes()) == digest
for rate in (2500000, 5000000):
    assert (out / f'templates-{rate}').stat().st_mode & 0o777 == 0o600
fixture = json.loads((out / 'fixture.json').read_bytes())
assert fixture['server_sha256'] == sha((out / 'build/iiod/test_scanner_glrt_network_server').read_bytes())
assert fixture['library_sha256'] == sha((out / 'build/libiio.so').read_bytes())
destination.mkdir(exist_ok=False)
artifacts = []
for name in ('build.py', 'archive.py', 'configure.json', 'build.json', 'fixture.json',
             'source-freeze.json', 'sdk.so.build.json', 'worker.build.json',
             'network-publication.xml', 'network-publication-retry.xml', 'regression.xml', 'web.json'):
    data = (out / name).read_bytes()
    compressed = gzip.compress(data, mtime=0)
    (destination / (name + '.gz')).write_bytes(compressed)
    artifacts.append(dict(path=name + '.gz', bytes=len(data), sha256=sha(data),
                          compressed_sha256=sha(compressed)))
index = dict(
    scope='Protected native localhost -> scheduled IQ/GLRT publication -> read-only ASGI API; no RF',
    native_build=fixture, network_cases=cases, selected_regressions=68, selected_web_tests=69,
    initial_failure='Template files were created 0664 and rejected by SDK trusted-file admission. '
                    'Only local generated template permissions were corrected to 0600; '
                    'no runtime security check or numerical expectation changed.',
    source_changes_after_native_build=changed,
    source_change_explanation='Test formatting and public store cleanup finalized before execution; '
                              'local build recipe corrected to set template mode 0600. '
                              'All frozen native/provider/header sources remain unchanged.',
    source_heads={str(path): subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path,
                                                    text=True).strip()
                  for path in (root, Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration'),
                               Path('/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host'))},
    exercised_test_sha256=sha((root / 'tests/radio/test_adaptive_hop_scheduled_network.py').read_bytes()),
    open_gates=['authorized live RF duty/continuity and adaptive allocation verification',
                'deployed browser, analysis cadence throughput and operational restoration',
                'coordinated remote merges and deployment'],
    artifacts=artifacts,
)
(destination / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for item in artifacts:
    data = (destination / item['path']).read_bytes()
    assert sha(data) == item['compressed_sha256']
    assert sha(gzip.decompress(data)) == item['sha256']
print(json.dumps(dict(path=str(destination), artifacts=len(artifacts),
                      network_tests=len(cases), regressions=68, web_tests=69)), flush=True)

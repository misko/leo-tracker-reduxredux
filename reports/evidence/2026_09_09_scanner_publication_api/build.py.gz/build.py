"""Fresh protected localhost fixture; no radio or deployment operations."""
import hashlib
import json
import subprocess
from pathlib import Path

from tools.native_presence import ROOT, build_scanner_glrt_port, build_worker, write_templates

out = Path(__file__).resolve().parent
libiio = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
previous = Path('/tmp/leo-capture-protection.SsUyjA')
build = out / 'build'

def save(name, value):
    with (out / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

config = json.loads((ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json').read_bytes())
flags = tuple(config['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{key}={value}' for key, value in config['variants'][0]['defines'].items()
) + tuple(f'-DLEO_PRESENCE_{name}=1' for name in (
    'DIFFERENTIAL_CI16', 'RANK_HYBRID_PROJECTION', 'RANK_AMPLITUDE_WEIGHTED',
    'GLRT_SYMBOL_DIVERSITY', 'BOUNDED_MAGNITUDE', 'CONDITIONED_BLOCK_ROTATION',
    'ENERGY_SUPPORT', 'ENERGY_SYMBOL_SUPPORT',
))
sdk = build_scanner_glrt_port(out / 'sdk.so')
worker = build_worker(out / 'worker', cflags=flags)
worker.chmod(0o700)
for rate in (2500000, 5000000):
    template = out / f'templates-{rate}'
    write_templates(template, rate)
    template.chmod(0o600)

old = json.loads((previous / 'positive-only-v1-protection-ON-configure-retry.json').read_bytes())
command = [arg.replace(str(previous), str(out)) for arg in old['command']]
command[command.index('-B') + 1] = str(build)
assert '-DIIOD_SCANNER_GLRT_CAPTURE_PROTECTION=ON' in command
assert '-DIIOD_SCANNER_ADAPTIVE_HOP=ON' in command
assert '-DIIOD_SCANNER_GLRT_MODE=positive-only-v1' in command
tracked = subprocess.check_output(['git', 'ls-files'], cwd=libiio, text=True).splitlines()
paths = [libiio / name for name in tracked]
paths += [ROOT / 'tests/radio/test_adaptive_hop_scheduled_network.py', Path(__file__)]
for arg in command:
    if arg.startswith('-DIIOD_BUFFER_METADATA_PROVIDER_EXTRA_SOURCES='):
        paths.extend(Path(name) for name in arg.split('=', 1)[1].split(';'))
    if arg.startswith('-DIIOD_BUFFER_METADATA_INCLUDE_DIRS='):
        for name in arg.split('=', 1)[1].split(';'):
            paths.extend(Path(name).rglob('*.h'))
source_hashes = {str(path): sha(path) for path in paths if path.is_file()}
save('source-freeze.json', source_hashes)
for stage, args in (
    ('configure', command),
    ('build', ['cmake', '--build', str(build), '--target',
               'test_scanner_glrt_network_server', '-j', '2']),
):
    result = subprocess.run(args, text=True, capture_output=True, timeout=180)
    save(stage + '.json', dict(command=args, returncode=result.returncode,
                              stdout=result.stdout, stderr=result.stderr))
    print(stage, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-3000:])
assert source_hashes == {path: sha(Path(path)) for path in source_hashes}
save('fixture.json', dict(
    scope='Fresh protected desktop localhost fixture; not ARM/live-RF/deployment',
    sdk_sha256=sha(sdk), worker_sha256=sha(worker),
    server_sha256=sha(build / 'iiod/test_scanner_glrt_network_server'),
    library_sha256=sha(build / 'libiio.so'),
    source_freeze_sha256=sha(out / 'source-freeze.json'),
))

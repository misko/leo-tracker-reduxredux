"""Score-selected positive rendering smoke on already-opened development RX1 IQ."""
import gzip
import json
from pathlib import Path

from leo.contracts.digests import canonical_json_bytes, sha256_digest
from leo.scanner.adaptive_hop_analysis import AdaptiveHopAnalysisSource, analyze_adaptive_hop_visit
from leo.storage.adaptive_hop_presentation import AdaptiveHopAnalysisPresentationStore
from tests.api.test_adaptive_hop_history_api import client_for
from tools.evaluate_presence_window_rank import load_dwells
from tools.qualify_adaptive_hop_analysis import ReplayReader, exercise_storage_and_cli

source = Path("/tmp/leo-native-presence-holdout-v1-20260908")
output = Path(__file__).parent / "positive-overviews"
output.mkdir(exist_ok=False)
hashes = {name: sha256_digest((source/name).read_bytes()) for name in ("inputs.json", "results.json")}
assert hashes == {
    "inputs.json": "sha256:572f502a0209c0171bcd7527b7f205f29f6669cecda4bca261c353adb184e3cd",
    "results.json": "sha256:0e473850bc02da46a5d1ee6c92de2d6dd1d9d42b2f31b5ea124b7ad54a063c02",
}
selected = set()
rows = []
for metadata, iq in load_dwells(source):
    rate = metadata["rate_hz"]
    if rate in selected or not any(metadata["reference_positive"]):
        continue
    selected.add(rate)
    reader = ReplayReader(metadata, iq)
    product = analyze_adaptive_hop_visit(AdaptiveHopAnalysisSource(reader), reader.index)
    passed = sum(c.passed_fractional_margin_gate for p in product.probes for c in p.candidates)
    assert passed > 0
    with (output/f"{rate}-product.json.gz").open("xb") as stream:
        stream.write(gzip.compress(canonical_json_bytes(product.model_dump(mode="json")), mtime=0))
    root = output / f"fixture-positive-{rate}"
    receipt = exercise_storage_and_cli(reader, product, root)
    with client_for(root, adaptive_hop_analysis=AdaptiveHopAnalysisPresentationStore(root)) as client:
        route = f"/api/v1/scanner/adaptive-sessions/{reader.session_id}/analysis"
        status_response = client.get(route)
        assert status_response.status_code == 200
        status = status_response.json()
        assert status["state"] == "figures_ready"
        assert status["overview"]["selected_observation_count"] == 1
        # One saved dwell cannot support a multi-dwell trajectory association.
        assert status["overview"]["association_count"] == 0
        for artifact in status["overview"]["artifacts"]:
            response = client.get(route+f"/{artifact['name']}.png", params={
                "binding_sha256": status["binding_sha256"], "artifact_sha256": artifact["sha256"]})
            assert response.status_code == 200 and sha256_digest(response.content) == artifact["sha256"]
            with (output/f"{rate}-{artifact['name']}.png").open("xb") as stream:
                stream.write(response.content)
    row = {"selection": "first reference-positive dwell per rate in opened corpus order",
           "scope": "positive rendering smoke, not holdout, sensitivity or trajectory qualification",
           "source": metadata, "passed_fractional_candidates": passed,
           "storage_cli": receipt, "status": status}
    rows.append(row)
    print(json.dumps(row), flush=True)
    if len(selected) == 2:
        break
assert len(rows) == 2
assert hashes == {name: sha256_digest((source/name).read_bytes()) for name in hashes}
with (output/"summary.json").open("xb") as stream:
    stream.write(canonical_json_bytes({"rows": rows, "input_hashes": hashes}))

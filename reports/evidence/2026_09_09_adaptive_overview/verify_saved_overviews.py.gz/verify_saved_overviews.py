"""Owned saved-IQ fixture smoke; no new RF or production inputs/writes."""
import io
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from matplotlib.image import imread

from leo.contracts.digests import canonical_json_bytes, sha256_digest
from leo.storage.adaptive_hop_analysis import AdaptiveHopAnalysisStore
from leo.storage.adaptive_hop_presentation import AdaptiveHopAnalysisPresentationStore
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.scanner.adaptive_hop_products import AdaptiveHopAnalysisBindingV1
from leo.scanner.adaptive_hop_analysis import AdaptiveHopAnalysisConfigurationV1
from tests.api.test_adaptive_hop_history_api import client_for


def write_new(path, payload):
    with path.open("xb") as stream:
        stream.write(payload)


output = Path(__file__).parent / "saved-overviews-corrected"
output.mkdir(exist_ok=False)
prior = Path("/tmp/leo-adaptive-analysis.g6WLQT/saved-parity-storage-final")
source = json.loads((prior / "summary.json").read_text())
positive_parent = Path(__file__).parent / "positive-overviews"
positive = json.loads((positive_parent / "summary.json").read_text())
source["rows"].extend({
    "rate_hz": r["source"]["rate_hz"],
    "edge": "positive-" + r["source"]["edge"],
    "storage_cli": r["storage_cli"],
    "original_provenance": r["source"],
} for r in positive["rows"])
rows = []
for case in source["rows"]:
    old = case["storage_cli"]
    root = Path(old["temporary_synthetic_capture_root"])
    assert root.parent in (prior, positive_parent)
    session = old["cli_runs"][0]["session_id"]
    key = f"{case['rate_hz']}-{case['edge']}"
    # Copy only owned generated fixtures; preserve the first, flawed render and
    # its receipts. Capture/metrics bytes stay exact, and IQ is not reanalyzed.
    fresh = output / f"fixture-{key}"
    shutil.copytree(root, fresh, ignore=shutil.ignore_patterns(
        "overview-v1-*.png", "overview-manifest.v1.json"))
    root = fresh
    captures = AdaptiveHopIqStore(root, read_only=True)
    try:
        capture = captures.inspect(session)
        assert capture.manifest_sha256 == old["synthetic_capture_manifest_sha256"]
        binding = AdaptiveHopAnalysisBindingV1(
            receipt=capture.manifest.receipt,
            input_manifest_sha256=capture.manifest_sha256,
            configuration=AdaptiveHopAnalysisConfigurationV1(sample_rate_hz=case["rate_hz"]),
        )
        assert binding.sha256 == old["metrics_binding_sha256"]
    finally:
        captures.close()
    store = AdaptiveHopAnalysisStore(root, read_only=True)
    try:
        with store.job(binding) as job:
            before = job.verify()
            assert before is not None
            before_bytes = canonical_json_bytes(before.model_dump(mode="json"))
    finally:
        store.close()
    command = [sys.executable, "-m", "leo.cli.adaptive_hop_analysis", "--bulk-root", str(root),
               "--session-id", session, "--maximum-seconds", "30"]
    cli_rows = []
    for attempt in range(2):
        start = time.perf_counter()
        run = subprocess.run(command, capture_output=True, timeout=120, check=False)
        elapsed = time.perf_counter() - start
        write_new(output / f"{key}-cli-{attempt}.stdout", run.stdout)
        write_new(output / f"{key}-cli-{attempt}.stderr", run.stderr)
        assert run.returncode == 0, run.stderr.decode()
        result = json.loads(run.stdout)
        assert result["state"] == "metrics_complete" and result["overview_state"] == "ready"
        assert result["newly_analyzed_visits"] == 0
        cli_rows.append({"seconds": elapsed, "result": result, "returncode": run.returncode})
    api = AdaptiveHopAnalysisPresentationStore(root)
    timings = []
    with client_for(root, adaptive_hop_analysis=api) as client:
        route = f"/api/v1/scanner/adaptive-sessions/{session}/analysis"
        for _ in range(10):
            start = time.perf_counter()
            response = client.get(route)
            timings.append(time.perf_counter() - start)
            assert response.status_code == 200
        status = response.json()
        assert status["state"] == "figures_ready" and status["worker_activity"] == "not_observed"
        write_new(output / f"{key}-api-status.json", canonical_json_bytes(status))
        images = []
        for artifact in status["overview"]["artifacts"]:
            query = {"binding_sha256": binding.sha256, "artifact_sha256": artifact["sha256"]}
            start = time.perf_counter()
            response = client.get(route + f"/{artifact['name']}.png", params=query)
            seconds = time.perf_counter() - start
            assert response.status_code == 200
            png = response.content
            assert len(png) == artifact["byte_count"] and sha256_digest(png) == artifact["sha256"]
            decoded = imread(io.BytesIO(png), format="png")
            assert decoded.shape[1] == 2480 and np.isfinite(decoded).all()
            path = output / f"{key}-{artifact['name']}.png"
            write_new(path, png)
            images.append({**artifact, "file": path.name, "shape": list(decoded.shape),
                           "api_seconds": seconds})
    store = AdaptiveHopAnalysisStore(root, read_only=True)
    try:
        with store.job(binding) as job:
            after = job.verify()
            assert canonical_json_bytes(after.model_dump(mode="json")) == before_bytes
    finally:
        store.close()
    row = {"case": key, "session_id": session, "root": str(root),
           "original_provenance": case["original_provenance"],
           "scope": "one saved RX1 dwell; RX0, receipt and extra visits synthetic",
           "metrics_unchanged_sha256": sha256_digest(before_bytes), "cli": cli_rows,
           "status_seconds": timings, "images": images}
    rows.append(row)
    print(json.dumps(row), flush=True)
write_new(output / "summary.json", canonical_json_bytes({
    "kind": "saved-rx1-adaptive-overview-smoke-v1", "rows": rows,
    "no_rf": True, "no_sensitivity_or_trajectory_quality_claim": True,
    "source_summary_sha256": sha256_digest((prior / "summary.json").read_bytes()),
}))

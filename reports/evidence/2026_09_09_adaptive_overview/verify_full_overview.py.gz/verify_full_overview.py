"""300 s analytic-metadata scale benchmark, not RF or scientific sensitivity."""
import json
import resource
import time
from pathlib import Path

from leo.contracts.digests import canonical_json_bytes, sha256_digest
from leo.presentation.adaptive_hop_analysis import render_adaptive_hop_overview
from leo.storage.adaptive_hop_analysis import AdaptiveHopAnalysisStore
from tests.presentation.adaptive_overview_fixtures import full_overview_fixture

output = Path(__file__).parent / "full-overview-corrected"
output.mkdir(exist_ok=False)
root = output / "synthetic-store"
root.mkdir()
binding, _, products = full_overview_fixture(rate=5_000_000, mode="shadow", candidate_count=16)
store = AdaptiveHopAnalysisStore(root)
start = time.perf_counter()
with store.job(binding, writable=True) as job:
    for product in products():
        job.write_visit(product)
        if product.visit_index % 250 == 0:
            print(json.dumps({"written": product.visit_index + 1, "seconds": time.perf_counter()-start}), flush=True)
    metrics = job.finalize_metrics()
    write_seconds = time.perf_counter() - start
    start = time.perf_counter()
    rendered = render_adaptive_hop_overview(binding, metrics, job.published_visits())
    assert rendered.association_count > 0
    render_seconds = time.perf_counter() - start
    start = time.perf_counter()
    overview = job.publish_overview(rendered)
    publish_seconds = time.perf_counter() - start
store.close()
store = AdaptiveHopAnalysisStore(root, read_only=True)
times = []
for _ in range(10):
    start = time.perf_counter()
    with store.job(binding) as job:
        status = job.status()
        assert status.state == "figures_ready"
    times.append(time.perf_counter()-start)
with store.job(binding) as job:
    artifact_times = []
    for artifact in overview.artifacts:
        start = time.perf_counter()
        payload = job.read_artifact(artifact.name, expected_sha256=artifact.sha256)
        artifact_times.append(time.perf_counter()-start)
        assert payload is not None and sha256_digest(payload) == artifact.sha256
        with (output / f"synthetic-full-{artifact.name}.png").open("xb") as stream:
            stream.write(payload)
store.close()
result = {
    "scope": "analytic metadata only; full synthetic 300 s source span; no IQ or radio",
    "rate_hz": 5_000_000, "mode": "shadow", "maximum_candidates_per_probe": 16,
    "source_seconds": binding.receipt.duty_denominator_sample_count / 5_000_000,
    "visits": metrics.complete_visit_count,
    "passed_candidates": sum(v.passed_fractional_candidate_count for v in metrics.visits),
    "compressed_visit_bytes": sum(v.compressed_bytes for v in metrics.visits),
    "write_and_finalize_seconds": write_seconds,
    "verified_stream_and_render_seconds": render_seconds,
    "reverify_and_publish_seconds": publish_seconds,
    "reopen_and_status_seconds": times,
    "artifact_read_seconds": artifact_times,
    "maximum_process_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "status": status.model_dump(mode="json"),
}
with (output / "summary.json").open("xb") as stream:
    stream.write(canonical_json_bytes(result))
print(json.dumps(result), flush=True)

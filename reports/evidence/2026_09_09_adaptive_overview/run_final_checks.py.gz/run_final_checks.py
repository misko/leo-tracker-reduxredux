"""Retained exact portable regression commands, with no radio markers selected."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd()
output = Path(__file__).parent / "final-corrected"
output.mkdir(exist_ok=False)
prior = json.loads((root/"reports/evidence/2026_09_09_adaptive_analysis/index.json").read_text())
tests = [p for p in prior["test_command"] if p.startswith("tests/")]
tests.extend([
    "tests/presentation/test_adaptive_hop_overview.py",
    "tests/storage/test_adaptive_hop_overview_store.py",
    "tests/application/test_adaptive_hop_overview_service.py",
    "tests/api/test_adaptive_hop_analysis_api.py",
    "tests/api/test_production_entrypoint.py",
])
changed = subprocess.check_output(
    ["git", "ls-files", "--modified", "--others", "--exclude-standard", "*.py"], text=True
).splitlines()
modules = [
    "src/leo/scanner/adaptive_hop_presentation.py",
    "src/leo/presentation/adaptive_hop_analysis.py",
    "src/leo/storage/adaptive_hop_analysis.py",
    "src/leo/storage/adaptive_hop_presentation.py",
    "src/leo/application/adaptive_hop_overview.py",
    "src/leo/cli/adaptive_hop_analysis.py",
]
commands = [
    ("python-final", [sys.executable, "-m", "pytest", *tests,
                      "--junitxml="+str(output/"python-final.xml"), "-q", "--tb=short"], root),
    ("ruff-final", [sys.executable, "-m", "ruff", "check", *changed], root),
    ("format-final", [sys.executable, "-m", "ruff", "format", "--check", *changed], root),
    ("mypy-final", [sys.executable, "-m", "mypy", "--python-version=3.12",
                    "--follow-imports=silent", *modules], root),
    ("whitespace-final", ["git", "diff", "--check"], root),
    ("web-final", ["npm", "test", "--", "--reporter=default", "--reporter=junit",
                   "--outputFile.junit="+str(output/"web-final.xml")], root/"web"),
    ("build-final", ["npm", "run", "build"], root/"web"),
]
receipts = []
for name, command, cwd in commands:
    start = time.perf_counter()
    print(json.dumps({"starting": name}), flush=True)
    with (output/f"{name}.log").open("xb") as stream:
        result = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=300, check=False)
    receipt = {"name": name, "command": command, "cwd": str(cwd),
               "returncode": result.returncode, "seconds": time.perf_counter()-start}
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        break
with (output/"final-checks.json").open("xb") as stream:
    stream.write(json.dumps(receipts, sort_keys=True).encode())
assert len(receipts) == len(commands) and all(r["returncode"] == 0 for r in receipts)

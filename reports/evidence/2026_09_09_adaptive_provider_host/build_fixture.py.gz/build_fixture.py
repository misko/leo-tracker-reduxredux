import json
import subprocess
import hashlib
import sys
import os
from pathlib import Path

from tools.native_presence import ROOT, build_scanner_glrt_port, build_worker, write_templates

out = Path(__file__).parent
libiio = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
spf = Path('/home/mouse9911/gits/plutosdr-fw-metadata-gain-timeline-v8')
config = json.loads((ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json').read_text())
flags = tuple(config['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
) + tuple(f'-DLEO_PRESENCE_{name}=1' for name in (
    'DIFFERENTIAL_CI16', 'RANK_HYBRID_PROJECTION', 'RANK_AMPLITUDE_WEIGHTED',
    'GLRT_SYMBOL_DIVERSITY', 'BOUNDED_MAGNITUDE', 'CONDITIONED_BLOCK_ROTATION',
    'ENERGY_SUPPORT', 'ENERGY_SYMBOL_SUPPORT',
))
resume = '--resume' in sys.argv
sdk, worker = out / 'sdk.so', out / 'worker'
if resume:
    for artifact in (sdk, worker):
        receipt = json.loads(artifact.with_name(artifact.name + '.build.json').read_text())
        assert hashlib.sha256(artifact.read_bytes()).hexdigest() == receipt['binary_sha256']
        for name, sha in receipt['sources_sha256'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
else:
    build_scanner_glrt_port(sdk)
    build_worker(worker, cflags=flags)
    worker.chmod(0o755)
    for rate in (2500000, 5000000):
        p = out / f'templates-{rate}'
        write_templates(p, rate)
        p.chmod(0o600)
extra = [libiio / 'iiod/spf-tandem-session.c', libiio / 'iiod/spf-tandem-metadata.c']
extra += [spf / name for name in (
    'spf_gain_read.c', 'spf_gain_sampler.c', 'spf_rssi_read.c', 'spf_radio_frame_v3.c', 'spf_thread_join.c'
)]
common = [
    'cmake', '-S', str(libiio), '-DCMAKE_BUILD_TYPE=Debug', '-DWITH_TESTS=ON',
    '-DWITH_IIOD=ON', '-DWITH_XML_BACKEND=ON', '-DWITH_NETWORK_BACKEND=ON',
    '-DWITH_LOCAL_BACKEND=ON', '-DWITH_USB_BACKEND=OFF', '-DWITH_SERIAL_BACKEND=OFF',
    '-DWITH_AIO=OFF', '-DWITH_ZSTD=OFF', '-DWITH_IIOD_SERIAL=OFF', '-DWITH_IIOD_USBD=OFF',
    '-DWITH_DOC=OFF', '-DWITH_MAN=OFF', '-DWITH_SYSTEMD=OFF', '-DHAVE_DNS_SD=OFF',
    f'-DIIOD_BUFFER_METADATA_PROVIDER={libiio}/iiod/spf-buffer-metadata.c',
    f'-DIIOD_BUFFER_METADATA_INCLUDE_DIRS={spf};/home/mouse9911/gits/plutosdr-fw/linux/usr/include',
    '-DIIOD_BUFFER_METADATA_PROVIDER_EXTRA_SOURCES=' + ';'.join(map(str, extra)),
    f'-DIIOD_BUFFER_PERSISTENT_HOP_DEVICE_PROVIDER={libiio}/iiod/spf-hop-device-userspace.c',
    f'-DIIOD_SCANNER_GLRT_LIBRARY={sdk}',
    f'-DIIOD_SCANNER_GLRT_INCLUDE_DIR={ROOT}/src/leo/scanner/native_presence',
    f'-DIIOD_SCANNER_GLRT_WORKER_PATH={worker}',
    f'-DIIOD_SCANNER_GLRT_TEMPLATES_2500000={out}/templates-2500000',
    f'-DIIOD_SCANNER_GLRT_TEMPLATES_5000000={out}/templates-5000000',
    '-DIIOD_SCANNER_GLRT_ALGORITHM_SHA256=' + '12' * 32,
    '-DIIOD_SCANNER_GLRT_CONFIGURATION_SHA256=' + '34' * 32,
]
receipts = []
if '--adaptive' in sys.argv:
    from tools.qualify_presence_dwell_controls import generate
    pilot_manifest = []
    for rate in (2500000, 5000000):
        for edge in ('lower', 'upper'):
            iq, truth = generate(rate, edge, 91, 'pilot', 4)
            path = out / f'pilot-{rate}-{edge}.ci16'
            iq.astype('<i2', copy=False).tofile(path)
            os.environ[f'SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}'] = str(path)
            pilot_manifest.append(dict(path=str(path), truth=truth, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (out / 'synthetic-pilot-manifest.json').write_text(json.dumps(pilot_manifest, indent=2) + '\n')
for mode in (('adaptive-positive',) if '--adaptive' in sys.argv else ('unqualified-evidence', 'positive-only-v1')):
    build = out / (mode + ('-sanitized' if '--sanitize' in sys.argv else ''))
    profile = 'positive-only-v1' if mode == 'adaptive-positive' else mode
    command = common + ['-B', str(build), f'-DIIOD_SCANNER_GLRT_MODE={profile}']
    if mode == 'adaptive-positive':
        command += ['-DIIOD_SCANNER_ADAPTIVE_HOP=ON']
    if '--sanitize' in sys.argv:
        command += ['-DCMAKE_C_FLAGS=-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer',
                    '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
        os.environ['ASAN_OPTIONS'] = 'detect_leaks=1:halt_on_error=1'
        os.environ['UBSAN_OPTIONS'] = 'halt_on_error=1'
    if profile == 'positive-only-v1':
        command += ['-DIIOD_SCANNER_GLRT_MINIMUM_EXACT_SCORE=0.175', '-DIIOD_SCANNER_GLRT_MINIMUM_MARGIN=0.025']
    for stage, cmd in (
        ('configure', command),
        ('compile', ['cmake', '--build', str(build), '--target', 'test_scanner_glrt_provider', 'test_scanner_glrt_network_server', '-j', '2']),
        ('provider', [str(build / 'iiod/test_scanner_glrt_provider')]),
    ):
        run = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        receipt = dict(mode=mode, stage=stage, command=cmd, status=run.returncode, stdout=run.stdout, stderr=run.stderr)
        label = next((a[8:] for a in sys.argv if a.startswith('--label=')), '-retry' if resume else '')
        (out / f'{mode}-{stage}{label}.json').write_text(json.dumps(receipt, indent=2) + '\n')
        receipts.append(receipt)
        print(mode, stage, run.returncode, flush=True)
        if run.returncode:
            print(run.stdout[-6000:], run.stderr[-6000:])
            raise SystemExit(run.returncode)
(out / ('adaptive-sanitized-build-results.json' if '--sanitize' in sys.argv else 'adaptive-build-results.json' if '--adaptive' in sys.argv else 'build-results.json')).write_text(json.dumps(receipts, indent=2) + '\n')

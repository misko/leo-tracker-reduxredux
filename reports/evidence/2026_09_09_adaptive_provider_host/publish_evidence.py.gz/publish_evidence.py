"""Publish bounded generated receipts only: no IQ, executables, or QNAP access."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

raw = Path(__file__).parent
leo = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
target = leo / 'reports/evidence/2026_09_09_adaptive_provider_host'
target.mkdir(parents=True, exist_ok=False)
verified = json.loads((raw / 'verified-source-hashes.json').read_text())
for repo, snapshot in verified.items():
    for relative, expected in snapshot['files'].items():
        if relative.endswith(('.c', '.h', '.py', 'CMakeLists.txt')):
            assert hashlib.sha256((Path(repo) / relative).read_bytes()).hexdigest() == expected, relative
artifacts = []
for path in sorted(raw.iterdir()):
    if path.suffix not in ('.json', '.xml', '.py'):
        continue
    data = path.read_bytes()
    encoded = gzip.compress(data, mtime=0)
    name = path.name + '.gz'
    (target / name).write_bytes(encoded)
    artifacts.append(dict(name=name, bytes=len(encoded), sha256=hashlib.sha256(encoded).hexdigest(),
                          original_bytes=len(data), original_sha256=hashlib.sha256(data).hexdigest()))
tests = {}
for path in sorted(raw.glob('final-*.xml')):
    root = ET.parse(path).getroot()
    cases = root.findall('.//testcase')
    tests[path.name] = dict(tests=len(cases), failures=len(root.findall('.//failure')),
        errors=len(root.findall('.//error')), skipped=len(root.findall('.//skipped')),
        source_span_cases=[dict(name=c.get('name'), properties={p.get('name'): p.get('value')
            for p in c.findall('./properties/property')}) for c in cases if '300s' in c.get('name', '')])
repositories = {}
for repo in verified:
    repositories[repo] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
index = dict(kind='adaptive_provider_host_checkpoint', schema_version=1, raw_directory=str(raw),
    repositories=repositories, tests=tests, artifacts=artifacts,
    scope='offline provider and host integration; no RF, ARM execution, deployment or application/UI publication',
    note='Provider sanitizer instruments libiio/provider code, not the unchanged separately built SDK/worker.')
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps(dict(artifacts=len(artifacts), total_bytes=sum(a['bytes'] for a in artifacts), tests=tests), indent=2))

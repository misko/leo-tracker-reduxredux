"""Retain exact offline commands, JUnit and changed-source hashes; never RF."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).parent
leo = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
ppu = Path('/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host')
lib = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
python = '/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin/python'
ruff = '/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin/ruff'
base = os.environ | {'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1'}

def run(name, command, cwd, env):
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=240)
    receipt = dict(command=command, cwd=str(cwd), environment={k: env.get(k) for k in (
        'PYTHONDONTWRITEBYTECODE', 'OPENBLAS_NUM_THREADS', 'PYTHONPATH', 'LD_LIBRARY_PATH',
        'SCANNER_GLRT_TEST_MODE', 'SCANNER_GLRT_NETWORK_SERVER')}, status=result.returncode,
        stdout=result.stdout, stderr=result.stderr)
    (out / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, result.returncode, result.stdout[-2000:], result.stderr[-2000:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

def pytest(name, cwd, env, files):
    run(name, [python, '-m', 'pytest', *files, '-q', '-p', 'no:cacheprovider',
               f'--junitxml={out}/{name}.xml', '-o', 'junit_family=xunit1'], cwd, env)

if '--network' in sys.argv:
    for mode in ('unqualified-evidence', 'positive-only-v1', 'adaptive-positive'):
        env = base | {'PYTHONPATH': f'src:.:{ppu}/src:{lib}/bindings/python',
            'LD_LIBRARY_PATH': str(out / mode),
            'SCANNER_GLRT_TEST_MODE': 'unqualified-evidence' if mode == 'unqualified-evidence' else 'positive-only-v1',
            'SCANNER_GLRT_NETWORK_SERVER': str(out / mode / 'iiod/test_scanner_glrt_network_server')}
        files = ['tests/radio/test_adaptive_hop_network.py'] if mode == 'adaptive-positive' else ['tests/radio/test_scanner_glrt_network.py']
        pytest(f'final-{mode}-network', leo, env, files)
else:
    env = base | {'PYTHONPATH': 'src'}
    pytest('final-ppu', ppu, env, [
        'tests/test_adaptive_hop.py', 'tests/test_adaptive_hop_stream.py', 'tests/test_iio_adaptive_hop.py',
        'tests/test_persistent_hop.py', 'tests/test_iio_persistent_hop.py',
        'tests/test_pilot_iio_client.py', 'tests/test_pss_iio.py', 'tests/test_source_support.py'])
    pytest('final-leo', leo, base | {'PYTHONPATH': f'src:.:{ppu}/src'}, [
        'tests/scanner/test_adaptive_scan.py', 'tests/radio/test_adaptive_glrt_metadata.py',
        'tests/radio/test_scanner_glrt_metadata.py', 'tests/radio/test_scanner_glrt_frames.py',
        'tests/radio/test_pluto_persistent_hop.py', 'tests/scanner/test_persistent_hop_application.py',
        'tests/scanner/test_scanner_glrt_request.py', 'tests/scanner/test_scanner_glrt_positive.py',
        'tests/storage/test_scanner_glrt_store.py', 'tests/api/test_scanner_glrt_api.py'])
    pytest('final-build-config', lib, base, ['tests/test_scanner_glrt_build_config.py'])
    ppu_sources = ['src/pluto_plus/adaptive_hop.py', 'src/pluto_plus/adaptive_hop_stream.py',
        'src/pluto_plus/adaptive_hop_client.py', 'src/pluto_plus/hardware/iio_adaptive_hop.py',
        'src/pluto_plus/hardware/iio_persistent_hop.py']
    run('final-ppu-ruff', [ruff, 'check', *ppu_sources, 'tests/test_adaptive_hop.py',
        'tests/test_adaptive_hop_stream.py', 'tests/test_iio_adaptive_hop.py'], ppu, base)
    run('final-leo-ruff', [ruff, 'check', 'src/leo/radio/scanner_glrt_metadata.py',
        'tests/radio/test_adaptive_glrt_metadata.py', 'tests/radio/test_adaptive_hop_network.py'], leo, base)
    run('final-mypy-python312', [python, '-m', 'mypy', '--python-version=3.12', '--follow-imports=silent',
        f'--cache-dir={out}/mypy312', *ppu_sources], ppu, env)
    manifest = {}
    for repo in (leo, ppu, lib):
        names = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=repo, text=True).splitlines()
        names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, text=True).splitlines()
        manifest[str(repo)] = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
            files={n: hashlib.sha256((repo / n).read_bytes()).hexdigest() for n in sorted(set(names)) if (repo / n).is_file()})
        run(f'final-{repo.name}-whitespace', ['git', 'diff', '--check'], repo, base)
    (out / 'verified-source-hashes.json').write_text(json.dumps(manifest, indent=2) + '\n')

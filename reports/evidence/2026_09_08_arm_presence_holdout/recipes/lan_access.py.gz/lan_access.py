"""LAN-only saved-IQ benchmarking on the physically verified USB spare."""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/tmp/leo-presence-holdout.8JIL7Y")
HOST = "root@192.168.1.14"
OPTIONS = ["-o", "StrictHostKeyChecking=yes", "-o", f"UserKnownHostsFile={ROOT}/known_hosts",
           "-o", "HostKeyAlgorithms=ssh-ed25519", "-o", "ConnectTimeout=4",
           "-o", "NumberOfPasswordPrompts=1", "-o", "WarnWeakCrypto=no"]
configuration = Path("/home/mouse9911/gits/plutosdr-fw/buildroot/configs/zynq_pluto_defconfig").read_text()
password = re.search(r'^BR2_TARGET_GENERIC_ROOT_PASSWD="([^"\n]+)"$', configuration, re.M).group(1)


def call(command, timeout=15):
    return subprocess.run(["sshpass", "-e", "ssh", *OPTIONS, HOST, command],
                          env=dict(os.environ, SSHPASS=password), text=True,
                          capture_output=True, timeout=timeout)


def transfer(paths, destination):
    return subprocess.run(["sshpass", "-e", "scp", "-O", *OPTIONS,
                           *map(str, paths), f"{HOST}:{destination}"],
                          env=dict(os.environ, SSHPASS=password), text=True,
                          capture_output=True, timeout=50)


if __name__ == "__main__":
    assert len(sys.argv) == 1
    command = "\n".join([
        "cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber",
        "cat /proc/loadavg", "cat /proc/meminfo",
        "cat /sys/bus/iio/devices/iio:device*/buffer/enable", "netstat -nt", "ps",
        "ls -l /usr/lib/libfftw3.so*", "df -k /tmp",
    ])
    result = call(command)
    record = dict(command=command, returncode=result.returncode,
                  stdout=result.stdout, stderr=result.stderr)
    with (ROOT / f"lan-preflight-{time.time_ns()}.json").open("x") as stream:
        json.dump(record, stream, indent=2)
    print(json.dumps(record, indent=2))

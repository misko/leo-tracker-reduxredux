"""Package bounded scientific/runtime evidence without IQ, binaries or credentials."""
from pathlib import Path
import gzip
import json
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json

scratch=Path('/tmp/leo-presence-holdout.8JIL7Y')
out=ROOT/'reports/evidence/2026_09_08_arm_presence_holdout'
figures=ROOT/'reports/figures/2026_09_08_arm_presence_holdout'
out.mkdir(parents=True,exist_ok=False)
figures.mkdir(parents=True,exist_ok=False)
inventory={}


def retain(source, relative, compress=False):
    data=source.read_bytes()
    target=out/(relative+('.gz' if compress else ''))
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:
        stream.write(gzip.compress(data,mtime=0) if compress else data)
    inventory[str(target.relative_to(out))]=dict(sha256=digest(target),source_sha256=digest(source),compressed=compress)


for path in sorted((scratch/'challenge').iterdir()):
    if path.suffix=='.json' or path.name=='results.jsonl':
        retain(path,'challenge/'+path.name,compress=path.name in ('freeze.json','results.jsonl'))
for path in sorted((scratch/'arm').glob('*.json')):
    retain(path,'arm/'+path.name,compress=path.name.endswith('.manifest.json'))
for name in ('arm-runs','arm-runs-v2','arm-runs-v3'):
    for path in sorted((scratch/name).iterdir()):
        retain(path,name+'/'+path.name,compress=path.suffix=='.jsonl')
for name in ('regression.xml','period-tests.xml','regression-final.xml'):
    retain(scratch/name,'tests/'+name,compress=True)
for name in ('probe_console.py','lan_access.py','prepare_arm.py','run_arm.py',
             'run_arm_rejected_timeout.py','run_arm_rejected_taskset.py','save_evidence.py'):
    retain(scratch/name,'recipes/'+name,compress=True)
for path in sorted(scratch.glob('console-*.json')):
    retain(path,'hardware/'+path.name,compress=True)
for path in sorted(scratch.glob('lan-preflight-*.json')):
    retain(path,'hardware/'+path.name,compress=True)

challenge=[json.loads(s) for s in (scratch/'challenge/results.jsonl').read_text().splitlines()]
summary=json.loads((scratch/'challenge/summary.json').read_text())
derived={'challenge':{},'arm':{}}
for name in ('amplitude','amplitude-diverse'):
    group=[r for r in challenge if r['truth']['kind']=='boundary_pilot']
    derived['challenge'][name]=dict(summary['results'][name],
        boundary_cases=len(group),boundary_associated=sum(r['variants'][name]['associated'] for r in group),
        boundary_flags=sum(r['variants'][name]['flagged'] for r in group))
assert len(challenge)==480
assert not any(r['truth']['clipped_components'] for r in challenge)
run_summary=json.loads((scratch/'arm-runs-v3/summary.json').read_text())
for index,run in enumerate(run_summary['runs']):
    rate,name=run['rate_hz'],run['variant']
    raw=scratch/f'arm-runs-v3/{index}-{rate}-{name}.jsonl'
    rows=[json.loads(s) for s in raw.read_text().splitlines()][:-1]
    assert len(rows)==250 and run['verified']
    derived['arm'][f'{rate}:{name}']=dict(run,
        over_120ms=sum(r['delivery_latency_ms']>120 for r in rows),
        first_delivery_latency_ms=rows[0]['delivery_latency_ms'],
        stages_cpu_ms={
            key:np.percentile(values,[50,99]).tolist() for key,values in (
                ('screen',[r['rank']['total_cpu_ms'] for r in rows]),
                ('confirmation',[r['confirmation_cpu_ms'] for r in rows]))})
write_json(out/'comparison.json',derived)

fig,axes=plt.subplots(2,1,figsize=(12,8),layout='constrained')
colors=['#54728e','#198269']
names=['amplitude','amplitude-diverse']
for index,name in enumerate(names):
    item=derived['challenge'][name]
    bars=axes[0].bar(np.array([0,1])+index*.32-.16,
                     [100*item['primary_associated']/144,100*item['boundary_associated']/80],
                     width=.30,color=colors[index],label=['Early scoring','Diverse scoring'][index])
    axes[0].bar_label(bars,labels=[f"{item['primary_associated']}/144",f"{item['boundary_associated']}/80"],padding=3)
axes[0].set(xticks=[0,1],xticklabels=['Primary signals (20 ms)','Boundary stress (4 ms)'],
            ylabel='Associated cases (%)',ylim=(0,117),
            title='Fresh synthetic holdout: amplitude ranking, unchanged thresholds, one confirmation')
axes[0].text(.5,.90,'Nonpilot flags: early 3/256; diverse 0/256',transform=axes[0].transAxes,ha='center',fontsize=10)
axes[0].legend(loc='center right')
for index,(name,label) in enumerate([('normalized','Normalized'),('amplitude-diverse','Amplitude + diversity')]):
    raw=scratch/f'arm-runs-v3/{index}-5000000-{name}.jsonl'
    rows=[json.loads(s) for s in raw.read_text().splitlines()][:-1]
    axes[1].plot(np.arange(len(rows))*.120,[r['delivery_latency_ms'] for r in rows],
                 color=colors[index],alpha=.8,linewidth=.9,label=label)
axes[1].axhline(120,color='#ad453c',linestyle='--',label='120 ms arrival interval')
axes[1].set(xlabel='Scheduled time within each separate replay (s)',ylabel='Copy-to-result latency (ms)',
            title='5 MS/s on the verified ARM spare: 250/250 results per run; one >120 ms result in each',ylim=(80,135))
axes[1].legend(loc='lower right')
for axis in axes:
    axis.grid(axis='y',alpha=.2)
    axis.set_axisbelow(True)
fig.suptitle('Fresh holdout and actual ARM execution — not live RF duty verification',fontsize=14)
figure=figures/'holdout-and-arm.png'
fig.savefig(figure,dpi=170)
plt.close(fig)
tests=ET.parse(scratch/'regression-final.xml').getroot()
suites=list(tests.iter('testsuite'))
test_counts={k:sum(int(s.get(k,'0')) for s in suites) for k in ('tests','failures','errors','skipped')}
receipt=dict(implementation_commit='6b516b02',exporter_sha256=digest(Path(__file__)),
             artifact_files=inventory,comparison_sha256=digest(out/'comparison.json'),
             figure_sha256=digest(figure),tests=test_counts,synthetic_cases=480,native_challenge_executions=960,
             arm_executions=1000,unique_arm_dwells=32,arm_seconds_per_run=30,arm_rate_variants=4,
             target_serial='winbond-db620818a328172c',target_lan='192.168.1.14',
             ssh_trust='USB-console verified public key; isolated known_hosts; original trust store unchanged',
             launch_failures='timeout and taskset commands absent; both failed batches retained, no detector executions; v3 uses built-in watchdog and inherited affinity',
             hardware_scope='Only currently USB-attached spare; .20/.21 production radios, .15 and .18 canary not used',
             radio_effects='Read-only identity/workload queries; authenticated SSH naturally generated volatile host keys; temporary userspace benchmark payload uploaded then removed after hash checks. Host tty left raw to prevent echo and logged out. No RF, IIO contexts, services, firmware or installed dependencies changed.',
             release=dict(deployed=False,merged_remote_main=False,classification_enabled=False,goal_complete=False),
             limitations=['Synthetic seeds are fresh but reuse the existing model; seed reuse across rates/edges/SNR is dependent.',
                          'Only 28/80 revised-scorer boundary bursts associated; no absence claim.',
                          'ARM runs repeat 16 original saved dwells per rate; not independent RF classification truth.',
                          'Chunks are burst-delivered, not original DMA/metadata arrivals. No active RF/IRQ load.',
                          '30 seconds per run, not a 300-second recording. Startup setup and input loading excluded.',
                          '5 MS/s revised scorer has 119.88ms delivery p99 and 128.14ms max; insufficient live-load margin.'])
write_json(out/'receipt.json',receipt)
for name,record in inventory.items():
    path=out/name
    assert digest(path)==record['sha256']
    if record['compressed']:
        import hashlib
        assert hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest()==record['source_sha256']
print(json.dumps(dict(output=str(out),artifacts=len(inventory),tests=test_counts,figure=str(figure)),indent=2))

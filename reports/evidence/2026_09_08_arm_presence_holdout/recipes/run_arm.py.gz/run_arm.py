"""Bounded LAN saved-IQ replay; no IIO context, RF writes or deployment."""
from pathlib import Path
import json
import re
import shlex
import time

from lan_access import call, transfer
from pluto_plus.inventory import scan_local_usb_plutos
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_worker import verify

root=Path('/tmp/leo-presence-holdout.8JIL7Y')
assets=root/'arm'
out=root/'arm-runs-v3'
out.mkdir(exist_ok=False)
serial='winbond-db620818a328172c'
payload=json.loads((assets/'payload.json').read_text())
paths={name:assets/name for name in payload}
paths['libfftw3.so.3']=Path('/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr/lib/libfftw3.so.3.6.10')
payload['libfftw3.so.3']=digest(paths['libfftw3.so.3'])
assert all(digest(path)==payload[name] for name,path in paths.items())
freeze=dict(recipe_sha256=digest(Path(__file__)),payload_sha256=payload,
            original_payload_sha256=digest(assets/'payload.json'),
            target=serial,address='192.168.1.14',duration_ms=30000,arrival_period_ms=120,
            order=[[5000000,'normalized'],[5000000,'amplitude-diverse'],
                   [2500000,'amplitude-diverse'],[2500000,'normalized']],
            scheduling='parent and worker nice 10, inherited CPU affinity; original arrival timeline not replayed',
            fftw='isolated RAM copy of the exact cross-build dependency; installed library untouched',
            live_rf=False, deployed=False, firmware_changed=False)
write_json(out/'freeze.json',freeze)
remote=None
logs=[]


def recorded(label,command,timeout=15):
    result=call(command,timeout=timeout)
    document=dict(command=command,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
    write_json(out/f'{label}.json',document)
    logs.append(label)
    if result.returncode:
        raise RuntimeError(f'{label}: remote exit {result.returncode}: {result.stderr}')
    return result.stdout


def identity_idle(label):
    devices=[d for d in scan_local_usb_plutos() if d.serial==serial]
    assert len(devices)==1 and devices[0].usb_path=='/sys/bus/usb/devices/5-1'
    identity=recorded(label+'-serial', 'cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber')
    assert identity.strip()==serial
    buffers=recorded(label+'-buffers','cat /sys/bus/iio/devices/iio:device*/buffer/enable')
    assert buffers.split()==['0','0'], 'capture active; do not benchmark'
    recorded(label+'-state','cat /proc/loadavg\nnetstat -nt\nps')


try:
    with acquire_radio_lock(serial):
        identity_idle('preflight')
        remote=recorded('scratch','mktemp -d /tmp/leo-glrt-bench.XXXXXX').strip()
        assert re.fullmatch(r'/tmp/leo-glrt-bench\.[A-Za-z0-9]{6}',remote)
        for name,path in paths.items():
            result=transfer([path],f'{remote}/{name}')
            write_json(out/f'transfer-{name}.json',dict(returncode=result.returncode,stderr=result.stderr,
                                                      source_sha256=payload[name],remote=f'{remote}/{name}'))
            assert result.returncode==0, result.stderr
        hash_output=recorded('payload-hashes','sha256sum '+' '.join(shlex.quote(f'{remote}/{name}') for name in paths))
        actual={Path(line.split()[1]).name:line.split()[0] for line in hash_output.splitlines()}
        assert actual==payload
        summaries=[]
        for index,(rate,name) in enumerate(freeze['order']):
            identity_idle(f'before-{index}')
            label=f'{index}-{rate}-{name}'
            command=(f'LD_LIBRARY_PATH={remote} nice -n 10 '
                     f'{remote}/parent {remote}/worker-{name} {remote}/{rate}.templates '
                     f'{remote}/{rate}.pack 30000 120')
            print(f'Starting {label}: 30s saved-IQ worker replay, 120ms arrivals',flush=True)
            started=time.monotonic()
            result=call(command,timeout=55)
            document=dict(command=command,returncode=result.returncode,stderr=result.stderr,
                          observed_elapsed_s=time.monotonic()-started)
            write_json(out/f'{label}.execution.json',document)
            with (out/f'{label}.jsonl').open('x') as stream:
                stream.write(result.stdout)
            manifest=json.loads((assets/f'{rate}-{name}.manifest.json').read_text())
            try:
                assert result.returncode==0 and not result.stderr, 'replay did not finish cleanly'
                checked=verify(result.stdout,manifest,30000,arrival_period_ms=120)
                checked.update(verified=True,raw_sha256=digest(out/f'{label}.jsonl'))
            except (AssertionError,ValueError,KeyError) as error:
                checked=dict(verified=False,error=str(error))
            write_json(out/f'{label}.verification.json',checked)
            summaries.append(dict(rate_hz=rate,variant=name,**checked))
            print(json.dumps(summaries[-1]),flush=True)
        identity_idle('postflight')
        hash_output=recorded('final-payload-hashes','sha256sum '+' '.join(shlex.quote(f'{remote}/{name}') for name in paths))
        assert {Path(line.split()[1]).name:line.split()[0] for line in hash_output.splitlines()}==payload
        assert all(digest(path)==payload[name] for name,path in paths.items())
        write_json(out/'summary.json',dict(runs=summaries,goal_complete=False,
            scope='saved-IQ timing and numerical parity, not RF duty or full DMA/metadata replay'))
        # Only the enumerated unchanged payload files uploaded to this new RAM
        # directory are removed. No archive, firmware or installed file is touched.
        recorded('cleanup-files','rm '+' '.join(shlex.quote(f'{remote}/{name}') for name in paths))
        recorded('cleanup-directory','rmdir '+shlex.quote(remote))
        remote=None
finally:
    write_json(out/'end.json',dict(remote_scratch_retained=remote,logs=logs,
                                 recipe_unchanged=freeze['recipe_sha256']==digest(Path(__file__))))

"""One exact USB console: bounded read-only identity and ownership inspection."""
import argparse
import fcntl
import json
import os
import re
import select
import termios
import time
import tty
from pathlib import Path

from pluto_plus.inventory import scan_local_usb_plutos
from pluto_plus.radio_lock import acquire_radio_lock

SERIAL = "winbond-db620818a328172c"
DEVICE = "/dev/serial/by-id/usb-Analog_Devices_Inc._PlutoSDR+_with_timestamp_support_winbond-db620818a328172c-if03"
ROOT = Path("/tmp/leo-presence-holdout.8JIL7Y")
PROMPT = re.compile(rb"(?:^|[\r\n])(?:\x1b\[[0-9;]*m)*(?:[A-Za-z0-9_.@:/~+-]+)? ?# ?$")


def receive(fd, seconds):
    deadline = time.monotonic() + seconds
    data = bytearray()
    while time.monotonic() < deadline and len(data) < 65536:
        if select.select([fd], [], [], min(0.2, max(0, deadline-time.monotonic())))[0]:
            chunk = os.read(fd, 4096)
            if not chunk:
                break
            data.extend(chunk)
            if PROMPT.search(data) or bytes(data).rstrip().endswith((b"login:", b"Password:")):
                break
    return bytes(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inspect", action="store_true")
    parser.add_argument("--login", action="store_true")
    args = parser.parse_args()
    selected = [d for d in scan_local_usb_plutos() if d.serial == SERIAL]
    assert len(selected) == 1 and selected[0].terminal_devices == ("/dev/ttyACM2",)
    assert Path(DEVICE).resolve() == Path("/dev/ttyACM2")
    records = []
    with acquire_radio_lock(SERIAL):
        fd = os.open(DEVICE, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        original = termios.tcgetattr(fd)
        fcntl.ioctl(fd, termios.TIOCEXCL)
        try:
            # No modem-control/DTR ioctls, no buffer flush, no break or Ctrl-C.
            tty.setraw(fd, termios.TCSANOW)
            state = termios.tcgetattr(fd)
            state[2] &= ~termios.HUPCL
            termios.tcsetattr(fd, termios.TCSANOW, state)
            data = receive(fd, 1)
            if not data:
                os.write(fd, b"\r")
                data = receive(fd, 3)
            records.append(dict(command=None, output=data.decode(errors="replace")))
            logged_in = False
            if args.login and data.rstrip().endswith(b"Password:"):
                # The console was already at an unknown-user password prompt.
                # Submit no credential; wait for a fresh explicit login prompt.
                os.write(fd, b"\r")
                data = receive(fd, 8)
                records.append(dict(command="empty unknown-user authentication", output=data.decode(errors="replace")))
            if args.login and data.rstrip().endswith(b"login:"):
                os.write(fd, b"root\r")
                data = receive(fd, 3)
                records.append(dict(command="login root", output=data.decode(errors="replace")))
                if data.rstrip().endswith(b"Password:"):
                    configuration = Path("/home/mouse9911/gits/plutosdr-fw/buildroot/configs/zynq_pluto_defconfig").read_text()
                    default = re.search(r'^BR2_TARGET_GENERIC_ROOT_PASSWD="([^"\n]+)"$', configuration, re.M).group(1)
                    os.write(fd, default.encode() + b"\r")
                    data = receive(fd, 4)
                    records.append(dict(command="configured default console authentication", output=data.decode(errors="replace").replace(default, "[redacted]")))
                logged_in = bool(PROMPT.search(data))
            if args.inspect and PROMPT.search(data):
                for command in (
                    "cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber",
                    "ip -4 addr show",
                    "ls -l /etc/dropbear/",
                    "dropbearkey -y -f /etc/dropbear/dropbear_ed25519_host_key",
                    "dropbearkey -y -f /etc/dropbear/dropbear_rsa_host_key",
                    "dropbearkey -y -f /etc/dropbear/dropbear_ecdsa_host_key",
                    "cat /opt/VERSIONS",
                    "cat /sys/class/net/eth0/address",
                ):
                    os.write(fd, command.encode() + b"\r")
                    reply = receive(fd, 4)
                    records.append(dict(command=command, output=reply.decode(errors="replace")))
                    if not PROMPT.search(reply):
                        break
            if logged_in and PROMPT.search(data if not args.inspect else reply):
                os.write(fd, b"exit\r")
                records.append(dict(command="exit", output=receive(fd, 3).decode(errors="replace")))
        finally:
            # A serial-console client must not echo the radio's output back as
            # its input. Leave the host tty raw, with no close-time hangup.
            fcntl.ioctl(fd, termios.TIOCNXCL)
            os.close(fd)
    document = dict(usb=selected[0].model_dump(mode="json"), records=records)
    path = ROOT / f"console-{time.time_ns()}.json"
    with path.open("x") as stream:
        json.dump(document, stream, indent=2)
    print(json.dumps(document, indent=2))


if __name__ == "__main__":
    main()

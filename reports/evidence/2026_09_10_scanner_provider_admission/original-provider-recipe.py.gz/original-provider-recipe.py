"""Build/run actual libiio provider with synthetic IQ only; no radio access."""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from tools.native_presence import ROOT, build_scanner_glrt_port, build_worker, write_templates
from tools.qualify_presence_dwell_controls import generate

DEST = Path(os.environ.get('COOPERATIVE_PROVIDER_OUTPUT', Path(__file__).resolve().parent))
LIBIIO = Path('/home/mouse9911/gits/libiio-scanner-cooperative-provider')
METADATA = Path('/home/mouse9911/gits/plutosdr-fw-metadata-gain-timeline-v8')


def run(command, log, **kwargs):
    original, attempt = log, 0
    while log.exists():
        attempt += 1
        log = original.with_name(original.name + f'.retry{attempt}')
    with log.open('x') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, **kwargs)
    if result.returncode:
        print(log.read_text()[-12000:], flush=True)
        raise RuntimeError(f'{command[0]} failed ({result.returncode}); {log}')


def prepare():
    sdk = build_scanner_glrt_port(DEST / 'sdk.so')
    config = json.loads((ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json').read_text())
    flags = tuple(config['common_flags']) + tuple(
        f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
    ) + tuple(f'-DLEO_PRESENCE_{name}=1' for name in (
        'DIFFERENTIAL_CI16', 'RANK_HYBRID_PROJECTION', 'GLRT_SYMBOL_DIVERSITY',
        'RANK_AMPLITUDE_WEIGHTED', 'BOUNDED_MAGNITUDE', 'CONDITIONED_BLOCK_ROTATION',
        'ENERGY_SUPPORT', 'ENERGY_SYMBOL_SUPPORT',
    ))
    worker = build_worker(DEST / 'worker', cflags=flags)
    worker.chmod(0o755)
    for rate in (2500000, 5000000):
        write_templates(DEST / f'{rate}.templates', rate)
        (DEST / f'{rate}.templates').chmod(0o600)
        for edge in ('lower', 'upper'):
            iq, _ = generate(rate, edge, 92851, 'pilot', 0)
            (DEST / f'{rate}-{edge}.ci16').write_bytes(iq.astype('<i2', copy=False).tobytes())
    print(f'Prepared SDK, worker and explicit synthetic pilot fixtures: {sdk}', flush=True)


def case(name):
    assert name in ('off', 'on', 'asan')
    build = DEST / name
    sdk = DEST / 'sdk.so'
    if name == 'asan':
        sdk = DEST / 'sdk-asan.so'
        if not sdk.exists():
            build_scanner_glrt_port(sdk, cflags=(
                '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-g', '-O1',
            ))
    options = [
        '-DWITH_TESTS=ON', '-DWITH_IIOD=ON', '-DWITH_XML_BACKEND=ON',
        '-DWITH_LOCAL_BACKEND=ON', '-DWITH_USB_BACKEND=OFF', '-DWITH_SERIAL_BACKEND=OFF',
        '-DHAVE_DNS_SD=OFF', '-DWITH_AIO=OFF', '-DWITH_ZSTD=OFF', '-DWITH_DOC=OFF',
        '-DWITH_MAN=OFF', '-DIIOD_SCANNER_GLRT_MODE=positive-only-v1',
        '-DIIOD_SCANNER_GLRT_MINIMUM_EXACT_SCORE=0.175',
        '-DIIOD_SCANNER_GLRT_MINIMUM_MARGIN=0.025', '-DIIOD_SCANNER_ADAPTIVE_HOP=ON',
        '-DIIOD_SCANNER_GLRT_CAPTURE_PROTECTION=ON',
        f'-DIIOD_SCANNER_GLRT_COOPERATIVE_SKIPS={"OFF" if name == "off" else "ON"}',
        f'-DIIOD_BUFFER_METADATA_PROVIDER={LIBIIO}/iiod/spf-buffer-metadata.c',
        f'-DIIOD_BUFFER_PERSISTENT_HOP_DEVICE_PROVIDER={LIBIIO}/iiod/spf-hop-device-userspace.c',
        f'-DIIOD_BUFFER_METADATA_INCLUDE_DIRS={METADATA};/home/mouse9911/gits/plutosdr-fw/linux/usr/include',
        '-DIIOD_BUFFER_METADATA_PROVIDER_EXTRA_SOURCES=' + ';'.join(map(str, (
            LIBIIO / 'iiod/spf-tandem-session.c', LIBIIO / 'iiod/spf-tandem-metadata.c',
            *(METADATA / name for name in ('spf_gain_read.c', 'spf_gain_sampler.c',
                'spf_rssi_read.c', 'spf_radio_frame_v3.c', 'spf_thread_join.c')),
        ))),
        f'-DIIOD_SCANNER_GLRT_LIBRARY={sdk}',
        f'-DIIOD_SCANNER_GLRT_INCLUDE_DIR={ROOT}/src/leo/scanner/native_presence',
        f'-DIIOD_SCANNER_GLRT_WORKER_PATH={DEST}/worker',
        f'-DIIOD_SCANNER_GLRT_TEMPLATES_2500000={DEST}/2500000.templates',
        f'-DIIOD_SCANNER_GLRT_TEMPLATES_5000000={DEST}/5000000.templates',
        '-DIIOD_SCANNER_GLRT_ALGORITHM_SHA256=' + '12' * 32,
        '-DIIOD_SCANNER_GLRT_CONFIGURATION_SHA256=' + '34' * 32,
    ]
    if name == 'asan':
        options += ['-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer -g',
                    '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(['cmake', '-S', str(LIBIIO), '-B', str(build), *options], DEST / f'{name}-configure.log', timeout=60)
    run(['cmake', '--build', str(build), '-j4', '--target', 'iiod', 'test_scanner_glrt_provider',
         'test_scanner_glrt_network_server', 'test_spf_hop_adaptive_native', 'test_spf_hop_adaptive_policy'],
        DEST / f'{name}-build.log', timeout=120)
    print(f'{name}: real provider/daemon build passed', flush=True)
    env = os.environ.copy()
    for rate in (2500000, 5000000):
        for edge in ('lower', 'upper'):
            env[f'SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}'] = str(DEST / f'{rate}-{edge}.ci16')
    env['ASAN_OPTIONS'] = 'detect_leaks=1:halt_on_error=1'
    env['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
    for target in ('test_spf_hop_adaptive_native', 'test_spf_hop_adaptive_policy', 'test_scanner_glrt_provider'):
        run([str(build / 'iiod' / target)], DEST / f'{name}-{target}.log', timeout=100, env=env)
        print(f'{name}: {target} passed', flush=True)
    files = [sdk, DEST / 'worker', build / 'iiod/test_scanner_glrt_provider']
    receipt = {'case': name, 'passed': True, 'synthetic_iq_only': True,
               'leo_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
               'libiio_diff': subprocess.check_output(['git', 'diff'], cwd=LIBIIO, text=True),
               'artifacts': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    receipt['sanitizer_scope'] = 'SDK, provider and policy; isolated numerical worker unsanitized' if name == 'asan' else None
    receipt_path = DEST / f'{name}-receipt.json'
    attempt = 0
    while receipt_path.exists():
        attempt += 1
        receipt_path = DEST / f'{name}-receipt-retry{attempt}.json'
    with receipt_path.open('x') as output:
        json.dump(receipt, output, indent=2)
        output.write('\n')


if __name__ == '__main__':
    prepare() if sys.argv[1] == 'prepare' else case(sys.argv[1])

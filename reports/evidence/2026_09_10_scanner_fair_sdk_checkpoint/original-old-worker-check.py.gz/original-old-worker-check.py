"""Try only an archived numerical worker; no hardware or daemon operations."""

import ctypes as ct
import errno
import hashlib
import json
import os
from pathlib import Path

from tests.scanner.test_scanner_glrt_port import Config, load_port
from tools.native_presence import build_scanner_glrt_port, write_templates

root = Path(__file__).parent
worker = Path('/tmp/leo-cooperative-provider-final.6laOv4/worker')
worker_sha = hashlib.sha256(worker.read_bytes()).hexdigest()
assert worker_sha == '2191e8ed881bf7a01769bbb0288ac41a0c21664aced57a1a2fdd582e6ee859c0'
binary = build_scanner_glrt_port(root / 'new-sdk.so')
port = load_port(binary)
template = root / 'templates-2500000.bin'
write_templates(template, 2500000)
template.chmod(0o600)
config = Config(71, 9, 2500000, 1, 2500, 50000)
config.algorithm_sha256[:] = [18] * 32
config.configuration_sha256[:] = [52] * 32
pointer = ct.c_void_p()
children = Path(f'/proc/self/task/{os.getpid()}/children')
before = children.read_text().split()
result = port.leo_scanner_glrt_open(ct.byref(pointer), ct.byref(config),
    os.fsencode(worker), os.fsencode(template))
assert result == -errno.EIO and pointer.value is None
assert children.read_text().split() == before
receipt = {
    'scope': 'Archived legacy numerical worker + new SDK, no RF',
    'worker_sha256': worker_sha,
    'sdk_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'open_result': result,
    'returned_session': pointer.value,
    'child_reaped': True,
}
with (root / 'legacy-worker-rejection.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))

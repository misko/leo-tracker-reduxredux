"""Reuse the recording checkpoint's bounded non-IQ evidence archive format."""

from __future__ import annotations

import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

RAW = Path(__file__).parent
LEO = Path("/home/mouse9911/gits/leo-tracker-arm-presence")
PPU = Path("/home/mouse9911/gits/pluto-plus-utils-arm-glrt-host")
LIBIIO = Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration")
DEST = LEO / "reports/evidence/2026_09_09_adaptive_runtime"
FINAL = ("leo-final.xml", "ppu-final.xml", "network-final.xml")


def sha(payload):
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def run(cwd, command):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=60)
    return dict(command=command, cwd=str(cwd), returncode=result.returncode,
                stdout=result.stdout, stderr=result.stderr)


def main():
    final_counts = {}
    for name in FINAL:
        suite = ET.parse(RAW / name).getroot().find("testsuite")
        assert suite is not None
        assert all(int(suite.attrib[k]) == 0 for k in ("failures", "errors", "skipped")), name
        final_counts[name] = int(suite.attrib["tests"])
    changed = run(LEO, ["git", "ls-files", "-m", "-o", "--exclude-standard"])
    assert changed["returncode"] == 0
    files = sorted({name for name in changed["stdout"].splitlines()
                    if name.startswith(("src/", "tests/")) and name.endswith(".py")})
    assert files
    commands = []
    for root in (LEO, PPU, LIBIIO):
        for command in (["git", "status", "--short"], ["git", "rev-parse", "HEAD"],
                        ["git", "diff", "--check"]):
            commands.append(run(root, command))
    for root in (LEO, PPU):
        commands.append(run(root, ["git", "rev-parse", "origin/main"]))
        commands.append(run(root, ["git", "merge-base", "--is-ancestor", "origin/main", "HEAD"]))
    venv = Path("/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin")
    commands.append(run(LEO, [str(venv / "ruff"), "check", *files]))
    commands.append(run(LEO, [str(venv / "python"), "-m", "mypy", "--python-version=3.12",
                             "--follow-imports=silent", *[p for p in files if p.startswith("src/")]]))
    assert all(record["returncode"] == 0 for record in commands), commands
    source_hashes = {"leo:" + name: sha((LEO / name).read_bytes()) for name in files}
    source_hashes.update({"ppu:" + name: sha((PPU / name).read_bytes()) for name in (
        "src/pluto_plus/adaptive_hop_client.py", "src/pluto_plus/adaptive_hop_stream.py",
        "src/pluto_plus/hardware/iio_adaptive_hop.py", "src/pluto_plus/hardware/pss_control.py",
        "src/pluto_plus/hardware/pss_iio.py", "tests/test_pss_control.py")})
    DEST.mkdir(parents=True, exist_ok=False)
    records = []
    for path in sorted(RAW.iterdir()):
        if path.suffix not in (".xml", ".py"):
            continue
        payload = path.read_bytes()
        assert len(payload) < 8 * 1024 * 1024
        compressed = gzip.compress(payload, mtime=0)
        target = DEST / (path.name + ".gz")
        target.write_bytes(compressed)
        record = dict(path=target.name, bytes=len(payload), sha256=sha(payload),
                      compressed_sha256=sha(compressed), final=path.name in FINAL)
        if path.suffix == ".xml":
            suite = ET.fromstring(payload).find("testsuite")
            record["suite"] = dict(suite.attrib)
            record["cases"] = [dict(name=case.attrib["name"], time=case.attrib.get("time"),
                properties={p.attrib["name"]: p.attrib["value"] for p in case.findall("properties/property")})
                for case in suite.findall("testcase") if case.find("properties") is not None]
        records.append(record)
    server = Path("/tmp/leo-adaptive-provider.nZDbhN/adaptive-positive/iiod/test_scanner_glrt_network_server")
    index = dict(schema_version=1, scope="scheduled adaptive application, concrete adapter, source binding, IQ/publication and retry",
                 excludes=["live RF", "ARM throughput qualification", "detector sensitivity qualification", "production deployment", "adaptive UI"],
                 final_receipts=FINAL, final_counts=final_counts, artifacts=records,
                 source_hashes=source_hashes, commands=commands,
                 server=dict(path=str(server), sha256=sha(server.read_bytes())))
    (DEST / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    print(json.dumps({"evidence": str(DEST), "artifacts": len(records), "final_counts": final_counts}))


if __name__ == "__main__":
    main()

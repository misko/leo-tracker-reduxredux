"""Post-hoc symbol-diversity comparison on the existing 64-dwell RF cohort."""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path

import numpy as np

from leo.storage.persistent_hop import PersistentHopIqStore
from leo.storage.persistent_hop_analysis_source import PersistentHopAnalysisInputStore
from tools.evaluate_presence_decision_rf import load_references, validate_reference, visits
from tools.evaluate_native_presence_budgets import associated
from tools.presence_decision_challenge import passing
from tools.presence_dwell import NativeDwell, unpack
from tools.qualify_native_presence import digest, write_json
from tools.benchmark_presence_execution import numerical

root = Path('/tmp/leo-presence-structured.ZxAkDl')
output = root / 'rf-diversity-final'
reference_path = Path('reports/evidence/2026_09_08_arm_presence_decision/rf-diagnostic')
protocol = json.loads(Path('config/analysis/arm-presence-decision-challenge-v1.json').read_text())
inputs = PersistentHopAnalysisInputStore(PersistentHopIqStore.open_read_only(Path('/srv/bulk/leo')))
sources = [inputs.source(s['session_id']) for s in protocol['rf_sessions']]
indices = visits(protocol)
references = load_references(reference_path, {s.session_id:s.input_manifest_sha256 for s in sources}, indices)
libraries = {kind+'_'+name: root/area/f'{name}.so' for kind,area in [('original','challenge'),('diverse','diversity-final')]
             for name in ('normalized','amplitude')}
output.mkdir(exist_ok=False)
write_json(output/'freeze.json', dict(
    scope='post-hoc opened RF; reference agreement is not independent truth',
    recipe_sha256=digest(Path(__file__)), reference_sha256=digest(reference_path/'results.jsonl'),
    sessions={s.session_id:s.input_manifest_sha256 for s in sources}, visits=indices,
    libraries={name:dict(path=str(path),sha256=digest(path)) for name,path in libraries.items()},
    rx=1, confirmations=1, timing_repeats=5,
    timing_order='alternating forward/reverse artifact order by visit/repetition',
    policy=protocol['policies']['frozen_absolute_score_hypothesis']))
rows=[]
with ExitStack() as stack, (output/'results.jsonl').open('x') as stream:
    engines={}
    for source in sources:
        assert source.receipt.qualified and source.plan.valid_visit_ms==120 and 1 in source.receiver_ids
        for index in indices:
            visit=source.read_visit(index)
            rate,edge=source.sample_rate_hz,visit.span.target.edge
            iq=np.ascontiguousarray(visit.samples_ci16[:,source.receiver_ids.index(1),:])
            sha=hashlib.sha256(iq.tobytes()).hexdigest()
            prior=references[source.session_id,index]
            validate_reference(prior,input_sha=sha,rate=rate,edge=edge,counter=visit.span.valid_device_sample_counter)
            refs=[[c for c in cs if c['margin']>=0.025] for cs in prior['reference_candidates']]
            variants={}
            for name,path in libraries.items():
                key=name,rate,edge
                if key not in engines:
                    engines[key]=stack.enter_context(NativeDwell(path,rate,edge,512))
                result=unpack(engines[key].run(iq,maximum=1,seeded=False))
                selected=result['rank']['order'][0]
                confirm=result['confirmations'][0]
                candidates=confirm['candidates'][:confirm['candidate_count']]
                accepted=passing(candidates,protocol['policies']['frozen_absolute_score_hypothesis'])
                if name=='original_normalized':
                    assert selected==prior['selected_window'] and candidates==prior['candidates']
                variants[name]=dict(result=result,selected_window=selected,flagged=bool(accepted),
                                    same_slice_associated=any(associated(c,r,rate,protocol['association'])
                                                              for c in accepted for r in refs[selected]),
                                    within_dwell_associated=any(associated(c,r,rate,protocol['association'])
                                                                for c in accepted for rs in refs for r in rs))
            # A separate paired recurring-execution comparison after the
            # scientific first runs; source IQ and every numerical result stay fixed.
            timing={name:[] for name in libraries}
            for repeat in range(5):
                names=list(libraries) if (index+repeat)%2==0 else list(reversed(libraries))
                for name in names:
                    result=unpack(engines[name,rate,edge].run(iq,maximum=1,seeded=False))
                    assert numerical(result)==numerical(variants[name]['result'])
                    timing[name].append({key:result[key] for key in ('total_cpu_ms','total_wall_ms')})
            assert hashlib.sha256(iq.tobytes()).hexdigest()==sha
            row=dict(session=source.session_id,visit=index,rate_hz=rate,edge=edge,
                     source_counter=str(visit.span.valid_device_sample_counter),iq_sha256=sha,
                     timing=timing,reference_positive=any(refs),strong_reference_positive=any(
                         c['exact_score']>=0.175 for rs in refs for c in rs),variants=variants)
            rows.append(row); stream.write(json.dumps(row,allow_nan=False)+'\n'); stream.flush()
            if len(rows)%8==0: print(f'{len(rows)}/64 RF identities and original first results verified',flush=True)
summary={}
for name in libraries:
    positive=[r for r in rows if r['reference_positive']]
    unresolved=[r for r in rows if not r['reference_positive']]
    summary[name]=dict(reference_positive=len(positive),flags_in_reference_positive=sum(r['variants'][name]['flagged'] for r in positive),
                       same_slice_associated=sum(r['variants'][name]['same_slice_associated'] for r in positive),
                       within_dwell_associated=sum(r['variants'][name]['within_dwell_associated'] for r in positive),
                       unresolved=len(unresolved),unresolved_flags=sum(r['variants'][name]['flagged'] for r in unresolved))
timing_summary={}
for rate in (2500000,5000000):
    timing_summary[str(rate)]={name:{field:np.percentile(
        [v[field] for r in rows if r['rate_hz']==rate for v in r['timing'][name]],[50,95,99,100]).tolist()
        for field in ('total_cpu_ms','total_wall_ms')} for name in libraries}
write_json(output/'timing-summary.json',dict(scope='paired desktop warm recurring calls; not ARM or live duty',rates=timing_summary))
write_json(output/'summary.json',summary)
print(json.dumps(summary,indent=2),flush=True)

"""Post-hoc symbol-diversity ablation on the opened structured challenge."""
import hashlib
import json
from pathlib import Path
from contextlib import ExitStack

from tools.native_presence import build_dwell_presence
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_decision_challenge import passing, associated
from tools.presence_structured_challenge import PROTOCOL, generate, summarize
from tools.presence_fftw import fftw_options
from tools.qualify_native_presence import digest, write_json
from tools.benchmark_presence_execution import numerical

root = Path('/tmp/leo-presence-structured.ZxAkDl')
source, output = root / 'challenge', root / 'diversity-final'
protocol = json.loads(PROTOCOL.read_text())
original_freeze = json.loads((source / 'freeze.json').read_text())
original_rows = [json.loads(line) for line in (source / 'results.jsonl').read_text().splitlines()]
prototype_rows = [json.loads(line) for line in (root/'diversity/results.jsonl').read_text().splitlines()]
assert protocol == original_freeze['protocol']
assert digest(Path('tools/presence_structured_challenge.py')) == original_freeze['tool_sha256']
output.mkdir(exist_ok=False)
write_json(output / 'freeze.json', dict(
    scope='post-hoc development, not fresh qualification', protocol=protocol,
    source_results_sha256=digest(source / 'results.jsonl'),
    source_freeze_sha256=digest(source / 'freeze.json'),
    prototype_results_sha256=digest(root/'diversity/results.jsonl'),
    recipe_sha256=digest(Path(__file__)),
    change='alternate final-scoring frame regions 2..65 / 152..215; retain early epoch lattice',
    thresholds_changed=False, confirmations=1, blocks_per_frame=1, symbols_per_block=64))
detector = json.loads(Path(protocol['detector_protocol']).read_text())
flags = tuple(detector['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{k}={v}' for k, v in detector['variants'][0]['defines'].items()
) + ('-DLEO_PRESENCE_DIFFERENTIAL_CI16=1', '-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1',
     '-DLEO_PRESENCE_GLRT_SYMBOL_DIVERSITY=1')
options = fftw_options(Path('/tmp/leo-presence-fftw.nLw4v6/install'))
libraries = {name: build_dwell_presence(output / f'{name}.so', cflags=flags+options['cflags']+
             (f'-DLEO_PRESENCE_RANK_AMPLITUDE_WEIGHTED={int(name=="amplitude")}',),
             ldflags=options['ldflags'], dependencies=options['dependencies'])
             for name in protocol['variants']}
rows = []
with ExitStack() as stack, (output / 'results.jsonl').open('x') as stream:
    engines = {}
    for index, prior in enumerate(original_rows):
        spec = original_freeze['cases'][index]
        iq, truth = generate(spec, protocol)
        assert truth == prior['truth']
        assert hashlib.sha256(iq.tobytes()).hexdigest() == prior['iq_sha256']
        variants = {}
        for name in protocol['variants']:
            key = name, spec['rate_hz'], spec['edge']
            if key not in engines:
                engines[key] = stack.enter_context(NativeDwell(libraries[name], *key[1:], 512))
            result = unpack(engines[key].run(iq, maximum=1, seeded=False))
            assert numerical(result)==numerical(prototype_rows[index]['variants'][name]['result'])
            selected = result['rank']['order'][0]
            confirm = result['confirmations'][0]
            accepted = passing(confirm['candidates'][:confirm['candidate_count']], protocol['policy'])
            assert selected == prior['variants'][name]['selected_window']
            old_confirm = prior['variants'][name]['result']['confirmations'][0]
            assert confirm['candidate_count'] == old_confirm['candidate_count']
            for actual, old in zip(confirm['candidates'], old_confirm['candidates'], strict=True):
                for field in ('epoch', 'fractional_complete', 'fractional_offset_samples',
                              'acquired_cfo_hz', 'exact_grid', 'control_grid'):
                    assert actual[field] == old[field], field
            variants[name] = dict(result=result, screens=unpack(engines[key].screens()),
                                  selected_window=selected, flagged=bool(accepted),
                                  associated=any(associated(c, truth, selected, protocol['association'])
                                                 for c in accepted))
        row = dict(truth=truth, iq_sha256=prior['iq_sha256'], variants=variants)
        rows.append(row)
        stream.write(json.dumps(row, allow_nan=False)+'\n')
        stream.flush()
        if (index+1)%40==0:
            print(f'{index+1}/480 regenerated IQ identities and unchanged acquisition/epoch lattices verified', flush=True)
summary = dict(scope='post-hoc opened challenge; not qualification', cases=len(rows), results=summarize(rows, protocol))
write_json(output / 'summary.json', summary)
print(json.dumps(summary, indent=2), flush=True)

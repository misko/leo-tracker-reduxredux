"""Cross-build userspace workers and run bounded sanitizer replay, no radio."""
from pathlib import Path
import json
import os
import subprocess

from tools.native_presence import build_dwell_presence, build_worker, write_templates
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_structured_challenge import PROTOCOL, generate
from tools.presence_window_rank import write_rank_probe
from tools.presence_fftw import fftw_options
from tools.qualify_native_presence import digest, write_json
from tools.benchmark_presence_execution import numerical, differences

root=Path('/tmp/leo-presence-structured.ZxAkDl')
out=root/'execution'
out.mkdir(exist_ok=False)
protocol=json.loads(PROTOCOL.read_text())
detector=json.loads(Path(protocol['detector_protocol']).read_text())
flags=tuple(detector['common_flags'])+tuple(f'-DLEO_PRESENCE_{k}={v}' for k,v in detector['variants'][0]['defines'].items())+(
    '-DLEO_PRESENCE_DIFFERENTIAL_CI16=1','-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1','-DLEO_PRESENCE_GLRT_SYMBOL_DIVERSITY=1')
arm=fftw_options(Path('/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr'),runtime_rpath=False)
compiler='/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc'
write_json(out/'freeze.json',dict(recipe_sha256=digest(Path(__file__)),protocol_sha256=digest(PROTOCOL),
    scope='sanitizer memory/UB/leaks and same-backend numerical execution; cross-build is not ARM timing',
    cases_per_variant=8,repeats=2,confirmations=6,rtol=1e-9,atol=1e-10))
artifacts={}
for name,amplitude in [('normalized',0),('amplitude',1)]:
    options=flags+(f'-DLEO_PRESENCE_RANK_AMPLITUDE_WEIGHTED={amplitude}',)
    artifacts[name]=build_dwell_presence(out/f'{name}.so',cflags=options)
    build_dwell_presence(out/f'{name}-sanitize',executable=True,cflags=options+('-fsanitize=address,undefined','-fno-omit-frame-pointer'))
    build_worker(out/f'{name}-arm',compiler=compiler,cflags=options+('-mcpu=cortex-a9','-mfpu=neon','-mfloat-abi=hard')+arm['cflags'],
                 ldflags=arm['ldflags'],dependencies=arm['dependencies'])

def subset(expected,actual):
    if isinstance(actual,dict): return {k:subset(expected[k],v) for k,v in actual.items()}
    if isinstance(actual,list):
        assert len(expected)==len(actual)
        return [subset(a,b) for a,b in zip(expected,actual,strict=True)]
    return expected

runs=[]
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for rate in (2500000,5000000):
    template=out/f'{rate}.templates'; write_templates(template,rate)
    for edge in ('lower','upper'):
        for kind,seed in [('repeating_qpsk',91004),('pilot_plus_tone',92001)]:
            spec=dict(rate_hz=rate,edge=edge,kind=kind,seed=seed,snr_db=12.0 if kind=='repeating_qpsk' else 0.0,
                      start_ms=0.0 if kind=='repeating_qpsk' else 40.0,duration_ms=120.0 if kind=='repeating_qpsk' else 20.0)
            if kind=='pilot_plus_tone': spec['tone_offset_hz']=220000.0
            iq,truth=generate(spec,protocol)
            counter=2**64-1-len(iq)
            probe=out/f'{rate}-{edge}-{kind}.rank'; write_rank_probe(probe,iq,rate,edge,counter)
            for name,library in artifacts.items():
                with NativeDwell(library,rate,edge,512) as native:
                    expected=numerical(unpack(native.run(iq,maximum=6,seeded=False)))
                    screens=numerical(unpack(native.screens()))
                for c in expected['confirmations']: c['candidates']=c['candidates'][:c['candidate_count']]
                command=[str(out/f'{name}-sanitize'),str(probe),str(template),'512','6','blind','2']
                process=subprocess.run(command,text=True,capture_output=True,env=env,timeout=50)
                record=dict(command=command,truth=truth,returncode=process.returncode,stderr=process.stderr,stdout=process.stdout)
                runs.append(record)
                write_json(out/f'run-{len(runs):02}.json',record)
                assert process.returncode==0 and not process.stderr
                rows=[json.loads(line) for line in process.stdout.splitlines()]
                assert len(rows)==2
                for index,row in enumerate(rows):
                    assert row['counter']==str(counter) and row['iteration']==index and row['confirmation_count']==6
                    actual=numerical({k:v for k,v in row.items() if k in expected})
                    assert not differences(subset(expected,actual),actual)
                    assert not differences(screens,numerical(row['screen_diagnostics']))
                print(f'{len(runs)}/16 instrumented processes passed',flush=True)
write_json(out/'results.json',runs)
write_json(out/'summary.json',dict(processes=len(runs),dwell_executions=2*len(runs),confirmations=12*len(runs),
                                  sanitizer_diagnostics=0,numerical_mismatches=0,arm_workers_cross_built=2))

"""Retain numerical evidence and one figure, without IQ or executables."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from tools.qualify_native_presence import digest, write_json

repo=Path.cwd()
root=Path('/tmp/leo-presence-structured.ZxAkDl')
out=repo/'reports/evidence/2026_09_08_arm_presence_structured'
figures=repo/'reports/figures/2026_09_08_arm_presence_structured'
out.mkdir(parents=True,exist_ok=False); figures.mkdir(parents=True,exist_ok=False)
artifacts={}

def retain(path,name,compress=False):
    raw=path.read_bytes(); data=gzip.compress(raw,mtime=0) if compress else raw
    target=out/(name+('.gz' if compress else '')); target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(data)
    artifacts[str(target.relative_to(out))]=dict(source=str(path),sha256=digest(target),
        original_sha256=hashlib.sha256(raw).hexdigest(),original_bytes=len(raw),retained_bytes=len(data))

for area in ('challenge','diversity','diversity-final','rf-diversity','rf-diversity-final','execution'):
    for path in sorted((root/area).iterdir()):
        if path.name in ('freeze.json','summary.json','results.jsonl','results.json','timing-summary.json') or path.name.endswith('.build.json'):
            retain(path,area+'/'+path.name,path.name in ('results.jsonl','results.json'))
        if path.name.endswith('.build.json') and area in ('diversity-final','execution'):
            metadata=json.loads(path.read_text())
            assert digest(path.with_name(path.name.removesuffix('.build.json')))==metadata['binary_sha256']
            assert all(digest(repo/relative)==sha for relative,sha in metadata['sources_sha256'].items())
for name in ('generator-tests.xml','diversity-tests.xml','regression.xml','regression-final.xml'):
    retain(root/name,name)
for name in ('evaluate_diversity.py','evaluate_diversity_prototype.py','evaluate_rf.py',
             'evaluate_rf_prototype.py','verify_diversity_execution.py','save_report_evidence.py'):
    retain(root/name,'recipes/'+name,True)
suite=ET.parse(root/'regression-final.xml').getroot().find('testsuite')
assert (suite.get('tests'),suite.get('errors'),suite.get('failures'),suite.get('skipped'))==('613','0','0','0')
initial=json.loads((root/'challenge/summary.json').read_text())['results']
final=json.loads((root/'diversity-final/summary.json').read_text())['results']
rf=json.loads((root/'rf-diversity-final/summary.json').read_text())
timing=json.loads((root/'rf-diversity-final/timing-summary.json').read_text())
summary={}
for label,study,variant in [('Normalized',initial,'normalized'),('Amplitude',initial,'amplitude'),
                           ('Normalized + diversity',final,'normalized'),('Amplitude + diversity',final,'amplitude')]:
    result=study[variant]
    summary[label]=dict(nonpilot_flags=result['nonpilot_flags'],nonpilot_cases=result['nonpilot_cases'],
        primary_associated=result['primary_associated'],primary_cases=result['primary_cases'],
        boundary_associated=sum(v['associated'] for k,v in result['groups'].items() if ':boundary_pilot:' in k),
        boundary_flagged=sum(v['flagged'] for k,v in result['groups'].items() if ':boundary_pilot:' in k),
        boundary_cases=80,bounded_challenge_pass=result['bounded_challenge_pass'])
write_json(out/'comparison.json',dict(synthetic=summary,rf=rf,desktop_timing=timing))
artifacts['comparison.json']=dict(sha256=digest(out/'comparison.json'))
labels=['Normalized\nearly only','Amplitude\nearly only','Normalized\nearly/late','Amplitude\nearly/late']
values=list(summary.values()); x=np.arange(4)
fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
for shift,key,denom,label,color in [(-.18,'primary_associated',144,'20 ms pilot / pilot + tone','#397fab'),
                                  (.18,'boundary_associated',80,'4 ms boundary bursts','#c07b37')]:
    counts=[v[key] for v in values]
    bars=axes[0].bar(x+shift,np.array(counts)/denom*100,.36,label=label,color=color)
    axes[0].bar_label(bars,labels=[f'{n}/{denom}' for n in counts],fontsize=8,padding=2)
axes[0].set(xticks=x,xticklabels=labels,ylim=(0,116),ylabel='Associated model injections (%)',title='Recall: short bursts remain a limitation')
axes[0].legend(fontsize=8,loc='upper left',bbox_to_anchor=(0,-.19))
bars=axes[1].bar(x,[v['nonpilot_flags'] for v in values],color=['#a95660','#a95660','#408977','#408977'])
axes[1].bar_label(bars,labels=[f"{v['nonpilot_flags']}/256" for v in values],padding=4)
axes[1].set(xticks=x,xticklabels=labels,ylim=(0,4),yticks=range(5),ylabel='Flags on structured nonpilot controls',
            title='Specificity: repeating payload was a missing control')
for ax in axes: ax.set_axisbelow(True); ax.grid(axis='y',alpha=.2)
fig.suptitle('RX1, 120 ms, one confirmation; early/late results are post-hoc development\nSame symbol/FFT budgets do not establish unchanged ARM runtime or RF duty',fontsize=11)
figure=figures/'structured-challenge.png'; fig.savefig(figure,dpi=170); plt.close(fig)
write_json(out/'receipt.json',dict(
    implementation_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    scope='offline development; no classification policy, RF, deployment, firmware or remote-main changes',
    checks=dict(component_tests=613,instrumented_processes=16,instrumented_dwells=32,instrumented_confirmations=192,
                fresh_initial_synthetic_cases=480,posthoc_cases=480,hash_reproduced_rf_dwells=64,arm_cross_builds=2),
    gate='Initial normalized and amplitude gates failed. Post-hoc amplitude + symbol diversity passes the same bounded synthetic gate, not fresh qualification.',
    original_rf_access_failure='Initial ordinary-group read could not enumerate protected sessions. Repeated with the previously used mouse9911 user and leo group; no archive permissions or contents changed.',
    arm_context='No ARM execution. Spare .15 may regenerate host keys on reboot per relayed user context; its fingerprint is not independently verified. Another campaign owns this spare; serialize access and do not disrupt it.',
    commands=dict(
        python='/home/mouse9911/gits/leo-tracker-reduxredux/.venv/bin/python',
        environment='PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. OPENBLAS_NUM_THREADS=1 FFTW_PREFIX=/tmp/leo-presence-fftw.nLw4v6/install',
        initial='-m tools.presence_structured_challenge /tmp/leo-presence-structured.ZxAkDl/challenge --fftw-prefix /tmp/leo-presence-fftw.nLw4v6/install',
        ablation=str(root/'evaluate_diversity.py'),rf=str(root/'evaluate_rf.py'),sanitizer=str(root/'verify_diversity_execution.py'),
        rf_user_group='sudo -n -u mouse9911 -g leo /usr/bin/env; absolute PYTHONPATH for the Leo and PPU worktrees',
        pytest='-m pytest -q tests/analysis/test_native_presence_execution.py tests/analysis/test_native_presence.py tests/analysis/test_presence_dwell.py tests/analysis/test_native_presence_ci16_fold.py tests/analysis/test_native_presence_ci16_lag.py tests/analysis/test_native_presence_fftw.py tests/analysis/test_native_presence_differential.py tests/analysis/test_native_presence_symbol_diversity.py tests/analysis/test_presence_structured_challenge.py tests/analysis/test_presence_decision_challenge.py tests/scanner/test_native_presence_dwell_worker.py tests/scanner/test_glrt_frame_result.py --junitxml=/tmp/leo-presence-structured.ZxAkDl/regression-final.xml'),
    artifacts=artifacts,figures={str(figure.relative_to(repo)):digest(figure)}))
print(json.dumps(dict(output=str(out),summary=summary,figure=str(figure)),indent=2))

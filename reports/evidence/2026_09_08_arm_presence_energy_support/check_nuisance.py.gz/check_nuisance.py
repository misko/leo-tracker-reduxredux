"""Fresh nuisance controls, with no invalid rolled-pilot negative label."""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path

from tools.presence_decision_challenge import generate, passing
from tools.presence_dwell import NativeDwell, unpack
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
output = root / "nuisance"
output.mkdir(exist_ok=False)
names = ("amplitude-diverse", "amplitude-diverse-supported")
libraries = {n: root / "final-replay" / f"{n}.so" for n in names}
identities = {n: digest(p) for n, p in libraries.items()}
kinds = ("white_noise", "colored_noise", "tone", "two_tones", "pulsed_tone", "chirp", "clipped_tones")
inventory = [dict(rate_hz=rate, edge=edge, kind=kind, start_ms=0.0, duration_ms=120.0)
             for rate in (2500000, 5000000) for edge in ("lower", "upper")
             for kind in kinds for _ in range(8)]
for index, spec in enumerate(inventory):
    spec["seed"] = 2026100000 + index
policy = dict(minimum_exact_score=.175, minimum_margin=.025)
write_json(output / "freeze.json", dict(recipe_sha256=digest(Path(__file__)),
    generator_sha256=digest(Path(generate.__code__.co_filename)), libraries=identities,
    cases=inventory, policy=policy, state="frozen_before_generation_and_scoring",
    scope="independent-per-case synthetic nuisance; conditional controls, not operational FAR"))
rows = []
with ExitStack() as stack, (output / "results.jsonl").open("x") as stream:
    engines = {}
    for spec in inventory:
        iq, truth = generate(spec)
        assert not truth["starlink_model_present"]
        sha = hashlib.sha256(iq.tobytes()).hexdigest()
        variants = {}
        for name in names if len(rows) % 2 == 0 else reversed(names):
            key = name, spec["rate_hz"], spec["edge"]
            if key not in engines:
                engines[key] = stack.enter_context(NativeDwell(libraries[name], *key[1:], 512))
            result = unpack(engines[key].run(iq, maximum=1, seeded=False))
            confirmation = result["confirmations"][0]
            accepted = passing(confirmation["candidates"][:confirmation["candidate_count"]], policy)
            variants[name] = dict(result=result, flagged=bool(accepted))
        assert hashlib.sha256(iq.tobytes()).hexdigest() == sha
        row = dict(truth=truth, iq_sha256=sha, variants=variants)
        rows.append(row)
        stream.write(json.dumps(row, allow_nan=False) + "\n")
        stream.flush()
        if len(rows) % 32 == 0:
            print(f"{len(rows)}/224 fresh nuisance controls", flush=True)
assert identities == {n: digest(p) for n, p in libraries.items()}
summary = {n: {kind: dict(cases=sum(r["truth"]["kind"] == kind for r in rows),
    flagged=sum(r["variants"][n]["flagged"] for r in rows if r["truth"]["kind"] == kind))
    for kind in kinds} for n in names}
write_json(output / "summary.json", summary)
print(json.dumps(summary, indent=2), flush=True)

"""Derive the checkpoint, figures and lossless non-IQ evidence inventory."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from tools.benchmark_presence_execution import differences, numerical
from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
out = ROOT / "reports/evidence/2026_09_08_arm_presence_energy_support"
figures = ROOT / "reports/figures/2026_09_08_arm_presence_energy_support"
out.mkdir(exist_ok=False)
figures.mkdir(exist_ok=False)

def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]

fresh = rows(root / "fresh/results.jsonl")
final = rows(root / "final-replay/results.jsonl")
rf = rows(root / "rf/results.jsonl")
nuisance = rows(root / "nuisance/results.jsonl")
names = ("amplitude-diverse", "amplitude-diverse-supported")
assert len(fresh) == len(final) == 576 and len(rf) == 64 and len(nuisance) == 224
for a, b in zip(fresh, final, strict=True):
    assert a["truth"] == b["truth"] and a["iq_sha256"] == b["iq_sha256"]
    assert not differences(numerical(a["variants"]), numerical(b["variants"]))
    assert a["variants"][names[0]]["selected_window"] == a["variants"][names[1]]["selected_window"]
seeds = [r["truth"]["seed"] for r in final + nuisance]
assert len(seeds) == len(set(seeds)) == 800

def stage(row, name):
    truth, variant = row["truth"], row["variants"][name]
    window = variant["selected_window"]
    confirmation = variant["result"]["confirmations"][0]
    if variant["associated"]: return "Associated"
    if window*20 >= truth["start_ms"]+truth["duration_ms"] or (window+1)*20 <= truth["start_ms"]:
        return "Wrong slice"
    if not confirmation["candidate_count"]: return "No candidate"
    candidate = confirmation["candidates"][0]
    if abs(candidate["acquired_cfo_hz"]-truth["cfo_hz"]) > 8000: return "Initial CFO miss"
    if not candidate["fractional_complete"]: return "Fractional incomplete"
    period = truth["rate_hz"] / 750
    error = abs((candidate["epoch"]+candidate["fractional_offset_samples"]-truth["epoch_samples"]
                 + period/2) % period - period/2)
    if error / truth["rate_hz"] > 2e-6: return "Epoch mismatch"
    if not variant["flagged"]: return "Below fixed threshold"
    return "Tracking CFO mismatch"

boundary = [r for r in final if r["truth"]["kind"] == "boundary_pilot"]
groups = [
    ("20 ms signals\n−6 to +12 dB / tone", [r for r in final if r["truth"]["kind"] in ("pilot", "pilot_plus_tone")]),
    ("4 ms boundary\n−6 dB", [r for r in boundary if r["truth"]["snr_db"] == -6]),
    ("4 ms boundary\n+6 dB", [r for r in boundary if r["truth"]["snr_db"] == 6]),
]
counts = {n: [sum(r["variants"][n]["associated"] for r in rs) for _, rs in groups] for n in names}
stages = {n: dict(Counter(stage(r, n) for r in boundary)) for n in names}
paired = Counter((r["variants"][names[0]]["associated"], r["variants"][names[1]]["associated"]) for r in boundary)
rfsummary = json.loads((root / "rf/summary.json").read_text())
comparison = dict(
    scope="desktop, default-off; no RF, deployment or duty qualification",
    regenerated_numerical_parity_cases=576,
    independent_synthetic_cases=800,
    synthetic_groups={label.replace("\n", " "): dict(cases=len(rs), associated={n: counts[n][i] for n in names})
                      for i, (label, rs) in enumerate(groups)},
    synthetic_false_flags={n: sum(r["variants"][n]["flagged"] for r in final+nuisance
                                if not r["truth"]["starlink_model_present"]) for n in names},
    synthetic_negative_cases=480, boundary_failure_stages=stages,
    boundary_gains=paired[False, True], boundary_losses=paired[True, False],
    boundary_unassociated_flags={n: sum(r["variants"][n]["flagged"] and not r["variants"][n]["associated"]
                                       for r in boundary) for n in names},
    rf=rfsummary,
    rf_gained=[dict(session=r["session"], visit=r["visit"]) for r in rf
               if not r["variants"][names[0]]["within_dwell_associated"]
               and r["variants"][names[1]]["within_dwell_associated"]],
    rf_lost=[dict(session=r["session"], visit=r["visit"]) for r in rf
             if r["variants"][names[0]]["within_dwell_associated"]
             and not r["variants"][names[1]]["within_dwell_associated"]],
)
assert comparison["synthetic_false_flags"] == dict.fromkeys(names, 0)
test_counts = {}
for label, file in (("analysis", "regression-final.xml"), ("worker", "worker-tests.xml")):
    suites = ET.parse(root / file).getroot().findall("testsuite")
    assert all(int(s.get(k, 0)) == 0 for s in suites for k in ("failures", "errors", "skipped"))
    test_counts[label] = sum(int(s.get("tests", 0)) for s in suites)
comparison["passing_tests"] = test_counts
comparison["execution"] = json.loads((root / "execution/summary.json").read_text())
write_json(out / "comparison.json", comparison)

plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
colors = ("#526a89", "#138b79")
fig, axes = plt.subplots(1, 2, figsize=(13, 5.8), layout="constrained")
for index, name in enumerate(names):
    values = np.array(counts[name]) / np.array([len(rs) for _, rs in groups]) * 100
    bars = axes[0].bar(np.arange(3)+(index-.5)*.36, values, .36, color=colors[index],
                       label=("First two frames", "Energy-selected pair")[index])
    axes[0].bar_label(bars, labels=[f"{v}/{len(rs)}" for v, (_, rs) in zip(counts[name], groups)], padding=4)
axes[0].set(xticks=range(3), xticklabels=[label for label, _ in groups], ylim=(0, 118),
            ylabel="Truth-associated signals (%)", title="Fresh independent-per-case challenge")
axes[0].legend(loc="upper right", fontsize=9)
categories = ["Associated", "Wrong slice", "Initial CFO miss", "Fractional incomplete", "Below fixed threshold"]
palette = ["#138b79", "#afb7c2", "#dc9a41", "#925ca2", "#d36b67"]
for index, name in enumerate(names):
    left = 0
    for label, color in zip(categories, palette):
        count = stages[name].get(label, 0)
        axes[1].barh(index, count, left=left, color=color, label=label if index == 0 else None)
        if count >= 3: axes[1].text(left+count/2, index, str(count), ha="center", va="center", color="white")
        left += count
    assert left == 80
axes[1].set(yticks=[0, 1], yticklabels=["First two\nframes", "Energy-selected\npair"], xlim=(0, 80),
            xlabel="4 ms boundary cases (80 total)", title="Where the remaining misses occur")
axes[1].invert_yaxis()
axes[1].legend(loc="upper center", bbox_to_anchor=(.5, -.15), ncol=2, fontsize=9)
fig.suptitle("RX1 support selection: better CFO acquisition, incomplete burst recovery\n"
             "240/240 primary matches and 0/480 synthetic-negative flags for both versions", fontsize=13)
fig.savefig(figures / "synthetic-and-failure-stages.png", dpi=160)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), layout="constrained")
fields = ("same_slice_associated", "within_dwell_associated", "flags_in_positive")
for index, name in enumerate(names):
    values = [rfsummary["results"][name][key] for key in fields]
    bars = axes[0].bar(np.arange(3)+(index-.5)*.36, values, .36, color=colors[index],
                       label=("First two frames", "Energy-selected pair")[index])
    axes[0].bar_label(bars, padding=3)
axes[0].set(xticks=range(3), xticklabels=["Same-slice\nmatch", "Within-dwell\nmatch", "Flag in reference-\npositive dwell"],
            ylim=(0, 38), ylabel="Count / 35 reference-positive dwells", title="Opened 64-dwell RF comparison")
axes[0].legend(loc="upper left", fontsize=9)
for index, name in enumerate(names):
    medians = [rfsummary["desktop_timing_percentiles"][str(rate)][name]["total_cpu_ms"][0]
               for rate in (2500000, 5000000)]
    p99 = [rfsummary["desktop_timing_percentiles"][str(rate)][name]["total_cpu_ms"][2]
           for rate in (2500000, 5000000)]
    x = np.arange(2)+(index-.5)*.18
    axes[1].plot(x, medians, "o", color=colors[index], markersize=8)
    axes[1].plot(x, p99, "_", color=colors[index], markersize=15)
    for xx, med, tail in zip(x, medians, p99):
        axes[1].plot([xx, xx], [med, tail], color=colors[index])
axes[1].set(xticks=range(2), xticklabels=["2.5 MS/s", "5 MS/s"], ylim=(0, 2.3),
            ylabel="Whole-dwell CPU time (desktop ms)", title="Median (dot) to p99 (cap), 5 paired repeats")
axes[1].text(.5, .05, "Not ARM timing; not proof of unchanged live duty", transform=axes[1].transAxes,
             ha="center", fontsize=9, color="#a03838")
fig.suptitle("Saved-RF gain is modest: one additional associated dwell, no lost matches\n"
             "Both versions flag 1/29 unresolved dwells; those are not labelled true or false", fontsize=12)
fig.savefig(figures / "rf-and-desktop-cost.png", dpi=160)
plt.close(fig)

inventory = {}
paths = [root / name for name in ("regression.xml", "regression-final.xml", "worker-tests.xml",
                                "check_rf.py", "check_execution.py", "check_nuisance.py", "save_checkpoint.py")]
for directory in ("fresh", "final-replay", "rf", "nuisance", "execution"):
    paths += sorted(p for p in (root / directory).iterdir() if p.suffix in (".json", ".jsonl"))
for path in paths:
    relative = path.relative_to(root)
    data = path.read_bytes()
    compress = path.suffix in (".jsonl", ".xml", ".py") or len(data) > 50000
    target = out / (str(relative)+(".gz" if compress else ""))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0) if compress else data)
    assert (gzip.decompress(target.read_bytes()) if compress else target.read_bytes()) == data
    inventory[str(target.relative_to(out))] = dict(sha256=digest(target),
        original_sha256=hashlib.sha256(data).hexdigest(), source=str(path), original_bytes=len(data))
write_json(out / "index.json", dict(scope=comparison["scope"], artifacts=inventory,
    comparison_sha256=digest(out / "comparison.json"),
    figures={str(p.relative_to(ROOT)): digest(p) for p in sorted(figures.glob("*.png"))}))
print(json.dumps(comparison, indent=2))
print(f"Retained {len(inventory)} hash-checked non-IQ/non-executable artifacts", flush=True)

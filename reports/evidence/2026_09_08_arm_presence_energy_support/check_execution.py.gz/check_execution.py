"""Bounded sanitizer and ARM userspace cross-build, no hardware access."""
import json
import os
from pathlib import Path
import subprocess

import numpy as np

from tools.benchmark_presence_execution import numerical, differences
from tools.native_presence import ROOT, build_dwell_presence, build_worker, write_templates
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_fftw import fftw_options
from tools.presence_structured_challenge import generate
from tools.presence_window_rank import write_rank_probe
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
out = root / "execution"
out.mkdir(exist_ok=False)
protocol = json.loads((ROOT / "config/analysis/arm-presence-energy-support-challenge-v1.json").read_text())
receipt = json.loads((root / "final-replay/amplitude-diverse-supported.so.build.json").read_text())
# Explicitly reuse the numerical flags, substituting only the FFT backend.
detector = json.loads((ROOT / protocol["detector_protocol"]).read_text())
flags = tuple(detector["common_flags"]) + tuple(f"-DLEO_PRESENCE_{k}={v}"
    for k, v in detector["variants"][0]["defines"].items()) + (
    "-DLEO_PRESENCE_DIFFERENTIAL_CI16=1", "-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1",
    "-DLEO_PRESENCE_RANK_AMPLITUDE_WEIGHTED=1", "-DLEO_PRESENCE_GLRT_SYMBOL_DIVERSITY=1",
    "-DLEO_PRESENCE_BOUNDED_MAGNITUDE=1", "-DLEO_PRESENCE_CONDITIONED_BLOCK_ROTATION=1",
    "-DLEO_PRESENCE_ENERGY_SUPPORT=1")
assert all(flag in receipt["command"] for flag in flags)
write_json(out / "freeze.json", dict(recipe_sha256=digest(Path(__file__)), flags=flags,
    scope="8 sanitizer processes, 2 repeats and 6 confirmations per process; no live or ARM timing",
    cases="both rates and edges; zero IQ and 4 ms terminal pilot burst", rx=1))
plain = build_dwell_presence(out / "plain.so", cflags=flags)
sanitize = build_dwell_presence(out / "sanitize", executable=True,
    cflags=flags + ("-fsanitize=address,undefined", "-fno-omit-frame-pointer"))
arm = fftw_options(Path("/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr"), runtime_rpath=False)
binary = build_worker(out / "worker-arm",
    compiler="/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc",
    cflags=flags + ("-mcpu=cortex-a9", "-mfpu=neon", "-mfloat-abi=hard") + arm["cflags"],
    ldflags=arm["ldflags"], dependencies=arm["dependencies"])

def subset(expected, actual):
    if isinstance(actual, dict): return {k: subset(expected[k], v) for k, v in actual.items()}
    if isinstance(actual, list):
        assert len(expected) == len(actual)
        return [subset(x, y) for x, y in zip(expected, actual, strict=True)]
    return expected

env = dict(os.environ, ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
           UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
results = []
for rate in (2500000, 5000000):
    template = out / f"{rate}.templates"
    write_templates(template, rate)
    for edge in ("lower", "upper"):
        for kind in ("zero", "terminal_pilot"):
            iq = np.zeros((rate * 120 // 1000, 2), dtype=np.int16)
            if kind == "terminal_pilot":
                iq, _ = generate(dict(rate_hz=rate, edge=edge, seed=995103,
                    kind="pilot", snr_db=12.0, start_ms=116.0, duration_ms=4.0), protocol)
            counter = 2**64 - 1 - len(iq)
            probe = out / f"{rate}-{edge}-{kind}.rank"
            write_rank_probe(probe, iq, rate, edge, counter)
            with NativeDwell(plain, rate, edge, 512) as native:
                expected = numerical(unpack(native.run(iq, maximum=6, seeded=False)))
                screens = numerical(unpack(native.screens()))
            for c in expected["confirmations"]:
                c["candidates"] = c["candidates"][:c["candidate_count"]]
            command = [str(sanitize), str(probe), str(template), "512", "6", "blind", "2"]
            proc = subprocess.run(command, env=env, text=True, capture_output=True, timeout=30)
            record = dict(command=command, stdout=proc.stdout, stderr=proc.stderr, returncode=proc.returncode)
            results.append(record)
            write_json(out / f"run-{len(results)}.json", record)
            assert proc.returncode == 0 and not proc.stderr
            rows = [json.loads(s) for s in proc.stdout.splitlines()]
            assert len(rows) == 2
            for index, row in enumerate(rows):
                assert row["counter"] == str(counter) and row["iteration"] == index
                assert row["confirmation_count"] == 6
                actual = numerical({k: v for k, v in row.items() if k in expected})
                assert not differences(subset(expected, actual), actual)
                assert not differences(screens, numerical(row["screen_diagnostics"]))
            print(f"{len(results)}/8 sanitizer processes verified", flush=True)
write_json(out / "summary.json", dict(processes=len(results), dwells=2*len(results),
    confirmations=12*len(results), sanitizer_diagnostics=0, numerical_mismatches=0,
    arm_worker_sha256=digest(binary), arm_worker_executed=False))

"""Offline SDK feedback qualification on an existing, hash-pinned saved corpus.

No radio/network/IIO access. Two desktop rates run concurrently; these timings
are not isolated ARM tail estimates. Source packs/manifests remain unchanged.
"""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess

from tools.native_presence import ROOT, build_worker
from tools.presence_fftw import fftw_options
from tools.presence_structured_challenge import variant_flags
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE, build, verify


def main():
    base = Path(__file__).parent
    source = Path('/tmp/leo-presence-symbol-support.b0iza3SZ/arm')
    name = 'amplitude-diverse-symbol-supported'
    index_path = ROOT / 'reports/evidence/2026_09_08_arm_presence_symbol_support/index.json'
    index = json.loads(index_path.read_text())
    reference_build = source / f'{name}.so.build.json'
    reference = json.loads(reference_build.read_text())
    assert digest(reference_build) == index['artifacts'][f'arm/{name}.so.build.json']['original_sha256']
    # Same scientific implementation as the frozen numerical reference.
    for path, sha in reference['sources_sha256'].items():
        if path.startswith('src/leo/analysis/'):
            assert digest(ROOT / path) == sha, path
    config_path = ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json'
    config = json.loads(config_path.read_text())
    flags = tuple(config['common_flags']) + tuple(
        f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
    ) + (
        '-DLEO_PRESENCE_DIFFERENTIAL_CI16=1', '-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1',
        '-DLEO_PRESENCE_BOUNDED_MAGNITUDE=1', '-DLEO_PRESENCE_CONDITIONED_BLOCK_ROTATION=1',
    ) + variant_flags(name)
    fftw = fftw_options(Path('/tmp/leo-presence-fftw.nLw4v6/install'))
    parent = build(base / 'parent')
    worker = build_worker(base / 'worker', cflags=flags + fftw['cflags'],
                          ldflags=fftw['ldflags'], dependencies=fftw['dependencies'])
    worker.chmod(0o755)
    algorithm = digest(worker)
    profile = dict(profile=POSITIVE_PROFILE, minimum_exact_score=0.175, minimum_margin=0.025,
                   detector_protocol_sha256=digest(config_path), variant=name,
                   identity_scope='research replay; not a production release identity')
    configuration = hashlib.sha256(json.dumps(profile, sort_keys=True).encode()).hexdigest()
    manifests = {}
    paths = [parent, worker, parent.parent / 'libleo-scanner-glrt.so', config_path,
             reference_build, Path(__file__), index_path]
    for rate in (2500000, 5000000):
        path = source / f'{rate}-{name}.manifest.json'
        assert digest(path) == index['artifacts'][f'arm/{path.name}']['original_sha256']
        manifest = json.loads(path.read_text())
        assert digest(source / f'{rate}.pack') == manifest['pack_sha256']
        assert digest(source / f'{rate}.templates') == manifest['templates_sha256']
        assert len(manifest['records']) == 16
        paths.extend((path, source / f'{rate}.pack', source / f'{rate}.templates'))
        manifests[rate] = manifest
    before = {str(path): digest(path) for path in paths}
    freeze = dict(profile=profile, algorithm_sha256=algorithm, configuration_sha256=configuration,
                  input_sha256=before, delay_blocks=2, jitter_ms=40, durations_ms=[968, 300000],
                  rates_hz=[2500000, 5000000], simultaneous_desktop_rates=True,
                  saved_dwells_per_rate=16, new_rf=False, adaptive_scheduling=False)
    write_json(base / 'saved-freeze.json', freeze)

    def run(rate, duration):
        stem = base / f'saved-{rate}-{duration}'
        command = [str(parent), str(worker), str(source / f'{rate}.templates'),
                   str(source / f'{rate}.pack'), str(duration), '2', '40', '1',
                   algorithm, configuration, POSITIVE_PROFILE]
        with stem.with_suffix('.jsonl').open('x') as output, stem.with_suffix('.stderr').open('x') as error:
            process = subprocess.run(command, stdout=output, stderr=error, timeout=duration / 1000 + 25)
        write_json(stem.with_suffix('.execution.json'), dict(command=command, exit_code=process.returncode))
        assert process.returncode == 0, stem
        assert not stem.with_suffix('.stderr').read_bytes(), stem
        checked = verify(stem.with_suffix('.jsonl').read_text(), manifests[rate], duration,
                         delay_blocks=2, jitter_ms=40, enabled=True, positive_feedback=True,
                         algorithm_sha256=algorithm, configuration_sha256=configuration)
        checked['raw_sha256'] = digest(stem.with_suffix('.jsonl'))
        write_json(stem.with_suffix('.verification.json'), checked)
        print(json.dumps(dict(rate=rate, duration=duration, verified=checked['verified'],
                              results=checked['results'], observations=checked['observations'])), flush=True)
        return checked

    checks = []
    for duration in (968, 300000):
        with ThreadPoolExecutor(max_workers=2) as executor:
            checks.extend(executor.map(lambda rate: run(rate, duration), (2500000, 5000000)))
    assert before == {str(path): digest(path) for path in paths}
    write_json(base / 'saved-summary.json', dict(freeze_sha256=digest(base / 'saved-freeze.json'),
                                               unchanged_inputs=True, checks=checks))


if __name__ == '__main__':
    main()

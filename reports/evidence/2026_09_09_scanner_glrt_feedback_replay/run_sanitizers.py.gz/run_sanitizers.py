"""Instrument the SDK and replay consumer, not the unchanged numerical worker."""
import json
import os
from pathlib import Path
import subprocess

from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE, build, verify

base = Path(__file__).parent
source = Path('/tmp/leo-presence-symbol-support.b0iza3SZ/arm')
freeze = json.loads((base / 'saved-replay-final/saved-freeze.json').read_text())
parent = build(base / 'sanitized-final', cflags=(
    '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
))
worker = base / 'saved-replay-final/worker'
assert digest(worker) == freeze['algorithm_sha256']
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for rate in (2500000, 5000000):
    stem = base / f'sanitized-final-{rate}'
    manifest = source / f'{rate}-amplitude-diverse-symbol-supported.manifest.json'
    for path in (manifest, source / f'{rate}.pack', source / f'{rate}.templates'):
        assert digest(path) == freeze['input_sha256'][str(path)]
    template = base / f'saved-replay-final/{rate}.templates'
    assert digest(template) == freeze['input_sha256'][str(template)]
    command = [str(parent), str(worker), str(template),
               str(source / f'{rate}.pack'), '1936', '2', '40', '1',
               freeze['algorithm_sha256'], freeze['configuration_sha256'], POSITIVE_PROFILE]
    with stem.with_suffix('.jsonl').open('x') as output, stem.with_suffix('.stderr').open('x') as error:
        result = subprocess.run(command, stdout=output, stderr=error, env=env, timeout=30)
    write_json(stem.with_suffix('.execution.json'), dict(
        command=command, exit_code=result.returncode,
        sanitizer_options={k: env[k] for k in ('ASAN_OPTIONS', 'UBSAN_OPTIONS')},
        scope='SDK and replay consumer instrumented; numerical worker/FFTW not instrumented',
    ))
    assert result.returncode == 0, stem
    assert not stem.with_suffix('.stderr').read_bytes(), stem
    checked = verify(stem.with_suffix('.jsonl').read_text(), json.loads(manifest.read_text()),
                     1936, delay_blocks=2, jitter_ms=40, enabled=True, positive_feedback=True,
                     algorithm_sha256=freeze['algorithm_sha256'],
                     configuration_sha256=freeze['configuration_sha256'])
    write_json(stem.with_suffix('.verification.json'), checked)
    print(json.dumps(dict(rate=rate, results=checked['results'],
                          observations=checked['observations'], sanitizers='pass')), flush=True)

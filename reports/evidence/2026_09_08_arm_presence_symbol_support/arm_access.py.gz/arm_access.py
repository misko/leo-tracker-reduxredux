"""Exact-spare identity and idle gate for saved-data execution only."""
import json
from pathlib import Path

from lan_access import call
from pluto_plus.inventory import scan_local_usb_plutos
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import write_json

SERIAL = "winbond-db620818a328172c"


def recorded(output, label, command, timeout=15):
    result = call(command, timeout=timeout)
    write_json(output / f"{label}.json", dict(command=command, returncode=result.returncode,
               stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        raise RuntimeError(f"{label}: remote exit {result.returncode}: {result.stderr[-1000:]}")
    return result.stdout


def idle(output, label):
    devices = [d for d in scan_local_usb_plutos() if d.serial == SERIAL]
    assert len(devices) == 1 and devices[0].usb_path == "/sys/bus/usb/devices/5-1"
    write_json(output / f"{label}-usb.json", [d.model_dump(mode="json") for d in devices])
    assert recorded(output, label+"-serial", "cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber").strip() == SERIAL
    assert recorded(output, label+"-mac", "cat /sys/class/net/eth0/address").strip() == "7e:09:12:85:cf:8e"
    assert "192.168.1.14/" in recorded(output, label+"-eth0", "ip -4 addr show dev eth0")
    assert recorded(output, label+"-buffers", "cat /sys/bus/iio/devices/iio:device*/buffer/enable").split() == ["0", "0"]
    network = recorded(output, label+"-network", "netstat -nt")
    assert all(":22 " in line and "192.168.1.142:" in line
               for line in network.splitlines() if line.startswith("tcp"))
    processes = recorded(output, label+"-processes", "ps")
    assert not any("/tmp/" in line and ("sdk-replay" in line or "/worker" in line or "ppu-iiod-" in line
                                       or "/parent" in line) for line in processes.splitlines())
    recorded(output, label+"-resources", "cat /proc/loadavg\ncat /proc/meminfo\ndf -Pk /tmp")


def system_hashes(output, label):
    return recorded(output, label, "sha256sum /usr/sbin/iiod /usr/lib/libfftw3.so.3 /lib/libc.so.6 "
                    "/lib/libm.so.6 /lib/libpthread.so.0 /lib/librt.so.1 /lib/libdl.so.2 /lib/ld-linux-armhf.so.3")


if __name__ == "__main__":
    output = Path(__file__).parent / "arm-preflight"
    output.mkdir(exist_ok=False)
    with acquire_radio_lock(SERIAL):
        idle(output, "preflight")
        system_hashes(output, "system")
    print(json.dumps(dict(serial=SERIAL, address="192.168.1.14", idle=True, new_rf=False)))

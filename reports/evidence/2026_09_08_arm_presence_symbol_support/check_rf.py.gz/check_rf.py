"""Paired opened-corpus support experiment; archive adapter is read-only."""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path

import numpy as np

from leo.storage.persistent_hop import PersistentHopIqStore
from leo.storage.persistent_hop_analysis_source import PersistentHopAnalysisInputStore
from tools.benchmark_presence_execution import differences, numerical
from tools.evaluate_native_presence_budgets import associated
from tools.evaluate_presence_decision_rf import load_references, validate_reference, visits
from tools.native_presence import ROOT
from tools.presence_decision_challenge import passing
from tools.presence_dwell import NativeDwell, unpack
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
output = root / "rf"
names = ("amplitude-diverse-supported", "amplitude-diverse-symbol-supported")
libraries = {name: root / "challenge" / f"{name}.so" for name in names}
identities = {name: digest(path) for name, path in libraries.items()}
reference_path = ROOT / "reports/evidence/2026_09_08_arm_presence_decision/rf-diagnostic"
prior_path = Path("/tmp/leo-presence-support.JdkNut7p/rf/results.jsonl")
prior_rows = {(r["session"], r["visit"]): r for r in
              map(json.loads, prior_path.read_text().splitlines())}
protocol = json.loads((ROOT / "config/analysis/arm-presence-decision-challenge-v1.json").read_text())
inputs = PersistentHopAnalysisInputStore(PersistentHopIqStore.open_read_only(Path("/srv/bulk/leo")))
sources = [inputs.source(s["session_id"]) for s in protocol["rf_sessions"]]
indices = visits(protocol)
references = load_references(reference_path, {s.session_id: s.input_manifest_sha256 for s in sources}, indices)
policy = protocol["policies"]["frozen_absolute_score_hypothesis"]
output.mkdir(exist_ok=False)
write_json(output / "freeze.json", dict(
    scope="opened RF reference agreement; neither independent truth nor live duty",
    recipe_sha256=digest(Path(__file__)), libraries=identities,
    reference_sha256=digest(reference_path / "results.jsonl"),
    prior_sha256=digest(prior_path), sessions={s.session_id: s.input_manifest_sha256 for s in sources},
    visits=indices, rx=1, confirmations=1, policy=policy, paired_timing_repeats=5,
))
rows = []
with ExitStack() as stack, (output / "results.jsonl").open("x") as stream:
    engines = {}
    for source in sources:
        assert source.receipt.qualified and source.plan.valid_visit_ms == 120 and 1 in source.receiver_ids
        for index in indices:
            visit = source.read_visit(index)
            rate, edge = source.sample_rate_hz, visit.span.target.edge
            iq = np.ascontiguousarray(visit.samples_ci16[:, source.receiver_ids.index(1), :])
            sha = hashlib.sha256(iq.tobytes()).hexdigest()
            reference = references[source.session_id, index]
            validate_reference(reference, input_sha=sha, rate=rate, edge=edge,
                               counter=visit.span.valid_device_sample_counter)
            refs = [[c for c in cs if c["margin"] >= .025] for cs in reference["reference_candidates"]]
            prior = prior_rows[source.session_id, index]
            assert sha == prior["iq_sha256"]
            variants, timing = {}, {name: [] for name in names}
            for name in names:
                key = name, rate, edge
                if key not in engines:
                    engines[key] = stack.enter_context(NativeDwell(libraries[name], rate, edge, 512))
                result = unpack(engines[key].run(iq, maximum=1, seeded=False))
                selected = result["rank"]["order"][0]
                confirmation = result["confirmations"][0]
                accepted = passing(confirmation["candidates"][:confirmation["candidate_count"]], policy)
                if name == names[0]:
                    assert not differences(numerical(prior["variants"][names[0]]["result"]),
                                           numerical(result)), "original RF numerical output changed"
                variants[name] = dict(result=result, selected_window=selected, flagged=bool(accepted),
                    same_slice_associated=any(associated(c, r, rate, protocol["association"])
                                              for c in accepted for r in refs[selected]),
                    within_dwell_associated=any(associated(c, r, rate, protocol["association"])
                                                for c in accepted for rs in refs for r in rs))
            assert variants[names[0]]["selected_window"] == variants[names[1]]["selected_window"]
            for repeat in range(5):
                for name in names if (index + repeat) % 2 == 0 else reversed(names):
                    result = unpack(engines[name, rate, edge].run(iq, maximum=1, seeded=False))
                    assert numerical(result) == numerical(variants[name]["result"])
                    timing[name].append({k: result[k] for k in ("total_cpu_ms", "total_wall_ms")})
            assert hashlib.sha256(iq.tobytes()).hexdigest() == sha
            row = dict(session=source.session_id, visit=index, rate_hz=rate, edge=edge,
                       source_counter=str(visit.span.valid_device_sample_counter), iq_sha256=sha,
                       reference_positive=any(refs), variants=variants, timing=timing)
            rows.append(row)
            stream.write(json.dumps(row, allow_nan=False) + "\n")
            stream.flush()
            if len(rows) % 8 == 0:
                print(f"{len(rows)}/64 RF inputs and original outputs verified", flush=True)
assert identities == {name: digest(path) for name, path in libraries.items()}
summary = {}
for name in names:
    positives = [r for r in rows if r["reference_positive"]]
    unresolved = [r for r in rows if not r["reference_positive"]]
    summary[name] = dict(reference_positive=len(positives), unresolved=len(unresolved),
        same_slice_associated=sum(r["variants"][name]["same_slice_associated"] for r in positives),
        within_dwell_associated=sum(r["variants"][name]["within_dwell_associated"] for r in positives),
        flags_in_positive=sum(r["variants"][name]["flagged"] for r in positives),
        flags_in_unresolved=sum(r["variants"][name]["flagged"] for r in unresolved))
timing = {str(rate): {name: {field: np.percentile(
    [t[field] for r in rows if r["rate_hz"] == rate for t in r["timing"][name]],
    [50, 95, 99, 100]).tolist() for field in ("total_cpu_ms", "total_wall_ms")}
    for name in names} for rate in (2500000, 5000000)}
write_json(output / "summary.json", dict(results=summary, desktop_timing_percentiles=timing))
print(json.dumps(summary, indent=2), flush=True)

"""Freeze and prepare userspace RX1 replay; never opens RF."""
from contextlib import ExitStack
from pathlib import Path
import hashlib
import json
import struct
import subprocess

from tools.native_presence import ROOT, build_dwell_presence, build_worker, write_templates
from tools.presence_fftw import fftw_options
from tools.presence_structured_challenge import variant_flags
from tools.presence_dwell import NativeDwell, unpack
from tools.evaluate_presence_window_rank import load_dwells
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_worker import FIELDS

base = Path(__file__).parent
out = base / 'arm'
source = Path('/tmp/leo-native-presence-holdout-v1-20260908')
out.mkdir(exist_ok=False)
detector_path = ROOT/'config/analysis/arm-presence-native-tone-ci16-v1.json'
detector = json.loads(detector_path.read_text())
flags = tuple(detector['common_flags']) + tuple(f'-DLEO_PRESENCE_{k}={v}' for k,v in detector['variants'][0]['defines'].items()) + (
    '-DLEO_PRESENCE_DIFFERENTIAL_CI16=1', '-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1',
    '-DLEO_PRESENCE_BOUNDED_MAGNITUDE=1', '-DLEO_PRESENCE_CONDITIONED_BLOCK_ROTATION=1')
compiler = '/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc'
arm = fftw_options(Path('/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr'), runtime_rpath=False)
desktop = fftw_options(Path('/tmp/leo-presence-fftw.nLw4v6/install'))
names = ('amplitude-diverse-supported', 'amplitude-diverse-symbol-supported')
freeze = dict(source=str(source), source_sha256={n:digest(source/n) for n in ('inputs.json','results.json')},
              recipe_sha256=digest(Path(__file__)), detector_protocol_sha256=digest(detector_path),
              selection='First 16 complete dwells per rate in frozen source order, independent of outcomes',
              variants=names, receiver=1, confirmations=1, screen_bins=512, seeded=False,
              arrival_period_ms=120, duration_ms=30000, target='winbond-db620818a328172c',
              address='192.168.1.14', new_rf=False,
              scope='Paced original saved dwells; chunk bursts, not original arrival timeline or unchanged duty proof')
write_json(out/'freeze.json',freeze)
libraries = {}
for name in names:
    options = flags + variant_flags(name)
    libraries[name] = build_dwell_presence(out/f'{name}.so', cflags=options+desktop['cflags'], ldflags=desktop['ldflags'], dependencies=desktop['dependencies'])
    build_worker(out/f'worker-{name}', compiler=compiler,
                 cflags=options+('-mcpu=cortex-a9','-mfpu=neon','-mfloat-abi=hard')+arm['cflags'],
                 ldflags=arm['ldflags'],dependencies=arm['dependencies'])
parent_command = [compiler,'-std=c11','-O2','-Wall','-Wextra','-Werror',
                  str(ROOT/'tests/fixtures/scanner_presence_worker_smoke.c'),
                  str(ROOT/'src/leo/scanner/native_presence/pool.c'),'-o',str(out/'parent')]
subprocess.run(parent_command,check=True)
write_json(out/'parent.build.json',dict(command=parent_command,binary_sha256=digest(out/'parent'),
    sources_sha256={str(p.relative_to(ROOT)):digest(p) for p in (
        ROOT/'tests/fixtures/scanner_presence_worker_smoke.c', ROOT/'src/leo/scanner/native_presence/pool.c',
        ROOT/'src/leo/scanner/native_presence/pool.h')}))
selected = {r:[] for r in (2500000,5000000)}
for metadata, iq in load_dwells(source):
    if len(selected[metadata['rate_hz']]) < 16:
        selected[metadata['rate_hz']].append((metadata,iq))
assert all(len(v)==16 for v in selected.values())
with ExitStack() as stack:
    for rate, records in selected.items():
        write_templates(out/f'{rate}.templates',rate)
        engines = {(name,edge):stack.enter_context(NativeDwell(libraries[name],rate,edge,512))
                   for name in names for edge in ('lower','upper')}
        manifests = {name:[] for name in names}
        with (out/f'{rate}.pack').open('xb') as pack:
            pack.write(struct.pack('<4sII',b'LDP1',rate,len(records)))
            for metadata,iq in records:
                original = hashlib.sha256(iq.tobytes()).hexdigest()
                pack.write(struct.pack('<QQII',int(metadata['counter']),metadata['visit'],
                                       int(metadata['edge']=='upper'),metadata['channel']))
                pack.write(iq.astype('<i2',copy=False).tobytes())
                for name in names:
                    native = engines[name,metadata['edge']]
                    result = unpack(native.run(iq,maximum=1,seeded=False))
                    confirmation = result['confirmations'][0]
                    manifests[name].append(dict(metadata,iq_sha256=original,expected=dict(
                        candidates=[{k:c[k] for k in FIELDS} for c in confirmation['candidates'][:confirmation['candidate_count']]],
                        nuisance={k:v for k,v in result['nuisances'][0].items() if not k.endswith('_ms')},
                        rank={k:v for k,v in result['rank'].items() if not k.endswith('_ms')},
                        screen_diagnostics=unpack(native.screens()),
                        confirmation_window_mask=result['confirmation_window_mask'])))
                assert hashlib.sha256(iq.tobytes()).hexdigest()==original
        for name in names:
            write_json(out/f'{rate}-{name}.manifest.json',dict(
                schema='org.leo.research.presence-dwell-worker-pack/v1',rate_hz=rate,
                records=manifests[name], pack_sha256=digest(out/f'{rate}.pack'),
                templates_sha256=digest(out/f'{rate}.templates'),
                reference_sha256=digest(libraries[name]),worker_sha256=digest(out/f'worker-{name}'),
                scope=freeze['scope']))
write_json(out/'payload.json',{p.name:digest(p) for p in (
    out/'parent', *(out/f'worker-{name}' for name in names),
    *(out/f'{rate}.{suffix}' for rate in selected for suffix in ('pack','templates')),
)})
assert freeze['source_sha256']=={n:digest(source/n) for n in freeze['source_sha256']}
assert freeze['recipe_sha256']==digest(Path(__file__))
print(json.dumps(dict(prepared=True,unique_dwells=32,variants=names,output=str(out)),indent=2))

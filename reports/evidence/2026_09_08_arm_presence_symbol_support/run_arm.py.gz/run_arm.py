"""Four bounded saved-IQ worker replays on the idle, pinned USB spare; no RF."""
import json
from pathlib import Path
import re
import shlex
import time

from arm_access import SERIAL, idle, recorded, system_hashes
from lan_access import call, transfer
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_worker import verify

root = Path(__file__).parent
assets = root / "arm"
out = root / "arm-runs"
out.mkdir(exist_ok=False)
names = ("amplitude-diverse-supported", "amplitude-diverse-symbol-supported")
payload = json.loads((assets / "payload.json").read_text())
paths = {name: assets / name for name in payload}
paths["libfftw3.so.3"] = Path("/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr/lib/libfftw3.so.3.6.10")
payload["libfftw3.so.3"] = digest(paths["libfftw3.so.3"])
assert all(digest(path) == payload[name] for name, path in paths.items())
order = [(5000000, names[0]), (5000000, names[1]), (2500000, names[1]), (2500000, names[0])]
freeze = dict(recipe_sha256=digest(Path(__file__)), access_sha256=digest(root / "arm_access.py"),
    payload_sha256=payload, serial=SERIAL, address="192.168.1.14", order=order,
    duration_ms=30000, arrival_period_ms=120, live_rf=False, firmware_changed=False,
    scope="saved RX1 worker/IPC timing; no IIO, SDK producer load, full transport or duty qualification",
    scheduling="nice 10; inherited CPU affinity; sequential rate-reversed pairs, not randomized thermal trials")
write_json(out / "freeze.json", freeze)
scratch = None
summaries = []
cleanup_errors = []


def verify_payload(label):
    listing = recorded(out, label+"-inventory", "ls -1A " + shlex.quote(scratch))
    assert set(listing.splitlines()) == set(paths)
    command = "sha256sum " + " ".join(shlex.quote(f"{scratch}/{name}") for name in paths)
    output = recorded(out, label+"-hashes", command)
    assert {Path(s.split()[1]).name: s.split()[0] for s in output.splitlines()} == payload


try:
    with acquire_radio_lock(SERIAL):
        try:
            idle(out, "preflight")
            original_system = system_hashes(out, "system-before")
            scratch = recorded(out, "scratch", "mktemp -d /tmp/leo-symbol-bench.XXXXXX").strip()
            assert re.fullmatch(r"/tmp/leo-symbol-bench\.[A-Za-z0-9]{6}", scratch)
            write_json(out / "owned-scratch.json", dict(path=scratch, expected_files=payload))
            for name, path in paths.items():
                result = transfer([path], f"{scratch}/{name}")
                write_json(out / f"transfer-{name}.json", dict(returncode=result.returncode,
                    stderr=result.stderr, source_sha256=payload[name], remote=f"{scratch}/{name}"))
                assert result.returncode == 0
            executables = ["parent", *(f"worker-{name}" for name in names)]
            recorded(out, "executable-modes", "chmod 700 " + " ".join(shlex.quote(f"{scratch}/{name}") for name in executables))
            verify_payload("payload-initial")
            for index, (rate, name) in enumerate(order):
                idle(out, f"before-{index}")
                label = f"{index}-{rate}-{name}"
                command = (f"LD_LIBRARY_PATH={scratch} nice -n 10 {scratch}/parent "
                           f"{scratch}/worker-{name} {scratch}/{rate}.templates {scratch}/{rate}.pack 30000 120")
                print(f"Starting {label}: 30s saved-IQ replay, 120ms arrivals", flush=True)
                began = time.monotonic()
                result = call(command, timeout=55)
                write_json(out / f"{label}.execution.json", dict(command=command, returncode=result.returncode,
                    stderr=result.stderr, elapsed_s=time.monotonic()-began))
                with (out / f"{label}.jsonl").open("x") as stream:
                    stream.write(result.stdout)
                assert result.returncode == 0 and not result.stderr
                manifest = json.loads((assets / f"{rate}-{name}.manifest.json").read_text())
                checked = verify(result.stdout, manifest, 30000, arrival_period_ms=120)
                checked.update(verified=True, raw_sha256=digest(out / f"{label}.jsonl"))
                write_json(out / f"{label}.verification.json", checked)
                summaries.append(dict(rate_hz=rate, variant=name, **checked))
                print(json.dumps(summaries[-1]), flush=True)
            idle(out, "postflight")
            assert original_system == system_hashes(out, "system-after")
            assert all(digest(path) == payload[name] for name, path in paths.items())
            write_json(out / "summary.json", dict(runs=summaries, goal_complete=False,
                system_libraries_unchanged=True, scope=freeze["scope"]))
        finally:
            if scratch is not None:
                try:
                    # A command timeout is not evidence that a remote child
                    # exited. Retain scratch if the idle/identity gate fails.
                    idle(out, "cleanup-precondition")
                    verify_payload("payload-final")
                    recorded(out, "cleanup-files", "rm " + " ".join(shlex.quote(f"{scratch}/{name}") for name in paths))
                    recorded(out, "cleanup-directory", "rmdir " + shlex.quote(scratch))
                    scratch = None
                except BaseException as error:
                    cleanup_errors.append(str(error))
finally:
    write_json(out / "end.json", dict(remote_scratch_retained=scratch, cleanup_errors=cleanup_errors,
        recipe_unchanged=freeze["recipe_sha256"] == digest(Path(__file__))))

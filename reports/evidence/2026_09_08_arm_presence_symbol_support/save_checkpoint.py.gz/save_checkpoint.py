"""Verify and retain the symbol-support checkpoint; no radio access."""
from collections import Counter
from contextlib import ExitStack
import gzip
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from tools.native_presence import ROOT
from tools.presence_decision_challenge import associated, passing
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_structured_challenge import generate
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
out = ROOT / "reports/evidence/2026_09_08_arm_presence_symbol_support"
figures = ROOT / "reports/figures/2026_09_08_arm_presence_symbol_support"
out.mkdir(exist_ok=False)
figures.mkdir(exist_ok=False)
names = ("amplitude-diverse-supported", "amplitude-diverse-symbol-supported")

def load_rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]

rows = load_rows(root / "challenge/results.jsonl")
nuisance = load_rows(root / "nuisance/results.jsonl")
rf = load_rows(root / "rf/results.jsonl")
diagnostic = json.loads((root / "diagnostic-results.json").read_text())
protocol = json.loads((ROOT / "config/analysis/arm-presence-symbol-support-challenge-v1.json").read_text())
assert len(rows) == 576 and len(nuisance) == 224 and len(rf) == 64 and len(diagnostic) == 17
seeds = [r["truth"]["seed"] for r in rows+nuisance]
assert len(seeds) == len(set(seeds)) == 800
old = load_rows(Path("/tmp/leo-presence-support.JdkNut7p/final-replay/results.jsonl"))
old += load_rows(Path("/tmp/leo-presence-support.JdkNut7p/nuisance/results.jsonl"))
assert not set(seeds).intersection(r["truth"]["seed"] for r in old)

# Check the actual blind C implementation against the opened-case direct FFT
# diagnosis, rather than reporting a Python-only recovery as implemented.
with ExitStack() as stack:
    engines = {}
    for row in diagnostic:
        truth = row["truth"]
        key = truth["rate_hz"], truth["edge"]
        if key not in engines:
            engines[key] = stack.enter_context(NativeDwell(root / "challenge" / f"{names[1]}.so", *key, 512))
        iq, _ = generate(truth, protocol)
        result = unpack(engines[key].run(iq, maximum=1, seeded=False))
        window = result["rank"]["order"][0]
        candidate = result["confirmations"][0]["candidates"][0]
        assert window == row["selected_window"]
        for field, column in (("exact_grid", 0), ("control_grid", 1)):
            np.testing.assert_allclose(candidate[field], np.asarray(row["revised_grid"])[:, column], rtol=1e-9, atol=1e-10)
        assert any(associated(c, truth, window, protocol["association"])
                   for c in passing([candidate], protocol["policy"]))

boundary = [r for r in rows if r["truth"]["kind"] == "boundary_pilot"]
primary = [r for r in rows if r["truth"]["kind"] in ("pilot", "pilot_plus_tone")]
negatives = [r for r in rows+nuisance if not r["truth"]["starlink_model_present"]]
summary = {}
stages = {}
for name in names:
    summary[name] = dict(primary_associated=sum(r["variants"][name]["associated"] for r in primary),
        boundary_associated=sum(r["variants"][name]["associated"] for r in boundary),
        weak_boundary_associated=sum(r["variants"][name]["associated"] for r in boundary if r["truth"]["snr_db"] == -6),
        strong_boundary_associated=sum(r["variants"][name]["associated"] for r in boundary if r["truth"]["snr_db"] == 6),
        negative_flags=sum(r["variants"][name]["flagged"] for r in negatives),
        unassociated_boundary_flags=sum(r["variants"][name]["flagged"] and not r["variants"][name]["associated"] for r in boundary))
    stages[name] = Counter()
    for r in boundary:
        truth, variant = r["truth"], r["variants"][name]
        w = variant["selected_window"]
        c = variant["result"]["confirmations"][0]["candidates"][0]
        if variant["associated"]: label = "Associated"
        elif w*20 >= truth["start_ms"]+truth["duration_ms"] or (w+1)*20 <= truth["start_ms"]: label = "Wrong slice"
        elif abs(c["acquired_cfo_hz"]-truth["cfo_hz"]) > 8000: label = "Initial CFO miss"
        elif not c["fractional_complete"]: label = "Fractional incomplete"
        elif not variant["flagged"]: label = "Below threshold"
        else: label = "Unassociated flag"
        stages[name][label] += 1
paired = Counter((r["variants"][names[0]]["associated"], r["variants"][names[1]]["associated"]) for r in boundary)
arm = json.loads((root / "arm-runs/summary.json").read_text())
cleanup = json.loads((root / "arm-runs/end.json").read_text())
assert cleanup == dict(remote_scratch_retained=None, cleanup_errors=[], recipe_unchanged=True)
assert arm["system_libraries_unchanged"]
assert len(arm["runs"]) == 4 and all(r["verified"] and r["executions"] == 250
    and r["terminal"]["dropped"] == r["terminal"]["skipped"] == 0 for r in arm["runs"])
tests = {}
for label, path in (("analysis", "regression.xml"), ("worker", "worker-tests.xml")):
    suites = ET.parse(root / path).getroot().findall("testsuite")
    assert all(int(s.get(k, 0)) == 0 for s in suites for k in ("failures", "errors", "skipped"))
    tests[label] = sum(int(s.get("tests", 0)) for s in suites)
comparison = dict(scope="default-off research, actual ARM saved-IQ execution, no live duty or deployed verdicts",
    counts=dict(primary=len(primary), boundary=len(boundary), negatives=len(negatives)),
    synthetic=summary, stages=stages, boundary_gains=paired[False, True], boundary_losses=paired[True, False],
    opened_diagnostic_cases=17, direct_fft_and_blind_C_recoveries=17,
    rf=json.loads((root / "rf/summary.json").read_text()), arm=arm, cleanup=cleanup,
    tests=tests, execution=json.loads((root / "execution/summary.json").read_text()))
write_json(out / "comparison.json", comparison)

plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
colors = ("#65758d", "#128a75")
fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.4), layout="constrained")
example = next(r for r in diagnostic if r["truth"]["snr_db"] == 6)
axes[0].plot(range(-2, 3), np.asarray(example["early_grid"])[:, 0], "o-", color=colors[0], label="Early region")
axes[0].plot(range(-2, 3), np.asarray(example["revised_grid"])[:, 0], "o-", color=colors[1], label="Energy-selected region")
axes[0].set(xlabel="Local integer-epoch hypothesis (samples)", ylabel="Exact GLRT score",
            title="One opened failure: a usable timing peak appears", xticks=range(-2, 3))
axes[0].legend()
categories = ("Associated", "Wrong slice", "Fractional incomplete", "Below threshold")
palette = ("#128a75", "#b0b7c1", "#995ca2", "#d79a46")
for index, name in enumerate(names):
    left = 0
    for label, color in zip(categories, palette):
        count = stages[name].get(label, 0)
        axes[1].barh(index, count, left=left, color=color, label=label if index == 0 else None)
        if count: axes[1].text(left+count/2, index, str(count), ha="center", va="center", color="white")
        left += count
    assert left == 80
axes[1].set(yticks=[0, 1], yticklabels=["Frame selection\nonly", "+ Symbol-region\nselection"],
            xlabel="Fresh 4 ms boundary cases", xlim=(0, 80), title="Remaining failures are now slice-selection misses")
axes[1].invert_yaxis()
axes[1].legend(loc="upper center", bbox_to_anchor=(.5, -.15), ncol=2, fontsize=9)
fig.suptitle("Keep the 64-symbol budget; put refinement on the observed burst\n"
             "Fresh test: 36/80 → 57/80 boundary associations, 240/240 primary, 0/480 synthetic-negative flags", fontsize=12)
fig.savefig(figures / "lattice-and-fresh-results.png", dpi=160)
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 5.1), layout="constrained")
for ax, rate in zip(axes, (2500000, 5000000)):
    for index, name in enumerate(names):
        record = next(r for r in arm["runs"] if r["rate_hz"] == rate and r["variant"] == name)
        values = [record["timings"][field]["p99"] for field in ("total_cpu_ms", "total_wall_ms", "delivery_latency_ms")]
        bars = ax.bar(np.arange(3)+(index-.5)*.36, values, .36, color=colors[index],
                      label=("Frame selection only", "+ Symbol selection")[index])
        ax.bar_label(bars, fmt="%.1f", padding=3, fontsize=9)
    ax.axhline(120, color="#b84b43", linestyle="--", linewidth=1)
    ax.set(xticks=range(3), xticklabels=["Worker\nCPU", "Worker\nwall", "Copy →\nresult"],
           ylabel="Measured p99 (ms)", ylim=(0, 145), title=f"{rate/1e6:g} MS/s; 120 ms arrivals")
axes[0].legend(loc="upper left", fontsize=9)
fig.suptitle("Actual ARM saved-data replay: all 1,000 results verified, no skips/drops\n"
             "Four 30-second runs on 32 repeated source dwells; no live IIO/IRQ/network load", fontsize=12)
fig.savefig(figures / "arm-p99-timing.png", dpi=160)
plt.close(fig)

artifacts = {}
paths = sorted(p for p in root.iterdir() if p.suffix in (".json", ".xml", ".py"))
for folder in ("challenge", "nuisance", "rf", "execution", "arm", "arm-preflight", "arm-runs"):
    paths += sorted(p for p in (root / folder).iterdir() if p.suffix in (".json", ".jsonl"))
for path in paths:
    data = path.read_bytes()
    compress = path.suffix in (".jsonl", ".xml", ".py") or len(data) > 50000
    target = out / (str(path.relative_to(root)) + (".gz" if compress else ""))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0) if compress else data)
    assert (gzip.decompress(target.read_bytes()) if compress else target.read_bytes()) == data
    artifacts[str(target.relative_to(out))] = dict(sha256=digest(target),
        original_sha256=hashlib.sha256(data).hexdigest(), source=str(path), original_bytes=len(data))
write_json(out / "index.json", dict(scope=comparison["scope"], artifacts=artifacts,
    comparison_sha256=digest(out / "comparison.json"),
    figures={str(p.relative_to(ROOT)): digest(p) for p in figures.glob("*.png")}))
print(json.dumps(dict(synthetic=summary, stages=stages, tests=tests, cleanup=cleanup,
    artifact_count=len(artifacts)), indent=2))

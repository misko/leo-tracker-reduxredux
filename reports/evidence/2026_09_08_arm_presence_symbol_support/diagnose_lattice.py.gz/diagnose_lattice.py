"""Direct-FFT diagnosis of previously opened fractional failures, no RF."""
from contextlib import ExitStack
import json
from pathlib import Path
import hashlib

import numpy as np

from leo.analysis.starlink.templates import qin_edge_pilot_frame
from tools.native_presence import ROOT, NativePresence
from tools.presence_structured_challenge import generate
from tools.presence_decision_challenge import passing, associated
from tools.qualify_native_presence import digest, write_json

root = Path(__file__).parent
source = Path("/tmp/leo-presence-support.JdkNut7p/final-replay")
protocol = json.loads((ROOT / "config/analysis/arm-presence-energy-support-challenge-v1.json").read_text())
rows = [json.loads(s) for s in (source / "results.jsonl").read_text().splitlines()]
selected = []
for row in rows:
    truth = row["truth"]
    variant = row["variants"]["amplitude-diverse-supported"]
    candidate = variant["result"]["confirmations"][0]["candidates"][0]
    if (truth["kind"] == "boundary_pilot" and not variant["associated"]
            and not candidate["fractional_complete"]
            and abs(candidate["acquired_cfo_hz"]-truth["cfo_hz"]) <= 8000):
        selected.append(row)
assert len(selected) == 17
write_json(root / "diagnostic-freeze.json", dict(recipe_sha256=digest(Path(__file__)),
    source_sha256=digest(source / "results.jsonl"), cases=[r["truth"] for r in selected],
    scope="post-hoc direct-FFT diagnosis of 17 opened failures; no independent qualification",
    proposal="freeze higher-energy early/late 64-symbol region independently per selected frame"))

def lattice(values, templates, rate, epoch, first_frame, cfo, regions):
    period = round(rate / 750)
    scores = []
    for delta in range(-2, 3):
        proposed = (epoch+delta) % period
        spectra = np.zeros((2, 512))
        ceilings = np.zeros(2)
        for frame, region in enumerate(regions):
            anchor = proposed + round((first_frame+frame)*(rate/750))
            first = 2+150*region
            for which, template in enumerate(templates):
                correlations = []
                for symbol in range(first, first+64):
                    indices = np.arange(round(symbol*rate*4.4e-6), round((symbol+1)*rate*4.4e-6))
                    corrected = values[anchor+indices]*np.exp(-2j*np.pi*cfo*indices/rate)
                    correlations.append(np.sum(template[indices].conj()*corrected))
                correlations = np.asarray(correlations)
                spectra[which] += abs(np.fft.fft(correlations, 512))**2
                ceilings[which] += np.sum(abs(correlations))**2
        scores.append((spectra.max(axis=1) / ceilings).tolist())
    return np.asarray(scores)

results = []
with ExitStack() as stack:
    engines = {}
    for row in selected:
        truth = row["truth"]
        variant = row["variants"]["amplitude-diverse-supported"]
        assert not variant["result"]["nuisances"][0]["applied"]
        candidate = variant["result"]["confirmations"][0]["candidates"][0]
        iq, regenerated = generate(truth, protocol)
        assert regenerated == truth and hashlib.sha256(iq.tobytes()).hexdigest() == row["iq_sha256"]
        rate, edge = truth["rate_hz"], truth["edge"]
        window = variant["selected_window"]
        section = iq[window*rate//50:(window+1)*rate//50]
        values = section[:, 0].astype(float) + 1j*section[:, 1]
        epoch = candidate["epoch"]
        n = round(rate/750)
        energy = []
        for frame in range(16):
            start = epoch+round(frame*(rate/750))
            if start+n+2 > len(values): break
            energy.append(float(np.sum(abs(values[start:start+n])**2)))
        first_frame = int(np.argmax(np.asarray(energy[:-1])+energy[1:]))
        region_energy = []
        for frame in (first_frame, first_frame+1):
            anchor = epoch+round(frame*(rate/750))
            region_energy.append([float(np.sum(abs(values[
                anchor+round(symbol*rate*4.4e-6):anchor+round((symbol+64)*rate*4.4e-6)])**2))
                for symbol in (2, 152)])
        regions = np.argmax(region_energy, axis=1).tolist()
        templates = [qin_edge_pilot_frame(rate, edge, symbol_roll=roll).astype(complex) for roll in (0, 17)]
        early = lattice(values, templates, rate, epoch, first_frame, candidate["acquired_cfo_hz"], [0, 0])
        np.testing.assert_allclose(early[:, 0], candidate["exact_grid"], rtol=1e-9, atol=1e-10)
        np.testing.assert_allclose(early[:, 1], candidate["control_grid"], rtol=1e-9, atol=1e-10)
        revised = lattice(values, templates, rate, epoch, first_frame, candidate["acquired_cfo_hz"], regions)
        best = int(np.argmax(revised[:, 0]))
        recovered = dict(candidate)
        if 0 < best < 4:
            a, b, c = np.log(revised[best-1:best+2, 0])
            curve = a-2*b+c
            if curve < -np.finfo(float).eps:
                offset = float(best-2+np.clip(.5*(a-c)/curve, -.5, .5))
                key = rate, edge
                if key not in engines:
                    engines[key] = stack.enter_context(NativePresence(source / "amplitude-diverse-supported.so", rate, edge))
                score = engines[key].glrt(values, epoch, candidate["acquired_cfo_hz"], offset)
                recovered.update(fractional_complete=1, fractional_offset_samples=offset,
                    exact_score=float(score[0]), control_score=float(score[1]), margin=float(score[0]-score[1]),
                    tracking_cfo_hz=float(candidate["acquired_cfo_hz"]+score[2]))
        accepted = passing([recovered], protocol["policy"])
        results.append(dict(truth=truth, selected_window=window, first_frame=first_frame,
            region_energy=region_energy, regions=regions, early_grid=early.tolist(),
            revised_grid=revised.tolist(), candidate=recovered,
            associated=any(associated(c, truth, window, protocol["association"]) for c in accepted)))
write_json(root / "diagnostic-results.json", results)
print(json.dumps(dict(cases=len(results), original_grids_reproduced=len(results),
    fractional_recovered=sum(r["candidate"]["fractional_complete"] for r in results),
    associated=sum(r["associated"] for r in results),
    chose_late=sum(any(r["regions"]) for r in results)), indent=2))

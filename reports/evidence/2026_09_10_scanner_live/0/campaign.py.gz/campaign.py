"""One authorized <=25-minute maintenance campaign; userspace only, .20 only."""
import argparse
from collections import Counter
import dataclasses
from datetime import UTC, datetime, timedelta
import importlib.util
import json
import os
from pathlib import Path
import signal
from threading import Event, Thread, Timer
import time
import traceback

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('legacy', ROOT / 'legacy_recipe.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
legacy.ROOT = ROOT
legacy.RELEASE = Path('/opt/leo-tracker/releases/40de667bc8fb98b99d2b343cb19f9045193d7b86')
legacy.BUNDLE = legacy.RELEASE / 'runtime/scanner-glrt'
legacy.ALG = 'a89bc80c20cd9181fa27e8fb27847087e8f24687712b934689e44bbfb5ad0bbf'
legacy.CONFIG = '05f1d964ec5d505dcf2abd41c670c47e04772c7b92564458a9ba86e59937d8e3'
legacy.MANIFEST = '5ff6ea2eb861cbdba02f89744a7f6d42e86825ed2e5f4b1ab5e60d11526ebf72'
CASES = ((2500000, True, 8), (2500000, False, 300), (2500000, True, 300),
         (5000000, True, 8), (5000000, False, 300), (5000000, True, 300))
legacy.RATES = tuple(case[0] for case in CASES)
save, progress = legacy.save, legacy.progress


def settings(index):
    rate, enabled, seconds = CASES[index]
    original = legacy.settings(index)
    root = ROOT / f'case-{index}-{rate}-{"on" if enabled else "off"}-{seconds}s'
    return dataclasses.replace(original, bulk_root=root / 'bulk', scanner_report_root=root / 'reports',
        scanner_hop_policy='adaptive' if enabled else 'fixed',
        scanner_glrt=original.scanner_glrt if enabled else None)


def intent(backend, index):
    # Same canonical geometry/rate slot, isolated store per attempt; no retry can recapture.
    slot = datetime(2026, 9, 10, tzinfo=UTC) + timedelta(minutes=20 * (CASES[index][0] == 5000000))
    result = backend.scheduled_scanner_intent(
        operation_key=legacy.canonical_scheduled_scanner_operation_key(slot), scheduled_for=slot)
    assert result.configuration.sample_rate_hz == CASES[index][0]
    assert result.configuration.bandwidth_hz == CASES[index][0]
    assert result.run_duration_seconds == 300
    return result


def preflight():
    # PPU reads only public IIOD context XML before authentication with the newly
    # scanned, strictly pinned SSH key. Never load firmware or relax host checking.
    found = legacy.discover_network_iio([legacy.HOST + '/32'], max_hosts=1, workers=1)
    assert len(found) == 1 and found[0].serial == legacy.SERIAL
    output = legacy.transport().run('sh -s', stdin=legacy.PRECHECK, timeout_s=15)
    connections = [line for line in output.splitlines() if 'ESTABLISHED' in line]
    assert len(connections) == 1 and legacy.HOST + ':22' in connections[0], connections
    boot = next(line.split()[1] for line in output.splitlines() if line.startswith('BOOT '))
    attrs = [line for line in output.splitlines() if line.startswith('ATTR ')]
    return dict(network=found[0], readback=output, boot_id=boot, attributes=attrs)


def summary(index, result):
    from leo.storage.persistent_hop import PersistentHopIqStore
    config = settings(index)
    if CASES[index][1]:
        store = legacy.AdaptiveHopIqStore(config.bulk_root, read_only=True)
        try:
            published = store.verify(result.published.session_id)
        finally:
            store.close()
    else:
        published = PersistentHopIqStore.open_read_only(config.bulk_root).verify(result.published.session_id)
    receipt = published.manifest.receipt
    save(config.bulk_root.parent / 'public-receipt.json', receipt)
    common = dict(index=index, rate_hz=CASES[index][0], detector_enabled=CASES[index][1],
        smoke=CASES[index][2] != 300, session_id=published.session_id, full_iq_verified=True,
        valid_duty_ppm=receipt.valid_duty_ppm,
        source_seconds=receipt.duty_denominator_sample_count / CASES[index][0],
        manifest_sha256=published.manifest_sha256, classification_warning=result.classification_warning)
    if CASES[index][1]:
        glrt = legacy.ScannerGlrtStore.open_read_only(config.bulk_root).read(published.session_id)
        assert glrt is not None
        save(config.bulk_root.parent / 'public-glrt.json', glrt)
        rows = glrt.evidence.results
        common.update(terminal=receipt.terminal.state, complete_visits=receipt.complete_visit_count,
            delivery_complete=glrt.evidence.delivery_complete, dropped_results=glrt.evidence.dropped_results,
            classifications=len(rows), masks=dict(Counter(r.search_window_mask for r in rows)),
            verdicts=dict(Counter(r.verdict for r in rows)),
            decision_reasons=dict(Counter(str(e.decision.reason) for e in receipt.events)))
    else:
        common.update(terminal=receipt.capture_outcome, complete_visits=len(receipt.visits))
    save(config.bulk_root.parent / 'summary.json', common)
    progress('case_verified', **common)
    if CASES[index][2] == 300:
        assert common['terminal'] == 'complete' and common['source_seconds'] >= 300
        assert common['valid_duty_ppm'] >= 900000, 'capture duty below 90%'
        if CASES[index][1]:
            assert common['delivery_complete'] and common['dropped_results'] == 0
            assert not common['classification_warning']
    return common


def run():
    legacy.runtime()
    owner = legacy.authority()
    before = owner.snapshot()
    assert before.desired_state.value == 'running', 'Do not take over another maintenance pause'
    for index in range(len(CASES)):
        config = settings(index)
        config.bulk_root.mkdir(parents=True)
        intent(legacy.LocalAcquisitionBackend(config), index)
    save(ROOT / 'before.json', before)
    started = time.monotonic()
    cancelled, done = Event(), Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: cancelled.set())
    def heartbeat():
        while not done.wait(25):
            progress('campaign_running', elapsed_seconds=time.monotonic()-started,
                     cancellation_requested=cancelled.is_set())
    Thread(target=heartbeat, daemon=True).start()
    deadline = Timer(1435, cancelled.set)
    deadline.daemon = True
    deadline.start()
    pause = None
    results = []
    try:
        progress('pausing_after_active_capture')
        pause = owner.pause(operator_id='authorized-scanner-fair-canary',
            reason='User-authorized <=25-minute scanner verification; resume automatically',
            wait=False)
        save(ROOT / 'pause-request.json', pause)
        for _ in range(100):
            state = owner.snapshot()
            assert state.generation == pause.generation
            if state.observed_state.value == 'paused':
                break
            if cancelled.wait(1):
                raise RuntimeError('Cancelled while draining production')
        else:
            raise RuntimeError('Production did not drain within 100 seconds; no RF started')
        save(ROOT / 'paused.json', state)
        with owner.claim_paused_maintenance((legacy.RADIO,), task_id='scanner-fair-live-20260910',
                expected_generation=pause.generation), legacy.acquire_radio_lock(legacy.SERIAL):
            initial = preflight()
            save(ROOT / 'identity-preflight.json', initial)
            progress('identity_attested', serial=legacy.SERIAL, host=legacy.HOST,
                     boot_id=initial['boot_id'], generation=pause.generation)
            for index, (_, _, seconds) in enumerate(CASES):
                # Reserve at least 60 seconds for final cleanup/resume. No automatic retries.
                if cancelled.is_set() or time.monotonic()-started + seconds + 45 > 1435:
                    raise RuntimeError('Insufficient remaining approved maintenance budget')
                config = settings(index)
                root = config.bulk_root.parent
                admission = preflight()
                assert admission['boot_id'] == initial['boot_id']
                save(root / 'preflight.json', admission)
                save(root / 'attempt.json', dict(index=index, nominal_seconds=300,
                    cancel_after_ready_seconds=seconds if seconds != 300 else None))
                cancel = Event()
                timer = None
                class Lifecycle(legacy.ObservedLifecycle):
                    def enter_and_attest(self):
                        nonlocal timer
                        super().enter_and_attest()
                        timer = Timer(seconds if seconds != 300 else 325, cancel.set)
                        timer.daemon = True
                        timer.start()
                stop_relay = Event()
                def relay():
                    while not stop_relay.wait(0.2):
                        if cancelled.is_set():
                            cancel.set()
                            return
                Thread(target=relay, daemon=True).start()
                backend = legacy.LocalAcquisitionBackend(config, legacy.CompositionHooks(
                    persistent_hop_iiod_lifecycle_factory=lambda c: Lifecycle(c, root)))
                progress('case_start', index=index, rate_hz=CASES[index][0], detector=CASES[index][1])
                try:
                    result = backend.capture_scheduled_scanner(intent(backend, index), cancel=cancel)
                    save(root / 'capture-result.json', result)
                finally:
                    stop_relay.set()
                    if timer:
                        timer.cancel()
                    restored = preflight()
                    save(root / 'postflight.json', restored)
                    assert restored['boot_id'] == admission['boot_id']
                    assert restored['attributes'] == admission['attributes'], 'Radio restoration mismatch'
                results.append(summary(index, result))
        save(ROOT / 'completed.json', dict(results=results, new_rf=True, firmware_changed=False,
            elapsed_seconds=time.monotonic()-started, comparison='Fixed detector-off vs adaptive detector-on; changing sky/target allocation is not a sensitivity A/B.'))
    except BaseException as error:
        save(ROOT / 'failure.json', dict(error=str(error), traceback=traceback.format_exc(),
            elapsed_seconds=time.monotonic()-started))
        progress('campaign_failed', error=str(error))
        raise
    finally:
        deadline.cancel()
        if pause is not None:
            current = owner.snapshot()
            if current.generation == pause.generation and current.desired_state.value == 'paused':
                resumed = owner.resume(operator_id='authorized-scanner-fair-canary',
                    reason='Authorized scanner maintenance finished; restore scheduled capture')
                save(ROOT / 'resumed.json', resumed)
                progress('scheduled_capture_resumed', generation=resumed.generation)
        done.set()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('validate', 'run'))
    args = parser.parse_args()
    if args.action == 'validate':
        proof = legacy.runtime()
        for index in range(len(CASES)):
            config = settings(index)
            intent(legacy.LocalAcquisitionBackend(config), index)
        progress('validated_without_radio', runtime=proof, cases=CASES)
    else:
        run()

"""Sanitize the real queue/scheduler/SDK on desktop and cross-build for ARM.
No radio connection. Numerical worker/FFTW remain the hash-pinned uninstrumented build.
"""
import json
import os
from pathlib import Path
import subprocess

from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE, build
from tools.qualify_scanner_glrt_shadow import verify

base = Path(__file__).parent
libiio = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
parent = build(base / 'sanitized', libiio_source=libiio,
               cflags=('-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'))
worker = base / 'workload/worker'
source = base / 'retained-workload'
algorithm, configuration = digest(worker), digest(source / 'freeze.json')
env = dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for rate in (2500000,5000000):
    manifest = json.loads((source / f'{rate}.manifest.json').read_text())
    for kind in ('pack','templates'):
        assert digest(source / f'{rate}.{kind}') == manifest[f'{kind}_sha256']
    stem = base / f'sanitized-{rate}'
    command = [str(parent),str(worker),str(source / f'{rate}.templates'),str(source / f'{rate}.pack'),
               '4840','2','40','1',algorithm,configuration,POSITIVE_PROFILE]
    with stem.with_suffix('.jsonl').open('x') as output,stem.with_suffix('.stderr').open('x') as error:
        process = subprocess.run(command,stdout=output,stderr=error,env=env,timeout=30)
    write_json(stem.with_suffix('.execution.json'),dict(command=command,exit_code=process.returncode,
        ASAN_OPTIONS=env['ASAN_OPTIONS'],UBSAN_OPTIONS=env['UBSAN_OPTIONS']))
    assert process.returncode==0 and not stem.with_suffix('.stderr').read_bytes(),stem
    checked = verify(stem.with_suffix('.jsonl').read_text(),manifest,4840,jitter_ms=40,
                     algorithm_sha256=algorithm,configuration_sha256=configuration)
    write_json(stem.with_suffix('.verification.json'),checked)
    print(json.dumps(dict(rate_hz=rate,choices=checked['choices'],sanitizers='pass')),flush=True)
arm = build(base / 'arm',libiio_source=libiio,
    compiler='/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc',
    cflags=('-mcpu=cortex-a9','-mfpu=neon','-mfloat-abi=hard'))
print(json.dumps(dict(arm_cross_build=str(arm),arm_executed=False)),flush=True)

"""Select positive-rich whole sweeps from retained, already opened RX1 IQ.

Development stress selection deliberately uses detector outcomes; NOT holdout
quality evidence. Missing original recording bundles are not reconstructed.
"""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import struct

from tools.evaluate_presence_window_rank import load_dwells
from tools.native_presence import write_templates
from tools.presence_dwell import NativeDwell, unpack
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_worker import FIELDS
from tools.qualify_scanner_glrt_sdk import _decision

base = Path(__file__).parent
out = base / 'retained-workload'
out.mkdir(exist_ok=False)
source = Path('/tmp/leo-native-presence-holdout-v1-20260908')
library, worker = base / 'workload/reference.so', base / 'workload/worker'
assert digest(library) == json.loads(library.with_name('reference.so.build.json').read_text())['binary_sha256']
assert digest(worker) == json.loads(worker.with_name('worker.build.json').read_text())['binary_sha256']
freeze = dict(recipe_sha256=digest(Path(__file__)), source=str(source),
              source_sha256={n:digest(source / n) for n in ('inputs.json','results.json')},
              reference_sha256=digest(library), worker_sha256=digest(worker),
              selection='Rank complete 8-target saved sweeps by number of passing dwells; take first two per rate, key breaks ties',
              independent_holdout=False, development_only=True, new_rf=False,
              minimum_exact_score=0.175, minimum_margin=0.025)
write_json(out / 'freeze.json', freeze)
groups = {}
all_records = []
with ExitStack() as stack:
    engines = {(rate, edge):stack.enter_context(NativeDwell(library,rate,edge,512))
               for rate in (2500000,5000000) for edge in ('lower','upper')}
    for meta, iq in load_dwells(source):
        result = unpack(engines[meta['rate_hz'],meta['edge']].run(iq,maximum=1,seeded=False))
        confirmation = result['confirmations'][0]
        record = dict(meta, iq_sha256=hashlib.sha256(iq.tobytes()).hexdigest(), expected=dict(
            candidates=[{k:c[k] for k in FIELDS} for c in confirmation['candidates'][:confirmation['candidate_count']]],
            rank=result['rank']))
        record['outcome'] = _decision(record,True)[3]
        all_records.append(record)
        groups.setdefault((meta['rate_hz'],meta['session'],meta['visit']//8),[]).append(record)
write_json(out / 'development-reference.json', all_records)
selected = {}
for rate in (2500000,5000000):
    choices = [(key, sorted(rs,key=lambda r:r['visit'])) for key,rs in groups.items() if key[0]==rate]
    assert all(len(rs)==8 and [r['channel']-1+4*int(r['edge']=='upper') for r in rs]==list(range(8)) for _,rs in choices)
    choices.sort(key=lambda item:(-sum(r['outcome']==1 for r in item[1]),item[0]))
    selected[rate] = [r for _,rs in choices[:2] for r in rs]
    assert sum(r['outcome']==1 for r in selected[rate]) > 0
write_json(out / 'selection.json', {str(k):v for k,v in selected.items()})
keys = {(r['session'],r['visit']) for rs in selected.values() for r in rs}
# Reopen through the existing hash/geometry-checked loader, retaining only selected IQ.
iqs = {(m['session'],m['visit']):iq for m,iq in load_dwells(source) if (m['session'],m['visit']) in keys}
summaries = []
for rate, records in selected.items():
    write_templates(out / f'{rate}.templates',rate)
    (out / f'{rate}.templates').chmod(0o600)
    with (out / f'{rate}.pack').open('xb') as pack:
        pack.write(struct.pack('<4sII',b'LDP1',rate,len(records)))
        for r in records:
            iq = iqs[r['session'],r['visit']]
            assert hashlib.sha256(iq.tobytes()).hexdigest()==r['iq_sha256']
            pack.write(struct.pack('<QQII',int(r['counter']),r['visit'],int(r['edge']=='upper'),r['channel']))
            pack.write(iq.astype('<i2',copy=False).tobytes())
    write_json(out / f'{rate}.manifest.json',dict(schema='org.leo.research.presence-dwell-worker-pack/v1',
        rate_hz=rate,records=records,pack_sha256=digest(out / f'{rate}.pack'),
        templates_sha256=digest(out / f'{rate}.templates'),freeze_sha256=digest(out / 'freeze.json'),
        worker_sha256=digest(worker),reference_sha256=digest(library)))
    summaries.append(dict(rate_hz=rate,selected_dwells=len(records),selected_positives=sum(r['outcome']==1 for r in records),
        positive_edges=sorted({r['edge'] for r in records if r['outcome']==1}),
        available_dwells=sum(r['rate_hz']==rate for r in all_records),
        available_positives=sum(r['rate_hz']==rate and r['outcome']==1 for r in all_records)))
    print(json.dumps(summaries[-1]),flush=True)
assert freeze['source_sha256']=={n:digest(source/n) for n in freeze['source_sha256']}
assert freeze['recipe_sha256']==digest(Path(__file__))
write_json(out / 'summary.json',dict(workloads=summaries,inputs_unchanged=True,independent_holdout=False))

"""Publish bounded, hash-verified desktop integration evidence; no IQ/binaries."""

import gzip
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_shadow import verify

source = Path(__file__).parent
destination = ROOT / "reports/evidence/2026_09_09_scanner_threaded_shadow"
assert not destination.exists()

# Recheck the exact long/short executions and all final build dependencies.
freeze = json.loads((source / "threaded-runs/freeze.json").read_text())
assert all(digest(Path(p)) == h for p, h in freeze["input_sha256"].items())
builds = [source / "workload" / f"{name}.build.json" for name in ("reference.so", "worker")]
for directory in ("threaded-runs/build", "sanitized", "arm"):
    builds.extend(source / directory / f"{name}.build.json" for name in
                  ("libleo-scanner-glrt.so", "sdk-replay"))
for receipt in builds:
    data = json.loads(receipt.read_text())
    assert digest(receipt.with_name(receipt.name.removesuffix(".build.json"))) == data["binary_sha256"]
    for key in ("sources_sha256", "dependencies_sha256"):
        for name, sha in data.get(key, {}).items():
            path = Path(name)
            assert digest(path if path.is_absolute() else ROOT / path) == sha, name

for rate in (2500000, 5000000):
    manifest = json.loads((source / f"retained-workload/{rate}.manifest.json").read_text())
    for duration in (4840, 300000):
        stem = source / f"threaded-runs/{rate}-{duration}"
        raw = stem.with_suffix(".jsonl")
        checked = verify(raw.read_text(), manifest, duration, jitter_ms=40,
                         algorithm_sha256=freeze["algorithm_sha256"],
                         configuration_sha256=freeze["configuration_sha256"])
        checked["raw_sha256"] = digest(raw)
        assert checked == json.loads(stem.with_suffix(".verification.json").read_text())

tests = []
for name in ("initial-tests", "integration", "regression"):
    suites = ET.parse(source / f"{name}.xml").getroot().findall("testsuite")
    counts = {k: sum(int(s.attrib[k]) for s in suites)
              for k in ("tests", "failures", "errors", "skipped")}
    assert counts["tests"] > 0 and not any(counts[k] for k in ("failures", "errors", "skipped"))
    tests.append(dict(name=name, **counts))

# Explicit content allowlist. Saved IQ, templates, executables and host keys
# are never archived. Failed setup/preflight receipts remain visible.
files = [p for p in source.iterdir() if p.is_file() and p.suffix in
         (".py", ".json", ".jsonl", ".stderr", ".log", ".xml")]
for directory in ("preflight", "workload", "retained-workload", "threaded-runs", "sanitized", "arm"):
    files.extend(p for p in (source / directory).rglob("*") if p.is_file()
                 and p.suffix in (".json", ".jsonl", ".stderr"))
destination.mkdir()
artifacts = {}
for path in sorted(set(files)):
    relative = str(path.relative_to(source)) + ".gz"
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    with target.open("xb") as output:
        output.write(gzip.compress(raw, compresslevel=9, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[relative] = dict(sha256=digest(target), original_sha256=digest(path),
                               original_bytes=len(raw), source=str(path))

tracked = ["pyproject.toml", "tools/qualify_scanner_glrt_sdk.py", "tools/scanner_glrt_sdk_replay.c",
           "tools/qualify_scanner_glrt_shadow.py", "tools/scanner_glrt_shadow_replay.c",
           "tools/scanner_glrt_shadow_replay.h", "tests/scanner/test_glrt_shadow_replay.py",
           "tests/scanner/test_glrt_shadow_integration.py"]
libiio = Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration")
index = dict(schema="org.leo.research.threaded-shadow-checkpoint/v1",
             base_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
             libiio_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=libiio, text=True).strip(),
             scope="Saved-IQ desktop real SDK/queue/scheduler-thread integration; mock clock/recall",
             new_rf=False, arm_executed=False, independent_holdout=False, deployed=False,
             firmware_changed=False, remotely_merged=False,
             tests=tests, sources_sha256={p:digest(ROOT / p) for p in tracked}, artifacts=artifacts)
write_json(destination / "index.json", index)
print(json.dumps(dict(artifacts=len(artifacts), tests=tests, index=str(destination / "index.json")), indent=2))

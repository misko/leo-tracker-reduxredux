"""Freeze a mixed, positive-rich DEVELOPMENT replay from already opened RF.

Whole saved sweeps retain their actual target order. No counterfactual IQ,
new RF, independent holdout claim, or threshold tuning.
"""
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import struct

import numpy as np

from leo.storage.persistent_hop import PersistentHopIqStore
from leo.storage.persistent_hop_analysis_source import PersistentHopAnalysisInputStore
from tools.benchmark_presence_execution import differences, numerical
from tools.native_presence import ROOT, build_dwell_presence, build_worker, write_templates
from tools.presence_dwell import NativeDwell, unpack
from tools.presence_fftw import fftw_options
from tools.presence_structured_challenge import variant_flags
from tools.qualify_native_presence import digest, write_json
from tools.qualify_presence_dwell_worker import FIELDS

base = Path(__file__).parent
out = base / 'workload'
out.mkdir(exist_ok=False)
name = 'amplitude-diverse-symbol-supported'
prior = Path('/tmp/leo-presence-symbol-support.b0iza3SZ/rf/results.jsonl')
index_path = ROOT / 'reports/evidence/2026_09_08_arm_presence_symbol_support/index.json'
index = json.loads(index_path.read_text())
assert digest(prior) == index['artifacts']['rf/results.jsonl.gz']['original_sha256']
rows = [json.loads(line) for line in prior.read_text().splitlines()]
selected = {r: [row for row in rows if row['rate_hz'] == r][:16] for r in (2500000, 5000000)}
assert all(len(rs) == 16 and len({r['session'] for r in rs}) == 1 for rs in selected.values())
assert all([r['visit'] % 8 for r in rs] == list(range(8)) * 2 for rs in selected.values())
config_path = ROOT / 'config/analysis/arm-presence-native-tone-ci16-v1.json'
config = json.loads(config_path.read_text())
flags = tuple(config['common_flags']) + tuple(
    f'-DLEO_PRESENCE_{k}={v}' for k, v in config['variants'][0]['defines'].items()
) + ('-DLEO_PRESENCE_DIFFERENTIAL_CI16=1', '-DLEO_PRESENCE_RANK_HYBRID_PROJECTION=1',
     '-DLEO_PRESENCE_BOUNDED_MAGNITUDE=1', '-DLEO_PRESENCE_CONDITIONED_BLOCK_ROTATION=1') + variant_flags(name)
fftw = fftw_options(Path('/tmp/leo-presence-fftw.nLw4v6/install'))
freeze = dict(prior_sha256=digest(prior), prior_index_sha256=digest(index_path),
              recipe_sha256=digest(Path(__file__)), config_sha256=digest(config_path),
              selection='First 16 rows per rate in the opened RF comparison; two complete saved sweeps',
              selected={str(rate): [(r['session'], r['visit'], r['iq_sha256']) for r in rs]
                        for rate, rs in selected.items()},
              development_only=True, independent_holdout=False, new_rf=False,
              flags=list(flags), minimum_exact_score=0.175, minimum_margin=0.025)
write_json(out / 'freeze.json', freeze)
library = build_dwell_presence(out / 'reference.so', cflags=flags + fftw['cflags'],
                              ldflags=fftw['ldflags'], dependencies=fftw['dependencies'])
worker = build_worker(out / 'worker', cflags=flags + fftw['cflags'],
                      ldflags=fftw['ldflags'], dependencies=fftw['dependencies'])
worker.chmod(0o700)
inputs = PersistentHopAnalysisInputStore(PersistentHopIqStore.open_read_only(Path('/srv/bulk/leo')))
summaries = []
with ExitStack() as stack:
    for rate, rs in selected.items():
        engines = {edge: stack.enter_context(NativeDwell(library, rate, edge, 512))
                   for edge in ('lower', 'upper')}
        source = inputs.source(rs[0]['session'])
        assert source.receipt.qualified and source.sample_rate_hz == rate
        records = []
        write_templates(out / f'{rate}.templates', rate)
        (out / f'{rate}.templates').chmod(0o600)
        with (out / f'{rate}.pack').open('xb') as pack:
            pack.write(struct.pack('<4sII', b'LDP1', rate, len(rs)))
            for i, row in enumerate(rs):
                visit = source.read_visit(row['visit'])
                target = visit.span.target
                iq = np.ascontiguousarray(visit.samples_ci16[:, source.receiver_ids.index(1), :])
                assert hashlib.sha256(iq.tobytes()).hexdigest() == row['iq_sha256']
                assert target.edge == row['edge']
                assert target.channel - 1 + 4 * int(target.edge == 'upper') == i % 8
                result = unpack(engines[target.edge].run(iq, maximum=1, seeded=False))
                assert not differences(numerical(row['variants'][name]['result']), numerical(result))
                confirmation = result['confirmations'][0]
                counter = visit.span.valid_device_sample_counter
                assert str(counter) == row['source_counter']
                pack.write(struct.pack('<QQII', counter, row['visit'], int(target.edge == 'upper'), target.channel))
                pack.write(iq.astype('<i2', copy=False).tobytes())
                records.append(dict(counter=str(counter), visit=row['visit'], session=row['session'],
                    channel=target.channel, edge=target.edge, rx=1, iq_sha256=row['iq_sha256'],
                    source_manifest_sha256=source.input_manifest_sha256,
                    expected=dict(candidates=[{k: c[k] for k in FIELDS} for c in
                        confirmation['candidates'][:confirmation['candidate_count']]], rank=result['rank']),
                    previously_flagged=row['variants'][name]['flagged']))
                assert hashlib.sha256(iq.tobytes()).hexdigest() == row['iq_sha256']
        manifest = dict(schema='org.leo.research.presence-dwell-worker-pack/v1', rate_hz=rate,
                        records=records, pack_sha256=digest(out / f'{rate}.pack'),
                        templates_sha256=digest(out / f'{rate}.templates'),
                        worker_sha256=digest(worker), reference_sha256=digest(library),
                        freeze_sha256=digest(out / 'freeze.json'), scope=freeze['selection'])
        write_json(out / f'{rate}.manifest.json', manifest)
        summaries.append(dict(rate_hz=rate, dwells=len(rs), positives=sum(r['previously_flagged'] for r in records),
                              positive_edges=sorted({r['edge'] for r in records if r['previously_flagged']})))
        print(json.dumps(summaries[-1]), flush=True)
assert digest(prior) == freeze['prior_sha256']
assert digest(Path(__file__)) == freeze['recipe_sha256']
write_json(out / 'summary.json', dict(workloads=summaries, original_inputs_unchanged=True))

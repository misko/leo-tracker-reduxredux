"""Two paced desktop shadow integrations; no radio or counterfactual samples."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess

from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import POSITIVE_PROFILE, build
from tools.qualify_scanner_glrt_shadow import verify

base = Path(__file__).parent
out = base / 'threaded-runs'
out.mkdir(exist_ok=False)
parent = build(out / 'build', libiio_source=Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration'))
source = base / 'retained-workload'
worker = base / 'workload/worker'
algorithm, configuration = digest(worker), digest(source / 'freeze.json')
paths = [parent, parent.parent / 'libleo-scanner-glrt.so', worker, Path(__file__),
         ROOT / 'tools/qualify_scanner_glrt_shadow.py']
manifests = {}
for rate in (2500000,5000000):
    manifests[rate] = json.loads((source / f'{rate}.manifest.json').read_text())
    for extension in ('pack','templates'):
        p = source / f'{rate}.{extension}'
        assert digest(p) == manifests[rate][f'{extension}_sha256']
        paths.append(p)
    paths.append(source / f'{rate}.manifest.json')
before = {str(p):digest(p) for p in paths}
write_json(out / 'freeze.json',dict(input_sha256=before,algorithm_sha256=algorithm,
    configuration_sha256=configuration, durations_ms=[4840,300000], rates_hz=[2500000,5000000],
    delay_blocks=2,jitter_ms=40,simultaneous_desktop_rates=True,
    new_rf=False,clock='quantized 121ms modeled device clock',real_scheduler_thread=True,
    original_target_iq=True,executed_adaptive_proposals=False))

def run(rate,duration):
    stem = out / f'{rate}-{duration}'
    command = [str(parent),str(worker),str(source / f'{rate}.templates'),str(source / f'{rate}.pack'),
               str(duration),'2','40','1',algorithm,configuration,POSITIVE_PROFILE]
    with stem.with_suffix('.jsonl').open('x') as output, stem.with_suffix('.stderr').open('x') as error:
        result = subprocess.run(command,stdout=output,stderr=error,timeout=duration/1000+25)
    write_json(stem.with_suffix('.execution.json'),dict(command=command,exit_code=result.returncode))
    assert result.returncode == 0 and not stem.with_suffix('.stderr').read_bytes(), stem
    checked = verify(stem.with_suffix('.jsonl').read_text(),manifests[rate],duration,jitter_ms=40,
                     algorithm_sha256=algorithm,configuration_sha256=configuration)
    checked['raw_sha256'] = digest(stem.with_suffix('.jsonl'))
    write_json(stem.with_suffix('.verification.json'),checked)
    print(json.dumps({k:checked[k] for k in ('rate_hz','duration_ms','results','observations',
        'choices','observation_outcomes','policy_model_matched','proposals_differing_from_actual')}),flush=True)
    return checked

checks=[]
for duration in (4840,300000):
    with ThreadPoolExecutor(max_workers=2) as executor:
        checks.extend(executor.map(lambda rate:run(rate,duration),(2500000,5000000)))
assert before == {str(p):digest(p) for p in paths}
write_json(out / 'summary.json',dict(checks=checks,inputs_unchanged=True))

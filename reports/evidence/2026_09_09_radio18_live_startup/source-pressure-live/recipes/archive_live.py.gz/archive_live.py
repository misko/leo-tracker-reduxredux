"""Archive one verified source-pressure live attempt, without IQ or credentials."""
import gzip
import hashlib
import json
from pathlib import Path
from run_matrix_case import ROOT, save

case = ROOT / "case-3-5000000-fixed-glrt1"
destination = Path("/home/mouse9911/gits/leo-tracker-arm-presence/reports/evidence/2026_09_09_radio18_live_startup/source-pressure-live")
files = [(ROOT / name, "recipes/" + name) for name in
         ("run_matrix_case.py", "run_observed_fixed_case.py", "verify_case_api.py", "characterize_case.py", "archive_live.py")]
for name in ("attempt.json", "preflight.json", "daemon-start.json", "daemon-log.json", "daemon-stop.json", "postflight.json",
             "observed-postflight.json", "trace.json", "capture-result.json", "summary.json", "qualification.json",
             "api-responses.json", "public-receipt.json", "public-glrt.json", "characterization.json"):
    files.append((case / name, name))
summary = json.loads((case / "summary.json").read_text())
qualification = json.loads((case / "qualification.json").read_text())
assert summary["full_iq_verified"] and qualification["api_verified"]
assert summary["classification_warning"] is None
artifacts = []
for source, relative in files:
    assert source.is_file() and not source.is_symlink(), source
    payload = source.read_bytes()
    compressed = gzip.compress(payload, mtime=0)
    target = destination / (relative + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(compressed)
    artifacts.append(dict(source=str(source), archive=str(target.relative_to(destination.parent)),
                          bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
                          archive_sha256=hashlib.sha256(compressed).hexdigest()))
save(destination.parent / "source-pressure-live.json", dict(
    schema="org.leo.research.radio18-source-pressure-live/v1", artifacts=artifacts,
    capture_summary=summary, qualification=qualification,
    limitation="A single live canary does not establish no duty regression or independent detector quality"))
print(json.dumps(dict(artifacts=len(artifacts), session_id=summary["session_id"])))

"""One original matrix case with bounded read-only diagnostic retention.

Actual application, radio, IQ, daemon and detector remain unchanged. Retain
the first 16 and last 64 metadata blocks, at most 16 status reads, and the
owned daemon's final 64 KiB log before normal PPU cleanup. No RF retry loop.
"""
import argparse
from collections import deque
import dataclasses
import shlex
import time

from pluto_plus.hardware.iio_persistent_hop import IioPersistentHopBackend
from pluto_plus.persistent_hop import PersistentHopClient, PersistentHopEvidenceV1, PersistentHopStatusV1
from leo.radio.pluto_persistent_hop import PlutoPersistentHopRadio
import run_matrix_case as matrix

parser = argparse.ArgumentParser()
parser.add_argument("--index", required=True, type=int, choices=(3,))
args = parser.parse_args()
config = matrix.settings(args.index)
root = config.bulk_root.parent
first = []
tail = deque(maxlen=64)
statuses = deque(maxlen=16)
errors = []
counts = {"blocks": 0}


class TracedBackend(IioPersistentHopBackend):
    def read_status(self):
        payload = super().read_status()
        statuses.append(dict(monotonic=time.monotonic(), status=dataclasses.asdict(PersistentHopStatusV1.unpack(payload))))
        return payload

    def blocks(self):
        try:
            for index, block in enumerate(super().blocks()):
                evidence = PersistentHopEvidenceV1.unpack(block.evidence)
                row = dict(index=index, monotonic=time.monotonic(),
                           evidence=dataclasses.asdict(evidence),
                           iq_bytes=len(block.iq_payload), generation=block.stream_generation)
                if index < 16:
                    first.append(row)
                tail.append(row)
                counts["blocks"] += 1
                yield block
        except BaseException as error:
            errors.append(dict(stage="blocks", type=type(error).__name__, error=str(error)))
            raise


def client_factory(uri, serial, *, metadata_extension):
    return PersistentHopClient(uri, expected_serial=serial,
        backend_factory=lambda endpoint: TracedBackend(endpoint, expected_serial=serial,
                                                       metadata_extension=metadata_extension))


def radio_factory(radio):
    return PlutoPersistentHopRadio(radio.host, expected_serial=radio.serial, radio_id=radio.radio_id,
        iiod_port=config.scanner_persistent_iiod_port, scanner_glrt=config.scanner_glrt,
        read_ahead_visits=config.scanner_persistent_read_ahead_visits, client_factory=client_factory)


class DiagnosticLifecycle(matrix.ObservedLifecycle):
    def exit_and_verify(self):
        active = self.inner.active
        try:
            if active is not None:
                matrix.save(root / "daemon-log.json", dict(text=matrix.transport().run(
                    "tail -c 65536 " + shlex.quote(active.paths.log), timeout_s=10)))
        except Exception as error:
            errors.append(dict(stage="owned_log_retention", type=type(error).__name__, error=str(error)))
        finally:
            super().exit_and_verify()


class DiagnosticApplication(matrix.LocalAcquisitionBackend):
    def __init__(self, settings, hooks):
        super().__init__(settings, dataclasses.replace(hooks, persistent_hop_radio_factory=radio_factory))


matrix.ObservedLifecycle = DiagnosticLifecycle
matrix.LocalAcquisitionBackend = DiagnosticApplication
try:
    matrix.run(args.index)
finally:
    matrix.save(root / "trace.json", dict(counts=counts, first=first, tail=list(tail),
                                         statuses=list(statuses), errors=errors))
    with matrix.acquire_radio_lock(matrix.SERIAL):
        matrix.save(root / "observed-postflight.json", matrix.preflight())

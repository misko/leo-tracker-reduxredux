"""Additional explicit evidence inventory; preserve prior checkpoint archives."""
import gzip
import hashlib
import json
from pathlib import Path

import archive_checkpoint as initial

root = initial.ROOT
bundle = Path("/tmp/leo-scanner-source-pressure-bundle.6V1rnV")
destination = initial.OUT / "source-pressure-followup"
files = []
for name in ("run_observed_fixed_case.py", "source_pressure_trace.py", "verify_source_pressure.py", "archive_followup.py",
             "rf_budget_ledger.py", "rf-budget-ledger.json",
             "source-pressure-trace-replay.json", "source-pressure-provider.json", "source-pressure-network.xml", "deployment-existing-baseline.xml",
             "case-1-5000000-fixed-glrt0/postfailure-preflight.json", "case-1-5000000-fixed-glrt0/postfailure-kernel.json",
             "case-3-5000000-fixed-glrt1/observed-postflight.json"):
    files.append((root / name, name))
for name in ("build_bundle.py", "receipt.json", "configure.json", "compile.json", "release/bundle.json", "release/algorithm.json", "release/configuration.json"):
    files.append((bundle / name, "next-arm-bundle/" + name))
index = []
for source, relative in files:
    assert source.is_file() and not source.is_symlink(), source
    payload = source.read_bytes()
    compressed = gzip.compress(payload, mtime=0)
    target = destination / (relative + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == compressed
    else:
        with target.open("xb") as stream:
            stream.write(compressed)
    index.append(dict(source=str(source), archive=str(target.relative_to(initial.OUT)),
                      bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
                      archive_sha256=hashlib.sha256(compressed).hexdigest()))
figure = Path("/home/mouse9911/gits/leo-tracker-arm-presence/reports/figures/2026_09_09_radio18_live_startup/source-backlog-before-gap.png")
output = initial.OUT / "source-pressure-followup.json"
document = dict(schema="org.leo.research.radio18-source-pressure-followup/v1", artifacts=index,
                figure=dict(path=str(figure), sha256=hashlib.sha256(figure.read_bytes()).hexdigest()))
with output.open("x") as stream:
    json.dump(document, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(artifacts=len(index), index=str(output))))

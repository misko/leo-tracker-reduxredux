"""Conservative RF accounting: include setup, cleanup and verification overhead."""
import json
import math
from pathlib import Path
from run_matrix_case import ROOT, save

old = Path("/srv/bulk/leo/scanner-live-20260909.WXLlWn")
rows = []
for base, case, filename in (
    (old, "case-0-2500000-fixed-glrt0", "summary.json"),
    (old, "case-2-2500000-fixed-glrt1", "failure.json"),
    (ROOT, "case-2-2500000-fixed-glrt1", "summary.json"),
    (ROOT, "case-1-5000000-fixed-glrt0", "failure.json"),
    (ROOT, "case-3-5000000-fixed-glrt1", "failure.json"),
):
    path = base / case / filename
    elapsed = json.loads(path.read_text())["elapsed_seconds"]
    rows.append(dict(source=str(path), basis="entire enclosing attempt monotonic duration, rounded up", upper_bound_seconds=math.ceil(elapsed)))
for number in (1, 2, 3):
    case = old / f"startup-diagnostic-{number:02d}"
    before, after = case / "preflight.json", case / "postflight.json"
    elapsed = after.stat().st_mtime - before.stat().st_mtime
    assert elapsed > 0
    rows.append(dict(source=str(case), basis="preflight-file to postflight-file wall time, rounded up plus one second", upper_bound_seconds=math.ceil(elapsed) + 1))
used = sum(row["upper_bound_seconds"] for row in rows)
assert used < 1800
result = dict(scope="Conservative upper bound for this bounded radio18 canary matrix, not measured RF duty",
              authorized_seconds=1800, upper_bound_used_seconds=used,
              guaranteed_remaining_seconds=1800-used, extension_approval_received=False, attempts=rows)
save(ROOT / "rf-budget-ledger.json", result)
print(json.dumps(result, indent=2))

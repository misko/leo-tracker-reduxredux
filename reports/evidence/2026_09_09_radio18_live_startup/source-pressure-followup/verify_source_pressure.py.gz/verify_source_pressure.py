"""Freeze final source-pressure provider regression outputs; CPU-only fixtures."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from run_matrix_case import ROOT, save

source = Path("/home/mouse9911/gits/libiio-arm-glrt-frame-integration")
fixture = Path("/tmp/leo-capture-protection.SsUyjA")
paths = [source / name for name in ("iiod/spf-scanner-glrt.c", "iiod/spf-scanner-glrt.h", "tests/test_scanner_glrt_provider.c")]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
environment = os.environ.copy()
for rate in (2500000, 5000000):
    for edge in ("lower", "upper"):
        environment[f"SPF_ADAPTIVE_PILOT_{rate}_{edge.upper()}"] = str(fixture / f"synthetic-pilot-{rate}-{edge}.ci16")
results = []
for name in ("positive-only-v1-protection-ON", "positive-only-v1-protection-OFF",
             "unqualified-evidence-protection-ON", "unqualified-evidence-protection-OFF", "sanitized"):
    build = fixture / name
    env = dict(environment)
    if name == "sanitized":
        env.update(ASAN_OPTIONS="detect_leaks=1:abort_on_error=1", UBSAN_OPTIONS="halt_on_error=1")
    for stage, command in (("build", ["cmake", "--build", str(build), "--target", "test_scanner_glrt_provider", "-j", "2"]),
                           ("run", [str(build / "iiod/test_scanner_glrt_provider")])):
        run = subprocess.run(command, capture_output=True, text=True, env=env, timeout=65)
        row = dict(name=name, stage=stage, command=command, returncode=run.returncode,
                   stdout=run.stdout, stderr=run.stderr)
        results.append(row)
        print(json.dumps(dict(name=name, stage=stage, returncode=run.returncode)), flush=True)
        if run.returncode:
            save(ROOT / "source-pressure-provider-failed.json", dict(sources=hashes, results=results))
            raise SystemExit(run.returncode)
assert hashes == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
save(ROOT / "source-pressure-provider.json", dict(scope="CPU-only real provider/SDK/worker; hardware substituted; sanitizer excludes numerical worker and FFTW", sources=hashes, results=results))

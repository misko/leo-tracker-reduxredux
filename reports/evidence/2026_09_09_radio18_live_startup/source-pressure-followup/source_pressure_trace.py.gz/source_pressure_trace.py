"""Independent counter-lag replay and figure from the failed live 5 MS/s case.

This predicts an advisory trigger on fixed observed arrival data. It does not
invent the counterfactual stream after work shedding or prove recovered duty.
"""
import hashlib
import json
from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from run_matrix_case import ROOT, save

case = ROOT / "case-3-5000000-fixed-glrt1"
trace_path = case / "trace.json"
log_path = case / "daemon-log.json"
trace = json.loads(trace_path.read_text())
log = json.loads(log_path.read_text())["text"]
frames = trace["tail"]
rate = 5_000_000
block = 131_072
assert len(frames) == trace["counts"]["blocks"] == 33
assert [row["index"] for row in frames] == list(range(33))
assert re.search(r"first_sample=168552076928 missing=131072", log)
assert 168552076928 - frames[-1]["evidence"]["block_end_counter_exclusive"] == block
assert trace["statuses"][-1]["status"]["reason"] == 7
latest = 0
pressured = False
rows = []
for row in frames:
    sidecar = row["evidence"]
    events = sidecar["events"]
    if events:
        latest = max(event["transition_after_counter"] for event in events)
    lag = max(0, latest - sidecar["block_end_counter_exclusive"])
    if events and lag >= 2 * block:
        pressured = True
    elif events and lag <= block:
        pressured = False
    rows.append(dict(block=row["index"], known_source_lag_ms=lag*1000/rate,
        fresh_hop=bool(events), proposed_source_pressure=pressured,
        accumulated_arrival_delay_ms=(row["monotonic"] - frames[0]["monotonic"]
                                    - row["index"]*block/rate)*1000))
first_trigger = next(row["block"] for row in rows if row["proposed_source_pressure"])
assert first_trigger == 8
assert all(row["proposed_source_pressure"] for row in rows[8:])
result = dict(scope="Independent fixed-trace advisory replay, not counterfactual RF or duty",
    rate_hz=rate, samples_per_block=block, high_lag_blocks=2, low_lag_blocks=1,
    first_trigger_block=first_trigger, first_missing_block=33, missing_samples=block,
    missing_time_ms=block*1000/rate, observed_final_arrival_delay_ms=rows[-1]["accumulated_arrival_delay_ms"],
    inputs={str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (trace_path, log_path)},
    rows=rows)
save(ROOT / "source-pressure-trace-replay.json", result)
out = Path("/home/mouse9911/gits/leo-tracker-arm-presence/reports/figures/2026_09_09_radio18_live_startup")
out.mkdir(parents=True, exist_ok=True)
fig, ax = plt.subplots(figsize=(10, 5), layout="constrained")
ax.plot([r["block"] for r in rows], [r["accumulated_arrival_delay_ms"] for r in rows],
        color="#24589b", label="Accumulated arrival delay: host time minus source time")
ax.plot([r["block"] for r in rows], [r["known_source_lag_ms"] for r in rows],
        color="#c56a1b", marker=".", label="Hop-counter lower bound on IQ backlog")
ax.axhline(2*block*1000/rate, color="#2c8062", linestyle="--", label="Proposed trigger: 2 blocks (52.4 ms)")
ax.axhline(8*block*1000/rate, color="#777777", linestyle=":", label="8-buffer nominal capacity (209.7 ms)")
ax.axvline(first_trigger, color="#2c8062", alpha=.65)
ax.axvline(33, color="#b83146", linestyle="--", label="Missing block 33 (26.2 ms of IQ)")
ax.set(xlabel="Source block index", ylabel="Delay / backlog lower bound (ms)",
       title="5 MS/s live failure: a fast callback can coexist with growing backlog",
       xlim=(0,34), ylim=(0,245))
ax.grid(alpha=.18)
ax.legend(loc="upper left", fontsize=8)
fig.savefig(out / "source-backlog-before-gap.png", dpi=160)
plt.close(fig)
print(json.dumps({key: value for key, value in result.items() if key not in ("rows", "inputs")}, indent=2))

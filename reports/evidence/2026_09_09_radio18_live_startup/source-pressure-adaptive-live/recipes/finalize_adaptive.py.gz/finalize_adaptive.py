"""Seal allowlisted adaptive-canary evidence and conservative RF accounting.

Reads only saved receipts. Does not import radio or application composition.
All outputs are exclusive; credentials, binaries and IQ are excluded.
"""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASE = ROOT / "case-4-2500000-adaptive-glrt1"
DEST = Path("/home/mouse9911/gits/leo-tracker-arm-presence/reports/evidence/2026_09_09_radio18_live_startup")


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


summary = read(CASE / "summary.json")
qualification = read(CASE / "qualification.json")
receipt = read(CASE / "public-receipt.json")
glrt = read(CASE / "public-glrt.json")
stop = read(CASE / "daemon-stop.json")
results = glrt["evidence"]["results"]
events = receipt["events"]
assert summary["full_iq_verified"] and summary["classification_warning"] is None
assert qualification["passed"] and qualification["api_verified"]
assert not qualification["deployed_browser_verified"]
assert receipt["terminal"]["state"] == "completed"
assert receipt["terminal"]["device_dropped_events"] == 0
assert receipt["source_span_attested"] and receipt["duty_target_met"]
assert receipt["unreceived_tail_sample_count"] == 0
assert receipt["unclassified_sample_count"] == 0
assert receipt["restoration"]["status"] == "restored"
assert stop["outcome"] == "stopped" and stop["stock_endpoint_healthy"]
assert stop["alternate_port_closed"] and not stop["errors"]
assert len(results) == len(events) == receipt["complete_visit_count"] == 2354
assert glrt["evidence"]["delivery_complete"] and glrt["evidence"]["dropped_results"] == 0
assert all(r["search_window_mask"] == 63 for r in results)
assert all(r["rx"] == 1 and r["verdict"] == "unavailable" for r in results)
assert all(e["target_index"] == i % 8 and e["event_sequence"] == i for i, e in enumerate(events))
assert all(e["decision"]["active_mask"] == 0 for e in events)
reasons = Counter(e["decision"]["reason"] for e in events)
assert reasons == {"warmup": 24, "none_active": 2330}
audit = dict(
    session_id=summary["session_id"], valid_iq_seconds=receipt["valid_sample_count"] / 2500000,
    full_screenings=len(results), canonical_round_robin=True,
    scheduler_reasons=dict(reasons), zero_active_mask_throughout=True,
    final_quiet_mask=events[-1]["decision"]["quiet_mask"],
    limitation="Full screening is not an absence assertion. Evaluated misses are separate scheduling hints; no active-target weighting or cooldown retention under real positives was exercised.",
    restored=True, verified=True)
save(CASE / "final-audit.json", audit)

previous_path = Path("/srv/bulk/leo/scanner-live-startup-fixed-20260909.PgX2jJ/rf-budget-ledger.json")
previous = read(previous_path)
rows = list(previous["attempts"])
assert sum(row["upper_bound_seconds"] for row in rows) == 1008
for name in ("case-3-5000000-fixed-glrt1", "case-4-2500000-adaptive-glrt1"):
    source = ROOT / name / "summary.json"
    rows.append(dict(source=str(source), basis="entire enclosing attempt monotonic duration, rounded up",
                     upper_bound_seconds=math.ceil(read(source)["elapsed_seconds"])))
used = sum(row["upper_bound_seconds"] for row in rows)
assert used == 1660 and used < previous["authorized_seconds"]
ledger = dict(scope=previous["scope"], authorized_seconds=1800,
              upper_bound_used_seconds=used, guaranteed_remaining_seconds=1800-used,
              extension_approval_received=False, rf_collection_stopped=True,
              next_full_300s_canary_requires_new_authorization=True, attempts=rows)
save(ROOT / "rf-budget-final.json", ledger)

files = [(ROOT / name, "recipes/" + name) for name in
         ("run_matrix_case.py", "run_observed_adaptive_case.py", "verify_case_api.py", "characterize_case.py", "finalize_adaptive.py")]
files.append((ROOT / "rf-budget-final.json", "rf-budget-final.json"))
for name in ("attempt.json", "preflight.json", "daemon-start.json", "daemon-log.json", "daemon-stop.json",
             "postflight.json", "observed-postflight.json", "capture-result.json", "summary.json",
             "qualification.json", "api-responses.json", "public-receipt.json", "public-glrt.json",
             "characterization.json", "final-audit.json"):
    files.append((CASE / name, name))
artifacts = []
for source, relative in files:
    assert source.is_file() and not source.is_symlink(), source
    payload = source.read_bytes()
    compressed = gzip.compress(payload, mtime=0)
    target = DEST / "source-pressure-adaptive-live" / (relative + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(compressed)
    artifacts.append(dict(source=str(source), archive=str(target.relative_to(DEST)), bytes=len(payload),
                          sha256=hashlib.sha256(payload).hexdigest(),
                          archive_sha256=hashlib.sha256(compressed).hexdigest()))
save(DEST / "source-pressure-adaptive-live.json", dict(
    schema="org.leo.research.radio18-source-pressure-adaptive-live/v1", artifacts=artifacts,
    capture_summary=summary, qualification=qualification, audit=audit, rf_budget=ledger))
print(json.dumps(dict(artifacts=len(artifacts), audit=audit, rf_upper_bound_seconds=used), indent=2))

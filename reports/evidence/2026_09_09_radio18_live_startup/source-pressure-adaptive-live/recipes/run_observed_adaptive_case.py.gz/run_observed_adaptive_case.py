"""One original adaptive matrix case, preserving the owned daemon log."""
import shlex
import run_matrix_case as matrix

root = matrix.settings(4).bulk_root.parent

class RetainedLogLifecycle(matrix.ObservedLifecycle):
    def exit_and_verify(self):
        active = self.inner.active
        try:
            if active is not None:
                matrix.save(root / "daemon-log.json", dict(text=matrix.transport().run(
                    "tail -c 65536 " + shlex.quote(active.paths.log), timeout_s=10)))
        except Exception as error:
            matrix.save(root / "log-retention-failure.json", dict(error=str(error)))
        finally:
            super().exit_and_verify()

matrix.ObservedLifecycle = RetainedLogLifecycle
try:
    matrix.run(4)
finally:
    with matrix.acquire_radio_lock(matrix.SERIAL):
        matrix.save(root / "observed-postflight.json", matrix.preflight())

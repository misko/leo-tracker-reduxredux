"""Bounded real scanner canaries on the explicitly authorized USB spare.

Uses production application/PPU ports, no simulated radio or IQ. Each index
may start once. Cadence slots are labels dispatched immediately for this
six-case canary, not claims of scheduled production execution.
"""
import argparse
from collections import Counter
import dataclasses
from datetime import UTC, datetime, timedelta
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import sys
from threading import Event, Timer
import time
import traceback

from leo.cli.composition import CliSettings, CompositionHooks, LocalAcquisitionBackend, RadioConfigurationV1
from leo.radio.persistent_hop_iiod_lifecycle import PERSISTENT_HOP_IIOD_KNOWN_HOSTS_CREDENTIAL, PERSISTENT_HOP_IIOD_PASSWORD_CREDENTIAL
from leo.radio.pluto_userspace_iiod_lifecycle import create_pluto_userspace_iiod_lifecycle
from leo.radio.scanner_glrt_metadata import ScannerGlrtOptions
from leo.scanner import canonical_scheduled_scanner_operation_key
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.persistent_hop import PersistentHopIqStore
from leo.storage.scanner_glrt import ScannerGlrtStore
from pluto_plus.hardware.preflight import verify_metadata_runtime
from pluto_plus.radio_lock import acquire_radio_lock

sys.path.insert(0, "/home/mouse9911/.local/state/pluto-plus-utils/r18-restore-2r2t.VHHdCU")
from operate import ROOT as MAINTENANCE, SERIAL, HOST, PRECHECK, network, password, transport, usb

ROOT = Path(__file__).resolve().parent
BUNDLE = Path("/tmp/leo-scanner-source-pressure-bundle.6V1rnV/release")
ALG = "3a2b6f66a39f197f8544be8a7af635122d762fc3bf2c649ee4c8937d1490b41c"
CONFIG = "7119b7116309835f308c5db23acb23b0e98f098fdf4c853caf8e4f0bb83424f8"
MANIFEST = "19c3650480a8386b12384b0f9a0c5d49e237b04ad98f474d3e703d3f820ddd7c"
CASES = ((2500000, "fixed", False), (5000000, "fixed", False),
         (2500000, "fixed", True), (5000000, "fixed", True),
         (2500000, "adaptive", True), (5000000, "adaptive", True))

def normalize(value):
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, default=normalize)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())

def progress(stage, **facts):
    print(json.dumps({"utc": datetime.now(UTC).isoformat(), "stage": stage, **facts}, default=normalize), flush=True)

def settings(index):
    rate, mode, detector = CASES[index]
    root = ROOT / f"case-{index}-{rate}-{mode}-glrt{int(detector)}"
    options = ScannerGlrtOptions(ALG, CONFIG, mode="positive-only-v1") if detector else None
    return CliSettings(
        profile_root=Path("/home/mouse9911/gits/leo-tracker-arm-presence/profiles"),
        bulk_root=root / "bulk", radio_backend="pluto",
        radios=(RadioConfigurationV1(radio_id="radio_usb_18_canary", serial=SERIAL, host=HOST),),
        safety_reserve_bytes=16 * 1024**3, scanner_enabled=True,
        scanner_capture_mode="persistent_hop", scanner_radio_id="radio_usb_18_canary",
        scanner_persistent_credentials_directory=ROOT / "credentials",
        scanner_persistent_iiod_binary_path=BUNDLE / "iiod",
        scanner_persistent_iiod_bundle_manifest_path=BUNDLE / "bundle.json",
        scanner_persistent_transition_guard_us=1000, scanner_persistent_samples_per_block=131072,
        scanner_persistent_kernel_buffers=8, scanner_persistent_read_ahead_visits=8,
        scanner_persistent_queue_capacity_visits=64, scanner_gain_db=40.0,
        scanner_glrt=options, scanner_hop_policy=mode, scanner_report_root=root / "reports",
    )

def intent(backend, index):
    slot = datetime(2026, 9, 9, 0, 0, tzinfo=UTC) + timedelta(minutes=20 * index)
    resolved = backend.scheduled_scanner_intent(
        operation_key=canonical_scheduled_scanner_operation_key(slot), scheduled_for=slot)
    assert resolved.configuration.sample_rate_hz == CASES[index][0]
    return resolved

def verify_bundle():
    assert hashlib.sha256((BUNDLE / "bundle.json").read_bytes()).hexdigest() == MANIFEST
    assert hashlib.sha256((BUNDLE / "algorithm.json").read_bytes()).hexdigest() == ALG
    assert hashlib.sha256((BUNDLE / "configuration.json").read_bytes()).hexdigest() == CONFIG
    spec = json.loads((BUNDLE / "bundle.json").read_text())
    files = spec["files"] + [dict(name="iiod", bytes=spec["daemon_bytes"], sha256=spec["daemon_sha256"])]
    for file in files:
        payload = (BUNDLE / file["name"]).read_bytes()
        assert len(payload) == file["bytes"] and hashlib.sha256(payload).hexdigest() == file["sha256"]
    return verify_metadata_runtime(expected_abi=3)

def preflight():
    local, remote = usb(), network()
    assert remote.firmware_version == "v0.49-plutoplus-spf-iq-direct-async-v4"
    output = transport().run("sh -s", stdin=PRECHECK, timeout_s=15)
    established = [line for line in output.splitlines() if "ESTABLISHED" in line]
    assert len(established) == 1 and "192.168.1.18:22" in established[0], established
    assert "192.168.1.18/24" in output
    assert shutil.disk_usage(ROOT).free > 64 * 1024**3
    return dict(usb=local, network=dataclasses.asdict(remote), readback=output)

def prepare():
    credentials = ROOT / "credentials"
    credentials.mkdir(mode=0o700)
    for name, payload in (
        (PERSISTENT_HOP_IIOD_KNOWN_HOSTS_CREDENTIAL, (MAINTENANCE / "known_hosts").read_bytes()),
        (PERSISTENT_HOP_IIOD_PASSWORD_CREDENTIAL, (password() + "\n").encode()),
    ):
        fd = os.open(credentials / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
    runtime = verify_bundle()
    plans = []
    for index in range(6):
        config = settings(index)
        config.bulk_root.mkdir(parents=True)
        backend = LocalAcquisitionBackend(config)
        plans.append(dict(index=index, case=CASES[index], settings=config, intent=intent(backend, index)))
    with acquire_radio_lock(SERIAL):
        admission = preflight()
    save(ROOT / "prepared.json", dict(runtime=runtime, plans=plans, admission=admission,
         scope="remaining authorized canaries after startup fix; prior baseline and diagnostic RF count toward the same 30-minute budget; no production services; same deployed 1ms guard"))
    progress("prepared", cases=6, runtime=runtime)

class ObservedLifecycle:
    def __init__(self, config, root):
        self.inner = create_pluto_userspace_iiod_lifecycle(config)
        self.root = root

    def enter_and_attest(self):
        progress("daemon_staging")
        receipt = self.inner.enter_and_attest()
        save(self.root / "daemon-start.json", receipt)
        progress("daemon_ready", receipt=receipt)

    def exit_and_verify(self):
        progress("daemon_cleanup")
        receipt = self.inner.exit_and_verify()
        save(self.root / "daemon-stop.json", receipt)
        progress("daemon_restored", receipt=receipt)

def run(index):
    assert (ROOT / "prepared.json").is_file()
    config = settings(index)
    case_root = config.bulk_root.parent
    save(case_root / "attempt.json", dict(index=index, start=datetime.now(UTC).isoformat()))
    cancel = Event()
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: cancel.set())
    # Finite application capture already ends at 300 source seconds. This
    # watchdog additionally requests orderly cancellation if wall time stalls.
    timer = Timer(360, cancel.set)
    timer.daemon = True
    timer.start()
    started = time.monotonic()
    try:
        with acquire_radio_lock(SERIAL):
            save(case_root / "preflight.json", preflight())
            verify_bundle()
            backend = LocalAcquisitionBackend(config, CompositionHooks(
                persistent_hop_iiod_lifecycle_factory=lambda c: ObservedLifecycle(c, case_root)))
            resolved = intent(backend, index)
            progress("capture_application_start", index=index, case=CASES[index], intent=resolved)
            run_result = backend.capture_scheduled_scanner(resolved, cancel=cancel)
            save(case_root / "capture-result.json", run_result)
            save(case_root / "postflight.json", preflight())
        timer.cancel()
        progress("iq_verification_start", index=index)
        store = (AdaptiveHopIqStore(config.bulk_root, read_only=True)
                 if CASES[index][1] == "adaptive" else PersistentHopIqStore.open_read_only(config.bulk_root))
        try:
            verified = store.verify(run_result.published.session_id)
        finally:
            if hasattr(store, "close"):
                store.close()
        receipt = verified.manifest.receipt
        evidence = ScannerGlrtStore.open_read_only(config.bulk_root).read(verified.session_id)
        results = evidence.evidence.results if evidence and evidence.evidence is not None else ()
        summary = dict(index=index, case=CASES[index], session_id=verified.session_id,
            manifest_sha256=verified.manifest_sha256, valid_duty_ppm=receipt.valid_duty_ppm,
            classification_warning=run_result.classification_warning,
            glrt_results=len(results),
            verdicts=dict(Counter(r.verdict for r in results)),
            elapsed_seconds=time.monotonic()-started, full_iq_verified=True)
        save(case_root / "summary.json", summary)
        progress("case_complete", **summary)
    except BaseException as error:
        save(case_root / "failure.json", dict(type=type(error).__name__, error=str(error),
            traceback=traceback.format_exc(), elapsed_seconds=time.monotonic()-started))
        progress("case_failed", index=index, error=str(error))
        raise
    finally:
        timer.cancel()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "run"))
    parser.add_argument("--index", type=int, choices=range(6), default=0)
    args = parser.parse_args()
    prepare() if args.action == "prepare" else run(args.index)

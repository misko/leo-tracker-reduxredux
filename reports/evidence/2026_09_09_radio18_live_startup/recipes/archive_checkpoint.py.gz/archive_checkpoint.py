"""Archive explicitly allowlisted scientific/test receipts, never credentials or IQ."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path("/srv/bulk/leo/scanner-live-20260909.WXLlWn")
BUNDLE = Path("/tmp/leo-scanner-startup-bundle.ORD6bT")
OUT = Path("/home/mouse9911/gits/leo-tracker-arm-presence/reports/evidence/2026_09_09_radio18_live_startup")
OUT.mkdir(parents=True, exist_ok=True)
files = []
for name in ("installed-runtime-regressions.xml", "coverage-diagnostic-before.xml", "coverage-diagnostic-after.xml", "deferred-start-network.xml", "deferred-start-network-verified-runtime.xml"):
    files.append((OLD / name, "tests/" + name))
for name in ("run_matrix_case.py", "verify_case_api.py", "characterize_case.py", "archive_checkpoint.py"):
    files.append((ROOT / name, "recipes/" + name))
for name in ("receipt.json", "configure.json", "compile.json", "build_bundle.py", "release/bundle.json", "release/algorithm.json", "release/configuration.json"):
    files.append((BUNDLE / name, "bundle/" + name))
for base, label in ((OLD, "original"), (ROOT, "startup-fixed")):
    cases = list(base.glob("case-*")) + list(base.glob("startup-diagnostic-*"))
    for case in cases:
        for name in ("attempt.json", "summary.json", "qualification.json", "characterization.json", "capture-result.json", "api-responses.json", "public-receipt.json", "public-glrt.json", "failure.json", "trace.json", "classifier-0.json", "daemon-log.json", "preflight.json", "postflight.json", "daemon-start.json", "daemon-stop.json"):
            path = case / name
            if path.is_file():
                files.append((path, f"{label}/{case.name}/{name}"))
index = []
for source, relative in files:
    assert source.is_file() and not source.is_symlink(), source
    assert "credentials" not in source.parts and source.name not in ("known_hosts", "password")
    data = source.read_bytes()
    target = OUT / (relative + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    if target.exists():
        assert target.read_bytes() == compressed, f"Refusing to overwrite changed evidence: {target}"
    else:
        with target.open("xb") as stream:
            stream.write(compressed)
    index.append(dict(source=str(source), archive=str(target.relative_to(OUT)),
                      bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                      archive_sha256=hashlib.sha256(compressed).hexdigest()))
# A new snapshot index preserves earlier partial-run inventories unchanged.
snapshot = OUT / f"index-{len(index):03d}.json"
payload = json.dumps(dict(schema="org.leo.research.radio18-live-startup-evidence/v1", artifacts=index), indent=2) + "\n"
if snapshot.exists():
    assert snapshot.read_text() == payload
else:
    with snapshot.open("x") as stream:
        stream.write(payload)
print(json.dumps(dict(artifacts=len(index), snapshot=str(snapshot))))

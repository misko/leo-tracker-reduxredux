"""Summarize sealed public scanner receipts; no radio or IQ mutation."""
import argparse
from collections import Counter
import json

import numpy as np

from run_matrix_case import CASES, settings, save, PersistentHopIqStore, AdaptiveHopIqStore, ScannerGlrtStore


def distribution(values):
    values = list(values)
    if not values:
        return {"count": 0}
    return dict(count=len(values), mean=float(np.mean(values)),
                p50=float(np.percentile(values, 50)), p95=float(np.percentile(values, 95)),
                p99=float(np.percentile(values, 99)), maximum=float(np.max(values)))


parser = argparse.ArgumentParser()
parser.add_argument("index", type=int, choices=range(6))
args = parser.parse_args()
config = settings(args.index)
root = config.bulk_root.parent
summary = json.loads((root / "summary.json").read_text())
adaptive = CASES[args.index][1] == "adaptive"
store = AdaptiveHopIqStore(config.bulk_root, read_only=True) if adaptive else PersistentHopIqStore.open_read_only(config.bulk_root)
try:
    publication = store.inspect(summary["session_id"])
    receipt = publication.manifest.receipt
    raw = receipt.model_dump(mode="json")
    save(root / "public-receipt.json", raw)
    glrt = ScannerGlrtStore.open_read_only(config.bulk_root).read(summary["session_id"])
    evidence = glrt.evidence if glrt else None
    if glrt:
        save(root / "public-glrt.json", glrt.model_dump(mode="json"))
    rows = raw["events"] if adaptive else [v["transition_invalid_before"] for v in raw["visits"]]
    if not adaptive:
        names = ("transition_before_counter", "transition_after_counter", "device_sample_counter", "device_sample_counter_end_exclusive")
        # Keep exact persisted names visible if the public type changes.
        if rows and not all(name in rows[0] for name in names):
            print(json.dumps({"transition_fields": list(rows[0])}))
    else:
        names = ("transition_before_counter", "transition_after_counter", "invalid_start_counter", "valid_start_counter")
    timings = {}
    if rows and all(name in rows[0] for name in names):
        rate = CASES[args.index][0]
        steady = rows[1:]
        timings = {
            "retune_ms": distribution((int(v[names[1]])-int(v[names[0]]))*1000/rate for v in steady),
            "scheduler_lateness_ms": distribution((int(v[names[0]])-int(v[names[2]]))*1000/rate for v in steady),
            "guard_ms": distribution((int(v[names[3]])-int(v[names[1]]))*1000/rate for v in steady),
        }
    results = evidence.results if evidence else ()
    computed = [r for r in results if r.confirmation_end > r.confirmation_start]
    report = dict(session_id=summary["session_id"], capture_summary=summary,
        excluded_startup_from_hop_statistics=True, timings=timings,
        evidence_present=evidence is not None,
        delivery_complete=evidence.delivery_complete if evidence else None,
        classification_complete=evidence.classification_complete if evidence else None,
        expected_results=evidence.expected_results if evidence else None,
        dropped_results=evidence.dropped_results if evidence else None,
        reasons=dict(Counter(r.reason for r in results)),
        searched_results=sum(r.search_end > r.search_start for r in results),
        confirmed_results=len(computed),
        cpu_ms_confirmed=distribution(r.cpu_ms for r in computed),
        wall_ms_confirmed=distribution(r.wall_ms for r in computed),
        positive_targets=dict(Counter(f"CH{r.channel}{r.edge[0].upper()}" for r in results if r.verdict == "starlink")),
        api_scope="ASGI against sealed real stores, not deployed browser")
    if adaptive:
        report["scheduler_modes"] = dict(Counter(e.decision.mode for e in receipt.events))
        report["scheduler_reasons"] = dict(Counter(str(e.decision.reason) for e in receipt.events))
    save(root / "characterization.json", report)
    print(json.dumps(report, indent=2))
finally:
    if hasattr(store, "close"):
        store.close()

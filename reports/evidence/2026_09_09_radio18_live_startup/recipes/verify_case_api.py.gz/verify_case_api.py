"""Read actual canary IQ/classifier publications through production HTTP routes.

ASGI transport, not a deployed-browser check. The unrelated catalog uses the
existing in-memory fixture; every scanner response comes from the real sealed
recording and source-bound classifier stores, with no substituted radio data.
"""
import argparse
from collections import Counter
import json

from fastapi.testclient import TestClient
from leo.api.app import create_app
from leo.presentation.fixtures import build_fixture_repository
from leo.storage.adaptive_hop_history import AdaptiveHopPresentationStore, AdaptiveHopGlrtPresentationStore
from leo.storage.scanner_glrt import ScannerGlrtPresentationStore

from run_matrix_case import ROOT, CASES, settings, save, PersistentHopIqStore, AdaptiveHopIqStore, ScannerGlrtStore

parser = argparse.ArgumentParser()
parser.add_argument("index", type=int, choices=range(6))
args = parser.parse_args()
config = settings(args.index)
case = config.bulk_root.parent
summary = json.loads((case / "summary.json").read_text())
session_id = summary["session_id"]
adaptive = CASES[args.index][1] == "adaptive"
if adaptive:
    store = AdaptiveHopIqStore(config.bulk_root, read_only=True)
    options = dict(adaptive_hop_sessions=AdaptiveHopPresentationStore(config.bulk_root),
                   adaptive_scanner_glrt=AdaptiveHopGlrtPresentationStore(config.bulk_root))
    prefix = "/api/v1/scanner/adaptive-sessions"
else:
    store = PersistentHopIqStore.open_read_only(config.bulk_root)
    options = dict(persistent_hop_sessions=store, scanner_glrt=ScannerGlrtPresentationStore(
        store, ScannerGlrtStore.open_read_only(config.bulk_root)))
    prefix = "/api/v1/scanner/persistent-sessions"
published = store.inspect(session_id)
receipt = published.manifest.receipt
app = create_app(build_fixture_repository(config.bulk_root), artifact_root=config.bulk_root, **options)
with TestClient(app) as client:
    responses = {}
    history = client.get(prefix)
    assert history.status_code == 200, history.text
    document = history.json()
    assert document["total"] == 1 and document["items"][0]["session_id"] == session_id
    responses[prefix] = dict(status=200, body=document)
    urls = [prefix]
    if adaptive:
        detail = client.get(prefix + "/" + session_id)
        assert detail.status_code == 200, detail.text
        assert detail.json()["capture"]["input_manifest_sha256"] == published.manifest_sha256
        responses[prefix + "/" + session_id] = dict(status=200, body=detail.json())
        urls.append(prefix + "/" + session_id)
    glrt_url = prefix + "/" + session_id + "/glrt"
    glrt = client.get(glrt_url)
    if CASES[args.index][2]:
        assert glrt.status_code == 200, glrt.text
        assert glrt.json()["input_manifest_sha256"] == published.manifest_sha256
        urls.append(glrt_url)
    else:
        assert glrt.status_code == 404
    responses[glrt_url] = dict(status=glrt.status_code, body=glrt.json())
    for url in urls:
        head = client.head(url)
        assert head.status_code == 200 and head.content == b""
visits = receipt.visits if not adaptive else receipt.events[:receipt.complete_visit_count]
targets = dict(Counter(v.target_index for v in visits))
qualification = dict(
    passed=bool(receipt.qualified if not adaptive else receipt.terminal.state == "completed"
                and receipt.source_span_attested and receipt.duty_target_met),
    valid_duty_ppm=receipt.valid_duty_ppm,
    source_span_seconds=receipt.duty_denominator_sample_count / CASES[args.index][0],
    retained_visits=len(visits), visits_by_target=targets,
    classification_warning=summary["classification_warning"],
    api_verified=True, deployed_browser_verified=False,
)
save(case / "api-responses.json", responses)
save(case / "qualification.json", qualification)
print(json.dumps(qualification, indent=2))
if hasattr(store, "close"):
    store.close()

"""Bounded offline build/test receipts. No radio contexts or RF operations."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).parent
lib = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
leo = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
native = leo / 'src/leo/scanner/native_presence'
receipts = []

def run(name, command, *, environment=None, required=True):
    env = os.environ.copy()
    env.update(environment or {})
    result = subprocess.run(command, cwd=lib, env=env, capture_output=True, text=True, timeout=180)
    receipt = dict(name=name, command=list(map(str, command)), status=result.returncode,
                   stdout=result.stdout, stderr=result.stderr, required=required)
    (root / f'verify-{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    receipts.append(receipt)
    print(name, result.returncode, flush=True)
    if result.returncode and required:
        print(result.stdout[-6000:], result.stderr[-6000:], flush=True)
        raise SystemExit(result.returncode)

def sources(name):
    src = ['iiod/spf-hop-protocol.c']
    if name != 'protocol':
        src += ['iiod/spf-hop-adaptive-protocol.c']
    if name in ('session', 'adaptive', 'native'):
        src += ['iiod/spf-hop-session.c']
    if name in ('scheduler', 'adaptive', 'native'):
        src += ['iiod/spf-hop-scheduler.c']
    if name in ('native', 'policy'):
        src += ['iiod/spf-hop-adaptive-policy.c', str(native / 'adaptive_scan.c')]
    test = 'adaptive' if name == 'native' else 'adaptive_policy' if name == 'policy' else name
    return [f'tests/test_spf_hop_{test}.c'] + src

for name in ('protocol', 'session', 'scheduler', 'adaptive', 'native', 'policy'):
    flags = ['-DSPF_HOP_TEST_NATIVE_POLICY=1'] if name == 'native' else []
    run(f'asan-build-{name}', ['cc', '-std=c11', '-g', '-O1', '-Wall', '-Wextra', '-Werror',
        '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-Iiiod', '-I' + str(native),
        *flags, *sources(name), '-pthread', '-o', str(root / f'test_{name}')])
    run(f'asan-run-{name}', [str(root / f'test_{name}')], environment={
        'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1', 'UBSAN_OPTIONS': 'halt_on_error=1'})

run('tsan-build-policy', ['cc', '-std=c11', '-g', '-O1', '-Wall', '-Wextra', '-Werror',
    '-fsanitize=thread', '-Iiiod', '-I' + str(native), *sources('policy'), '-pthread',
    '-o', str(root / 'test_policy_tsan')])
run('tsan-run-policy', [str(root / 'test_policy_tsan')], required=False)

compiler = '/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc'
for name in ('native', 'policy'):
    flags = ['-DSPF_HOP_TEST_NATIVE_POLICY=1'] if name == 'native' else []
    run(f'arm-build-{name}', [compiler, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
        '-mcpu=cortex-a9', '-mfpu=neon', '-mfloat-abi=hard', '-Iiiod', '-I' + str(native),
        *flags, *sources(name), '-pthread', '-o', str(root / f'test_{name}_arm')])

build = root / 'positive-only-v1'
targets = ['test_spf_hop_adaptive_native', 'test_spf_hop_adaptive_policy', 'test_spf_hop_adaptive',
           'test_spf_hop_protocol', 'test_spf_hop_session', 'test_spf_hop_scheduler']
run('cmake-configure', ['cmake', '-S', str(lib), '-B', str(build)])
run('cmake-build', ['cmake', '--build', str(build), '--target', *targets, '-j', '2'])
for target in targets:
    directory = 'iiod' if target in targets[:2] else 'tests'
    run(f'cmake-run-{target}', [str(build / directory / target)])

manifest = dict(scope='offline synthetic adaptive-hop component verification; no RF or ARM execution',
                receipts=receipts, sources={}, artifacts={})
for repo, names in ((lib, ['iiod/spf-hop-protocol.c', 'iiod/spf-hop-protocol.h',
    'iiod/spf-hop-adaptive-protocol.c', 'iiod/spf-hop-adaptive-protocol.h',
    'iiod/spf-hop-adaptive-policy.c', 'iiod/spf-hop-adaptive-policy.h',
    'iiod/spf-hop-scheduler.c', 'iiod/spf-hop-scheduler.h',
    'iiod/spf-hop-session.c', 'iiod/spf-hop-session.h',
    'tests/test_spf_hop_adaptive.c', 'tests/test_spf_hop_adaptive_policy.c']),
    (leo, ['src/leo/scanner/native_presence/adaptive_scan.c',
           'src/leo/scanner/native_presence/adaptive_scan.h', 'tests/scanner/test_adaptive_scan.py'])):
    for name in names:
        path = repo / name
        manifest['sources'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for path in root.iterdir():
    if path.is_file() and (path.name.startswith('test_') or path.name in ('sdk.so', 'worker')):
        manifest['artifacts'][path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
(root / 'verification.json').write_text(json.dumps(manifest, indent=2) + '\n')

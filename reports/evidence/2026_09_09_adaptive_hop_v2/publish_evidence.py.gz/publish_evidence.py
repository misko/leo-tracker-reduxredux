"""Retain generated non-IQ/non-executable offline receipts, without radio access."""
import gzip
import hashlib
import json
from pathlib import Path

source = Path(__file__).parent
destination = Path('/home/mouse9911/gits/leo-tracker-arm-presence/reports/evidence/2026_09_09_adaptive_hop_v2')
destination.mkdir(parents=True, exist_ok=False)
entries = []
for path in sorted(source.iterdir()):
    if not path.is_file() or path.suffix not in ('.json', '.xml', '.py'):
        continue
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    name = path.name + '.gz'
    (destination / name).write_bytes(compressed)
    entries.append(dict(path=name, original_name=path.name, original_bytes=len(raw),
                        original_sha256=hashlib.sha256(raw).hexdigest(),
                        compressed_sha256=hashlib.sha256(compressed).hexdigest()))
index = dict(scope='offline adaptive hop V2 component checkpoint; no RF or ARM execution',
             raw_root=str(source), artifacts=entries)
(destination / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps(dict(artifacts=len(entries), index=str(destination / 'index.json'))))

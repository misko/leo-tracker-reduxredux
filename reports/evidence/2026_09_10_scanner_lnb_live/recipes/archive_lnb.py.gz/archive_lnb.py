"""Archive bounded non-secret canary receipts; never archive IQ or credentials."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import pwd
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/mouse9911/gits/leo-tracker-arm-presence')
OUT = REPO / 'reports/evidence/2026_09_10_scanner_lnb_live'
OWNER = pwd.getpwnam('mouse9911')
rows = []

def own(path):
    os.chown(path, OWNER.pw_uid, OWNER.pw_gid)

def write(name, payload):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    for directory in (target.parent, *target.parent.parents):
        if directory == OUT.parent:
            break
        if directory.is_relative_to(OUT):
            own(directory)
    packed = gzip.compress(payload, mtime=0)
    with target.open('xb') as stream:
        stream.write(packed)
    own(target)
    rows.append(dict(path=str(target.relative_to(REPO)), raw_bytes=len(payload),
        raw_sha256=hashlib.sha256(payload).hexdigest(), compressed_bytes=len(packed),
        compressed_sha256=hashlib.sha256(packed).hexdigest()))

def command(name, argv):
    result = subprocess.run(argv, capture_output=True, timeout=60, check=False)
    write(name + '.json', json.dumps(dict(argv=argv, returncode=result.returncode,
        stdout=result.stdout.decode(errors='replace'), stderr=result.stderr.decode(errors='replace')), indent=2).encode())

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    own(OUT)
    for name in ('run_lnb.py', 'analyze_lnb.py', 'reference_lnb.py', 'audit_policy.py', 'archive_lnb.py', 'prepared.json', 'installed-tests.xml'):
        write('recipes/' + name if name.endswith('.py') else name, (ROOT / name).read_bytes())
    for index, rate in enumerate((2500000, 5000000)):
        case = ROOT / f'case-{index}-{rate}-adaptive'
        for path in sorted(case.glob('*.json')):
            write(f'case-{index}/' + path.name, path.read_bytes())
        for directory in ('desktop-reference', 'desktop-reference-v2'):
            for path in sorted((case / directory).glob('*.json')):
                write(f'case-{index}/{directory}/' + path.name, path.read_bytes())
    for name in ('cleanup-ppu-full.xml', 'cleanup-ppu-py311.xml', 'cleanup-leo-combined.xml', 'cleanup-deploy.xml'):
        path = Path('/tmp/leo-scanner-frozen-release.LGLfMd') / name
        write('source-tests/' + name, path.read_bytes())
    units = ('leo-scanner-candidate-stage-987e1e46', 'leo-lnb-canary-preflight-20260910',
        'leo-lnb-canary-preflight-20260910-r2', 'leo-lnb-canary-preflight-20260910-r3',
        'leo-lnb-canary-2p5m-20260910', 'leo-lnb-canary-5m-20260910',
        'leo-lnb-reference-2p5m-20260910', 'leo-lnb-reference-2p5m-20260910-r2',
        'leo-lnb-reference-5m-20260910')
    for unit in units:
        command('operations/' + unit, ['journalctl', '-u', unit + '.service', '--no-pager'])
    command('operations/production-control-after', ['curl', '-fsS', 'http://127.0.0.1:8090/api/v1/capture-control'])
    command('operations/production-services-after', ['systemctl', 'show', 'leo-api.service', 'leo-acquisition.service', '-p', 'MainPID', '-p', 'ActiveEnterTimestamp', '-p', 'ActiveState'])
    command('operations/locks-after', ['lslocks', '-o', 'PID,COMMAND,PATH'])
    command('operations/radio-connections-after', ['ss', '-tnp', 'dst', '192.168.1.20'])
    selectors = {name:os.readlink(Path('/opt/leo-tracker') / name) for name in ('current', 'current-api', 'current-acquisition')}
    write('operations/selectors-after.json', json.dumps(selectors, indent=2).encode())
    write('source/leo-change.diff', subprocess.check_output(['git', '-c', 'safe.directory='+str(REPO), '-C', str(REPO), 'show', '--format=fuller', '987e1e46a0fcc88973538ce846432738957033cf']))
    for path in sorted((REPO / 'reports/figures/2026_09_10_scanner_lnb_live').glob('*.png')):
        payload = path.read_bytes()
        rows.append(dict(path=str(path.relative_to(REPO)), raw_bytes=len(payload), raw_sha256=hashlib.sha256(payload).hexdigest()))
    document = dict(scope='Two receive-only 300 s LNB captures, isolated stores, not production activation. No credentials or IQ included.',
        raw_root=str(ROOT), release='987e1e46a0fcc88973538ce846432738957033cf',
        radio_host='192.168.1.20', radio_serial='1040005e0b100007100010000bf33a5d4d',
        rf_authorization_seconds=1200, conservative_two_case_reservation_seconds=960, artifacts=rows)
    path = OUT / 'index.json'
    with path.open('x') as stream:
        json.dump(document, stream, indent=2)
        stream.write('\n')
    own(path)
    for row in rows:
        path = REPO / row['path']
        if 'compressed_sha256' in row:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['compressed_sha256']
            assert hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest() == row['raw_sha256']
        else:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['raw_sha256']
    print(json.dumps(dict(artifacts=len(rows), all_hashes_verified=True, index=str(OUT / 'index.json'))))

if __name__ == '__main__':
    main()

"""Read-only live-canary HTTP and source-counter analysis; never opens a radio."""
import argparse
from collections import Counter
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from fastapi.testclient import TestClient
from leo.api.app import create_app
from leo.presentation.fixtures import build_fixture_repository
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.adaptive_hop_history import AdaptiveHopPresentationStore, AdaptiveHopGlrtPresentationStore
from leo.storage.scanner_glrt import ScannerGlrtStore

ROOT = Path(__file__).resolve().parent
LABELS = ['CH1L', 'CH2L', 'CH3L', 'CH4L', 'CH1U', 'CH2U', 'CH3U', 'CH4U']

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def stats(values):
    return dict(count=len(values), mean=float(np.mean(values)), p50=float(np.percentile(values, 50)),
        p99=float(np.percentile(values, 99)), maximum=float(max(values))) if len(values) else dict(count=0)

def analyze(index):
    root = ROOT / f'case-{index}-{(2500000, 5000000)[index]}-adaptive'
    summary = json.loads((root / 'summary.json').read_text())
    bulk = root / 'bulk'
    store = AdaptiveHopIqStore(bulk, read_only=True)
    try:
        published = store.inspect(summary['session_id'])
        receipt = published.manifest.receipt
    finally:
        store.close()
    rate = receipt.plan.geometry.sample_rate_hz
    first = receipt.terminal.first_counter
    span = receipt.duty_denominator_sample_count / rate
    events = receipt.events[:receipt.complete_visit_count]
    t = np.array([(e.valid_start_counter - first) / rate for e in events])
    target = np.array([e.target_index for e in events])
    record = ScannerGlrtStore.open_read_only(bulk).read(published.session_id)
    results = record.evidence.results if record and record.evidence else ()
    by_visit = {r.visit: r for r in results}
    full = np.array([by_visit[e.visit_index].search_window_mask == 63 for e in events])
    positive = np.array([by_visit[e.visit_index].verdict == 'starlink' for e in events])
    evaluated = np.array([by_visit[e.visit_index].confirmation_end > by_visit[e.visit_index].confirmation_start for e in events])
    steady = events[1:]
    details = dict(session_id=published.session_id,
        retune_ms=stats([(e.transition_after_counter-e.transition_before_counter)*1000/rate for e in steady]),
        scheduler_lateness_ms=stats([(e.transition_before_counter-e.invalid_start_counter)*1000/rate for e in steady]),
        guard_ms=stats([(e.valid_start_counter-e.transition_after_counter)*1000/rate for e in steady]),
        revisit_start_to_start_seconds={LABELS[i]: stats(np.diff(t[target == i])) for i in range(8)},
        active_mask_counts=dict(Counter(e.decision.active_mask for e in events)),
        quiet_mask_counts=dict(Counter(e.decision.quiet_mask for e in events)),
        decisions_with_cooldown_and_misses=sum(e.decision.cooldown_remaining_samples > 0 and e.decision.consecutive_misses > 0 for e in events),
        source_seconds=span, valid_seconds=receipt.valid_sample_count/rate,
        transition_invalid_seconds=receipt.transition_invalid_sample_count/rate,
        unclassified_seconds=receipt.unclassified_sample_count/rate,
        unreceived_tail_seconds=receipt.unreceived_tail_sample_count/rate,
        full_screen_fraction=float(full.mean()), positive_fraction=float(positive.mean()), evaluated_fraction=float(evaluated.mean()))
    save(root / 'timing-and-policy.json', details)

    # Scanner HTTP responses are from the sealed real stores. The unrelated
    # catalog fixture is only app wiring; this is ASGI, not deployed-browser proof.
    app = create_app(build_fixture_repository(bulk), artifact_root=bulk,
        adaptive_hop_sessions=AdaptiveHopPresentationStore(bulk),
        adaptive_scanner_glrt=AdaptiveHopGlrtPresentationStore(bulk))
    prefix = '/api/v1/scanner/adaptive-sessions'
    urls = [prefix, prefix + '/' + published.session_id, prefix + '/' + published.session_id + '/glrt']
    responses = {}
    with TestClient(app) as client:
        for url in urls:
            response = client.get(url)
            assert response.status_code == 200, response.text
            head = client.head(url)
            assert head.status_code == 200 and head.content == b''
            responses[url] = response.json()
    assert responses[urls[0]]['total'] == 1
    assert responses[urls[1]]['capture']['input_manifest_sha256'] == published.manifest_sha256
    assert responses[urls[2]]['input_manifest_sha256'] == published.manifest_sha256
    save(root / 'api-responses.json', responses)
    save(root / 'api-verification.json', dict(passed=True, scope='installed production ASGI routes with real sealed scanner stores, not deployed browser', session_id=published.session_id, get_and_head_urls=urls))

    fig, axes = plt.subplots(3, 1, figsize=(14, 9), sharex=True, constrained_layout=True)
    axes[0].scatter(t[~full & ~positive], target[~full & ~positive], s=5, color='#d79038', label='Unavailable / not fully screened')
    axes[0].scatter(t[full & ~positive], target[full & ~positive], s=5, color='#8a9ba8', label='Fully screened; no qualifying positive')
    axes[0].scatter(t[positive], target[positive], s=11, color='#087e66', label='Lightweight GLRT candidate')
    axes[0].set_yticks(range(8), LABELS)
    axes[0].invert_yaxis()
    axes[0].legend(loc='upper right', fontsize=8, ncol=3)
    axes[0].set_title(f'{rate/1e6:g} MS/s on .20 LNB — {published.session_id}\nActual 120 ms visits; candidates are not satellite identities')
    bins = np.arange(0, 301, 10, dtype=float)
    duty, coverage = [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        overlap = np.maximum(0, np.minimum(t + .120, hi) - np.maximum(t, lo))
        duty.append(float(overlap.sum() / (hi-lo) * 100))
        chosen = (t >= lo) & (t < hi)
        coverage.append(float(full[chosen].mean() * 100) if chosen.any() else np.nan)
    axes[1].plot((bins[:-1]+bins[1:])/2, duty, color='#245f86', label='Retained valid IQ duty')
    axes[1].plot((bins[:-1]+bins[1:])/2, coverage, color='#ba6b1b', label='Full temporal-screen coverage / visits')
    axes[1].axhline(90, color='gray', linestyle=':', linewidth=1, label='90% capture target')
    axes[1].set_ylabel('Percent per 10 s bin')
    axes[1].set_ylim(0, 105)
    axes[1].legend(fontsize=8, ncol=3)
    computed = [by_visit[e.visit_index] for e in events if by_visit[e.visit_index].confirmation_end > by_visit[e.visit_index].confirmation_start]
    times = [(r.valid_start-first)/rate for r in computed]
    axes[2].scatter(times, [r.cpu_ms for r in computed], s=4, alpha=.5, color='#6a58a5', label='ARM worker CPU / evaluated dwell')
    axes[2].axhline(100, color='#a5443e', linestyle='--', linewidth=1, label='100 ms compute target')
    axes[2].axhline(120, color='gray', linestyle=':', linewidth=1, label='120 ms valid dwell')
    axes[2].set_ylabel('CPU time (ms)')
    axes[2].set_xlabel('Source-counter time since capture start (s)')
    axes[2].legend(fontsize=8, ncol=3)
    for axis in axes:
        axis.grid(alpha=.15)
        axis.set_xlim(0, 300)
    fig.savefig(root / 'live-timeline.png', dpi=170)
    plt.close(fig)
    print(json.dumps(dict(summary=summary, timing=details, api_verified=True), indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('index', type=int, choices=(0, 1))
    analyze(parser.parse_args().index)

"""Audit observable decision/cooldown counters, without inventing private feedback."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def run(index):
    root = ROOT / f'case-{index}-{(2500000, 5000000)[index]}-adaptive'
    receipt = json.loads((root / 'public-receipt.json').read_text())
    glrt = json.loads((root / 'public-glrt.json').read_text())['evidence']['results']
    events = receipt['events']
    rate = receipt['plan']['geometry']['sample_rate_hz']
    last_mask = 0
    demotions, cooldown_examples = [], []
    for event in events:
        d = event['decision']
        lost = last_mask & ~d['active_mask']
        for target in range(8):
            if lost & (1 << target):
                basis = d['basis_visit']
                positives = [r for r in glrt if r['verdict'] == 'starlink'
                    and r['channel']-1 + (4 if r['edge'] == 'upper' else 0) == target
                    and basis is not None and int(r['visit']) <= basis]
                latest = max(positives, key=lambda r: int(r['visit']), default=None)
                elapsed = (d['decision_counter'] - int(latest['valid_end']))/rate if latest else None
                demotions.append(dict(visit=event['visit_index'], target=target,
                    seconds_since_latest_in_basis_positive=elapsed, decision_reason=d['reason']))
        if d['cooldown_remaining_samples'] > 0 and d['consecutive_misses'] > 0 and d['basis_visit'] is not None:
            target = events[d['basis_visit']]['target_index']
            cooldown_examples.append(dict(visit=event['visit_index'], basis_visit=d['basis_visit'],
                basis_target=target, consecutive_misses=d['consecutive_misses'],
                cooldown_remaining_ms=d['cooldown_remaining_samples']*1000/rate,
                basis_target_still_active=bool(d['active_mask'] & (1 << target))))
        last_mask = d['active_mask']
    document = dict(demotions=demotions, cooldown_examples=cooldown_examples,
        demotions_with_sub_two_second_public_positive=[x for x in demotions if x['seconds_since_latest_in_basis_positive'] is not None and x['seconds_since_latest_in_basis_positive'] < 2],
        scope='Observable persisted state only. Public unavailable is not a replayable evaluated-miss observation; this is not a complete independent policy replay.')
    with (root / 'policy-audit.json').open('x') as stream:
        json.dump(document, stream, indent=2)
    print(json.dumps(dict(demotions=len(demotions), cooldown_examples=len(cooldown_examples),
        examples_with_basis_target_active=sum(x['basis_target_still_active'] for x in cooldown_examples),
        sub_two_second_demotions=len(document['demotions_with_sub_two_second_public_positive']))))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('index', type=int, choices=(0, 1))
    run(parser.parse_args().index)

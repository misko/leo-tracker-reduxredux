"""Two receive-only LNB canaries through the installed production application.

Explicit .20/.21 authorization supersedes the old USB-only target restriction.
Use .20 only, under the actual paused production authority and PPU serial lock.
Each single-use case reserves 480 wall seconds; total new RF budget is 1200 s.
No firmware writes, production selector changes, or capture resume operations.
"""
import argparse
from collections import Counter
import dataclasses
from datetime import UTC, datetime, timedelta
import hashlib
import importlib.metadata
import ipaddress
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import sys
from threading import Event, Thread, Timer
import time
import traceback

from leo.acquisition.authority import LocalCaptureAuthority, RadioResource
from leo.cli.composition import CliSettings, CompositionHooks, LocalAcquisitionBackend, RadioConfigurationV1
from leo.radio.pluto_userspace_iiod_lifecycle import create_pluto_userspace_iiod_lifecycle
from leo.radio.scanner_glrt_metadata import ScannerGlrtOptions
from leo.scanner import canonical_scheduled_scanner_operation_key
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.scanner_glrt import ScannerGlrtStore
from pluto_plus.bootstrap_firmware import BoundSshBootstrapTransport
from pluto_plus.hardware.discovery import discover_network_iio
from pluto_plus.hardware.preflight import verify_metadata_runtime
from pluto_plus.radio_lock import acquire_radio_lock

ROOT = Path(__file__).resolve().parent
RELEASE = Path('/opt/leo-tracker/releases/987e1e46a0fcc88973538ce846432738957033cf')
BUNDLE = RELEASE / 'runtime/scanner-glrt'
HOST = '192.168.1.20'
SERIAL = '1040005e0b100007100010000bf33a5d4d'
RADIO = 'radio_pluto_5d4d'
CONTROL = Path('/srv/bulk/leo/control')
ALG = '3a2b6f66a39f197f8544be8a7af635122d762fc3bf2c649ee4c8937d1490b41c'
CONFIG = '7119b7116309835f308c5db23acb23b0e98f098fdf4c853caf8e4f0bb83424f8'
MANIFEST = '19c3650480a8386b12384b0f9a0c5d49e237b04ad98f474d3e703d3f820ddd7c'
RATES = (2500000, 5000000)
PRECHECK = rb'''set -eu
serial=$(cat /sys/kernel/config/usb_gadget/composite_gadget/strings/0x409/serialnumber)
[ "$serial" = '1040005e0b100007100010000bf33a5d4d' ]
printf 'SERIAL %s\n' "$serial"
printf 'BOOT '; cat /proc/sys/kernel/random/boot_id
ip -4 addr show dev eth0
cat /opt/VERSIONS
for d in /sys/bus/iio/devices/iio:device*; do
  [ ! -e "$d/buffer/enable" ] || [ "$(cat "$d/buffer/enable")" = 0 ]
  if [ "$(cat "$d/name")" = ad9361-phy ]; then
    for name in in_voltage_sampling_frequency in_voltage_rf_bandwidth in_voltage0_hardwaregain in_voltage1_hardwaregain in_voltage0_gain_control_mode in_voltage1_gain_control_mode in_voltage0_rf_port_select out_altvoltage0_RX_LO_frequency; do
      if [ -f "$d/$name" ]; then printf 'ATTR %s ' "$name"; cat "$d/$name"; fi
    done
  fi
done
test ! -e /tmp/pluto-plus-utils/pluto.frm
netstat -nt
ps -o pid,comm
'''

def normalize(value):
    if hasattr(value, 'model_dump'):
        return value.model_dump(mode='json')
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, default=normalize)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def progress(stage, **facts):
    print(json.dumps(dict(utc=datetime.now(UTC).isoformat(), stage=stage, **facts), default=normalize), flush=True)

def transport():
    credentials = Path(os.environ['CREDENTIALS_DIRECTORY'])
    # The generic diagnostic transport requires mode 0600; systemd exposes
    # root-owned credentials as 0440. Copy only the public host key, preserving
    # exact bytes and strict pinning. The password stays in systemd credentials.
    key = ROOT / 'diagnostic-known-hosts'
    payload = (credentials / 'scanner-iiod-ssh-known-hosts').read_bytes()
    if not key.exists():
        fd = os.open(key, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
    assert key.read_bytes() == payload
    return BoundSshBootstrapTransport(host=HOST, interface=None,
        password=(credentials / 'scanner-iiod-ssh-password').read_text().rstrip('\r\n'),
        known_hosts_file=key)

def authority():
    assert (CONTROL / 'capture-authority-v1.json').is_file(), 'Do not create a substitute authority'
    return LocalCaptureAuthority(CONTROL, (RadioResource(RADIO, SERIAL, 'ip:' + HOST),))

def preflight():
    found = discover_network_iio([HOST + '/32'], max_hosts=1, workers=1)
    assert len(found) == 1 and found[0].serial == SERIAL
    assert found[0].firmware_version == 'v0.49-plutoplus-spf-iq-direct-async-v4'
    output = transport().run('sh -s', stdin=PRECHECK, timeout_s=15)
    progress('preflight_readback', readback=output)
    connections = [line for line in output.splitlines() if 'ESTABLISHED' in line]
    assert len(connections) == 1 and HOST + ':22' in connections[0], connections
    addresses = [str(ipaddress.ip_interface(line.split()[1]).ip)
        for line in output.splitlines() if line.strip().startswith('inet ')]
    assert HOST in addresses, addresses
    assert shutil.disk_usage(ROOT).free > 64 * 1024**3
    boot = next(line.split()[1] for line in output.splitlines() if line.startswith('BOOT '))
    attrs = [line for line in output.splitlines() if line.startswith('ATTR ')]
    return dict(network=found[0], readback=output, boot_id=boot, attributes=attrs)

def runtime():
    assert Path(sys.prefix) == RELEASE / '.venv'
    provenance = json.loads(importlib.metadata.distribution('pluto-plus-utils').read_text('direct_url.json'))
    assert provenance['vcs_info']['commit_id'] == '664fa85cdde35050c0293a1dab90d2cc8b99eef9'
    for name, digest in (('bundle.json', MANIFEST), ('algorithm.json', ALG), ('configuration.json', CONFIG)):
        assert hashlib.sha256((BUNDLE / name).read_bytes()).hexdigest() == digest
    spec = json.loads((BUNDLE / 'bundle.json').read_text())
    files = spec['files'] + [dict(name='iiod', bytes=spec['daemon_bytes'], sha256=spec['daemon_sha256'])]
    for item in files:
        payload = (BUNDLE / item['name']).read_bytes()
        assert len(payload) == item['bytes'] and hashlib.sha256(payload).hexdigest() == item['sha256']
    return dict(release=RELEASE, python=sys.version, ppu=provenance, native=verify_metadata_runtime(expected_abi=3))

def settings(index):
    root = ROOT / f'case-{index}-{RATES[index]}-adaptive'
    return CliSettings(profile_root=RELEASE / 'profiles', bulk_root=root / 'bulk', radio_backend='pluto',
        radios=(RadioConfigurationV1(radio_id=RADIO, serial=SERIAL, host=HOST),),
        safety_reserve_bytes=16 * 1024**3, scanner_enabled=True, scanner_capture_mode='persistent_hop',
        scanner_radio_id=RADIO, scanner_persistent_credentials_directory=Path(os.environ['CREDENTIALS_DIRECTORY']),
        scanner_persistent_iiod_binary_path=BUNDLE / 'iiod',
        scanner_persistent_iiod_bundle_manifest_path=BUNDLE / 'bundle.json',
        scanner_persistent_transition_guard_us=1000, scanner_persistent_samples_per_block=131072,
        scanner_persistent_kernel_buffers=8, scanner_persistent_read_ahead_visits=8,
        scanner_persistent_queue_capacity_visits=64, scanner_gain_db=40.0,
        scanner_glrt=ScannerGlrtOptions(ALG, CONFIG, mode='positive-only-v1'),
        scanner_hop_policy='adaptive', scanner_report_root=root / 'reports')

def intent(backend, index):
    # These canonical slots select the rates; tests run immediately, not as production cadence.
    slot = datetime(2026, 9, 10, tzinfo=UTC) + timedelta(minutes=20 * index)
    result = backend.scheduled_scanner_intent(operation_key=canonical_scheduled_scanner_operation_key(slot), scheduled_for=slot)
    assert result.configuration.sample_rate_hz == RATES[index] and result.run_duration_seconds == 300
    return result

class ObservedLifecycle:
    def __init__(self, config, root):
        self.inner = create_pluto_userspace_iiod_lifecycle(config)
        self.root = root

    def enter_and_attest(self):
        progress('daemon_staging')
        result = self.inner.enter_and_attest()
        save(self.root / 'daemon-start.json', result)
        progress('daemon_ready', receipt=result)

    def exit_and_verify(self):
        progress('daemon_cleanup')
        try:
            active = self.inner.active
            if active is not None:
                save(self.root / 'daemon-log.json', dict(text=transport().run('tail -c 65536 ' + shlex.quote(active.paths.log), timeout_s=10)))
        except Exception as error:
            save(self.root / 'log-retention-error.json', dict(error=repr(error)))
        finally:
            result = self.inner.exit_and_verify()
        save(self.root / 'daemon-stop.json', result)
        progress('daemon_restored', receipt=result)

def prepare():
    proof = runtime()
    owner = authority()
    before = owner.snapshot()
    assert before.generation == 215 and before.desired_state == 'paused' and before.observed_state == 'paused'
    with owner.claim_paused_maintenance((RADIO,), task_id='lnb-canary-preflight', expected_generation=215), acquire_radio_lock(SERIAL):
        admission = preflight()
    plans = []
    for index in range(2):
        config = settings(index)
        config.bulk_root.mkdir(parents=True)
        plans.append(dict(index=index, settings=config, intent=intent(LocalAcquisitionBackend(config), index)))
    save(ROOT / 'prepared.json', dict(runtime=proof, before=before, admission=admission, plans=plans,
        rf_budget_seconds=1200, reserved_per_case_wall_seconds=480, max_cases=2,
        scope='receive-only .20 LNB, no firmware changes, preserve production pause; isolated test stores'))
    progress('prepared', host=HOST, serial=SERIAL, cases=2, production_generation=215)

def summarize(index, run_result):
    config = settings(index)
    root = config.bulk_root.parent
    store = AdaptiveHopIqStore(config.bulk_root, read_only=True)
    try:
        published = store.verify(run_result.published.session_id)
    finally:
        store.close()
    receipt = published.manifest.receipt
    glrt = ScannerGlrtStore.open_read_only(config.bulk_root).read(published.session_id)
    evidence = glrt.evidence if glrt else None
    rows = evidence.results if evidence else ()
    evaluated = [r for r in rows if r.confirmation_end > r.confirmation_start]
    import numpy as np
    def stats(values):
        return dict(count=len(values), mean=float(np.mean(values)), p99=float(np.percentile(values, 99)), maximum=max(values)) if values else dict(count=0)
    summary = dict(session_id=published.session_id, sample_rate_hz=RATES[index], manifest_sha256=published.manifest_sha256,
        terminal_state=receipt.terminal.state, source_span_attested=receipt.source_span_attested,
        source_seconds=receipt.duty_denominator_sample_count / RATES[index], valid_duty_ppm=receipt.valid_duty_ppm,
        full_iq_verified=True, complete_visits=receipt.complete_visit_count,
        classification_warning=run_result.classification_warning, glrt_results=len(rows),
        delivery_complete=evidence.delivery_complete if evidence else None, dropped_results=evidence.dropped_results if evidence else None,
        verdicts=dict(Counter(r.verdict for r in rows)), masks=dict(Counter(r.search_window_mask for r in rows)),
        positives_by_target=dict(Counter(f'CH{r.channel}{r.edge[0].upper()}' for r in rows if r.verdict == 'starlink')),
        cpu_ms_evaluated=stats([r.cpu_ms for r in evaluated]), wall_ms_evaluated=stats([r.wall_ms for r in evaluated]),
        visits_by_target=dict(Counter(e.target_index for e in receipt.events[:receipt.complete_visit_count])),
        scheduler_modes=dict(Counter(e.decision.mode for e in receipt.events)),
        scheduler_reasons=dict(Counter(str(e.decision.reason) for e in receipt.events)))
    save(root / 'public-receipt.json', receipt)
    if glrt:
        save(root / 'public-glrt.json', glrt)
    save(root / 'summary.json', summary)
    progress('case_verified', **summary)

def run(index):
    prepared = json.loads((ROOT / 'prepared.json').read_text())
    config = settings(index)
    root = config.bulk_root.parent
    spent = sum(json.loads(p.read_text())['reserved_wall_seconds'] for p in ROOT.glob('case-*/attempt.json'))
    assert spent + 480 <= 1200
    save(root / 'attempt.json', dict(index=index, utc=datetime.now(UTC).isoformat(), reserved_wall_seconds=480))
    runtime()
    owner = authority()
    before = owner.snapshot()
    assert before.generation == 215
    cancel, done = Event(), Event()
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: cancel.set())
    timer = Timer(360, cancel.set)
    timer.daemon = True
    started = time.monotonic()
    def heartbeat():
        while not done.wait(30):
            progress('case_running', index=index, elapsed_seconds=time.monotonic()-started, cancellation_requested=cancel.is_set())
    Thread(target=heartbeat, daemon=True).start()
    try:
        with owner.claim_paused_maintenance((RADIO,), task_id=f'lnb-canary-{index}', expected_generation=215), acquire_radio_lock(SERIAL):
            admission = preflight()
            assert admission['boot_id'] == prepared['admission']['boot_id'], 'New boot requires renewed preflight'
            save(root / 'preflight.json', admission)
            backend = LocalAcquisitionBackend(config, CompositionHooks(persistent_hop_iiod_lifecycle_factory=lambda c: ObservedLifecycle(c, root)))
            resolved = intent(backend, index)
            timer.start()
            progress('capture_start', index=index, rate_hz=RATES[index], intent=resolved)
            try:
                result = backend.capture_scheduled_scanner(resolved, cancel=cancel)
                save(root / 'capture-result.json', result)
            finally:
                restored = preflight()
                save(root / 'postflight.json', restored)
                assert restored['boot_id'] == admission['boot_id']
                assert restored['attributes'] == admission['attributes'], 'Radio setting restoration mismatch'
        timer.cancel()
        save(root / 'authority-after.json', owner.snapshot())
        summarize(index, result)
    except BaseException as error:
        save(root / 'failure.json', dict(type=type(error).__name__, error=str(error), traceback=traceback.format_exc(), elapsed_seconds=time.monotonic()-started))
        progress('case_failed', index=index, error=str(error))
        raise
    finally:
        timer.cancel()
        done.set()
        progress('case_stopped', index=index, elapsed_seconds=time.monotonic()-started)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'run'))
    parser.add_argument('--index', type=int, choices=(0, 1), default=0)
    args = parser.parse_args()
    prepare() if args.action == 'prepare' else run(args.index)

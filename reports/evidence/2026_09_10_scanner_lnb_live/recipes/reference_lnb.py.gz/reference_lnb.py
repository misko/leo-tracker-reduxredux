"""Bounded desktop fractional-GLRT cross-check of the new, sealed live IQ.

Select the first visit at/after 30 source seconds per target, without scores.
Both saved receivers are checked to expose feed/polarization differences;
the live ARM detector remains RX1-only. Reference support is not satellite truth.
"""
import argparse
from collections import Counter
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from leo.scanner.detector import analyze_glrt64_dwell
from leo.scanner.persistent_hop_analysis import PersistentHopGlrt64Configuration
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.scanner_glrt import ScannerGlrtStore

ROOT = Path(__file__).resolve().parent

def save(path, value):
    payload = json.dumps(value, indent=2, default=lambda v: v.model_dump(mode='json'))
    with path.open('x') as stream:
        stream.write(payload)
        stream.write('\n')

def run(index):
    root = ROOT / f'case-{index}-{(2500000, 5000000)[index]}-adaptive'
    summary = json.loads((root / 'summary.json').read_text())
    output = root / 'desktop-reference-v2'
    output.mkdir()
    store = AdaptiveHopIqStore(root / 'bulk', read_only=True)
    started = time.monotonic()
    try:
        publication = store.inspect(summary['session_id'])
        receipt = publication.manifest.receipt
        rate = receipt.plan.geometry.sample_rate_hz
        first = receipt.terminal.first_counter
        selected = []
        for target in range(8):
            eligible = [e for e in receipt.events[:receipt.complete_visit_count]
                if e.target_index == target and e.valid_start_counter-first >= rate*30]
            if eligible:
                selected.append(eligible[0].visit_index)
        selected.sort()
        save(output / 'selection.json', dict(session_id=publication.session_id,
            input_manifest_sha256=publication.manifest_sha256, visits=selected,
            rule='first visit >=30 source seconds for every available target; no score selection',
            probe_ms=20, stride_ms=20, candidates=8, receiver_ids=[0, 1],
            reference_gate='complete fractional margin >= 0.025',
            time_budget_seconds=240, note='budget checked between visits; one in-flight visit completes'))
        glrt = ScannerGlrtStore.open_read_only(root / 'bulk').read(publication.session_id).evidence
        live = {r.visit: r for r in glrt.results}
        configuration = PersistentHopGlrt64Configuration(receipt.plan.geometry, probe_stride_ms=20)
        rows = []
        with store.reader(publication.session_id, expected=publication) as reader:
            for index in selected:
                if time.monotonic()-started >= 240:
                    break
                visit, ci16 = reader.read_visit_ci16(index)
                values = np.empty(ci16.shape[:2], dtype=np.complex64)
                values.real, values.imag = ci16[:, :, 0], ci16[:, :, 1]
                analysis = analyze_glrt64_dwell(values, configuration, edge=visit.event.target.edge)
                passed = [dict(receiver=p.receiver_id, probe_start_ms=p.probe_start_ms, candidate=asdict(c))
                    for p in analysis.probes for c in p.candidates
                    if c.fractional_epoch_status == 'complete' and c.fractional_margin is not None and c.fractional_margin >= .025]
                row = dict(visit=index, target_index=visit.event.target_index,
                    source_counter=str(visit.event.valid_start_counter), iq_sha256=hashlib.sha256(ci16.tobytes()).hexdigest(),
                    live=live[index].model_dump(mode='json'), reference_support_by_receiver=dict(Counter(p['receiver'] for p in passed)),
                    passed_fractional=passed,
                    rms_counts_by_receiver=[float(np.sqrt(np.mean(np.abs(values[:, rx])**2))) for rx in range(2)],
                    best_fractional_margin_by_receiver={str(rx):max((c.fractional_margin for p in analysis.probes if p.receiver_id == rx for c in p.candidates if c.fractional_epoch_status == 'complete' and c.fractional_margin is not None), default=None) for rx in range(2)})
                save(output / f'visit-{index:04d}.json', dict(summary=row, complete_response=asdict(analysis)))
                rows.append(row)
                print(json.dumps(dict(visit=index, reference_support=row['reference_support_by_receiver'], live=row['live']['verdict'], elapsed_seconds=time.monotonic()-started)), flush=True)
        save(output / 'summary.json', dict(selected_visits=selected, completed_visits=[r['visit'] for r in rows],
            elapsed_seconds=time.monotonic()-started, rows=rows,
            limitations='Small score-blind reference-relative cross-check, not operational sensitivity or satellite ground truth; no CFO/epoch association claim'))
    finally:
        store.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('index', type=int, choices=(0, 1))
    run(parser.parse_args().index)

"""Build the explicit protected replay, pin unchanged worker and saved inputs."""
import json
import sys
from pathlib import Path

from tools.native_presence import ROOT, build_worker
from tools.presence_fftw import fftw_options
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import build

out = Path(__file__).parent
old = Path('/tmp/leo-threaded-arm.XOCIEB2H')
previous = Path('/tmp/leo-integrated-feedback.p7e840')
libiio = Path('/home/mouse9911/gits/libiio-arm-glrt-frame-integration')
compiler = '/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/bin/arm-linux-gnueabihf-gcc'
flags = ('-mcpu=cortex-a9', '-mfpu=neon', '-mfloat-abi=hard')
for label, options in (
    ('desktop', {}),
    ('arm', dict(compiler=compiler, cflags=flags)),
):
    if '--resume' not in sys.argv:
        build(out / label, libiio_source=libiio, **options)
    else:
        for name in ('sdk-replay', 'libleo-scanner-glrt.so'):
            path = out / label / name
            r = json.loads(path.with_name(name + '.build.json').read_text())
            assert digest(path) == r['binary_sha256']
            for p, sha in r['sources_sha256'].items():
                assert digest(ROOT / p) == sha, p
payload = json.loads((old / 'assets/payload.json').read_text())
numerical = tuple(json.loads((old / 'assets/freeze.json').read_text())['numerical_flags'])
fftw = fftw_options(Path('/home/mouse9911/gits/plutosdr-fw/buildroot/output/host/arm-buildroot-linux-gnueabihf/sysroot/usr'), runtime_rpath=False)
worker = build_worker(out / 'worker', compiler=compiler, cflags=numerical + flags + fftw['cflags'],
                      ldflags=fftw['ldflags'], dependencies=fftw['dependencies'])
worker.chmod(0o700)
payload['worker'] = dict(path=str(worker), sha256=digest(worker))
receipt = json.loads(worker.with_name('worker.build.json').read_text())
assert digest(worker) == receipt['binary_sha256']
for p, sha in receipt['sources_sha256'].items():
    assert digest(ROOT / p) == sha, p
for name in ('sdk-replay', 'libleo-scanner-glrt.so'):
    path = out / 'arm' / name
    payload[name] = dict(path=str(path), sha256=digest(path))
for name, row in payload.items():
    assert digest(Path(row['path'])) == row['sha256'], name
write_json(out / 'payload.json', payload)
profile = dict(profile='capture-protection-v1', max_occupied_slots=2, admission_age_ms=250,
               worker_timeout_ms=500, recovery_blocks=4, callback_budget_percent=80)
write_json(out / 'profile.json', profile)
write_json(out / 'freeze.json', dict(
    algorithm_sha256=digest(worker), configuration_sha256=digest(out / 'profile.json'),
    recipe_sha256=digest(Path(__file__)), previous_root=str(previous),
    saved_workload_sha256=digest(previous / 'retained-workload/freeze.json'),
    protected_profile=profile, new_rf=False, full_package=False,
    normal_runs_ms=[4840, 300000], pressure_smoke_ms=4840,
    rates_hz=[2500000, 5000000], delay_blocks=2, jitter_ms=40))
print('Built desktop/ARM protected SDK+queue+scheduler replay; exact saved inputs pinned', flush=True)

"""Reverify protected ARM receipts, preserve evidence and plot measured timing."""
import gzip
import json
from pathlib import Path
import subprocess

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from leo.contracts.scanner_glrt_frame import decode_frame
from tools.native_presence import ROOT
from tools.qualify_native_presence import digest, write_json
from tools.qualify_scanner_glrt_sdk import BASE
from tools.qualify_scanner_glrt_shadow import verify

source = Path(__file__).parent
out = ROOT / 'reports/evidence/2026_09_09_scanner_protected_arm'
figures = ROOT / 'reports/figures/2026_09_09_scanner_protected_arm'
assert not out.exists() and not figures.exists()
assert json.loads((source / 'runs/end.json').read_text()) == dict(
    remote_scratch_retained=None, cleanup_errors=[], recipe_unchanged=True)
summary = json.loads((source / 'runs/summary.json').read_text())
assert summary['system_libraries_unchanged'] and summary['inputs_unchanged']
freeze = json.loads((source / 'runs/freeze.json').read_text())
assert digest(source / 'run.py') == freeze['recipe_sha256']
assert digest(source / 'access.py') == freeze['access_sha256']
assert digest(source / 'known_hosts') == freeze['pin_sha256']
payload = json.loads((source / 'payload.json').read_text())
for name, row in payload.items():
    assert digest(Path(row['path'])) == row['sha256'] == freeze['payload_sha256'][name]
for path in [source / 'worker.build.json', *source.glob('*/*.build.json')]:
    receipt = json.loads(path.read_text())
    assert digest(path.with_name(path.name.removesuffix('.build.json'))) == receipt['binary_sha256']
    for field in ('sources_sha256', 'dependencies_sha256'):
        for name, value in receipt.get(field, {}).items():
            assert digest(ROOT / name) == value, name

previous = Path(json.loads((source / 'freeze.json').read_text())['previous_root'])
derived, runs = [], []
for i, (rate, duration, injected) in enumerate(freeze['order']):
    raw = source / f'runs/{i}-{rate}-{duration}-{int(injected)}.jsonl'
    manifest = json.loads((previous / f'retained-workload/{rate}.manifest.json').read_text())
    checked = verify(raw.read_text(), manifest, duration, jitter_ms=40,
        algorithm_sha256=freeze['algorithm_sha256'], configuration_sha256=freeze['configuration_sha256'],
        capture_protection=True, pressure_smoke=injected)
    checked['raw_sha256'] = digest(raw)
    assert checked == json.loads(raw.with_suffix('.verification.json').read_text())
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    records = [r for row in rows if row['kind'] == 'frame'
               for r in decode_frame(bytes.fromhex(row['hex'])).results]
    measured = [r for r in records if r.search_window_mask]
    blocks = [r for r in rows if r['kind'] == 'block']
    runs.append((rate, duration, injected, rows, records, blocks))
    derived.append(dict(rate_hz=rate, duration_ms=duration, pressure_smoke=injected,
        setup_ms=rows[0]['setup_ms'], elapsed_ms=rows[-1]['elapsed_ms'],
        worker_wall_mean_ms=float(np.mean([r.wall_ms for r in measured])),
        worker_cpu_mean_ms=float(np.mean([r.cpu_ms for r in measured])),
        worker_wall_over_120ms=sum(r.wall_ms > 120 for r in measured),
        callback_wall_fraction=sum(r['callback_wall_ms'] for r in blocks) / duration,
        unavailable=[dict(sequence=r.sequence, source_s=(r.valid_start-BASE)/rate, reason=r.reason)
                     for r in records if not r.search_window_mask],
        scope='Measured saved-IQ ARM execution; modeled arrivals, not capture duty or independent quality'))

out.mkdir()
figures.mkdir()
fig, axes = plt.subplots(2, 2, figsize=(12, 6), sharex=True, layout='constrained')
for row, rate in enumerate((2500000, 5000000)):
    _, _, _, rows, records, blocks = next(r for r in runs if r[0] == rate and r[1] == 300000)
    measured = [r for r in records if r.search_window_mask]
    axes[row, 0].scatter([(r.valid_end-BASE)/rate for r in measured],
                         [r.wall_ms for r in measured], s=4, alpha=.3, color='#24758e')
    axes[row, 0].axhline(120, color='#a63535', ls='--', lw=1, label='120 ms valid dwell')
    axes[row, 0].axhline(100, color='#777777', ls=':', lw=1, label='100 ms development target')
    axes[row, 0].set_ylim(0, 130)
    axes[row, 0].set_ylabel(f'{rate/1e6:g} MS/s\nWorker wall time (ms)')
    axes[row, 1].plot([(int(b['first'])-BASE)/rate for b in blocks],
                      [b['callback_wall_ms'] for b in blocks], lw=.5, alpha=.7, color='#99561f')
    budget = 131072 * 800 / rate
    axes[row, 1].axhline(budget, color='#a63535', ls='--', lw=1, label='80% block budget')
    axes[row, 1].set_ylim(0, max(45, budget+3))
    axes[row, 1].set_ylabel('SDK callback wall time (ms)')
    for r in records:
        if not r.search_window_mask:
            axes[row, 0].axvline((r.valid_start-BASE)/rate, color='#a63535', alpha=.35, lw=1)
    for ax in axes[row]:
        ax.grid(alpha=.15)
        ax.set_xlim(0, 300)
        ax.legend(fontsize=8, loc='upper right')
for ax in axes[-1]:
    ax.set_xlabel('Modeled device time (s); repeated saved RX1 dwells')
fig.suptitle('Protected ARM replay: 300 seconds at each rate\nRed vertical lines: unavailable checks, not missing IQ; no live IIO/network workload', fontsize=12)
timing = figures / 'protected-timing-300s.png'
fig.savefig(timing, dpi=160)
plt.close(fig)

fig, axes = plt.subplots(2, 1, figsize=(10, 5), sharex=True, layout='constrained')
for ax, rate in zip(axes, (2500000, 5000000), strict=True):
    _, _, _, rows, records, blocks = next(r for r in runs if r[0] == rate and r[2])
    times = [(int(b['first'])-BASE)/rate for b in blocks]
    ax.step(times, [b['protection_stats']['suspended'] for b in blocks], where='post',
            lw=1.5, color='#99561f', label='GLRT admission suspended')
    choices = [r for r in rows if r['kind'] == 'shadow-choice']
    ax.step([r['visit']*.121 for r in choices], [int(r['reason'] == 4) for r in choices],
            where='post', ls='--', color='#24758e', label='Uniform-scanning fallback latched')
    unavailable = [r for r in records if not r.search_window_mask]
    ax.scatter([(r.valid_start-BASE)/rate for r in unavailable], [.5]*len(unavailable),
               marker='x', color='#a63535', label='Unavailable check')
    ax.set_ylabel(f'{rate/1e6:g} MS/s\nState')
    ax.set_ylim(-.1,1.2)
    ax.set_yticks([0,1], ['off','on'])
    ax.grid(alpha=.15)
    ax.legend(loc='upper right', fontsize=8)
axes[-1].set_xlabel('Modeled device time (s); same 20 forced-pressure blocks, different block duration')
fig.suptitle('Forced pressure: GLRT resumes; uniform fallback remains latched\nUnknowns are not negative detections', fontsize=12)
recovery = figures / 'forced-pressure-recovery.png'
fig.savefig(recovery, dpi=160)
plt.close(fig)
write_json(out / 'derived-timing.json', derived)

artifacts = {}
for path in sorted(source.rglob('*')):
    if not path.is_file() or path.suffix not in ('.py', '.json', '.jsonl', '.xml', '.log'):
        continue
    relative = str(path.relative_to(source)) + '.gz'
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    with target.open('xb') as output:
        output.write(gzip.compress(raw, compresslevel=9, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[relative] = dict(sha256=digest(target), original_sha256=digest(path),
        original_bytes=len(raw), source=str(path))
write_json(out / 'index.json', dict(schema='org.leo.research.protected-arm-checkpoint/v1',
    runtime_implementation_commit=subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT,text=True).strip(),
    libiio_commit=subprocess.check_output(['git','rev-parse','HEAD'],
        cwd='/home/mouse9911/gits/libiio-arm-glrt-frame-integration',text=True).strip(),
    serial=freeze['serial'], address=freeze['address'], arm_executed=True,
    new_rf=False, full_package=False, firmware_changed_by_this_test=False,
    firmware_already_present=freeze['firmware_already_present'], usb_currently_visible=False,
    remotely_merged=False, deployed=False, independent_holdout=False, artifacts=artifacts,
    derived_sha256=digest(out / 'derived-timing.json'), figures=[dict(path=str(p.relative_to(ROOT)),
        sha256=digest(p)) for p in (timing, recovery)],
    verifier_sha256={str(p.relative_to(ROOT)):digest(p) for p in
        [ROOT / 'tools/qualify_scanner_glrt_sdk.py', ROOT / 'tools/qualify_scanner_glrt_shadow.py']}))
print(json.dumps(dict(artifacts=len(artifacts), derived=derived), indent=2))

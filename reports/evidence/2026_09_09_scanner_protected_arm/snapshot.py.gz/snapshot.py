"""One read-only snapshot of exact owned replay processes, not other tasks."""
import json
from pathlib import Path
import re
import sys

from access import recorded

root = Path(__file__).parent
label = sys.argv[1]
assert re.fullmatch(r'[a-z0-9-]+', label)
scratch = json.loads((root / 'runs/owned-scratch.json').read_text())['path']
assert re.fullmatch(r'/tmp/leo-protected-bench\.[A-Za-z0-9]{6}', scratch)
out = root / 'snapshots'
out.mkdir(exist_ok=True)
command = f'''for task_pid in $(pidof sdk-replay worker); do
task_exe=$(readlink /proc/$task_pid/exe)
case "$task_exe" in
{scratch}/sdk-replay|{scratch}/worker)
printf '%s\\n' "$task_exe"
cat /proc/$task_pid/status
cat /proc/$task_pid/stat
;;
esac
done
cat /proc/uptime
cat /proc/loadavg
cat /proc/meminfo
'''
recorded(out, label, command)
print('Read-only process snapshot retained: ' + label, flush=True)

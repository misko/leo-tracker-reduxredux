"""Current-boot strict pin, exact spare identity, shared lock; no RF collection."""
import json
import subprocess
import sys
from pathlib import Path

sys.path[:0] = ['/tmp/leo-presence-symbol-support.b0iza3SZ', '/tmp/leo-presence-holdout.8JIL7Y']
import lan_access
from arm_access import SERIAL, recorded, system_hashes
from pluto_plus.inventory import scan_local_usb_plutos
from pluto_plus.radio_lock import acquire_radio_lock
from tools.qualify_native_presence import digest, write_json

ROOT = Path(__file__).parent
lan_access.OPTIONS = [v.replace('/tmp/leo-presence-holdout.8JIL7Y/known_hosts', str(ROOT / 'known_hosts'))
                      for v in lan_access.OPTIONS]
call, transfer = lan_access.call, lan_access.transfer

def idle(out, label):
    devices = [d for d in scan_local_usb_plutos() if d.serial == SERIAL]
    assert len(devices) <= 1
    if devices:
        assert devices[0].usb_path == '/sys/bus/usb/devices/5-1'
    write_json(out / f'{label}-usb.json', [d.model_dump(mode='json') for d in devices])
    # CPU-only RAM replay does not require a USB recovery path. Never weaken
    # the target identity: retain the successful physical-recovery mapping and
    # check exact current-boot serial/MAC/LAN/firmware below before every run.
    historical = Path('/home/mouse9911/gits/plutosdr-fw-glrt-deployment-review/artifacts/device-tool-glrt-ethernet/artifacts/ethernet-canary-14/rate60000000-forward-receipts/47fe3240-503b-4d6a-b2ad-e973104ab29c.json')
    receipt = json.loads(historical.read_text())
    assert receipt['outcome'] == 'success' and receipt['returned_serial'] == SERIAL
    assert receipt['local_usb_recovery']['serial'] == SERIAL
    assert receipt['local_usb_recovery']['usb_sysfs_path'] == '/sys/bus/usb/devices/5-1'
    write_json(out / f'{label}-identity-basis.json', dict(usb_currently_visible=bool(devices),
        historical_receipt_sha256=digest(historical), historical_receipt=str(historical),
        operation='RAM-only CPU replay; no RF, hardware control or recovery needed'))
    assert recorded(out, label+'-serial', 'cat /sys/kernel/config/usb_gadget/*/strings/0x409/serialnumber').strip() == SERIAL
    assert 'device-fw glrt-eth-r60000000-v1' in recorded(out, label+'-versions', 'cat /opt/VERSIONS')
    assert recorded(out, label+'-boot', 'cat /proc/sys/kernel/random/boot_id').strip() == '2489580f-1edf-44be-8211-0af35892541f'
    assert recorded(out, label+'-mac', 'cat /sys/class/net/eth0/address').strip() == '00:0a:35:00:01:22'
    assert '192.168.1.14/' in recorded(out, label+'-eth0', 'ip -4 addr show dev eth0')
    assert recorded(out, label+'-buffers', 'cat /sys/bus/iio/devices/iio:device*/buffer/enable').split() == ['0', '0']
    network = recorded(out, label+'-network', 'netstat -nt')
    assert all(':22 ' in line and '192.168.1.142:' in line for line in network.splitlines()
               if line.startswith('tcp'))
    processes = recorded(out, label+'-processes', 'ps')
    assert not any('/tmp/' in line and any(name in line for name in
                   ('sdk-replay', '/worker', 'ppu-iiod-', '/parent')) for line in processes.splitlines())
    return recorded(out, label+'-resources', 'cat /proc/loadavg\ncat /proc/meminfo\ndf -Pk /tmp')

if __name__ == '__main__':
    out = ROOT / 'preflight'
    out.mkdir(exist_ok=False)
    write_json(out / 'key-acceptance.json', dict(
        authorization='User: ssh key changes on each reboot, its fine',
        scope='Exact spare serial and physical LAN .14 only; strict current-boot pin',
        known_hosts_sha256=digest(ROOT / 'known_hosts'),
        fingerprint=subprocess.check_output(['ssh-keygen', '-lf', str(ROOT / 'known_hosts')], text=True)))
    with acquire_radio_lock(SERIAL):
        idle(out, 'identity')
        system_hashes(out, 'system')
    print(json.dumps(dict(serial=SERIAL, address='192.168.1.14', idle=True, new_rf=False)))

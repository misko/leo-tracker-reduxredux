"""One authorized 300s recovery of the still-valid, never-recorded 16:20 slot."""
from datetime import UTC, datetime
import json
from pathlib import Path
import signal
from threading import Event, Timer
from leo.cli import CliSettings, configured_backend_factory
from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.persistent_hop import PersistentHopIqStore

root = Path(__file__).resolve().parent
settings = CliSettings.from_environ()
assert tuple(r.radio_id for r in settings.radios) == ('radio_pluto_19f2',)
backend = configured_backend_factory(settings)()
intent = backend.scheduled_scanner_intent(operation_key='scheduled-scanner:20260910T162000Z',
    scheduled_for=datetime(2026, 9, 10, 16, 20, tzinfo=UTC))
assert 0 <= (datetime.now(UTC) - intent.scheduled_for).total_seconds() < intent.maximum_lateness_seconds
assert intent.configuration.sample_rate_hz == 5000000 and intent.run_duration_seconds == 300
session = 'scan-hop-' + intent.intent_digest.removeprefix('sha256:')[:16]
fixed = PersistentHopIqStore.open_read_only(settings.bulk_root)
adaptive = AdaptiveHopIqStore(settings.bulk_root, read_only=True)
try:
    assert not fixed.contains_session(session) and not adaptive.contains_session(session)
finally:
    adaptive.close()
cancel = Event()
signal.signal(signal.SIGTERM, lambda *_: cancel.set())
timer = Timer(390, cancel.set)
timer.start()
print(json.dumps(dict(event='authorized_single_recovery', utc=datetime.now(UTC).isoformat(),
    session_id=session, intent=intent.model_dump(mode='json'))), flush=True)
try:
    captured = backend.capture_scheduled_scanner(intent, cancel=cancel)
    receipt = captured.published.manifest.receipt
    with (root / 'recovered-1620-receipt.json').open('x') as stream:
        stream.write(receipt.model_dump_json(indent=2))
    print(json.dumps(dict(event='recovery_terminal', session_id=session,
        outcome=receipt.capture_outcome, duty_ppm=receipt.valid_duty_ppm,
        restoration=receipt.restoration.status)), flush=True)
    assert receipt.capture_outcome == 'complete' and receipt.restoration.status == 'restored'
finally:
    timer.cancel()

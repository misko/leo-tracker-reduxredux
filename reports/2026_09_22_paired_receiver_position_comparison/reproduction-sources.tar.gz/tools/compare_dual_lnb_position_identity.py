#!/usr/bin/env python3
"""Matched position sensitivity to an unqualified paired-identity relabeling."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import numpy as np
from benchmark_dual_lnb_fusion import _exact_verification
from research_dual_lnb_full_corpus import load_prepared, propagate

from leo.analysis.research.formal_orbit import FormalOrbitConfig, FormalOrbitData, fit_formal_orbit
from leo.analysis.research.regional_doppler import Region
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.propagation import parse_element_sets

SCHEMA = "org.leo.research.dual-lnb-position-identity-comparison/v1"
SITE = (37.84903264307456, -122.4856541910174)


def relabeled_age_h(baseline_age_h: np.ndarray, old_epoch_ns: int, new_epoch_ns: int) -> np.ndarray:
    """Keep the original capture-time basis while changing element epoch."""
    return np.asarray(baseline_age_h) + (old_epoch_ns - new_epoch_ns) / 3.6e12


def resolve_updates(
    selection: dict[str, Any], identity: dict[str, Any]
) -> tuple[dict[tuple[str, str], int], dict[str, Any]]:
    """Accept only unanimous scored claims for an exactly selected track."""
    tracks = {
        (str(row["session_id"]), str(row["tracklet_id"])): row
        for row in selection["audit"]["tracks"]
    }
    claims: dict[tuple[str, str], list[int]] = {}
    for pair in identity["results"]:
        if pair.get("joint_state") != "scored":
            continue
        leader = int(pair["joint_best_number"])
        for side in ("rx0_tracklet_id", "rx1_tracklet_id"):
            key = (str(pair["session_id"]), str(pair[side]))
            claims.setdefault(key, []).append(leader)
    covered = {key: values for key, values in claims.items() if key in tracks}
    conflicts = {
        key: sorted(set(values)) for key, values in covered.items() if len(set(values)) != 1
    }
    updates = {
        key: values[0]
        for key, values in covered.items()
        if key not in conflicts and values[0] != int(tracks[key]["number"])
    }
    audit = {
        "selected_tracks": len(tracks),
        "covered_tracks": len(covered),
        "unanimous_unchanged_tracks": len(covered) - len(conflicts) - len(updates),
        "conflicting_tracks_abstained": len(conflicts),
        "changed_tracks": len(updates),
        "changed_observations": sum(int(tracks[key]["observations"]) for key in updates),
        "covered_observations_excluding_conflicts": sum(
            int(tracks[key]["observations"]) for key in covered if key not in conflicts
        ),
        "conflicts": [
            {"session_id": key[0], "tracklet_id": key[1], "leaders": values}
            for key, values in sorted(conflicts.items())
        ],
        "updates": [
            {
                "session_id": key[0],
                "tracklet_id": key[1],
                "old_number": int(tracks[key]["number"]),
                "new_number": number,
                "observations": int(tracks[key]["observations"]),
            }
            for key, number in sorted(updates.items())
        ],
    }
    return updates, audit


def _outer_states(data, tracks, archive, references, cache):
    values = {
        name: np.empty_like(data.p_km)
        for name in (
            "phase_p_minus2_km",
            "phase_v_minus2_km_s",
            "phase_p_plus2_km",
            "phase_v_plus2_km_s",
        )
    }
    snapshots = np.empty(len(data.y_hz), dtype=object)
    for track in tracks:
        rows = np.arange(int(track["row_start"]), int(track["row_stop"]))
        digest = str(track["snapshot_digest"])
        snapshots[rows] = digest
        if digest not in cache:
            cache[digest] = parse_element_sets(archive.read(references[digest]))
        catalogue = cache[digest]
        index = list(catalogue.satellite_numbers).index(int(track["number"]))
        utc = np.rint(data.time_s[rows] * 1e9).astype(np.int64)
        for shift, label in ((-2, "minus2"), (2, "plus2")):
            p, v = propagate(catalogue, index, utc + shift * 1_000_000_000)
            values[f"phase_p_{label}_km"][rows] = p
            values[f"phase_v_{label}_km_s"][rows] = v
    return replace(data, **values), snapshots


def prepare(data, selection, identity, archive_root):
    updates, audit = resolve_updates(selection, identity)
    tracks = selection["audit"]["tracks"]
    archive = TleArchiveReader(archive_root)
    references = {item.digest: item for item in archive.list_snapshots()}
    cache: dict[str, Any] = {}
    baseline, snapshots = _outer_states(data, tracks, archive, references, cache)
    joint = replace(
        baseline,
        **{
            name: None
            if getattr(baseline, name) is None
            else np.asarray(getattr(baseline, name)).copy()
            for name in FormalOrbitData.__dataclass_fields__
            if name != "extra_covariance"
        },
    )
    track_lookup = {(str(x["session_id"]), str(x["tracklet_id"])): x for x in tracks}
    for key, number in updates.items():
        track = track_lookup[key]
        rows = np.arange(int(track["row_start"]), int(track["row_stop"]))
        digest = str(track["snapshot_digest"])
        if digest not in cache:
            cache[digest] = parse_element_sets(archive.read(references[digest]))
        catalogue = cache[digest]
        if number not in catalogue.satellite_numbers:
            raise ValueError("paired leader absent from the track's causal snapshot")
        index = list(catalogue.satellite_numbers).index(number)
        new_epoch = int(catalogue.element_epoch_utc_ns()[index])
        old_epoch = int(track["element_epoch_utc_ns"])
        capture_ns = round(old_epoch + float(baseline.age_h[rows[0]]) * 3.6e12)
        if new_epoch >= capture_ns:
            raise ValueError("paired leader element epoch is not causal")
        utc = np.rint(joint.time_s[rows] * 1e9).astype(np.int64)
        states = {
            shift: propagate(catalogue, index, utc + shift * 1_000_000_000)
            for shift in (-2, -1, 0, 1, 2)
        }
        joint.source[rows] = number
        for shift, p_name, v_name in (
            (-2, "phase_p_minus2_km", "phase_v_minus2_km_s"),
            (-1, "phase_p_minus_km", "phase_v_minus_km_s"),
            (0, "p_km", "v_km_s"),
            (1, "phase_p_plus_km", "phase_v_plus_km_s"),
            (2, "phase_p_plus2_km", "phase_v_plus2_km_s"),
        ):
            getattr(joint, p_name)[rows] = states[shift][0]
            getattr(joint, v_name)[rows] = states[shift][1]
        joint.age_h[rows] = relabeled_age_h(baseline.age_h[rows], old_epoch, new_epoch)
    for name in ("y_hz", "training", "segment", "track", "time_s", "observation_id"):
        if not np.array_equal(getattr(baseline, name), getattr(joint, name)):
            raise AssertionError(f"matched measurement contract changed: {name}")
    return baseline, joint, snapshots, audit


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--identity", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--max-nfev", type=int, default=200)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    data, _ = load_prepared(args.prepared)
    selection = json.loads(args.selection.read_text())
    identity = json.loads(args.identity.read_text())
    baseline, joint, snapshots, audit = prepare(data, selection, identity, args.tle_archive)
    region = Region(SITE[0], SITE[1], 200.0, 200.0)
    initial = [20.0, -20.0]
    output = {
        "schema": SCHEMA,
        "scope": (
            "conditional retrospective association stability; not independent position validation"
        ),
        "new_rf_collection": False,
        "identity_labels_fitted_on_overlapping_measurements": True,
        "geometry_evidence_used_for_override": False,
        "conflicting_pair_claim_policy": "abstain and retain baseline identity",
        "same_observations_split_initialization_and_solver": True,
        "region": asdict(region),
        "initial_x_km": initial,
        "max_nfev": args.max_nfev,
        "selection": {
            **audit,
            "observations_per_arm": len(data.y_hz),
            "training_observations": int(np.count_nonzero(data.training)),
            "evaluation_observations": int(np.count_nonzero(~data.training)),
        },
        "fits": {},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    if args.prepare_only:
        return
    config = FormalOrbitConfig(max_nfev=args.max_nfev)
    truth = Region(SITE[0], SITE[1], 1.0, 1.0).points([0.0], [0.0]).ecef_km[0]
    for name, arm in (
        ("baseline-reviewed-identities", baseline),
        ("paired-joint-identities", joint),
    ):
        print(json.dumps({"phase": "fit-start", "model": name}), flush=True)
        result = fit_formal_orbit(arm, region, initial, config)
        estimated = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
        output["fits"][name] = {
            "horizontal_chord_error_m": float(np.linalg.norm(estimated - truth) * 1000),
            "result": asdict(result),
            "exact_phase_verification": _exact_verification(
                arm, snapshots, result, region, args.tle_archive
            ),
        }
        args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
        print(
            json.dumps(
                {
                    "phase": "fit-complete",
                    "model": name,
                    "error_m": output["fits"][name]["horizontal_chord_error_m"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()

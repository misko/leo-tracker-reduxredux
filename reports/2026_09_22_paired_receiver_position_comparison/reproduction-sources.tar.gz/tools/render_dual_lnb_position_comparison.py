#!/usr/bin/env python3
"""Render matched position comparisons from the frozen research receipts."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--identity-result", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    receipt = json.loads(args.identity_result.read_text())
    fits = list(receipt["fits"].values())
    if len(fits) != 2:
        raise ValueError("Both matched identity fits must be complete")
    rows = [
        ("Beam response\n(no advantage over shuffles)", 1059.319, 1054.390),
        ("RX0-reference extension\n(quartic; uncertain position)", 1090.485, 1016.765),
        ("RX1-reference extension\n(quadratic numerical check fails)", 1090.471, 897.853),
        (
            "Unqualified joint-ID substitution\n(sensitivity only)",
            receipt["fits"]["baseline-reviewed-identities"]["horizontal_chord_error_m"],
            receipt["fits"]["paired-joint-identities"]["horizontal_chord_error_m"],
        ),
    ]
    fig, ax = plt.subplots(figsize=(11, 6), layout="constrained")
    for i, (_, before, after) in enumerate(rows):
        ax.plot([before, after], [i, i], color="0.6", linewidth=3)
        ax.scatter(
            before,
            i,
            marker="o",
            s=70,
            color="tab:blue",
            label="Matched baseline" if i == 0 else None,
        )
        ax.scatter(
            after,
            i,
            marker="D",
            s=55,
            color="tab:orange",
            label="Added information / substitution" if i == 0 else None,
        )
        ax.annotate(
            f"{before:,.1f} → {after:,.1f} m",
            ((before + after) / 2, i),
            xytext=(0, 14),
            textcoords="offset points",
            ha="center",
        )
    ax.set_yticks(range(len(rows)), [row[0] for row in rows])
    ax.invert_yaxis()
    ax.set_ylim(len(rows) - 0.5, -0.6)
    ax.set_xlim(0, max(max(row[1:]) for row in rows) * 1.2)
    ax.axvline(1000, linestyle="--", color="0.4", alpha=0.6)
    ax.set_xlabel("Horizontal error relative to supplied site (m; linear scale)")
    ax.set_title(
        "Dual-receiver positioning: compare within each matched experiment\n"
        "Site-conditioned research; point error is not calibrated confidence"
    )
    ax.grid(axis="x", alpha=0.2)
    ax.legend(loc="lower left", fontsize=9)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()

import numpy as np
from compare_dual_lnb_position_identity import relabeled_age_h, resolve_updates


def test_resolve_updates_abstains_on_conflicts_and_keeps_unanimous_changes():
    selection = {
        "audit": {
            "tracks": [
                {"session_id": "s", "tracklet_id": "a", "number": 1, "observations": 4},
                {"session_id": "s", "tracklet_id": "b", "number": 2, "observations": 5},
            ]
        }
    }
    identity = {
        "results": [
            {
                "joint_state": "scored",
                "session_id": "s",
                "rx0_tracklet_id": "a",
                "rx1_tracklet_id": "x",
                "joint_best_number": 3,
            },
            {
                "joint_state": "scored",
                "session_id": "s",
                "rx0_tracklet_id": "a",
                "rx1_tracklet_id": "y",
                "joint_best_number": 4,
            },
            {
                "joint_state": "scored",
                "session_id": "s",
                "rx0_tracklet_id": "b",
                "rx1_tracklet_id": "z",
                "joint_best_number": 3,
            },
        ]
    }
    updates, audit = resolve_updates(selection, identity)
    assert updates == {("s", "b"): 3}
    assert audit["conflicting_tracks_abstained"] == 1
    assert audit["changed_observations"] == 5


def test_relabeled_age_preserves_original_capture_time_basis():
    old_epoch = 1_000_000_000
    new_epoch = 4_600_000_000
    baseline = np.asarray([2.0, 2.0])
    changed = relabeled_age_h(baseline, old_epoch, new_epoch)
    assert np.array_equal(changed, np.asarray([1.999, 1.999]))
    assert np.array_equal(
        old_epoch + baseline * 3.6e12,
        new_epoch + changed * 3.6e12,
    )

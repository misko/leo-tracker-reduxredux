"""Add a frozen folded-Doppler release to the still-blind synthetic packets."""

import argparse
import gzip
import json
import subprocess
import sys
from pathlib import Path
from time import perf_counter

from ..__main__ import encoded, save_json, write
from ..scoring import ARMS, distance_km, distribution, thresholds, validate_result
from ..variants import folded_doppler
from . import cold_scenes as base

METHOD = "folded_doppler"
TITLES = {
    "point_votes": "Point-pair votes",
    "rate_triplets": "Rate triplets",
    METHOD: "Folded Doppler",
}


def _digest(path):
    return base._sha(path.read_bytes())


def _check(root):
    base._check_lock(root)
    source = base._read(root / "folded-source-lock.json")
    if (
        source["input_lock_sha256"] != _digest(root / "input-lock.json")
        or source["protocol_sha256"] != _digest(base.PROTOCOL.with_name("FOLDED_ADDENDUM.md"))
        or source["mode"] != "global"
        or set(source["files"])
        != {f"tools/pipeline_eval/variants/{METHOD}{ext}" for ext in (".py", ".c")}
        or any(_digest(base.REPO / name) != digest for name, digest in source["files"].items())
    ):
        raise ValueError("folded Doppler inputs or programs differ from the addendum seal")


def _worker(public, case, output):
    capture = base._capture(public, case)
    started = perf_counter()
    result = folded_doppler.solve(capture, tile=None)
    elapsed = perf_counter() - started
    validate_result(result)
    save_json(output, dict(id=case, method=METHOD, wall_s=elapsed, result=result))


def predict(root):
    _check(root)
    folder = root / "folded-work"
    folder.mkdir()
    script = Path(__file__).resolve()
    runner_sha256 = _digest(script)
    public = root / "public"
    roster = base._read(public / "manifest.json")["order"]
    cases = []
    for case in roster:
        target = folder / f"{case}.json"
        started = perf_counter()
        command = [
            sys.executable,
            "-m",
            "tools.pipeline_eval.qualification.cold_scenes_folded",
            "worker",
            str(public),
            case,
            str(target),
        ]
        try:
            subprocess.run(command, check=True, timeout=150)
            cases.append(base._read(target))
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as error:
            status = "timed_out" if isinstance(error, subprocess.TimeoutExpired) else "failed"
            cases.append(
                dict(
                    id=case,
                    method=METHOD,
                    wall_s=perf_counter() - started,
                    result=dict(
                        status=status,
                        reason=f"folded Doppler worker {status}",
                        metrics={},
                        boundary=folded_doppler.BOUNDARY,
                    ),
                )
            )
    _check(root)
    if runner_sha256 != _digest(script):
        raise ValueError("folded Doppler runner changed during inference")
    predictions = gzip.compress(b"".join(encoded(r) + b"\n" for r in cases), mtime=0)
    base._new(root / "folded-predictions.jsonl.gz", predictions)
    base._new(
        root / "folded-prediction-lock.json",
        encoded(
            dict(
                mode="global",
                cases=roster,
                per_case_timeout_s=150,
                source_lock_sha256=_digest(root / "folded-source-lock.json"),
                runner_sha256=runner_sha256,
                predictions_sha256=base._sha(predictions),
            )
        )
        + b"\n",
    )


def _rows(predictions, truth):
    for record in predictions:
        target = truth[record["id"]]["latlon"]
        endpoint = record["result"]
        for arm in ARMS:
            estimate = endpoint.get("arms", {}).get(arm, {})
            yield dict(
                id=record["id"],
                method=METHOD,
                arm=arm,
                control=target is None,
                wall_s=record["wall_s"],
                status=endpoint["status"],
                reason=endpoint.get("reason"),
                latitude_deg=target[0] if target else None,
                longitude_deg=target[1] if target else None,
                published=estimate.get("latlon") is not None,
                error_km=distance_km(estimate.get("latlon"), target),
                forced_error_km=distance_km(estimate.get("forced_latlon"), target),
                rf_rms_hz=estimate.get("rf_rms_hz"),
            )


def score(root, output):
    _check(root)
    seal = base._read(root / "folded-prediction-lock.json")
    raw = (root / "folded-predictions.jsonl.gz").read_bytes()
    if (
        seal["source_lock_sha256"] != _digest(root / "folded-source-lock.json")
        or seal["predictions_sha256"] != base._sha(raw)
        or seal["runner_sha256"] != _digest(Path(__file__).resolve())
        or seal["cases"] != base._read(root / "prediction-lock.json")["cases"]
    ):
        raise ValueError("predictions or matched roster differ from the folded Doppler seal")
    predictions = list(map(json.loads, gzip.decompress(raw).splitlines()))
    if [r["id"] for r in predictions] != seal["cases"]:
        raise ValueError("folded predictions do not cover the matched case roster")
    # Unseal the labels only after verifying both releases' prospective locks.
    base.score(root, output)
    report = base._read(output / "scores.json")
    rows = list(_rows(predictions, report["generated_truth"]))
    report["cases"].extend(rows)
    for arm in ARMS:
        positive = [r for r in rows if r["arm"] == arm and not r["control"]]
        negative = [r for r in rows if r["arm"] == arm and r["control"]]
        errors = [r["error_km"] for r in positive]
        report["groups"].append(
            dict(
                method=METHOD,
                arm=arm,
                positive_attempts=len(positive),
                positive_fixes=sum(r["published"] for r in positive),
                error_km=distribution(errors),
                within_km=thresholds(errors),
                negative_attempts=len(negative),
                false_fixes=sum(r["published"] for r in negative),
                forced_error_km=distribution(r["forced_error_km"] for r in positive),
            )
        )
    for file in (
        "folded-source-lock.json",
        "folded-prediction-lock.json",
        "folded-predictions.jsonl.gz",
    ):
        write(output / file, (root / file).read_bytes())
    save_json(output / "scores-all.json", report)


def figure(scores, output):
    import matplotlib.pyplot as plt

    evidence = base._read(scores)
    order = sorted(
        evidence["generated_truth"],
        key=lambda key: (
            evidence["generated_truth"][key]["latlon"] is None,
            evidence["generated_truth"][key]["case_index"],
        ),
    )
    fig, panels = plt.subplots(1, 3, figsize=(13, 4.6), sharey=True)
    for ax, (method, name) in zip(panels, TITLES.items(), strict=True):
        groups = [r for r in evidence["groups"] if r["method"] == method]
        summaries = [f"{r['positive_fixes']}/{r['positive_attempts']}" for r in groups]
        ax.set_title(f"{name}\n{summaries[0]} zero · {summaries[1]} fitted published")
        for row in (r for r in evidence["cases"] if r["method"] == method):
            index = order.index(row["id"])
            zero = row["arm"] == "c0"
            x, color = (index - 0.12, "#146c73") if zero else (index + 0.12, "#87543f")
            error = row["error_km"]
            if error is not None:
                ax.scatter(x, max(0.005, error), s=32, color=color)
            elif row["published"]:
                ax.scatter(x, 0.005, s=34, color="#ba150f", marker="D")
            else:
                ax.scatter(x, 0.004, color=color, marker="x")
            forced = row["forced_error_km"]
            if error is None and forced is not None:
                ax.scatter(x, max(0.005, forced), s=32, edgecolors=color, facecolors="none")
        ax.axhline(5, color="#9eaab0", linestyle="--")
        ax.set_yscale("log")
        ax.set_ylim(0.003, 22000)
        ax.set_yticks(
            [0.004, 0.01, 0.1, 1, 5, 100, 1000, 10000],
            ["No fix", "0.01", "0.1", "1", "5", "100", "1,000", "10,000"],
        )
        ax.set_xticks(range(len(order)), ["Europe", "Australia", "Mexico", "S. Africa", "Shuffle"])
        ax.spines[["top", "right"]].set_visible(False)
    panels[0].set_ylabel("Horizontal error (km)")
    fig.suptitle("Cold-start GLRT candidate control · global search")
    fig.supxlabel(
        "Teal zero calibration · Brown fitted calibration · Open circle withheld best guess"
    )
    fig.tight_layout()
    fig.savefig(output, dpi=170)
    fig.savefig(output.with_suffix(".pdf"))
    plt.close(fig)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    parsers = cli.add_subparsers(dest="command", required=True)
    for name in ("predict", "score", "figure", "worker"):
        parser = parsers.add_parser(name)
        parser.add_argument("path", type=Path)
        if name == "worker":
            parser.add_argument("case")
        if name != "predict":
            parser.add_argument("output", type=Path)
    args = cli.parse_args()
    if args.command == "predict":
        predict(args.path)
    elif args.command == "worker":
        _worker(args.path, args.case, args.output)
    else:
        {"score": score, "figure": figure}[args.command](args.path, args.output)


if __name__ == "__main__":
    main()

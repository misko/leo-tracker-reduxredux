"""Resume only the failed bank and its dependent DBG01 stages."""
from pathlib import Path
import os
import signal
import subprocess
import sys
import time

import run_ds23_dbg01_iteration_010 as runner
from run_algo01_ds23_sample import ROOT,read,write,sha

out=runner.RAW
source=ROOT/'tools/repair_ds23_iteration010_bank.py'
old=read(out/'batch_execution.json')
assert old['all_terminal'] and old['stages'][-1]['stage']=='dbg_bank' and not old['all_passed']
receipt=out/'batch_resume_execution.json'
if receipt.exists():raise FileExistsError('preserve resumed execution')
record=dict(cases=old['cases'],original_batch_sha256=sha(out/'batch_execution.json'),
    repair_source_sha256=sha(source),original_failed_stage_preserved=True,
    earlier_nominations_positions_support_and_cold_discoveries_not_rerun=True,
    stages=[],all_terminal=False,running_stage=None)
for stage in ['dbg_bank','dbg_analysis','independent_audit','restart_selection']:
    record['running_stage']=stage;write(receipt,record);start=time.monotonic()
    with (out/(stage+'_resume.log')).open('w') as stream:
        child=subprocess.Popen([sys.executable,'-B',str(source),'--stage',stage],cwd=ROOT,
            stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=child.wait(timeout=900)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            code=124
    passed=code==0 and runner.stage_passed(stage,out,old['cases'])
    record['stages'].append(dict(stage=stage,returncode=code,scientific_passed=passed,seconds=time.monotonic()-start))
    print(stage,'complete' if passed else 'FAILED',flush=True)
    if not passed:break
record.update(all_terminal=True,running_stage=None,all_passed=len(record['stages'])==4 and all(r['scientific_passed'] for r in record['stages']))
write(receipt,record)
if not record['all_passed']:raise SystemExit(1)

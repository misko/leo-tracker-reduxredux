import pytest

from leo.analysis.research.dual_lnb_fusion import FusionObservation
from tools import benchmark_dual_lnb_native_reference as tool


def observation(candidate_id):
    return FusionObservation(
        "session",
        "rx1",
        1,
        60000,
        1,
        "lower",
        1.0,
        2.0,
        3.0,
        f"session:rx1:{candidate_id}",
        "branch",
        "sha256:source",
    )


def test_candidate_rows_exclude_anchor_measurements_by_digest():
    rows = [observation("sha256:keep"), observation("sha256:anchor")]

    selected = tool._candidate_rows(rows, {"sha256:anchor"})

    assert [row.observation_id for row in selected] == ["session:rx1:sha256:keep"]


def test_native_conversion_preserves_measurement_without_calibration():
    point = observation("sha256:one")
    converted = tool._native_point(point)
    assert converted.source_observation_id == point.observation_id
    assert converted.source_receiver_id == 1
    assert converted.normalized_cfo_hz == point.normalized_cfo_hz
    assert converted.calibration_group_id is None
    assert converted.applied_receiver_offset_hz == 0


def test_snapshot_rows_use_export_audit_and_reject_missing_provenance():
    selection = {
        "audit": {
            "tracks": [
                dict(row_start=0, row_stop=2, snapshot_digest="s1"),
                dict(row_start=2, row_stop=3, snapshot_digest="s2"),
            ]
        }
    }
    assert list(tool._snapshot_rows(selection, 3)) == ["s1", "s1", "s2"]
    with pytest.raises(ValueError, match="cover"):
        tool._snapshot_rows(selection, 4)

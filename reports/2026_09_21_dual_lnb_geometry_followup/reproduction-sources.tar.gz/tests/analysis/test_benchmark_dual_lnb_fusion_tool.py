import numpy as np

from tools import benchmark_dual_lnb_fusion as tool


def test_candidate_digest_parsing_preserves_sha256_prefix():
    observation_id = "session:sha256:track:sha256:candidate"
    assert tool._candidate_id(observation_id) == "sha256:candidate"


def test_covariance_mapping_follows_observation_rows_not_lexical_ids():
    class Block:
        observation_ids = ("b", "a")
        covariance_hz2 = ((4.0, 1.0), (1.0, 9.0))
        calibration_group_id = "calibration"

    mapped = tool.covariance_from_ids(Block(), np.asarray(["a", "baseline", "b"]))

    np.testing.assert_array_equal(mapped.observation_indices, [0, 2])
    np.testing.assert_array_equal(mapped.covariance_hz2, [[9.0, 1.0], [1.0, 4.0]])

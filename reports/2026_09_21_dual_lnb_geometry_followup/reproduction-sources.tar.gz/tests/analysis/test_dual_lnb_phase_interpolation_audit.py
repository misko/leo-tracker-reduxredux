"""Numerical audit interpolation must reproduce polynomial states off-stencil."""

import importlib.util
import sys
from pathlib import Path

import numpy as np


def test_quartic_recovers_off_stencil_state_where_quadratic_fails(monkeypatch):
    tools = Path(__file__).resolve().parents[2] / "tools"
    monkeypatch.syspath_prepend(str(tools))
    spec = importlib.util.spec_from_file_location(
        "phase_audit", tools / "audit_dual_lnb_phase_interpolation.py"
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    at = np.array([-6.8, -0.5, 0.0, 1.0, 4.0])
    coefficients = np.array(
        [
            [100.0, -3.0, 2.0],
            [2.0, 3.0, -1.0],
            [0.2, -0.3, 0.1],
            [0.001, 0.002, -0.003],
            [1e-5, -2e-5, 3e-5],
        ]
    )

    def state(t):
        return sum(
            t[:, None] ** degree * coefficient for degree, coefficient in enumerate(coefficients)
        )

    nodes = [-2, -1, 0, 1, 2]
    result = module.interpolate(nodes, [state(np.full(len(at), t)) for t in nodes], at)
    np.testing.assert_allclose(result, state(at), atol=1e-10, rtol=1e-12)
    quadratic = module.interpolate([-1, 0, 1], [state(np.full(len(at), t)) for t in [-1, 0, 1]], at)
    assert np.max(abs(quadratic - state(at))) > 0.1

"""Receiver association, ambiguous mappings, and opt-in position evidence."""

from dataclasses import replace

import numpy as np
import pytest

from leo.analysis.research.dual_lnb_tracking import (
    ALIAS_HZ,
    DualLnbBeamData,
    EastWestBeamCalibration,
    LnbDetection,
    beam_negative_log_likelihood,
    fit_receiver_offset,
    link_receiver_paths,
    mapping_marginal_log_likelihood,
    match_dual_lnb,
    timing_edges,
)


def synthetic():
    rows = []
    for i in range(80):
        for rx in (0, 1):
            rows.append(
                LnbDetection(
                    i,
                    rx,
                    1,
                    "lower",
                    float(i),
                    -3500 * i + rx * (42000 + 1.5 * i),
                    100 + rx * 0.3,
                    0.4,
                    0,
                )
            )
    return rows


def test_receiver_offset_recovers_on_separate_visits_and_preserves_alias_ambiguity():
    edges = timing_edges(synthetic(), 2.5e6)
    fit = fit_receiver_offset([e for e in edges if e[0].visit % 2 == 0])
    assert fit is not None
    assert fit.predict(0) == pytest.approx(42000)
    assert fit.drift_hz_s == pytest.approx(1.5)
    assert fit.fit_visit_count == 40
    assert len(match_dual_lnb([e for e in edges if e[0].visit % 2], fit)) == 40
    shifted = [replace(d, cfo_hz=d.cfo_hz + ALIAS_HZ) if d.receiver else d for d in synthetic()]
    assert len(match_dual_lnb(timing_edges(shifted, 2.5e6), fit)) == 80


def test_alias_duplicates_cannot_double_support_and_ambiguous_pair_is_rejected():
    rows = synthetic()
    fit = fit_receiver_offset(timing_edges(rows, 2.5e6))
    duplicate = replace(rows[1], rank=1, cfo_hz=rows[1].cfo_hz + ALIAS_HZ, margin=0.3)
    assert len(match_dual_lnb(timing_edges(rows + [duplicate], 2.5e6), fit)) == 80
    # Different timing mode inside the permissive timing gate, close CFO:
    # neither unique assignment is asserted.
    alternative = replace(rows[1], rank=2, cfo_hz=rows[1].cfo_hz + 1200, epoch_samples=100.5)
    assert len(match_dual_lnb(timing_edges(rows + [alternative], 2.5e6), fit, gate_hz=1500)) == 79


def test_timing_and_lane_constraints_prevent_fabricated_simultaneous_pairs():
    rows = synthetic()
    assert not timing_edges(
        [replace(d, epoch_samples=d.epoch_samples + 100) if d.receiver else d for d in rows], 2.5e6
    )
    assert not timing_edges([replace(d, channel=2) if d.receiver else d for d in rows], 2.5e6)
    assert fit_receiver_offset(timing_edges(rows[:4], 2.5e6)) is None


def test_receiver_offset_requires_distinct_visits_after_robust_filtering():
    left, right = synthetic()[:2]
    repeated = [
        (replace(left, rank=rank, time_s=0.0), replace(right, rank=rank, time_s=0.0), 0.0, 0.0)
        for rank in range(100)
    ]
    outlier_visits = [
        (
            replace(left, visit=visit, time_s=0.0),
            replace(right, visit=visit, time_s=0.0),
            1400.0 if visit % 2 else -1400.0,
            0.0,
        )
        for visit in range(1, 12)
    ]
    assert fit_receiver_offset(repeated + outlier_visits, minimum_pairs=12) is None


def test_nonfinite_association_controls_are_rejected():
    edges = timing_edges(synthetic(), 2.5e6)
    with pytest.raises(ValueError):
        timing_edges(synthetic(), np.nan)
    with pytest.raises(ValueError):
        timing_edges(synthetic(), 2.5e6, timing_gate_samples=np.nan)
    with pytest.raises(ValueError):
        fit_receiver_offset(edges, gate_hz=np.nan)
    with pytest.raises(ValueError):
        match_dual_lnb(edges, fit_receiver_offset(edges), gate_hz=np.nan)


def test_path_link_extends_support_but_rejects_parallel_wrong_signal_and_no_overlap():
    rows = synthetic()
    fit = fit_receiver_offset(timing_edges(rows, 2.5e6))
    left = [d for d in rows if d.receiver == 0 and d.visit < 50]
    right = [d for d in rows if d.receiver == 1 and d.visit >= 30]
    linked = link_receiver_paths(left, right, fit, 2.5e6)
    assert linked["state"] == "candidate-link" and linked["anchor_visits"] == 20
    assert linked["extension_s"] == 30
    assert not linked["alias_resolved"] and not linked["identity_claimed"]
    wrong = [replace(d, cfo_hz=d.cfo_hz + 10000) for d in right]
    assert link_receiver_paths(left, wrong, fit, 2.5e6)["state"] == "insufficient"
    assert (
        link_receiver_paths(left, [d for d in right if d.visit > 60], fit, 2.5e6)["state"]
        == "insufficient"
    )


def test_global_mapping_is_not_chosen_per_point():
    calibration = EastWestBeamCalibration(0, 15, 0.5, 90, "test")
    directions = np.array([[0.3, 0, np.sqrt(1 - 0.3**2)], [-0.3, 0, np.sqrt(1 - 0.3**2)]])
    consistent = np.array([4.5, -4.5])
    inconsistent = np.array([4.5, 4.5])
    assert mapping_marginal_log_likelihood(
        directions, consistent, calibration
    ) < mapping_marginal_log_likelihood(directions, inconsistent, calibration)
    assert beam_negative_log_likelihood(
        directions, consistent, calibration, mapping=1
    ) < beam_negative_log_likelihood(directions, consistent, calibration, mapping=-1)
    with pytest.raises(ValueError):
        beam_negative_log_likelihood(directions, consistent, calibration, mapping=0)


def test_duplicate_passes_and_invalid_calibration_are_rejected():
    c = EastWestBeamCalibration(0, 15, 1.3, 90, "test", "glrt_margin_log_ratio")
    with pytest.raises(ValueError, match="independent pass"):
        DualLnbBeamData(np.ones((2, 3)), np.zeros(2), (c, c), ("same", "same"))
    with pytest.raises(ValueError):
        EastWestBeamCalibration(0, 15, 0, 90, "test")


def test_beam_evaluation_rejects_nonfinite_position_and_coordinates():
    calibration = EastWestBeamCalibration(0, 15, 1.3, 90, "test")
    beam = DualLnbBeamData(
        np.array([[7000.0, 0.0, 0.0]]), np.zeros(1), (calibration,), ("pass",)
    )
    with pytest.raises(ValueError):
        beam.negative_log_likelihood(np.array([np.nan, 0.0, 0.0]), 0.0, 0.0)
    with pytest.raises(ValueError):
        beam.negative_log_likelihood(np.array([6378.0, 0.0, 0.0]), np.nan, 0.0)
    with pytest.raises(ValueError):
        beam.negative_log_likelihood(np.array([6378.0, 0.0, 0.0]), 0.0, np.inf)


def test_formal_model_beam_factor_is_opt_in_and_phase_aligns_geometry(monkeypatch):
    from test_formal_orbit import _synthetic

    from leo.analysis.research.formal_orbit import FormalOrbitConfig, fit_formal_orbit

    data, region, _ = _synthetic()
    cfg = FormalOrbitConfig(infer_measurement_sigma=False, measurement_sigma_hz=250, max_nfev=100)
    base = fit_formal_orbit(data, region, [0, 0], cfg)
    explicitly_disabled = fit_formal_orbit(data, region, [0, 0], cfg, beam_data=None)
    assert explicitly_disabled == base
    calibration = EastWestBeamCalibration(0, 15, 1.3, 90, "synthetic-calibration")
    indexes = np.arange(0, len(data.y_hz), 20)
    beam = DualLnbBeamData(
        data.p_km[indexes],
        np.zeros(8),
        (calibration,) * 8,
        tuple(str(i) for i in range(8)),
        doppler_row_indices=indexes,
    )
    evaluated_positions = []
    original = DualLnbBeamData.negative_log_likelihood

    def record_positions(self, *args, satellite_position_ecef_km=None, **kwargs):
        evaluated_positions.append(np.array(satellite_position_ecef_km, copy=True))
        return original(
            self,
            *args,
            satellite_position_ecef_km=satellite_position_ecef_km,
            **kwargs,
        )

    monkeypatch.setattr(DualLnbBeamData, "negative_log_likelihood", record_positions)
    extended = fit_formal_orbit(data, region, [0, 0], cfg, beam_data=beam)
    assert not base.beam_factor_used and extended.beam_factor_used
    assert not base.beam_phase_aligned and extended.beam_phase_aligned
    assert base.negative_log_posterior != extended.negative_log_posterior
    assert np.all(np.isfinite(extended.x_km))
    assert evaluated_positions
    assert any(not np.allclose(p, beam.satellite_position_ecef_km) for p in evaluated_positions)

    heldout_changed = replace(
        data, y_hz=np.where(data.training, data.y_hz, data.y_hz + 1e6)
    )
    changed = fit_formal_orbit(heldout_changed, region, [0, 0], cfg, beam_data=beam)
    assert changed.x_km == pytest.approx(extended.x_km, abs=1e-7)
    assert changed.evaluation_rms_hz != extended.evaluation_rms_hz


def test_formal_beam_row_linkage_rejects_missing_bad_or_mismatched_indices():
    from test_formal_orbit import _synthetic

    from leo.analysis.research.formal_orbit import FormalOrbitConfig, fit_formal_orbit

    data, region, _ = _synthetic()
    cfg = FormalOrbitConfig(infer_measurement_sigma=False, measurement_sigma_hz=250, max_nfev=5)
    calibration = EastWestBeamCalibration(0, 15, 1.3, 90, "synthetic-calibration")

    def beam(positions, indexes=None):
        return DualLnbBeamData(
            positions,
            np.zeros(2),
            (calibration,) * 2,
            ("a", "b"),
            doppler_row_indices=indexes,
        )

    with pytest.raises(ValueError, match="requires Doppler row indices"):
        fit_formal_orbit(data, region, [0, 0], cfg, beam_data=beam(data.p_km[:2]))
    with pytest.raises(ValueError, match="out of bounds"):
        fit_formal_orbit(
            data, region, [0, 0], cfg, beam_data=beam(data.p_km[:2], np.array([0, len(data.y_hz)]))
        )
    with pytest.raises(ValueError, match="must match"):
        fit_formal_orbit(
            data, region, [0, 0], cfg, beam_data=beam(data.p_km[:2] + 1, np.array([0, 1]))
        )
    with pytest.raises(ValueError, match="unique integers"):
        beam(data.p_km[:2], np.array([0, 0]))

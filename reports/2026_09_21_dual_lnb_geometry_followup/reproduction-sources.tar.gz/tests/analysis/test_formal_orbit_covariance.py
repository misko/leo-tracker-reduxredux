"""Integration checks for shared measurement covariance in the orbit fit."""

import numpy as np

from leo.analysis.research.formal_orbit import (
    FormalOrbitConfig,
    FormalOrbitData,
    doppler_hz,
    fit_formal_orbit,
)
from leo.analysis.research.measurement_covariance import TrackMeasurementCovariance
from leo.analysis.research.regional_doppler import Region


def test_gaussian_fit_reports_dense_normalized_covariance_likelihood():
    n = 16
    time = np.arange(n, dtype=float)
    angle = np.linspace(0.2, 2.7, n)
    p = np.column_stack(
        (7000 * np.cos(angle), 7000 * np.sin(angle), 900 + 300 * np.sin(2 * angle))
    )
    v = np.column_stack(
        (-5 * np.sin(angle), 5 * np.cos(angle), 0.5 * np.cos(2 * angle))
    )
    delta_p = np.tile([4.0, -3.0, 2.0], (n, 1))
    delta_v = np.tile([0.02, 0.01, -0.01], (n, 1))
    region = Region(40.0, -75.0, 80, 80)
    receiver = region.points([3.0], [-2.0]).ecef_km[0]
    y = doppler_hz(receiver, p, v) + 120.0 + np.linspace(-8.0, 8.0, n)

    block_rows = np.arange(8, 16)
    jacobian = np.column_stack((np.ones(8), time[block_rows] - np.mean(time[block_rows])))
    shared = jacobian @ np.diag([25.0, 0.25]) @ jacobian.T + np.eye(8) * 16.0
    block = TrackMeasurementCovariance(block_rows, shared, "receiver-offset-a")
    data = FormalOrbitData(
        y_hz=y,
        training=np.ones(n, dtype=bool),
        segment=np.zeros(n, dtype=int),
        track=np.zeros(n, dtype=int),
        source=np.full(n, 60000),
        age_h=np.full(n, 12.0),
        p_km=p,
        v_km_s=v,
        phase_p_minus_km=p - delta_p,
        phase_v_minus_km_s=v - delta_v,
        phase_p_plus_km=p + delta_p,
        phase_v_plus_km_s=v + delta_v,
        time_s=time,
        extra_covariance=(block,),
    )
    sigma = 20.0
    config = FormalOrbitConfig(
        gaussian_noise=True,
        ar1_rho=0,
        infer_measurement_sigma=False,
        measurement_sigma_hz=sigma,
        phase_rate_bound_s_h=0,
    )
    result = fit_formal_orbit(data, region, [0.0, 0.0], config)
    assert result.measurement_covariance_blocks == 1

    fitted_receiver = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
    residual = y - doppler_hz(fitted_receiver, p, v)
    residual -= result.segment_offsets_hz["0"]
    covariance = np.eye(n) * sigma**2
    covariance[np.ix_(block_rows, block_rows)] += shared
    sign, logdet = np.linalg.slogdet(covariance)
    assert sign == 1
    expected = 0.5 * (
        n * np.log(2 * np.pi)
        + logdet
        + residual @ np.linalg.solve(covariance, residual)
    )
    expected += np.log(config.phase_rate_sigma_s_h * np.sqrt(2 * np.pi))
    np.testing.assert_allclose(result.negative_log_posterior, expected, atol=1e-6)

"""Scientific controls for candidate-identity corroboration."""

import numpy as np
import pytest

from tools.research_dual_lnb_identity_controls import (
    analyze,
    doppler_stratum,
    pass_balanced_student_support,
    profile_rms_contrast,
)


def test_pass_support_does_not_treat_duplicated_samples_as_independent_evidence():
    residual = np.array([0.25, -0.5, 1.0])
    once = pass_balanced_student_support(residual, scale_db=1.3)
    duplicated = pass_balanced_student_support(np.repeat(residual, 7), scale_db=1.3)
    assert duplicated == pytest.approx(once)


def test_predeclared_doppler_strata_and_contrast():
    assert doppler_stratum(100, 149) == "weak-less-than-1.5"
    assert doppler_stratum(100, 150) == "intermediate-1.5-to-3"
    assert doppler_stratum(100, 300) == "clear-at-least-3"
    assert profile_rms_contrast(100, 300, floor=100) > 0
    with pytest.raises(ValueError):
        profile_rms_contrast(100, 300, floor=0)


def _source():
    cutoff = 1_000_000_000_000
    calibration = []
    directions = [
        (-0.8, -0.2, 0.56),
        (-0.2, 0.8, 0.56),
        (0.3, -0.7, 0.65),
        (0.8, 0.1, 0.59),
        (0.2, 0.5, 0.84),
        (-0.6, 0.3, 0.74),
    ]
    for group, enu in enumerate(directions):
        for point in range(4):
            calibration.append(
                {
                    "session_id": f"cal-{group}",
                    "number": 100 + group,
                    "channel": 1,
                    "edge": "lower",
                    "utc_ns": cutoff - (group + 1) * 1000 + point,
                    "enu": enu,
                    "proxy_db": 0.7 + 4 * enu[0] - 2 * enu[1] + 0.5 * enu[2] + 0.02 * point,
                }
            )
    pairs = [
        {
            "utc_ns": cutoff + i,
            "proxy_db": value,
            "visit_index": i,
            "rx0_tracklet_id": "ranked-track",
            "rx1_tracklet_id": "other-rx-track",
        }
        for i, value in enumerate([3.5, 3.7, 3.6, 3.8])
    ]
    good_enu = [[0.7, 0.0, 0.714]] * 4
    bad_enu = [[-0.7, 0.0, 0.714]] * 4
    tracks = [
        {
            "session_id": "eval",
            "tracklet_id": "ranked-track",
            "receiver_id": 0,
            "channel": 1,
            "edge": "lower",
            "start_utc_ns": cutoff + 1,
            "pass_key": "eval:1",
            "candidates": [
                {
                    "rank": 1,
                    "number": 1,
                    "training_rms_hz": 80.0,
                    "evaluation_rms_hz": 100.0,
                    "state": "scored",
                    "enu": good_enu,
                },
                {
                    "rank": 2,
                    "number": 2,
                    "training_rms_hz": 250.0,
                    "evaluation_rms_hz": 300.0,
                    "state": "scored",
                    "enu": bad_enu,
                },
            ],
            "pairs": pairs,
        },
        {
            "session_id": "unsupported",
            "tracklet_id": "no-pairs",
            "receiver_id": 1,
            "channel": 1,
            "edge": "lower",
            "start_utc_ns": cutoff - 1,
            "pass_key": "unsupported:1",
            "candidates": [
                {"rank": 1, "number": 3, "evaluation_rms_hz": 110.0, "state": "scored"},
                {"rank": 2, "number": 4, "evaluation_rms_hz": 120.0, "state": "scored"},
            ],
            "pairs": [],
        },
    ]
    return {
        "window_start_utc_ns": cutoff - 10_000,
        "window_end_utc_ns": cutoff + 10_000,
        "tracks": tracks,
        "calibration_points": calibration,
    }, cutoff


def test_analysis_locks_calibration_and_retains_unsupported_tracks():
    source, cutoff = _source()
    source["calibration_points"].append(
        {
            "session_id": "future",
            "number": 999,
            "channel": 1,
            "edge": "lower",
            "utc_ns": cutoff + 1,
            "enu": [0.7, 0.0, 0.714],
            "proxy_db": -1000.0,
        }
    )
    output = analyze(source, cutoff_utc_ns=cutoff, bootstrap_trials=8, null_trials=3)
    assert output["calibration"]["point_count"] == 24
    assert output["counts"]["all_tracks"] == 2
    assert output["counts"]["confirmatory_tracks"] == 1
    assert output["tracks"][0]["beam_category"] == "corroborates-rank-1"
    assert output["tracks"][0]["continuity"]["role"].startswith("provenance-only")
    assert output["tracks"][1]["state"] == "unsupported"
    assert len(output["pass_level_response_mean_nulls"]) == 3


def test_calibration_bootstrap_and_identity_output_are_deterministic():
    source, cutoff = _source()
    first = analyze(source, cutoff_utc_ns=cutoff, bootstrap_trials=5, null_trials=2)
    second = analyze(source, cutoff_utc_ns=cutoff, bootstrap_trials=5, null_trials=2)
    assert first == second
    assert not any("probability" in key for key in first["tracks"][0])


def test_response_mismatch_and_missing_detection_do_not_reject_identity():
    source, cutoff = _source()
    # Reverse candidate directions so the same observed response favors rank 2.
    candidates = source["tracks"][0]["candidates"]
    candidates[0]["enu"], candidates[1]["enu"] = candidates[1]["enu"], candidates[0]["enu"]
    output = analyze(source, cutoff_utc_ns=cutoff, bootstrap_trials=8, null_trials=2)
    mismatch, missing = output["tracks"]
    assert mismatch["beam_category"] == "contradicts-rank-1"
    assert missing["state"] == "unsupported"
    for row in (mismatch, missing):
        assert row["visibility_status"] == "unobstructed-visibility-unknown"
        assert row["identity_evidence_use"] == "descriptive-response-consistency-only"
        assert row["reject_identity_on_response_mismatch"] is False
        assert row["reject_identity_on_missing_detection"] is False

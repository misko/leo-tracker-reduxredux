from dataclasses import replace

import numpy as np
import pytest

from leo.analysis.research.formal_orbit import _ar1_operator
from leo.analysis.research.measurement_covariance import (
    TrackMeasurementCovariance,
    augment_track_whitening,
    validate_track_covariances,
)


def test_shared_covariance_whitens_total_noise_and_logdet():
    track = np.array([0, 0, 0, 1, 1])
    base, logdet = _ar1_operator(track, np.array([0, 1, 3, 0, 2]), 0.6, 1.0)
    a = np.array([[1.0, 0.0], [1.0, 2.0]])
    covariance = a @ np.diag([9.0, 4.0]) @ a.T + np.eye(2) * 5
    block = TrackMeasurementCovariance(np.array([1, 2]), covariance, "calibration-a")
    validate_track_covariances((block,), track, track, track)
    operator, determinant = augment_track_whitening(
        base, logdet, (block,), np.arange(5), track, 2.0
    )
    r = np.linalg.inv(base.toarray().T @ base.toarray())
    total = r.copy()
    total[np.ix_([1, 2], [1, 2])] += covariance / 4
    np.testing.assert_allclose(operator @ total @ operator.T, np.eye(5), atol=1e-12)
    assert determinant == pytest.approx(np.linalg.slogdet(total)[1])
    np.testing.assert_array_equal(operator.toarray()[3:], base.toarray()[3:])
    # Common calibration error survives off-diagonal; diagonal-only treatment
    # is a different and overconfident information model for the shared mean.
    assert total[1, 2] > r[1, 2]


def test_covariance_subsets_to_fitting_observations():
    track = np.array([0, 0, 0])
    rows = np.array([0, 2])
    covariance = np.array([[4.0, 2.0, 1.0], [2.0, 9.0, 3.0], [1.0, 3.0, 16.0]])
    block = TrackMeasurementCovariance(np.arange(3), covariance, "cal")
    base, logdet = _ar1_operator(track[rows], rows.astype(float), 0.4, 1.0)
    op, determinant = augment_track_whitening(base, logdet, (block,), rows, track, 3.0)
    changed = covariance.copy()
    changed[1, 1] += 10000
    op2, determinant2 = augment_track_whitening(
        base, logdet, (replace(block, covariance_hz2=changed),), rows, track, 3.0
    )
    np.testing.assert_array_equal(op.toarray(), op2.toarray())
    assert determinant == determinant2


def test_default_operator_is_exactly_unchanged():
    base, logdet = _ar1_operator(np.zeros(3), np.arange(3), 0.65, 1.0)
    operator, determinant = augment_track_whitening(base, logdet, (), np.arange(3), np.zeros(3), 2)
    assert operator is base
    assert determinant == logdet


def test_invalid_covariance_and_cross_track_dependencies_rejected():
    for indices, covariance in (
        (np.array([1, 0]), np.eye(2)),
        (np.array([0, 0]), np.eye(2)),
        (np.array([0.0, 1.0]), np.eye(2)),
        (np.array([0, 1]), np.array([[1, 2], [2, 1]])),
        (np.array([0, 1]), np.array([[1, 0], [2, 1]])),
        (np.array([0, 1]), np.array([[np.nan, 0], [0, 1]])),
    ):
        with pytest.raises(ValueError):
            TrackMeasurementCovariance(indices, covariance, "cal")
    block = TrackMeasurementCovariance(np.array([0, 1]), np.eye(2), "cal")
    with pytest.raises(ValueError, match="within one track"):
        validate_track_covariances((block,), np.array([0, 1]), np.zeros(2), np.zeros(2))
    with pytest.raises(ValueError, match="out of bounds"):
        validate_track_covariances((block,), np.zeros(1), np.zeros(1), np.zeros(1))
    with pytest.raises(ValueError, match="single track block"):
        validate_track_covariances((block, block), np.zeros(2), np.zeros(2), np.zeros(2))

import numpy as np

from tools import research_dual_lnb_identity_pairs as tool


def test_duplicate_pair_ids_are_excluded_instead_of_arbitrarily_selected():
    records = [
        {"pair_id": "duplicate", "value": 1},
        {"pair_id": "unique", "value": 2},
        {"pair_id": "duplicate", "value": 3},
    ]

    selected, excluded = tool._unique_pair_records(records)

    assert selected == [{"pair_id": "unique", "value": 2}]
    assert excluded == 2


def test_candidate_epoch_must_strictly_precede_capture():
    class Catalogue:
        satellite_numbers = np.asarray([10, 11])

        @staticmethod
        def element_epoch_utc_ns():
            return np.asarray([99, 100])

    catalogue = Catalogue()
    assert tool._candidate_epoch_reason(catalogue, 10, 100) is None
    assert (
        tool._candidate_epoch_reason(catalogue, 11, 100)
        == "candidate-element-epoch-not-before-capture"
    )
    assert (
        tool._candidate_epoch_reason(catalogue, 12, 100)
        == "candidate-absent-from-causal-snapshot"
    )

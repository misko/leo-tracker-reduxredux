"""Anchored extension fusion preserves observations and calibration covariance."""

from dataclasses import replace

import numpy as np

from leo.analysis.research.dual_lnb_fusion import (
    FusionConfig,
    FusionObservation,
    SimultaneousAnchor,
    fuse_anchored_paths,
    fusion_covariance_block,
)


def observation(receiver, time, cfo, *, path=None, branch=None, number=60000, channel=1):
    return FusionObservation(
        "session",
        path or f"rx{receiver}",
        receiver,
        number,
        channel,
        "lower",
        float(time),
        float(cfo),
        20.0,
        f"rx{receiver}-{time}",
        branch or f"branch-rx{receiver}",
        f"sha256:source-rx{receiver}",
    )


def paths_and_anchors(*, validation_error=0.0):
    rx0 = tuple(observation(0, time, -3000 * time) for time in range(11))
    rx1 = tuple(observation(1, time, -3000 * time + 100 + 2 * time) for time in range(15))
    anchors = []
    for index, time in enumerate((0, 2, 4, 6, 8)):
        left = observation(0, time + 0.01, -3000 * time, path="rx0")
        right = observation(
            1,
            time + 0.01,
            -3000 * time + 100 + 2 * time + (validation_error if index >= 3 else 0),
            path="rx1",
        )
        anchors.append(
            SimultaneousAnchor(
                f"anchor-{index}", left, right, "fit" if index < 3 else "validation"
            )
        )
    return rx0, rx1, tuple(anchors)


def test_fusion_adds_only_measured_nonoverlap_and_carries_shared_covariance():
    rx0, rx1, anchors = paths_and_anchors(validation_error=5.0)
    result = fuse_anchored_paths(
        rx0, rx1, anchors, FusionConfig(maximum_extension_gap_s=1.1)
    )
    assert result.state == "fused"
    assert result.rx0_points == 11
    assert result.rx1_extension_points == result.right_extension_points == 4
    assert result.left_extension_points == 0
    assert [point.time_s for point in result.points] == list(range(15))
    assert all(point.source_receiver_id == 0 for point in result.points[:11])
    assert all(point.source_receiver_id == 1 for point in result.points[11:])
    assert [point.source_observation_id for point in result.points[11:]] == [
        "rx1-11",
        "rx1-12",
        "rx1-13",
        "rx1-14",
    ]
    assert result.calibration is not None
    assert result.calibration.validation_rms_hz > 0
    assert len({point.calibration_group_id for point in result.points[11:]}) == 1
    covariance = np.asarray(result.calibration.parameter_covariance)
    jacobian = np.asarray([point.calibration_jacobian for point in result.points[11:]])
    shared = jacobian @ covariance @ jacobian.T
    assert np.any(abs(shared - np.diag(np.diag(shared))) > 0)
    block = fusion_covariance_block(result)
    assert block is not None
    extension_ids = tuple(sorted(point.source_observation_id for point in result.points[11:]))
    assert block.observation_ids == extension_ids
    expected = shared + result.calibration.validation_rms_hz**2 * np.eye(4)
    np.testing.assert_allclose(block.covariance_hz2, expected)
    assert all(point.independent_sigma_hz == 20.0 for point in result.points[11:])
    np.testing.assert_allclose(
        [point.marginal_predictive_sigma_hz**2 for point in result.points[11:]],
        20.0**2 + np.diag(expected),
    )
    assert set(result.calibration.fit_observation_ids).isdisjoint(
        result.calibration.validation_observation_ids
    )
    for point in result.points[11:]:
        np.testing.assert_allclose(
            point.original_normalized_cfo_hz - point.applied_receiver_offset_hz,
            point.normalized_cfo_hz,
        )


def test_fusion_can_use_native_rx1_as_reference_without_changing_offset_sign():
    rx0 = tuple(observation(0, time, -3000 * time) for time in range(-2, 11))
    rx1 = tuple(observation(1, time, -3000 * time + 100 + 2 * time) for time in range(11))
    _, _, anchors = paths_and_anchors(validation_error=5.0)

    result = fuse_anchored_paths(
        rx0,
        rx1,
        anchors,
        FusionConfig(maximum_extension_gap_s=1.1),
        reference_receiver_id=1,
    )

    assert result.state == "fused"
    assert result.reference_receiver_id == 1
    assert result.extension_receiver_id == 0
    assert result.reference_points == 11
    assert result.extension_points == 2
    added = [point for point in result.points if point.source_receiver_id == 0]
    assert [point.time_s for point in added] == [-2, -1]
    assert result.calibration is not None
    np.testing.assert_allclose(
        [point.normalized_cfo_hz for point in added],
        [
            point.original_normalized_cfo_hz
            + result.calibration.predict(point.time_s)
            for point in added
        ],
    )
    assert all(point.applied_receiver_offset_hz < 0 for point in added)
    block = fusion_covariance_block(result)
    assert block is not None
    assert block.observation_ids == ("rx0--1", "rx0--2")


def test_fusion_requires_separate_fit_and_validation_support():
    rx0, rx1, anchors = paths_and_anchors()
    assert fuse_anchored_paths(rx0, rx1, anchors[:3]).reason == "too-few-heldout-anchors"
    roles = tuple(replace(anchor, role="validation") for anchor in anchors)
    assert fuse_anchored_paths(rx0, rx1, roles).reason == "too-few-fit-anchors"


def test_fusion_rejects_alias_identity_lane_and_heldout_conflicts():
    rx0, rx1, anchors = paths_and_anchors()
    conflicting = list(anchors)
    conflicting[0] = replace(
        conflicting[0], rx1=replace(conflicting[0].rx1, alias_branch="different")
    )
    assert fuse_anchored_paths(rx0, rx1, tuple(conflicting)).reason == "anchor-contract-conflict"
    wrong_identity = tuple(replace(x, catalog_number=60001) for x in rx1)
    assert (
        fuse_anchored_paths(rx0, wrong_identity, anchors).reason
        == "different-session-identity-or-lane"
    )
    assert (
        fuse_anchored_paths(rx0, tuple(replace(x, channel=2) for x in rx1), anchors).reason
        == "different-session-identity-or-lane"
    )
    _, _, bad_validation = paths_and_anchors(validation_error=600.0)
    assert (
        fuse_anchored_paths(rx0, rx1, bad_validation).reason
        == "heldout-offset-validation-failed"
    )


def test_fusion_abstains_on_unsupported_gap_without_fabricating_points():
    rx0, rx1, anchors = paths_and_anchors()
    gapped = tuple(item for item in rx1 if item.time_s <= 10 or item.time_s >= 13)
    result = fuse_anchored_paths(
        rx0, gapped, anchors, FusionConfig(maximum_extension_gap_s=1.1)
    )
    assert result.state == "insufficient"
    assert result.reason == "right-gap-unsupported"
    assert result.rx1_extension_points == 0
    assert [point.source_observation_id for point in result.points] == [
        item.observation_id for item in rx0
    ]


def test_fusion_requires_common_epoch_anchor_and_short_drift_span():
    rx0, rx1, anchors = paths_and_anchors()
    late = list(anchors)
    late[0] = replace(late[0], rx1=replace(late[0].rx1, time_s=0.02))
    assert fuse_anchored_paths(rx0, rx1, tuple(late)).reason == "anchor-epochs-differ"
    rounding = list(anchors)
    rounding[0] = replace(
        rounding[0],
        rx1=replace(rounding[0].rx1, time_s=rounding[0].rx0.time_s + 0.5e-6),
    )
    assert fuse_anchored_paths(rx0, rx1, tuple(rounding)).state == "fused"
    config = FusionConfig(minimum_fit_span_s=10.0)
    assert fuse_anchored_paths(rx0, rx1, anchors, config).reason == "fit-anchor-span-too-short"

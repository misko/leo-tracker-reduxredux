"""Local dual-LNB information study with Doppler-only phase-aligned geometry.

This is a sensitivity diagnostic, not a positioning benchmark.  Satellite
identities and the calibration-site coordinate are fixed inputs.  Doppler alone
profiles source phase rates at each trial receiver; beam responses never enter
that profiling.  Temporal beam information is evaluated after free pass/lane
offsets, optionally with a free linear response drift per pass/lane.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

from leo.analysis.research.formal_orbit import doppler_hz
from leo.analysis.research.regional_doppler import Region
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.frames import greenwich_mean_sidereal_time_rad, julian_day_from_utc_ns, teme_to_ecef
from leo.sky.propagation import parse_element_sets

SITE = (37.84903264307456, -122.4856541910174)
PHASE_RATE_SIGMA_S_H = 0.09176615913014215
PHASE_RATE_BOUND_S_H = 0.25
DOPPLER_SIGMA_HZ = 250.0


def quadratic_state(centre, minus, plus, phase_s):
    u = np.asarray(phase_s)[:, None]
    return centre + 0.5 * (plus - minus) * u + 0.5 * (plus + minus - 2 * centre) * u * u


def centre_by_group(value, group):
    value = np.asarray(value, float)
    result = value.copy()
    for label in np.unique(group):
        mask = group == label
        result[mask] -= np.mean(value[mask], axis=0)
    return result


def fit_doppler_rates(receiver, mask, arrays):
    """Linearized ridge profile at a declared receiver; response data are absent."""
    source = arrays["source"]
    segment = arrays["segment"]
    rates = {}
    for label in np.unique(source[mask]):
        rows = mask & (source == label)
        base = doppler_hz(receiver, arrays["p"][rows], arrays["v"][rows])
        minus = doppler_hz(receiver, arrays["pm"][rows], arrays["vm"][rows])
        plus = doppler_hz(receiver, arrays["pp"][rows], arrays["vp"][rows])
        derivative = 0.5 * (plus - minus) * arrays["age_h"][rows]
        target = arrays["doppler_y"][rows] - base
        local_segment = segment[rows]
        derivative = centre_by_group(derivative, local_segment)
        target = centre_by_group(target, local_segment)
        ridge = (DOPPLER_SIGMA_HZ / PHASE_RATE_SIGMA_S_H) ** 2
        rate = float(np.dot(derivative, target) / (np.dot(derivative, derivative) + ridge))
        rates[int(label)] = float(np.clip(rate, -PHASE_RATE_BOUND_S_H, PHASE_RATE_BOUND_S_H))
    return rates


def phase_aligned_directions(region, east_km, north_km, mask, arrays):
    point = region.points([east_km], [north_km])
    receiver = point.ecef_km[0]
    rates = fit_doppler_rates(receiver, mask, arrays)
    indexes = np.flatnonzero(mask)
    phase = np.array([arrays["age_h"][i] * rates[int(arrays["source"][i])] for i in indexes])
    positions = quadratic_state(
        arrays["p"][indexes], arrays["pm"][indexes], arrays["pp"][indexes], phase
    )
    unit = positions - receiver
    unit /= np.linalg.norm(unit, axis=1)[:, None]
    lat, lon = np.deg2rad(region.coordinates(east_km, north_km))
    east = unit @ np.array([-np.sin(lon), np.cos(lon), 0.0])
    north = unit @ np.array(
        [-np.sin(lat) * np.cos(lon), -np.sin(lat) * np.sin(lon), np.cos(lat)]
    )
    up = unit @ np.array([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])
    return indexes, np.column_stack([east, north, up]), rates


def response_cross_validation(response, enu, folds, group):
    centered_y = centre_by_group(response, group)
    centered_enu = centre_by_group(enu[:, :2], group)
    counts = Counter(group)
    weight = np.array([1 / counts[x] for x in group])
    outputs = []
    oof_residual = np.empty(len(response))
    for fold in range(3):
        train, test = folds != fold, folds == fold
        root = np.sqrt(weight[train])
        baseline = float(np.sqrt(np.average(centered_y[test] ** 2, weights=weight[test])))
        fits = {}
        for name, design in (("east", centered_enu[:, :1]), ("east_north", centered_enu)):
            beta = np.linalg.lstsq(
                design[train] * root[:, None], centered_y[train] * root, rcond=None
            )[0]
            residual = centered_y[test] - design[test] @ beta
            fits[name] = dict(
                coefficients=beta.tolist(),
                evaluation_group_balanced_rms_db=float(
                    np.sqrt(np.average(residual**2, weights=weight[test]))
                ),
            )
            if name == "east":
                oof_residual[test] = residual
        outputs.append(dict(fold=fold, baseline_group_balanced_rms_db=baseline, **fits))
    return outputs, oof_residual


def absolute_response_cross_validation(response, enu, folds, source, group, lane):
    lanes = int(np.max(lane)) + 1
    intercept = np.eye(lanes)[lane]
    counts = Counter(group)
    weight = np.array([1 / counts[x] for x in group])
    outputs = []
    for fold in range(3):
        train, test = folds != fold, folds == fold
        for name, design in (
            ("lane-offset-only", intercept),
            ("east-west", np.column_stack([intercept, enu[:, 0]])),
            ("east-north", np.column_stack([intercept, enu[:, :2]])),
        ):
            root = np.sqrt(weight[train])
            beta = np.linalg.lstsq(
                design[train] * root[:, None], response[train] * root, rcond=None
            )[0]
            residual = response[test] - design[test] @ beta
            outputs.append(
                dict(
                    fold=fold,
                    model=name,
                    coefficients=beta.tolist(),
                    evaluation_proxy_rms_db=float(
                        np.sqrt(np.average(residual**2, weights=weight[test]))
                    ),
                    test_points=int(np.sum(test)),
                    test_satellites=len(np.unique(source[test])),
                )
            )
    return outputs


def fit_semivariogram(time_s, residual, group):
    lag, semivariance = [], []
    for label in np.unique(group):
        indexes = np.flatnonzero(group == label)
        for position, left in enumerate(indexes[:-1]):
            right = indexes[position + 1 :]
            lag.extend(abs(time_s[right] - time_s[left]))
            semivariance.extend(0.5 * (residual[right] - residual[left]) ** 2)
    lag = np.asarray(lag)
    semivariance = np.asarray(semivariance)
    edges = np.array([0, 0.35, 0.5, 0.75, 1, 1.5, 2, 3, 5, 8, 12, 20, 30, 50])
    bins = []
    for low, high in zip(edges[:-1], edges[1:], strict=True):
        values = semivariance[(lag > low) & (lag <= high)]
        if len(values) >= 20:
            bins.append((0.5 * (low + high), float(np.mean(values)), len(values)))
    x = np.array([row[0] for row in bins])
    observed = np.array([row[1] for row in bins])
    count = np.array([row[2] for row in bins])

    def error(log_parameters):
        nugget, correlated, tau = np.exp(log_parameters)
        expected = nugget + correlated * (1 - np.exp(-x / tau))
        scale = np.maximum(observed, np.median(observed) / 4)
        return np.sqrt(count / count.max()) * (expected - observed) / scale

    answer = least_squares(error, np.log([0.2**2, 0.8**2, 1.0]), loss="soft_l1")
    nugget, correlated, tau = np.exp(answer.x)
    return dict(
        white_sigma_db=float(np.sqrt(nugget)),
        correlated_sigma_db=float(np.sqrt(correlated)),
        correlation_time_s=float(tau),
        bins=[dict(lag_s=a, semivariance_db2=b, pairs=c) for a, b, c in bins],
    )


def block_inverse(time_s, noise, pass_level_sigma_db=0.0):
    white = noise["white_sigma_db"]
    correlated = noise["correlated_sigma_db"]
    tau = noise["correlation_time_s"]
    distance = abs(time_s[:, None] - time_s[None, :])
    covariance = white**2 * np.eye(len(time_s)) + correlated**2 * np.exp(-distance / tau)
    covariance += pass_level_sigma_db**2 * np.ones_like(covariance)
    return np.linalg.inv(covariance)


def profiled_block_information(design, time_s, noise, *, free_drift):
    inverse = block_inverse(time_s, noise)
    nuisance = np.ones((len(time_s), 1))
    if free_drift:
        nuisance = np.column_stack([nuisance, time_s - np.mean(time_s)])
    normal = nuisance.T @ inverse @ nuisance
    projected = inverse - inverse @ nuisance @ np.linalg.pinv(normal) @ nuisance.T @ inverse
    return design.T @ projected @ design


def marginal_position_information(normal, priors):
    augmented = normal.copy()
    for index, sigma in priors.items():
        if np.isfinite(sigma):
            augmented[index, index] += 1 / sigma**2
    xx = augmented[:2, :2]
    xn = augmented[:2, 2:]
    nn = augmented[2:, 2:]
    return xx - xn @ np.linalg.pinv(nn) @ xn.T


def bounds(information):
    eigenvalues = np.linalg.eigvalsh(information)
    if eigenvalues[0] <= 1e-12:
        return dict(
            eigenvalues_per_km2=eigenvalues.tolist(),
            rank=int(np.linalg.matrix_rank(information)),
        )
    covariance = np.linalg.inv(information)
    return dict(
        rank=int(np.linalg.matrix_rank(information)),
        eigenvalues_per_km2=eigenvalues.tolist(),
        covariance_km2=covariance.tolist(),
        horizontal_rms_m=float(1000 * np.sqrt(np.trace(covariance))),
        major_95_m=float(1000 * np.sqrt(5.991464547 * np.max(np.linalg.eigvalsh(covariance)))),
    )


def representative_indexes(rows, folds, fold):
    test = np.flatnonzero(folds == fold)
    labels = np.array([rows[i]["session_id"] + "/" + rows[i]["tracklet_id"] for i in test])
    _, segment = np.unique(labels, return_inverse=True)
    training = np.zeros(len(test), bool)
    for label in np.unique(segment):
        indexes = np.flatnonzero(segment == label)
        training[indexes] = np.arange(len(indexes)) % 5 != 4
    passes = {}
    for i in test[training]:
        passes.setdefault((rows[i]["session_id"], rows[i]["number"]), []).append(i)
    return np.array(
        [
            sorted(
                indexes,
                key=lambda i: (
                    rows[i]["time_s"],
                    rows[i]["channel"],
                    rows[i]["edge"],
                    rows[i]["tracklet_id"],
                ),
            )[len(indexes) // 2]
            for indexes in passes.values()
        ]
    )


def current_factor_information(rows, fold, folds, q, jacobian, slope, sigma, lane):
    indexes = representative_indexes(rows, folds, fold)
    lanes = int(np.max(lane)) + 1
    design = np.zeros((len(indexes), 4 + lanes))
    design[:, :2] = slope * jacobian[indexes]
    design[:, 2] = q[indexes, 0]
    design[:, 3] = -slope * q[indexes, 1]
    design[np.arange(len(indexes)), 4 + lane[indexes]] = 1
    return design.T @ design / sigma**2, indexes


def temporal_information(mask, group, time_s, q, jacobian, slope, noise, free_drift):
    normal = np.zeros((4, 4))
    for label in np.unique(group[mask]):
        indexes = np.flatnonzero(mask & (group == label))
        if len(indexes) < 2 + int(free_drift):
            continue
        design = np.column_stack(
            [slope * jacobian[indexes], q[indexes, 0], -slope * q[indexes, 1]]
        )
        normal += profiled_block_information(
            design, time_s[indexes], noise, free_drift=free_drift
        )
    return normal


def sensitivity_grid(normal, doppler_information, slope, *, include_lane=False):
    outputs = []
    lane_sigmas = (0.1, 0.25, 0.5, 1.0, np.inf) if include_lane else (np.inf,)
    for lane_sigma in lane_sigmas:
        for slope_fraction in (0.02, 0.05, 0.1, np.inf):
            for heading_deg in (1.0, 3.0, 5.0, 10.0, np.inf):
                priors = {
                    2: abs(slope) * slope_fraction,
                    3: np.deg2rad(heading_deg),
                }
                if include_lane and np.isfinite(lane_sigma):
                    for index in range(4, normal.shape[0]):
                        priors[index] = lane_sigma
                beam = marginal_position_information(normal, priors)
                outputs.append(
                    dict(
                        slope_sigma_fraction=(
                            None if not np.isfinite(slope_fraction) else slope_fraction
                        ),
                        heading_sigma_deg=None if not np.isfinite(heading_deg) else heading_deg,
                        lane_intercept_sigma_db=(
                            None if not np.isfinite(lane_sigma) else lane_sigma
                        ),
                        beam_only=bounds(beam),
                        combined_with_doppler=bounds(beam + doppler_information),
                    )
                )
    return outputs


def absolute_temporal_information(
    mask, group, time_s, q, jacobian, slope, noise, lane, pass_level_sigma_db
):
    lanes = int(np.max(lane)) + 1
    normal = np.zeros((4 + lanes, 4 + lanes))
    for label in np.unique(group[mask]):
        indexes = np.flatnonzero(mask & (group == label))
        design = np.zeros((len(indexes), 4 + lanes))
        design[:, :2] = slope * jacobian[indexes]
        design[:, 2] = q[indexes, 0]
        design[:, 3] = -slope * q[indexes, 1]
        design[np.arange(len(indexes)), 4 + lane[indexes]] = 1
        inverse = block_inverse(time_s[indexes], noise, pass_level_sigma_db)
        normal += design.T @ inverse @ design
    return normal


def required_pass_multiplier(normal, doppler_information, slope, target_major_95_m=1000.0):
    priors = {2: abs(slope) * 0.05, 3: np.deg2rad(3.0)}
    for index in range(4, normal.shape[0]):
        priors[index] = 0.25

    def major(multiplier):
        beam = marginal_position_information(multiplier * normal, priors)
        result = bounds(beam + doppler_information)
        return result.get("major_95_m", np.inf)

    if major(1e6) > target_major_95_m:
        return None
    low, high = 1.0, 1e6
    for _ in range(60):
        middle = np.sqrt(low * high)
        if major(middle) <= target_major_95_m:
            high = middle
        else:
            low = middle
    return float(high)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--position-results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    document = json.loads(args.input.read_text())
    rows = document["geometry_proxy_points"]
    n = len(rows)
    archive = TleArchiveReader(Path("/var/lib/leo/tle"))
    references = {snapshot.digest: snapshot for snapshot in archive.list_snapshots()}
    catalogues = {}
    states = np.empty((3, n, 2, 3))
    age_h = np.empty(n)
    for i, row in enumerate(rows):
        digest = row["catalogue_digest"]
        if digest not in catalogues:
            catalogues[digest] = parse_element_sets(archive.read(references[digest]))
        catalogue = catalogues[digest]
        index = list(catalogue.satellite_numbers).index(row["number"])
        age_h[i] = (row["utc_ns"] - catalogue.element_epoch_utc_ns()[index]) / 3.6e12
        for state_index, offset_s in enumerate((-1, 0, 1)):
            jd, fraction = julian_day_from_utc_ns(row["utc_ns"] + offset_s * 10**9)
            error, p, v = catalogue.satellites[index].sgp4_array(jd, fraction)
            if np.any(error):
                raise ValueError("propagation error")
            p, v = teme_to_ecef(p, v, greenwich_mean_sidereal_time_rad(jd, fraction))
            states[state_index, i] = [p[0], v[0]]

    response = np.array([row["proxy_db"] for row in rows])
    source = np.array([row["number"] for row in rows])
    segment = np.array([row["session_id"] + "/" + row["tracklet_id"] for row in rows])
    group = np.array(
        [
            f"{row['session_id']}/{row['number']}/{row['channel']}/{row['edge']}"
            for row in rows
        ]
    )
    folds = source % 3
    time_s = np.array([row["utc_ns"] / 1e9 for row in rows])
    lanes = sorted({(row["channel"], row["edge"]) for row in rows})
    lane = np.array([lanes.index((row["channel"], row["edge"])) for row in rows])
    arrays = dict(
        p=states[1, :, 0],
        v=states[1, :, 1],
        pm=states[0, :, 0],
        vm=states[0, :, 1],
        pp=states[2, :, 0],
        vp=states[2, :, 1],
        age_h=age_h,
        doppler_y=np.array([row["measured_hz"] for row in rows]),
        source=source,
        segment=segment,
    )
    region = Region(*SITE, 200, 200)
    all_rows = np.ones(n, bool)
    indexes, aligned_enu, rates = phase_aligned_directions(region, 0, 0, all_rows, arrays)
    assert np.array_equal(indexes, np.arange(n))
    cross_validation, oof_residual = response_cross_validation(response, aligned_enu, folds, group)
    absolute_cross_validation = absolute_response_cross_validation(
        response, aligned_enu, folds, source, group, lane
    )
    noise = fit_semivariogram(time_s, oof_residual, group)

    aligned_document = dict(document)
    aligned_document["geometry_proxy_points"] = []
    for row, direction in zip(rows, aligned_enu, strict=True):
        aligned_document["geometry_proxy_points"].append(
            dict(row, nominal_enu=row["enu"], enu=direction.tolist())
        )
    aligned_document["phase_alignment"] = dict(
        method="fixed-known-site linearized ridge Doppler profile; response excluded",
        phase_rate_sigma_s_h=PHASE_RATE_SIGMA_S_H,
        doppler_sigma_hz=DOPPLER_SIGMA_HZ,
        maximum_absolute_rate_s_h=max(abs(value) for value in rates.values()),
        research_only=True,
    )
    aligned_document["beam_proxy_cross_validation"] = absolute_cross_validation
    (args.output / "phase-aligned-geometry.json").write_text(
        json.dumps(aligned_document, indent=2) + "\n"
    )

    position = json.loads(args.position_results.read_text())["trials"]
    fold_results = []
    step_km = 0.01
    for fold in range(3):
        mask = folds == fold
        calibration = cross_validation[fold]["east"]
        slope = float(calibration["coefficients"][0])
        _, centre, _ = phase_aligned_directions(region, 0, 0, mask, arrays)
        _, east_plus, _ = phase_aligned_directions(region, step_km, 0, mask, arrays)
        _, east_minus, _ = phase_aligned_directions(region, -step_km, 0, mask, arrays)
        _, north_plus, _ = phase_aligned_directions(region, 0, step_km, mask, arrays)
        _, north_minus, _ = phase_aligned_directions(region, 0, -step_km, mask, arrays)
        local_jacobian = np.column_stack(
            [
                (east_plus[:, 0] - east_minus[:, 0]) / (2 * step_km),
                (north_plus[:, 0] - north_minus[:, 0]) / (2 * step_km),
            ]
        )
        q = np.zeros((n, 2))
        jacobian = np.zeros((n, 2))
        q[mask] = centre[:, :2]
        jacobian[mask] = local_jacobian
        doppler_trial = next(
            trial
            for trial in position
            if trial["fold"] == fold and trial["model"] == "doppler-only"
        )
        doppler_covariance = np.asarray(doppler_trial["result"]["position_covariance_km2"])
        doppler_information = np.linalg.inv(doppler_covariance)
        temporal = {}
        for free_drift in (False, True):
            key = "free_pass_offset_and_drift" if free_drift else "free_pass_offset"
            normal = temporal_information(
                mask, group, time_s, q, jacobian, slope, noise, free_drift
            )
            fixed = normal[:2, :2]
            nuisance_cross = normal[:2, 2:]
            fixed_combined = fixed + doppler_information
            slope_bias = np.linalg.solve(fixed_combined, nuisance_cross[:, 0] * slope * 0.01)
            heading_bias = np.linalg.solve(
                fixed_combined, nuisance_cross[:, 1] * np.deg2rad(1.0)
            )
            temporal[key] = dict(
                information_matrix=normal.tolist(),
                fixed_calibration_beam_only=bounds(fixed),
                fixed_calibration_combined=bounds(fixed_combined),
                combined_bias_per_one_percent_slope_m=float(1000 * np.linalg.norm(slope_bias)),
                combined_bias_per_heading_degree_m=float(1000 * np.linalg.norm(heading_bias)),
                calibration_sensitivity=sensitivity_grid(normal, doppler_information, slope),
            )

        representative_normal, representatives = current_factor_information(
            rows,
            fold,
            folds,
            q,
            jacobian,
            slope,
            float(doppler_trial["beam_calibration_sigma_db"]),
            lane,
        )
        absolute_temporal = {}
        for pass_level_sigma_db in (0.0, 0.1, 0.25, 0.5, 1.0):
            normal = absolute_temporal_information(
                mask,
                group,
                time_s,
                q,
                jacobian,
                slope,
                noise,
                lane,
                pass_level_sigma_db,
            )
            fixed = normal[:2, :2]
            key = f"pass_level_sigma_{pass_level_sigma_db:.2f}_db"
            absolute_temporal[key] = dict(
                pass_level_sigma_db=pass_level_sigma_db,
                information_matrix=normal.tolist(),
                fixed_calibration_beam_only=bounds(fixed),
                fixed_calibration_combined=bounds(fixed + doppler_information),
                calibration_sensitivity=sensitivity_grid(
                    normal, doppler_information, slope, include_lane=True
                ),
                required_independent_pass_multiplier_for_1km_major_95=(
                    required_pass_multiplier(normal, doppler_information, slope)
                ),
            )
        fold_results.append(
            dict(
                fold=fold,
                observations=int(np.sum(mask)),
                pass_lane_groups=len(np.unique(group[mask])),
                representatives=len(representatives),
                calibration_slope_db_per_direction_cosine=slope,
                doppler_only=bounds(doppler_information),
                current_single_representative=dict(
                    information_matrix=representative_normal.tolist(),
                    calibration_sensitivity=sensitivity_grid(
                        representative_normal, doppler_information, slope, include_lane=True
                    ),
                ),
                absolute_temporal=absolute_temporal,
                temporal=temporal,
            )
        )

    output = dict(
        scope="known-site local Fisher sensitivity; fixed candidate identities; not accuracy proof",
        phase_alignment=aligned_document["phase_alignment"],
        response_cross_validation=cross_validation,
        absolute_response_cross_validation=absolute_cross_validation,
        temporal_noise_model=noise,
        folds=fold_results,
        limitations=[
            "Phase rates use a linearized ridge profile, not the production robust IRLS profile.",
            "The exponential covariance is an empirical short-window model from the same corpus.",
            "Fisher bounds are local random-error sensitivity and exclude identity, orbit, "
            "calibration bias, and selection error.",
            "Beam rates are Doppler-profiled conditionally; the beam term does not jointly "
            "refit phase nuisances.",
        ],
    )
    (args.output / "information.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(dict(output=args.output.as_posix(), folds=len(fold_results), noise=noise)))


if __name__ == "__main__":
    main()

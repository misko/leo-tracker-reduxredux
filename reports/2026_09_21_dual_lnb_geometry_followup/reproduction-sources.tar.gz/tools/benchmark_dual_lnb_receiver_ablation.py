"""Compare receiver subsets under a frozen conditional local-position protocol."""

from __future__ import annotations

import argparse
from dataclasses import asdict
from pathlib import Path

import numpy as np
from research_dual_lnb_full_corpus import (
    digest,
    exact_phase_verification,
    load_prepared,
    read_document,
    write_json,
)

from leo.analysis.research.formal_orbit import FormalOrbitConfig, FormalOrbitData, fit_formal_orbit
from leo.analysis.research.regional_doppler import Region


def render_results(result: dict, output: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fits = [result["combined_baseline"], *result["receiver_fits"]]
    labels = ["Combined", "RX0 only", "RX1 only"]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), constrained_layout=True)
    axes[0].bar(labels, [row["horizontal_chord_error_m"] / 1000 for row in fits])
    axes[0].axhline(1, color="grey", linestyle="--", label="1 km objective")
    axes[0].set_ylabel("Error from user-supplied site (km)")
    axes[0].legend()
    axes[1].bar(labels, [row["result"]["evaluation_rms_hz"] for row in fits])
    axes[1].set_ylabel("Randomized evaluation residual RMS (Hz)")
    fig.suptitle(
        "Frozen receiver-subset ablation; conditional local fit\n"
        "Different observation counts; no independent identity truth"
    )
    fig.savefig(output, dpi=170)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    args = parser.parse_args()
    baseline = read_document(args.baseline)
    data, arrays = load_prepared(args.prepared)
    if baseline["inputs"]["prepared_states"]["digest"] != digest(args.prepared):
        raise ValueError("baseline and prepared-state provenance differ")
    configuration = baseline["configuration"]
    region = Region(**configuration["region"])
    site = configuration["evaluation_site"]
    truth = Region(site[0], site[1], 1, 1).points([0], [0]).ecef_km[0]
    result = {
        "scope": "Conditional local receiver ablation; no beam or non-detection identity gates",
        "baseline_digest": digest(args.baseline),
        "prepared_digest": digest(args.prepared),
        "configuration": configuration,
        "combined_baseline": baseline["fits"][0],
        "receiver_fits": [],
    }
    for receiver in (0, 1):
        indices = []
        tracks = []
        for track in baseline["audit"]["tracks"]:
            if track["receiver_id"] != receiver:
                continue
            start = len(indices)
            indices.extend(range(track["row_start"], track["row_stop"]))
            tracks.append({**track, "row_start": start, "row_stop": len(indices)})
        subset = FormalOrbitData(**{key: value[indices] for key, value in arrays.items()})
        fit = fit_formal_orbit(
            subset,
            region,
            configuration["initial_x_km"],
            FormalOrbitConfig(max_nfev=configuration["max_nfev"]),
        )
        error_m = (
            np.linalg.norm(region.points([fit.x_km[0]], [fit.x_km[1]]).ecef_km[0] - truth) * 1000
        )
        result["receiver_fits"].append(
            {
                "receiver_id": receiver,
                "tracks": len(tracks),
                "observations": len(indices),
                "horizontal_chord_error_m": float(error_m),
                "result": asdict(fit),
                "exact_phase_verification": exact_phase_verification(
                    subset, {"tracks": tracks}, fit, region, args.tle_archive
                ),
            }
        )
        write_json(args.output, result)
        print(f"RX{receiver}: {len(tracks)} tracks; error {error_m:.3f} m", flush=True)
    render_results(result, args.output.with_suffix(".png"))


if __name__ == "__main__":
    main()

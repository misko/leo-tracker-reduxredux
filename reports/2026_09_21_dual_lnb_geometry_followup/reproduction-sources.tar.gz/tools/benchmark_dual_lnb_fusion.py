#!/usr/bin/env python3
"""Matched offline benchmark of anchored RX1 extensions against one baseline."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import asdict
from importlib import import_module
from pathlib import Path
from typing import Any

import numpy as np

from leo.analysis.persistent_hop_trajectory import reconstruct_persistent_hop_trajectories
from leo.analysis.research.dual_lnb_fusion import (
    FusionObservation,
    SimultaneousAnchor,
    fuse_anchored_paths,
    fusion_covariance_block,
)
from leo.analysis.research.formal_orbit import (
    FormalOrbitConfig,
    FormalOrbitData,
    doppler_hz,
    fit_formal_orbit,
    phase_state,
)
from leo.analysis.research.measurement_covariance import TrackMeasurementCovariance
from leo.analysis.research.regional_doppler import Region
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.propagation import parse_element_sets

SCHEMA = "org.leo.research.dual-lnb-fusion-benchmark/v1"
SITE = (37.84903264307456, -122.4856541910174)
_FULL = import_module("research_dual_lnb_full_corpus")
read_document = _FULL.read_document
tracking_input = _FULL.tracking_input
load_prepared = _FULL.load_prepared
propagate = _FULL.propagate


def _subset_formal_data(data: FormalOrbitData, keep: np.ndarray) -> FormalOrbitData:
    values = {}
    for name in FormalOrbitData.__dataclass_fields__:
        if name == "extra_covariance":
            continue
        value = getattr(data, name)
        values[name] = None if value is None else np.asarray(value)[keep]
    return FormalOrbitData(**values)  # type: ignore[arg-type]


def _append_formal_data(
    baseline: FormalOrbitData,
    rows: list[dict[str, Any]],
    blocks: list[TrackMeasurementCovariance],
) -> FormalOrbitData:
    values: dict[str, Any] = {}
    for name in FormalOrbitData.__dataclass_fields__:
        if name == "extra_covariance":
            continue
        value = getattr(baseline, name)
        if value is None:
            values[name] = None
            continue
        extension = np.asarray([row[name] for row in rows], dtype=np.asarray(value).dtype)
        values[name] = np.concatenate((np.asarray(value), extension), axis=0)
    return FormalOrbitData(**values, extra_covariance=tuple(blocks))


def covariance_from_ids(block, observation_id: np.ndarray) -> TrackMeasurementCovariance:
    lookup = {str(value): index for index, value in enumerate(observation_id)}
    missing = set(block.observation_ids) - set(lookup)
    if missing:
        raise ValueError("fusion covariance references absent observations")
    source_order = np.asarray([lookup[value] for value in block.observation_ids], int)
    order = np.argsort(source_order)
    indexes = source_order[order]
    covariance = np.asarray(block.covariance_hz2)[np.ix_(order, order)]
    return TrackMeasurementCovariance(indexes, covariance, block.calibration_group_id)


def _candidate_id(observation_id: str) -> str:
    marker = observation_id.rfind(":sha256:")
    if marker < 0:
        raise ValueError("observation ID lacks candidate digest")
    return observation_id[marker + 1 :]


def _fusion_observation(session_id, tracklet_id, number, candidate, point):
    return FusionObservation(
        session_id=str(session_id),
        path_id=str(tracklet_id),
        receiver_id=int(candidate.receiver_id),
        catalog_number=int(number),
        channel=int(candidate.channel),
        edge=str(candidate.edge),
        time_s=float(candidate.support_center_utc_ns / 1e9),
        normalized_cfo_hz=float(point.normalized_dealiased_cfo_hz),
        measurement_sigma_hz=float(candidate.standard_uncertainty_hz),
        observation_id=f"{session_id}:{tracklet_id}:{candidate.candidate_id}",
        alias_branch=str(tracklet_id),
        source_digest=str(candidate.raw_recording_authority_digest),
    )


def _exact_verification(data, snapshot_by_row, result, region, archive_root):
    archive = TleArchiveReader(archive_root)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogues = {}
    receiver = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
    difference = []
    for snapshot_digest, number in sorted(
        set(zip(snapshot_by_row, np.asarray(data.source), strict=True))
    ):
        rows = np.flatnonzero(
            (np.asarray(snapshot_by_row) == snapshot_digest) & (data.source == number)
        )
        if snapshot_digest not in references:
            raise ValueError("verification snapshot absent from archive")
        if snapshot_digest not in catalogues:
            catalogues[snapshot_digest] = parse_element_sets(
                archive.read(references[snapshot_digest])
            )
        catalogue = catalogues[snapshot_digest]
        satellite_index = list(catalogue.satellite_numbers).index(int(number))
        phase = data.age_h[rows] * result.rate_corrections_s_h[str(number)]
        utc_ns = np.rint(data.time_s[rows] * 1e9 + phase * 1e9).astype(np.int64)
        exact_p, exact_v = propagate(catalogue, satellite_index, utc_ns)
        approximate_p = phase_state(data, rows, phase, 1.0)
        approximate_v = phase_state(data, rows, phase, 1.0, velocity=True)
        difference.extend(
            (
                doppler_hz(receiver, exact_p, exact_v)
                - doppler_hz(receiver, approximate_p, approximate_v)
            ).tolist()
        )
    values = np.asarray(difference)
    return {
        "observations": len(values),
        "rms_difference_hz": float(np.sqrt(np.mean(values**2))),
        "p99_absolute_difference_hz": float(np.percentile(abs(values), 99)),
        "maximum_absolute_difference_hz": float(np.max(abs(values))),
        "passes_0_2_hz_maximum": bool(np.max(abs(values)) < 0.2),
    }


def _prepare(args, data, selection, inventory):
    audit_tracks = {
        (str(row["session_id"]), str(row["tracklet_id"])): row
        for row in selection["audit"]["tracks"]
    }
    base_snapshot = np.empty(len(data.y_hz), dtype=object)
    for row in selection["audit"]["tracks"]:
        base_snapshot[int(row["row_start"]) : int(row["row_stop"])] = str(row["snapshot_digest"])
    base_candidate_ids = {_candidate_id(str(value)) for value in data.observation_id}
    eligible = [
        row
        for row in inventory["links"]
        if row["same_review_leader"]
        and row["helper_anchor_count_pass"]
        and row["receiver_lag_gate_pass"]
        and row["exterior_rx1_point_count"] > 0
        and (str(row["session_id"]), str(row["rx0_tracklet_id"])) in audit_tracks
    ]
    by_session = {}
    for row in eligible:
        by_session.setdefault(str(row["session_id"]), []).append(row)
    archive = TleArchiveReader(args.tle_archive)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogue_cache = {}
    accepted = []
    extension_rows = []
    anchor_ids = set()
    covariance_specs = []
    used_rx0 = set()
    appended_candidate_ids = set()
    anchor_candidate_ids = set()
    rejections: Counter[str] = Counter(
        {"inventory-links-outside-predeclared-eligibility": len(inventory["links"]) - len(eligible)}
    )
    for session_id, links in sorted(by_session.items()):
        document = read_document(Path(links[0]["source_path"]))
        source = tracking_input(document["source"])
        candidates = project_scanner_candidates(source)
        candidate_by_id = {str(candidate.candidate_id): candidate for candidate in candidates}
        trajectory = reconstruct_persistent_hop_trajectories(candidates)
        track_by_id = {str(track.tracklet_id): track for track in trajectory.tracklets}
        product = document["tracking"]
        persisted_ids = {str(track["tracklet_id"]) for track in product["tracklets"]}
        if set(track_by_id) != persisted_ids:
            raise ValueError("reconstructed track IDs differ from persisted inventory")
        snapshot = product["original_tle_snapshot"]
        snapshot_digest = str(snapshot["digest"])
        if snapshot_digest not in references:
            raise ValueError("fusion snapshot absent from archive")
        if snapshot_digest not in catalogue_cache:
            catalogue_cache[snapshot_digest] = parse_element_sets(
                archive.read(references[snapshot_digest])
            )
        catalogue = catalogue_cache[snapshot_digest]
        capture_ns = int(source.timing.first_sample_estimate_utc_ns)
        if int(snapshot["collected_utc_ns"]) >= capture_ns:
            raise ValueError("fusion snapshot was not available before capture")
        for link in links:
            rx0_id = str(link["rx0_tracklet_id"])
            rx1_id = str(link["rx1_tracklet_id"])
            key = (session_id, rx0_id)
            if key in used_rx0:
                rejections["rx0-track-already-fused"] += 1
                continue
            number = int(link["catalog_number"])
            rx0_path = tuple(
                _fusion_observation(session_id, rx0_id, number, candidate_by_id[p.candidate_id], p)
                for p in track_by_id[rx0_id].points
            )
            rx1_path = tuple(
                _fusion_observation(session_id, rx1_id, number, candidate_by_id[p.candidate_id], p)
                for p in track_by_id[rx1_id].points
            )
            lookup0 = {item.observation_id: item for item in rx0_path}
            lookup1 = {item.observation_id: item for item in rx1_path}
            anchors = []
            missing_anchor = False
            for anchor in link["anchors"]:
                id0 = f"{session_id}:{rx0_id}:{anchor['rx0_candidate_id']}"
                id1 = f"{session_id}:{rx1_id}:{anchor['rx1_candidate_id']}"
                if id0 not in lookup0 or id1 not in lookup1:
                    missing_anchor = True
                    break
                anchors.append(
                    SimultaneousAnchor(
                        f"{session_id}:{anchor['rx0_visit_index']}:{rx0_id}:{rx1_id}",
                        lookup0[id0],
                        lookup1[id1],
                        str(anchor["role"]),
                    )
                )
            if missing_anchor:
                rejections["anchor-candidate-absent-from-path"] += 1
                continue
            fused = fuse_anchored_paths(rx0_path, rx1_path, tuple(anchors))
            block = fusion_covariance_block(fused)
            if fused.state != "fused" or fused.calibration is None or block is None:
                rejections[f"helper-{fused.reason or 'missing-covariance'}"] += 1
                continue
            audit_track = audit_tracks[key]
            segment = int(audit_track["segment"])
            satellite_index = list(catalogue.satellite_numbers).index(number)
            element_epoch = int(catalogue.element_epoch_utc_ns()[satellite_index])
            if element_epoch >= capture_ns:
                raise ValueError("fusion element epoch was not causal")
            rx1_point_order = {
                str(point.candidate_id): index
                for index, point in enumerate(track_by_id[rx1_id].points)
            }
            appended_ids = []
            link_rows = []
            link_candidate_ids = []
            for item in fused.points:
                if item.source_receiver_id != 1:
                    continue
                observation_prefix = f"{session_id}:{rx1_id}:"
                if not item.source_observation_id.startswith(observation_prefix):
                    raise ValueError("fused observation provenance does not match RX1 path")
                candidate_id = item.source_observation_id[len(observation_prefix) :]
                candidate = candidate_by_id[candidate_id]
                utc_ns = np.asarray([candidate.support_center_utc_ns], np.int64)
                states = [
                    propagate(catalogue, satellite_index, utc_ns + shift * 1_000_000_000)
                    for shift in (-1, 0, 1)
                ]
                point_index = rx1_point_order[candidate_id]
                appended_ids.append(item.source_observation_id)
                link_candidate_ids.append(candidate_id)
                link_rows.append(
                    {
                        "y_hz": item.normalized_cfo_hz,
                        "training": point_index % 5 != 4,
                        "segment": segment,
                        "track": segment,
                        "source": number,
                        "age_h": (capture_ns - element_epoch) / 3.6e12,
                        "p_km": states[1][0][0],
                        "v_km_s": states[1][1][0],
                        "phase_p_minus_km": states[0][0][0],
                        "phase_v_minus_km_s": states[0][1][0],
                        "phase_p_plus_km": states[2][0][0],
                        "phase_v_plus_km_s": states[2][1][0],
                        "time_s": candidate.support_center_utc_ns / 1e9,
                        "observation_id": item.source_observation_id,
                        "snapshot_digest": snapshot_digest,
                    }
                )
            if len(set(link_candidate_ids)) != len(link_candidate_ids):
                rejections["duplicate-candidate-within-extension"] += 1
                continue
            if set(link_candidate_ids) & base_candidate_ids:
                rejections["extension-candidate-already-in-baseline"] += 1
                continue
            if set(link_candidate_ids) & appended_candidate_ids:
                rejections["extension-candidate-already-appended"] += 1
                continue
            extension_rows.extend(link_rows)
            appended_candidate_ids.update(link_candidate_ids)
            covariance_specs.append(block)
            anchor_ids.update(fused.calibration.fit_observation_ids)
            anchor_ids.update(fused.calibration.validation_observation_ids)
            anchor_candidate_ids.update(
                _candidate_id(value)
                for value in (
                    *fused.calibration.fit_observation_ids,
                    *fused.calibration.validation_observation_ids,
                )
            )
            used_rx0.add(key)
            accepted.append(
                {
                    "session_id": session_id,
                    "number": number,
                    "rx0_tracklet_id": rx0_id,
                    "rx1_tracklet_id": rx1_id,
                    "fit_anchors": len(fused.calibration.fit_anchor_ids),
                    "validation_anchors": len(fused.calibration.validation_anchor_ids),
                    "fit_rms_hz": fused.calibration.fit_rms_hz,
                    "validation_rms_hz": fused.calibration.validation_rms_hz,
                    "extension_points": len(appended_ids),
                    "calibration_group_id": fused.calibration.calibration_group_id,
                }
            )
    keep = np.asarray(
        [_candidate_id(str(value)) not in anchor_candidate_ids for value in data.observation_id]
    )
    removed_rows = int(np.count_nonzero(~keep))
    baseline = _subset_formal_data(data, keep)
    baseline_snapshot = base_snapshot[keep]
    temporary = _append_formal_data(baseline, extension_rows, [])
    blocks = [covariance_from_ids(block, temporary.observation_id) for block in covariance_specs]
    fused_data = FormalOrbitData(
        **{
            name: getattr(temporary, name)
            for name in FormalOrbitData.__dataclass_fields__
            if name != "extra_covariance"
        },
        extra_covariance=tuple(blocks),
    )
    fused_snapshot = np.concatenate(
        (baseline_snapshot, np.asarray([row["snapshot_digest"] for row in extension_rows], object))
    )
    return (
        baseline,
        fused_data,
        baseline_snapshot,
        fused_snapshot,
        accepted,
        removed_rows,
        len(anchor_ids),
        dict(sorted(rejections.items())),
    )


def _fit(data, snapshot, region, config, initial, archive_root):
    result = fit_formal_orbit(data, region, initial, config)
    truth = Region(SITE[0], SITE[1], 1, 1).points([0.0], [0.0]).ecef_km[0]
    estimated = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
    return {
        "horizontal_chord_error_m": float(np.linalg.norm(estimated - truth) * 1000),
        "result": asdict(result),
        "exact_phase_verification": _exact_verification(
            data, snapshot, result, region, archive_root
        ),
    }


def _common_evaluation_rms(data, result, region):
    receiver = region.points([result["x_km"][0]], [result["x_km"][1]]).ecef_km[0]
    rate = np.asarray([result["rate_corrections_s_h"][str(value)] for value in data.source])
    phase = data.age_h * rate
    position = phase_state(data, slice(None), phase, 1.0)
    velocity = phase_state(data, slice(None), phase, 1.0, velocity=True)
    offset = np.asarray([result["segment_offsets_hz"][str(value)] for value in data.segment])
    residual = data.y_hz - doppler_hz(receiver, position, velocity) - offset
    return float(np.sqrt(np.mean(residual[~data.training] ** 2)))


def _save_preparation(path, baseline, fused, baseline_snapshot, fused_snapshot):
    payload = {
        "schema": np.asarray(SCHEMA + "/prepared"),
        "baseline_snapshot_digest": np.asarray(baseline_snapshot, str),
        "fused_snapshot_digest": np.asarray(fused_snapshot, str),
        "fused_covariance_count": np.asarray(len(fused.extra_covariance)),
    }
    for prefix, data in (("baseline", baseline), ("fused", fused)):
        for name in FormalOrbitData.__dataclass_fields__:
            if name == "extra_covariance":
                continue
            value = getattr(data, name)
            if value is not None:
                payload[f"{prefix}__{name}"] = np.asarray(value)
    for index, block in enumerate(fused.extra_covariance):
        payload[f"fused_covariance__{index:03d}__indices"] = block.observation_indices
        payload[f"fused_covariance__{index:03d}__hz2"] = block.covariance_hz2
        payload[f"fused_covariance__{index:03d}__calibration_id"] = np.asarray(block.calibration_id)
    np.savez_compressed(path, **payload)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepared-output", type=Path)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--max-nfev", type=int, default=200)
    args = parser.parse_args()
    data, _ = load_prepared(args.prepared)
    selection = read_document(args.selection)
    inventory = read_document(args.inventory)
    (
        baseline,
        fused,
        baseline_snapshot,
        fused_snapshot,
        links,
        removed,
        anchor_ids,
        rejections,
    ) = _prepare(args, data, selection, inventory)
    region = Region(SITE[0], SITE[1], 200.0, 200.0)
    initial = [20.0, -20.0]
    config = FormalOrbitConfig(max_nfev=args.max_nfev)
    output: dict[str, Any] = {
        "schema": SCHEMA,
        "new_rf_collection": False,
        "known_site_used_for_evaluation_only": False,
        "conditional_local_site_centered_region": True,
        "site_conditioned_identity_labels": True,
        "region": asdict(region),
        "initial_x_km": initial,
        "selection": {
            "input_observations": len(data.y_hz),
            "anchor_observations_removed_from_both_arms": removed,
            "all_rx0_rx1_anchor_observation_ids": anchor_ids,
            "matched_baseline_observations": len(baseline.y_hz),
            "fused_observations": len(fused.y_hz),
            "extension_observations": len(fused.y_hz) - len(baseline.y_hz),
            "accepted_links": links,
            "rejections": rejections,
        },
        "fits": {},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    if args.prepared_output is not None:
        args.prepared_output.parent.mkdir(parents=True, exist_ok=True)
        _save_preparation(args.prepared_output, baseline, fused, baseline_snapshot, fused_snapshot)
    if args.prepare_only:
        return
    for name, fit_data, snapshot in (
        ("anchor-excluded-baseline", baseline, baseline_snapshot),
        ("uncertainty-aware-fusion", fused, fused_snapshot),
    ):
        print(json.dumps({"phase": "fit-start", "model": name}), flush=True)
        output["fits"][name] = _fit(fit_data, snapshot, region, config, initial, args.tle_archive)
        args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
        print(
            json.dumps(
                {
                    "phase": "fit-complete",
                    "model": name,
                    "error_m": output["fits"][name]["horizontal_chord_error_m"],
                }
            ),
            flush=True,
        )
    for fit in output["fits"].values():
        fit["common_baseline_evaluation_rms_hz"] = _common_evaluation_rms(
            baseline, fit["result"], region
        )
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()

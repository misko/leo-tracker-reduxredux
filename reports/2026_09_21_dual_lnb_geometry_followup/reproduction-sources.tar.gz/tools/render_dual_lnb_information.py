"""Render concise dual-LNB local-information diagnostics from retained results."""

import argparse
import gzip
import hashlib
import json
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

SLOPE_SIGMA_FRACTION = 0.05
HEADING_SIGMA_DEG = 3.0
LANE_INTERCEPT_SIGMA_DB = 0.25
PASS_LEVEL_SIGMA_DB = 0.25


def calibration_case(rows):
    matches = [
        row
        for row in rows
        if row["slope_sigma_fraction"] == SLOPE_SIGMA_FRACTION
        and row["heading_sigma_deg"] == HEADING_SIGMA_DEG
        and row["lane_intercept_sigma_db"] == LANE_INTERCEPT_SIGMA_DB
    ]
    if len(matches) != 1:
        raise ValueError("representative calibration sensitivity case is missing or ambiguous")
    return matches[0]


def summarize(document):
    folds = []
    for fold in document["folds"]:
        current = calibration_case(fold["current_single_representative"]["calibration_sensitivity"])
        absolute = fold["absolute_temporal"]["pass_level_sigma_0.25_db"]
        absolute_calibration = calibration_case(absolute["calibration_sensitivity"])
        free_offset = fold["temporal"]["free_pass_offset"]
        free_drift = fold["temporal"]["free_pass_offset_and_drift"]
        doppler = fold["doppler_only"]["major_95_m"]
        all_temporal = absolute_calibration["combined_with_doppler"]["major_95_m"]
        folds.append(
            {
                "fold": fold["fold"],
                "observations": fold["observations"],
                "representatives": fold["representatives"],
                "pass_lane_groups": fold["pass_lane_groups"],
                "slope_db_per_direction_cosine": (
                    fold["calibration_slope_db_per_direction_cosine"]
                ),
                "doppler_major_95_m": doppler,
                "current_representative_combined_major_95_m": current[
                    "combined_with_doppler"
                ]["major_95_m"],
                "correlated_all_points_combined_major_95_m": all_temporal,
                "combined_reduction_m": doppler - all_temporal,
                "combined_reduction_percent": 100 * (doppler - all_temporal) / doppler,
                "required_independent_pass_multiplier_for_1km": absolute[
                    "required_independent_pass_multiplier_for_1km_major_95"
                ],
                "free_pass_offset_beam_major_95_m": free_offset[
                    "fixed_calibration_beam_only"
                ]["major_95_m"],
                "free_pass_offset_and_drift_beam_major_95_m": free_drift[
                    "fixed_calibration_beam_only"
                ]["major_95_m"],
                "information_rank": absolute_calibration["combined_with_doppler"]["rank"],
            }
        )
    return {
        "scope": document["scope"],
        "representative_calibration_sensitivity": {
            "slope_sigma_fraction": SLOPE_SIGMA_FRACTION,
            "heading_sigma_deg": HEADING_SIGMA_DEG,
            "lane_intercept_sigma_db": LANE_INTERCEPT_SIGMA_DB,
            "pass_level_sigma_db": PASS_LEVEL_SIGMA_DB,
            "status": "representative sensitivity point, not measured calibration truth",
        },
        "phase_alignment": document["phase_alignment"],
        "response_cross_validation": document["response_cross_validation"],
        "temporal_noise_model": document["temporal_noise_model"],
        "folds": folds,
        "limitations": document["limitations"],
    }


def render_figure(summary, output):
    folds = summary["folds"]
    x = np.arange(len(folds))
    width = 0.24
    fig, axes = plt.subplots(1, 2, figsize=(15, 6), layout="constrained")

    doppler = np.array([row["doppler_major_95_m"] for row in folds]) / 1000
    current = np.array(
        [row["current_representative_combined_major_95_m"] for row in folds]
    ) / 1000
    all_points = np.array(
        [row["correlated_all_points_combined_major_95_m"] for row in folds]
    ) / 1000
    axes[0].bar(x - width, doppler, width, label="Doppler only")
    axes[0].bar(x, current, width, label="Doppler + one point/pass")
    axes[0].bar(
        x + width,
        all_points,
        width,
        label="Doppler + correlated pass samples",
    )
    axes[0].axhline(1, color="black", linestyle="--", linewidth=1, label="1 km reference")
    for position, row, value in zip(x, folds, all_points, strict=True):
        axes[0].text(
            position + width,
            value + 0.04,
            f"−{row['combined_reduction_m']:.0f} m",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    axes[0].set(
        title="A. Local major-axis 95% bound",
        xlabel="Satellite-disjoint fold",
        ylabel="Major-axis 95% bound (km)",
        xticks=x,
        xticklabels=[str(row["fold"]) for row in folds],
        ylim=(0, max(doppler) * 1.16),
    )
    axes[0].legend(fontsize=8)
    axes[0].grid(axis="y", alpha=0.2)

    noise = summary["temporal_noise_model"]
    bins = noise["bins"]
    lag = np.array([row["lag_s"] for row in bins])
    semivariance = np.array([row["semivariance_db2"] for row in bins])
    pairs = np.array([row["pairs"] for row in bins])
    size = 20 + 100 * np.sqrt(pairs / pairs.max())
    axes[1].scatter(lag, semivariance, s=size, alpha=0.7, label="Empirical semivariance")
    grid = np.linspace(0, max(lag), 400)
    fitted = noise["white_sigma_db"] ** 2 + noise["correlated_sigma_db"] ** 2 * (
        1 - np.exp(-grid / noise["correlation_time_s"])
    )
    axes[1].plot(grid, fitted, linewidth=2, label="Exponential covariance fit")
    required = "/".join(
        f"{row['required_independent_pass_multiplier_for_1km']:.0f}×" for row in folds
    )
    axes[1].text(
        0.98,
        0.05,
        (
            f"white σ = {noise['white_sigma_db']:.3f} dB\n"
            f"correlated σ = {noise['correlated_sigma_db']:.3f} dB\n"
            f"correlation time = {noise['correlation_time_s']:.2f} s\n"
            f"independent-pass multiplier for 1 km\n"
            f"at representative sensitivity: {required}"
        ),
        transform=axes[1].transAxes,
        ha="right",
        va="bottom",
        fontsize=9,
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.9},
    )
    axes[1].set(
        title="B. Measured response correlation",
        xlabel="Within-pass lag (s)",
        ylabel="Semivariance (dB²)",
    )
    axes[1].legend(fontsize=8, loc="upper left")
    axes[1].grid(alpha=0.2)
    fig.suptitle(
        "Dual-LNB local Fisher sensitivity — theoretical bound, not measured accuracy",
        fontsize=15,
    )
    fig.savefig(output / "local-information.png", dpi=170)
    plt.close(fig)


def render_markdown(summary, output):
    noise = summary["temporal_noise_model"]
    folds = summary["folds"]
    lines = [
        "# Dual-LNB local information sensitivity",
        "",
        "**This is a theoretical, known-site local Fisher bound, not measured position "
        "accuracy or a sub-kilometre result.** It conditions on fixed reviewed candidate "
        "identities and linearizes at the calibration site.",
        "",
        "The response adds only a small amount of local information to Doppler. Under the "
        "representative sensitivity point—5% slope, 3° heading, 0.25 dB lane-intercept, "
        "and 0.25 dB pass-level uncertainty—the combined major-axis 95% bound remains "
        f"{min(r['correlated_all_points_combined_major_95_m'] for r in folds) / 1000:.2f}–"
        f"{max(r['correlated_all_points_combined_major_95_m'] for r in folds) / 1000:.2f} km. "
        "Those uncertainty values are sensitivity assumptions, not measured calibration truth.",
        "",
        "| Fold | Observations / representatives | Slope | Doppler major 95% | Combined "
        "major 95% | Reduction | Independent-pass multiplier for 1 km |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in folds:
        lines.append(
            f"| {row['fold']} | {row['observations']} / {row['representatives']} | "
            f"{row['slope_db_per_direction_cosine']:.2f} dB/cosine | "
            f"{row['doppler_major_95_m'] / 1000:.3f} km | "
            f"{row['correlated_all_points_combined_major_95_m'] / 1000:.3f} km | "
            f"{row['combined_reduction_m']:.0f} m ({row['combined_reduction_percent']:.1f}%) | "
            f"{row['required_independent_pass_multiplier_for_1km']:.0f}× |"
        )
    lines.extend(
        [
            "",
            "![Doppler/beam local bound and response correlation](local-information.png)",
            "",
            "## What sets the bound",
            "",
            f"The empirical response model has white scatter {noise['white_sigma_db']:.3f} dB, "
            f"correlated scatter {noise['correlated_sigma_db']:.3f} dB, and an "
            f"{noise['correlation_time_s']:.2f} s correlation time. Treating all within-pass "
            "points as independent would therefore overstate information. Using all correlated "
            "samples improves the combined major-axis bound by only 34–54 m beyond one "
            "representative per pass at the same calibration assumptions.",
            "",
            "Allowing an unknown offset for every pass removes nearly all absolute-angle "
            "information: beam-only major-axis bounds become 812–1,244 km. Allowing pass offset "
            "and drift expands them to 1,684–2,215 km. Absolute response levels retain some "
            "local information, but the current geometry and pass count remain far from a "
            "sub-kilometre bound.",
            "",
            "The within-pass response cross-validation is demeaned and therefore demonstrates "
            "directional shape, not prospective absolute calibration. Baseline RMS values "
            "1.552/1.582/1.601 dB fall to 0.863/0.954/0.838 dB with east direction cosine.",
            "",
            "## Limitations",
            "",
        ]
    )
    limitations = [
        "The calculation uses a known calibration site and fixed, selection-conditioned review "
        "leaders; it does not validate identities or blind/global localization.",
        "Only captures with paired dual detections and clear reviews enter the response model.",
        "The covariance is estimated from this same short corpus and is not an independent-day "
        "noise calibration.",
        "Phase rates use a response-excluded, fixed-site linearized ridge Doppler profile rather "
        "than the production robust IRLS profiler.",
        "Beam geometry is conditionally Doppler-profiled; beam evidence does not jointly refit "
        "phase nuisances.",
        "Local Fisher bounds describe random-error curvature. They exclude orbit, identity, "
        "calibration and selection bias and must not be reported as achieved accuracy.",
    ]
    lines.extend(f"- {limitation}" for limitation in limitations)
    lines.extend(
        [
            "",
            "The complete matrices and sensitivity grid are retained in "
            "[information.json.gz](information.json.gz); the readable values above are in "
            "[information-summary.json](information-summary.json).",
        ]
    )
    (output / "README.md").write_text("\n".join(lines) + "\n")


def gzip_source(source, destination):
    with (
        source.open("rb") as input_stream,
        destination.open("wb") as output_stream,
        gzip.GzipFile(fileobj=output_stream, mode="wb", mtime=0) as compressed,
    ):
        shutil.copyfileobj(input_stream, compressed)


def write_manifest(output):
    artifacts = []
    for path in sorted(output.iterdir()):
        if not path.is_file() or path.name == "artifact-manifest.json":
            continue
        artifacts.append(
            {
                "name": path.name,
                "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    manifest = {
        "description": "Dual-LNB theoretical local-information follow-up artifacts",
        "artifacts": artifacts,
    }
    (output / "artifact-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    document = json.loads(args.input.read_text())
    summary = summarize(document)
    (args.output / "information-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    render_figure(summary, args.output)
    render_markdown(summary, args.output)
    gzip_source(args.input, args.output / "information.json.gz")
    write_manifest(args.output)


if __name__ == "__main__":
    main()

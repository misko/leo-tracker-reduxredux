#!/usr/bin/env python3
"""Render paired numerical-correction results from completed benchmark receipts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quadratic", type=Path, required=True)
    parser.add_argument("--quartic", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    documents = [json.loads(path.read_text()) for path in (args.quadratic, args.quartic)]
    arms = ["anchor-excluded-baseline", "uncertainty-aware-fusion"]
    metrics = [
        ("Position error (m)", lambda f: f["horizontal_chord_error_m"], 1000),
        ("Common evaluation RMS (Hz)", lambda f: f["common_baseline_evaluation_rms_hz"], None),
        (
            "Maximum exact-orbit error (Hz)",
            lambda f: f["exact_phase_verification"]["maximum_absolute_difference_hz"],
            0.2,
        ),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), layout="constrained")
    for ax, (title, get, gate) in zip(axes, metrics, strict=True):
        for i, (label, doc) in enumerate(zip(["Quadratic", "Quartic"], documents, strict=True)):
            values = [get(doc["fits"][arm]) for arm in arms]
            bars = ax.bar(np.arange(2) + (i - 0.5) * 0.34, values, width=0.34, label=label)
            ax.bar_label(bars, fmt="%.3f", fontsize=8)
        ax.set_xticks([0, 1], ["Matched baseline", "Receiver fusion"])
        ax.set_title(title)
        ax.set_ylim(0, ax.get_ylim()[1] * 1.12)
        ax.grid(axis="y", alpha=0.2)
        if gate is not None:
            ax.axhline(gate, color="black", linestyle="--", linewidth=1)
    axes[0].legend(loc="lower left")
    fig.suptitle(
        "Orbit interpolation correction: same data, starts and model settings\n"
        "Site-conditioned local fits; coordinate improvement alone "
        "does not establish reliable accuracy"
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Refit frozen matched fusion arms with opt-in five-state phase interpolation."""

from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np
from benchmark_dual_lnb_fusion import (
    _common_evaluation_rms,
    _fit,
    _save_preparation,
    parse_element_sets,
    propagate,
)

from leo.analysis.research.formal_orbit import FormalOrbitConfig, FormalOrbitData
from leo.analysis.research.measurement_covariance import TrackMeasurementCovariance
from leo.analysis.research.regional_doppler import Region
from leo.operations.tle_archive import TleArchiveReader


def load_arm(arrays, prefix):
    fields = {
        name: arrays[f"{prefix}__{name}"]
        for name in FormalOrbitData.__dataclass_fields__
        if f"{prefix}__{name}" in arrays
    }
    blocks = []
    if prefix == "fused":
        for i in range(int(arrays["fused_covariance_count"])):
            base = f"fused_covariance__{i:03d}__"
            blocks.append(
                TrackMeasurementCovariance(
                    arrays[base + "indices"],
                    arrays[base + "hz2"],
                    str(arrays[base + "calibration_id"]),
                )
            )
    return FormalOrbitData(**fields, extra_covariance=tuple(blocks))


def augment(data, snapshots, archive, references, catalogues):
    outer = {
        key: np.empty_like(data.p_km)
        for key in (
            "phase_p_minus2_km",
            "phase_v_minus2_km_s",
            "phase_p_plus2_km",
            "phase_v_plus2_km_s",
        )
    }
    for digest, source in sorted(set(zip(snapshots, data.source, strict=True))):
        rows = np.flatnonzero((snapshots == digest) & (data.source == source))
        if digest not in catalogues:
            catalogues[digest] = parse_element_sets(archive.read(references[digest]))
        catalogue = catalogues[digest]
        index = list(catalogue.satellite_numbers).index(int(source))
        utc = np.rint(data.time_s[rows] * 1e9).astype(np.int64)
        for sign, label in [(-1, "minus"), (1, "plus")]:
            p, v = propagate(catalogue, index, utc + sign * 2_000_000_000)
            outer[f"phase_p_{label}2_km"][rows] = p
            outer[f"phase_v_{label}2_km_s"][rows] = v
    return replace(data, **outer)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepared-output", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    args = parser.parse_args()
    arrays = np.load(args.prepared)
    receipt = json.loads(args.receipt.read_text())
    archive = TleArchiveReader(args.tle_archive)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogues = {}
    arms = {}
    for prefix in ("baseline", "fused"):
        arms[prefix] = augment(
            load_arm(arrays, prefix),
            arrays[prefix + "_snapshot_digest"],
            archive,
            references,
            catalogues,
        )
    _save_preparation(
        args.prepared_output,
        arms["baseline"],
        arms["fused"],
        arrays["baseline_snapshot_digest"],
        arrays["fused_snapshot_digest"],
    )
    out = {
        **receipt,
        "schema": "org.leo.research.dual-lnb-quartic-benchmark/v1",
        "fits": {},
        "change": "opt-in quartic states; observations/selection/initialization unchanged",
    }
    for prefix, name in [
        ("baseline", "anchor-excluded-baseline"),
        ("fused", "uncertainty-aware-fusion"),
    ]:
        print(json.dumps({"fit_start": name}), flush=True)
        fit = _fit(
            arms[prefix],
            arrays[prefix + "_snapshot_digest"],
            Region(**receipt["region"]),
            FormalOrbitConfig(max_nfev=200),
            receipt["initial_x_km"],
            args.tle_archive,
        )
        fit["common_baseline_evaluation_rms_hz"] = _common_evaluation_rms(
            arms["baseline"], fit["result"], Region(**receipt["region"])
        )
        out["fits"][name] = fit
        args.output.write_text(json.dumps(out, indent=2) + "\n")
        print(
            json.dumps(
                {
                    "fit_complete": name,
                    "error_m": fit["horizontal_chord_error_m"],
                    "exact": fit["exact_phase_verification"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()

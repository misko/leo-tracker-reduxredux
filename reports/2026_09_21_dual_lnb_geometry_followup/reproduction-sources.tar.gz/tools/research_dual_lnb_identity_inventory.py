#!/usr/bin/env python3
"""Export exhaustive, contract-faithful identity evidence for a cached scan window."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any

SCHEMA = "org.leo.research.dual-lnb-identity-inventory/v1"


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    payload = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(payload)


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def write_track_csv(path: Path, tracks: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "session_id",
        "tracklet_id",
        "receiver_id",
        "channel",
        "edge",
        "start_utc_ns",
        "end_utc_ns",
        "span_s",
        "observation_count",
        "tle_attempt_state",
        "production_score_state",
        "production_leader",
        "production_abstention_reasons",
        "review_state",
        "review_leader",
        "review_leader_evaluation_rms_hz",
        "review_runner",
        "review_runner_evaluation_rms_hz",
        "research_clear_leader_threshold_pass",
        "cross_receiver_group",
        "catalogue_exclusion_count",
        "propagation_exclusion_count",
    )
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    with temporary.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for track in tracks:
            review = track["review"]
            top = review.get("top_two", [])
            score = track["production_score"]
            writer.writerow(
                {
                    "session_id": track["session_id"],
                    "tracklet_id": track["tracklet_id"],
                    "receiver_id": track["receiver_id"],
                    "channel": track["channel"],
                    "edge": track["edge"],
                    "start_utc_ns": track["start_utc_ns"],
                    "end_utc_ns": track["end_utc_ns"],
                    "span_s": track["span_s"],
                    "observation_count": track["observation_count"],
                    "tle_attempt_state": track["tle_attempt"]["state"],
                    "production_score_state": score["state"],
                    "production_leader": score.get("leading_catalog_number", ""),
                    "production_abstention_reasons": ";".join(
                        score.get("abstention_reasons", [])
                    ),
                    "review_state": review["state"],
                    "review_leader": top[0]["catalog_number"] if top else "",
                    "review_leader_evaluation_rms_hz": (
                        top[0]["randomized_evaluation_rms_hz"] if top else ""
                    ),
                    "review_runner": top[1]["catalog_number"] if len(top) > 1 else "",
                    "review_runner_evaluation_rms_hz": (
                        top[1]["randomized_evaluation_rms_hz"] if len(top) > 1 else ""
                    ),
                    "research_clear_leader_threshold_pass": review.get(
                        "research_clear_leader_threshold_pass", ""
                    ),
                    "cross_receiver_group": track["cross_receiver_group"],
                    "catalogue_exclusion_count": track["catalogue_exclusion_count"],
                    "propagation_exclusion_count": track["propagation_exclusion_count"],
                }
            )
    temporary.replace(path)


def review_summary(review: dict[str, Any] | None) -> dict[str, Any]:
    if review is None:
        return {"state": "not-reviewed", "top_two": []}
    candidates = review["candidates"]
    top_two = [
        {
            "rank": int(row["rank"]),
            "catalog_number": int(row["catalog_number"]),
            "selected_tau_s": float(row["selected_tau_s"]),
            "fitted_offset_hz": float(row["fitted_offset_hz"]),
            "fit_rms_hz": float(row["fit_rms_hz"]),
            "randomized_evaluation_rms_hz": float(row["randomized_evaluation_rms_hz"]),
        }
        for row in candidates[:2]
    ]
    clear = len(top_two) >= 2 and top_two[0]["randomized_evaluation_rms_hz"] <= 150.0 and (
        top_two[1]["randomized_evaluation_rms_hz"]
        >= 3.0 * max(top_two[0]["randomized_evaluation_rms_hz"], 1.0)
    )
    return {
        "state": "reviewed",
        "observation_count": int(review["observation_count"]),
        "fit_observation_count": int(review["fit_observation_count"]),
        "randomized_evaluation_observation_count": int(
            review["randomized_evaluation_observation_count"]
        ),
        "artifact_name": str(review["artifact_name"]),
        "candidate_count": len(candidates),
        "top_two": top_two,
        "research_clear_leader_threshold_pass": clear,
    }


def production_score(candidate: dict[str, Any] | None) -> dict[str, Any]:
    if candidate is None:
        return {"state": "not-scored"}
    return {
        "state": "abstained" if candidate["abstention_recommended"] else "non-abstaining",
        "physical_group_id": str(candidate["physical_group_id"]),
        "hypothesis_rank": int(candidate["hypothesis_rank"]),
        "representative_tracklet_id": str(candidate["representative_tracklet_id"]),
        "leading_catalog_number": candidate["leading_catalog_number"],
        "selected_tau_s": candidate["selected_tau_s"],
        "training_leader_heldout_rank": int(candidate["training_leader_heldout_rank"]),
        "leading_candidate_persisted_on_heldout": bool(
            candidate["leading_candidate_persisted_on_heldout"]
        ),
        "training_runner_negative_log_score_margin": candidate[
            "training_runner_negative_log_score_margin"
        ],
        "heldout_runner_negative_log_score_margin": candidate[
            "heldout_runner_negative_log_score_margin"
        ],
        "nominal_heldout_negative_log_score": float(
            candidate["nominal_heldout_negative_log_score"]
        ),
        "radio_null_heldout_negative_log_score": float(
            candidate["radio_null_heldout_negative_log_score"]
        ),
        "wrong_time_minus_500_heldout_negative_log_score": float(
            candidate["wrong_time_minus_500_heldout_negative_log_score"]
        ),
        "wrong_time_plus_500_heldout_negative_log_score": float(
            candidate["wrong_time_plus_500_heldout_negative_log_score"]
        ),
        "abstention_reasons": list(candidate["abstention_reasons"]),
        "candidate_only": bool(candidate["candidate_only"]),
        "identity_claimed": bool(candidate["identity_claimed"]),
    }


def build(input_dir: Path, inventory_path: Path) -> dict[str, Any]:
    source_inventory = read_json(inventory_path)
    inventory_by_session = {str(row["session_id"]): row for row in source_inventory["scans"]}
    scans = []
    tracks = []
    geometry_revisions: dict[str, dict[str, Any]] = {}
    dispositions: Counter[str] = Counter()
    for path in sorted(input_dir.glob("*.json.gz")):
        document = read_json(path)
        session_id = str(document["session_id"])
        product = document.get("tracking")
        if not product:
            continue
        geometry = document["geometry"]
        geometry_revisions[str(geometry["station_geometry_digest"])] = geometry
        by_id = {str(row["tracklet_id"]): row for row in product["tracklets"]}
        reviews = {str(row["tracklet_id"]): row for row in product.get("track_reviews", [])}
        scored_by_track = {
            str(tracklet_id): candidate
            for candidate in product.get("tle_candidates", [])
            for tracklet_id in candidate["tracklet_ids"]
        }
        unscored = {
            str(row["representative_tracklet_id"]): row
            for row in product.get("unscored_groups", [])
        }
        for tracklet_id, track in sorted(by_id.items()):
            candidate = scored_by_track.get(tracklet_id)
            unscored_row = unscored.get(tracklet_id)
            if candidate is not None:
                attempt_state = "scored-group-member"
            elif unscored_row is not None:
                attempt_state = "attempted-unscored-representative"
            else:
                attempt_state = "not-attempted"
            dispositions[attempt_state] += 1
            span_s = (int(track["end_utc_ns"]) - int(track["start_utc_ns"])) / 1e9
            group_receivers = (
                sorted({int(by_id[item]["receiver_id"]) for item in candidate["tracklet_ids"]})
                if candidate is not None
                else [int(track["receiver_id"])]
            )
            tracks.append(
                {
                    "session_id": session_id,
                    "tracklet_id": tracklet_id,
                    "receiver_id": int(track["receiver_id"]),
                    "channel": int(track["channel"]),
                    "edge": str(track["edge"]),
                    "actual_rf_hz": float(track["actual_rf_hz"]),
                    "start_utc_ns": int(track["start_utc_ns"]),
                    "end_utc_ns": int(track["end_utc_ns"]),
                    "span_s": span_s,
                    "observation_count": int(track["observation_count"]),
                    "local_linear_residual_rms_hz": float(track["residual_rms_hz"]),
                    "normalized_rate_hz_per_s": float(track["normalized_rate_hz_per_s"]),
                    "structural_review_eligibility": {
                        "minimum_14_observations": int(track["observation_count"]) >= 14,
                        "minimum_7_second_span": span_s >= 7.0,
                    },
                    "tle_attempt": {
                        "state": attempt_state,
                        "unscored_reason": None if unscored_row is None else unscored_row["reason"],
                    },
                    "production_score": production_score(candidate),
                    "review": review_summary(reviews.get(tracklet_id)),
                    "physical_group_receiver_ids": group_receivers,
                    "cross_receiver_group": len(group_receivers) > 1,
                    "catalogue_exclusion_count": len(product.get("catalogue_exclusions", [])),
                    "propagation_exclusion_count": len(
                        product.get("propagation_exclusions", [])
                    ),
                }
            )
        scans.append(
            {
                "session_id": session_id,
                "source_path": str(path),
                "source_digest": digest(path),
                "tracking_state": str(document["tracking_state"]),
                "tracking_schema_version": int(product["schema_version"]),
                "trajectory_state": str(product["trajectory_state"]),
                "tle_state": str(product["tle_state"]),
                "tracklet_count": len(by_id),
                "physical_group_count": int(product["physical_group_count"]),
                "eligible_group_count": int(product["eligible_group_count"]),
                "attempted_group_count": int(product["attempted_group_count"]),
                "deferred_group_count": int(product["deferred_group_count"]),
                "review_eligible_count": int(product["review_eligible_count"]),
                "review_count": int(product["review_count"]),
                "deferred_review_count": int(product["deferred_review_count"]),
                "candidate_only": bool(product["candidate_only"]),
                "identity_claimed": bool(product["identity_claimed"]),
                "catalogue_exclusions": list(product.get("catalogue_exclusions", [])),
                "propagation_exclusions": list(product.get("propagation_exclusions", [])),
            }
        )
    completed_sessions = {scan["session_id"] for scan in scans}
    pending = [
        row
        for session_id, row in inventory_by_session.items()
        if session_id not in completed_sessions
    ]
    reviewed = [row for row in tracks if row["review"]["state"] == "reviewed"]
    abstained = [row for row in tracks if row["production_score"]["state"] == "abstained"]
    geometry_manifest = {
        "captured_station_geometry_revisions": list(geometry_revisions),
        "receiver_axis_semantics": (
            "mount_axis_unit is a nominal fixture mechanical axis; rf_boresight_unit and "
            "rf_phase_center_position_m are null, so it is not a measured RF boresight."
        ),
        "tilt_uncertainty": "not quantified by the persisted geometry contract",
        "receiver_mapping_uncertainty": (
            "receiver-to-slot assignments are provisional and based on receiver order; the "
            "physical left/right cable trace is not recorded"
        ),
        "beam_proxy_semantics": (
            "cross-receiver response or margin differences share emitter, propagation, timing, "
            "and front-end effects; they are correlated observations and are not independent beams"
        ),
        "continuity_semantics": (
            "tracklets are reconstructed TLE-blind within one receiver/lane; a production physical "
            "group may join multiple tracklets, including both receivers, but candidate identity "
            "remains explicitly candidate-only and never claimed"
        ),
        "captured_geometry": list(geometry_revisions.values()),
    }
    return {
        "schema": SCHEMA,
        "window": {
            "start_utc_ns": int(source_inventory["end_utc_ns"]) - 8 * 3600 * 1_000_000_000,
            "end_utc_ns": int(source_inventory["end_utc_ns"]),
            "duration_s": 8 * 3600,
            "inventory_path": str(inventory_path),
            "inventory_digest": digest(inventory_path),
        },
        "summary": {
            "inventory_scans": len(source_inventory["scans"]),
            "complete_scan_documents": len(scans),
            "pending_or_missing_scan_documents": len(pending),
            "tracks": len(tracks),
            "reviewed_tracks": len(reviewed),
            "unreviewed_tracks": len(tracks) - len(reviewed),
            "review_clear_leader_threshold_passes": sum(
                bool(row["review"].get("research_clear_leader_threshold_pass")) for row in reviewed
            ),
            "production_non_abstaining_track_members": sum(
                row["production_score"]["state"] == "non-abstaining" for row in tracks
            ),
            "production_abstaining_track_members": len(abstained),
            "attempt_dispositions": dict(sorted(dispositions.items())),
            "cross_receiver_group_track_members": sum(
                row["cross_receiver_group"] for row in tracks
            ),
        },
        "geometry_semantics": geometry_manifest,
        "pending_or_missing_scans": pending,
        "scans": scans,
        "tracks": tracks,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--csv-output", type=Path)
    args = parser.parse_args()
    output = build(args.input, args.inventory)
    write_json(args.output, output)
    if args.csv_output is not None:
        write_track_csv(args.csv_output, output["tracks"])
    print(json.dumps(output["summary"], sort_keys=True))


if __name__ == "__main__":
    main()

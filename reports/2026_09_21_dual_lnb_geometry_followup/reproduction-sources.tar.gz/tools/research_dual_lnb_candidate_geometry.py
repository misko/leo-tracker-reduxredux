"""Conditional known-site geometry discrimination of existing TLE candidates.

This diagnostic uses nominal orbital directions and is not an identity gate.
Calibration excludes the leader's NORAD fold. Points inherit the first audit's
clear-leader selection; results cannot certify unknown or ambiguous identities.
"""

import argparse
import gzip
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from research_dual_lnb_geometry import orbit

from leo.operations.tle_archive import TleArchiveReader
from leo.sky.propagation import parse_element_sets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    points = json.loads(args.input.read_text())["geometry_proxy_points"]
    lanes = sorted({(p["channel"], p["edge"]) for p in points})
    lane = np.array([lanes.index((p["channel"], p["edge"])) for p in points])
    design = np.column_stack([np.eye(len(lanes))[lane], [p["enu"][0] for p in points]])
    response = np.array([p["proxy_db"] for p in points])
    fold = np.array([p["number"] % 3 for p in points])
    group = [(p["session_id"], p["number"], p["channel"], p["edge"]) for p in points]
    counts = Counter(group)
    weights = np.array([1 / counts[g] for g in group])
    models = {}
    for f in range(3):
        mask = fold != f
        w = np.sqrt(weights[mask])
        models[f] = np.linalg.lstsq(design[mask] * w[:, None], response[mask] * w, rcond=None)[0]
    by_track = defaultdict(list)
    for i, point in enumerate(points):
        by_track[point["session_id"], point["tracklet_id"]].append(i)
    archive = TleArchiveReader(Path("/var/lib/leo/tle"))
    snapshots = {s.digest: s for s in archive.list_snapshots()}
    sessions, catalogues = {}, {}
    results = []
    for (session_id, track_id), idx in sorted(by_track.items()):
        if len(idx) < 3:
            continue
        if session_id not in sessions:
            with gzip.open(args.cache / f"{session_id}.json.gz", "rt") as source:
                sessions[session_id] = json.load(source)
        session = sessions[session_id]
        review = next(
            r for r in session["tracking"]["track_reviews"] if r["tracklet_id"] == track_id
        )
        point = points[idx[0]]
        digest = point["catalogue_digest"]
        if digest not in catalogues:
            catalogues[digest] = parse_element_sets(archive.read(snapshots[digest]))
        cat = catalogues[digest]
        numbers = list(cat.satellite_numbers)
        start = session["source"]["timing"]["first_sample_estimate_utc_ns"]
        beta = models[point["number"] % 3]
        candidates = []
        for rank, candidate in enumerate(review["candidates"][:2], 1):
            number = candidate["catalog_number"]
            if number not in numbers or cat.element_epoch_utc_ns()[numbers.index(number)] >= start:
                candidates.append({"rank": rank, "number": number, "state": "no-causal-orbit"})
                continue
            utc = np.array([points[i]["utc_ns"] for i in idx], np.int64)
            cfo, enu = orbit(cat, number, utc)
            if not np.all(np.isfinite(cfo)) or not np.all(np.isfinite(enu)):
                candidates.append({"rank": rank, "number": number, "state": "propagation-error"})
                continue
            predicted = beta[lane[idx]] + beta[-1] * enu[:, 0]
            residual = response[idx] - predicted
            candidates.append(
                dict(
                    rank=rank,
                    number=number,
                    state="scored",
                    proxy_rms_db=float(np.sqrt(np.mean(residual**2))),
                    proxy_bias_db=float(np.mean(residual)),
                    proxy_centered_variance_db2=float(np.var(residual)),
                    mean_predicted_db=float(np.mean(predicted)),
                    mean_east_cosine=float(np.mean(enu[:, 0])),
                    doppler_evaluation_rms_hz=candidate["randomized_evaluation_rms_hz"],
                )
            )
        results.append(
            dict(
                session_id=session_id,
                tracklet_id=track_id,
                points=len(idx),
                candidates=candidates,
                lane=(point["channel"], point["edge"]),
                mean_response_db=float(np.mean(response[idx])),
            )
        )
    scored = [
        r
        for r in results
        if len(r["candidates"]) == 2 and all(c["state"] == "scored" for c in r["candidates"])
    ]
    gain = np.array(
        [r["candidates"][1]["proxy_rms_db"] - r["candidates"][0]["proxy_rms_db"] for r in scored]
    )
    summary = dict(
        tracks=len(results),
        scored_pairs=len(scored),
        leader_geometry_better=int(np.count_nonzero(gain > 0)),
        median_runner_minus_leader_db=float(np.median(gain)) if len(gain) else None,
        leader_better_by_one_db=int(np.count_nonzero(gain > 1)),
    )
    # Shift entire track response levels within RF lanes. Preserve within-track
    # temporal structure; this tests absolute directional levels, not all geometry.
    nulls = []
    strata = defaultdict(list)
    for i, row in enumerate(scored):
        strata[tuple(row["lane"])].append(i)
    means = np.array([r["mean_response_db"] for r in scored])
    for seed in range(100):
        rng = np.random.default_rng(2026092100 + seed)
        shuffled = means.copy()
        for indices in strata.values():
            shuffled[indices] = means[rng.permutation(indices)]
        differences = []
        for value, row in zip(shuffled, scored, strict=True):
            rms = [
                np.sqrt(c["proxy_centered_variance_db2"] + (value - c["mean_predicted_db"]) ** 2)
                for c in row["candidates"]
            ]
            differences.append(rms[1] - rms[0])
        nulls.append(
            dict(
                seed=2026092100 + seed,
                leader_geometry_better=int(np.count_nonzero(np.array(differences) > 0)),
                median_runner_minus_leader_db=float(np.median(differences)),
            )
        )
    summary["shuffled_level_win_count_min_median_max"] = [
        float(f([r["leader_geometry_better"] for r in nulls])) for f in (np.min, np.median, np.max)
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            dict(scope=__doc__, summary=summary, tracks=results, level_nulls=nulls), indent=2
        )
        + "\n"
    )
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), constrained_layout=True)
    left = np.array([r["candidates"][0]["proxy_rms_db"] for r in scored])
    right = np.array([r["candidates"][1]["proxy_rms_db"] for r in scored])
    axes[0].scatter(left, right, s=22, alpha=0.65)
    limit = max(float(np.max(left)), float(np.max(right))) * 1.05
    axes[0].plot([0, limit], [0, limit], "k--", lw=1)
    axes[0].set(
        xlabel="Doppler leader: geometry proxy RMS (dB)",
        ylabel="Runner-up: geometry proxy RMS (dB)",
        xlim=(0, limit),
        ylim=(0, limit),
    )
    axes[1].hist([r["leader_geometry_better"] for r in nulls], bins=np.arange(70, 98), alpha=0.7)
    axes[1].axvline(summary["leader_geometry_better"], color="C1", label="Actual response", lw=2)
    axes[1].set(
        xlabel="Tracks whose geometry favors Doppler leader", ylabel="Shuffled-level trials"
    )
    axes[1].legend()
    for ax in axes:
        ax.grid(alpha=0.2)
    fig.suptitle(
        "Geometry corroboration of 106 clear TLE comparisons\n"
        "Known-site nominal-orbit diagnostic; not independent identity truth"
    )
    fig.savefig(args.output.with_suffix(".png"), dpi=170)
    plt.close(fig)
    print(json.dumps(summary))


if __name__ == "__main__":
    main()

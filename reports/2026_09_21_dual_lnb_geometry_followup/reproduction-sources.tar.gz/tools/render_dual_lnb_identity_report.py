"""Render inventory and continuity diagnostics without changing association decisions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--continuity", type=Path, required=True)
    parser.add_argument("--exact", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    inventory = json.loads(args.inventory.read_text())
    audit = json.loads(args.audit.read_text())
    continuity = json.loads(args.continuity.read_text())
    args.output.mkdir(parents=True, exist_ok=True)
    tracks = inventory["tracks"]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
    labels = ["All tracks", "Reviewed", "Production scored\ngroup members", "Unreviewed"]
    counts = [
        len(tracks),
        sum(t["review"]["state"] == "reviewed" for t in tracks),
        sum(t["tle_attempt"]["state"] == "scored-group-member" for t in tracks),
        sum(t["review"]["state"] == "not-reviewed" for t in tracks),
    ]
    axes[0].bar(labels, counts, color=["#456", "#278", "#497", "#b75"])
    for i, n in enumerate(counts):
        axes[0].text(i, n, str(n), ha="center", va="bottom")
    axes[0].set(ylabel="Persisted track members (correlated)", ylim=(0, max(counts) * 1.13))
    for rx, marker in [(0, "o"), (1, "x")]:
        rows = [t for t in tracks if t["receiver_id"] == rx and len(t["review"]["top_two"]) >= 2]
        x = [t["review"]["top_two"][0]["randomized_evaluation_rms_hz"] for t in rows]
        y = [t["review"]["top_two"][1]["randomized_evaluation_rms_hz"] for t in rows]
        axes[1].scatter(x, y, s=9, alpha=0.4, marker=marker, label=f"RX{rx}: {len(rows)} tracks")
    axes[1].plot([0, 1e5], [0, 1e5], "k--", lw=1, label="Equal RMS")
    axes[1].set(
        xscale="symlog",
        yscale="symlog",
        xlim=(0, 1e5),
        ylim=(0, 1e5),
        xlabel="Fit-rank #1 randomized evaluation RMS (Hz)",
        ylabel="Fit-rank #2 randomized evaluation RMS (Hz)",
    )
    axes[1].legend(fontsize=8)
    fig.suptitle(
        "21 September 2026 · 07:33:13–15:33:13 UTC\n"
        "Candidate review is not an independently verified satellite identity"
    )
    fig.savefig(args.output / "coverage-and-doppler.png", dpi=170)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
    cv = audit["beam_proxy_cross_validation"]
    for model in ["lane-offset-only", "east-west", "east-north"]:
        rows = [r for r in cv if r["model"] == model]
        axes[0].plot(
            [r["fold"] for r in rows],
            [r["evaluation_proxy_rms_db"] for r in rows],
            "o-",
            label=model,
        )
    axes[0].set(
        xlabel="Left-out satellite fold",
        ylabel="GLRT margin-ratio proxy RMS (dB)",
        xticks=[0, 1, 2],
    )
    axes[0].legend()
    for agrees, color in [(True, "#278"), (False, "#c65")]:
        rows = [
            r
            for r in continuity["links"]
            if r["same_review_leader"] == agrees
            and r["receiver_offset_residual_rms_hz"] is not None
        ]
        axes[1].scatter(
            [r["cfo_supported_anchor_visits"] for r in rows],
            [r["receiver_offset_residual_rms_hz"] for r in rows],
            s=15,
            alpha=0.6,
            color=color,
            label=f"{'Same' if agrees else 'Different'} leader ({len(rows)} pairs)",
        )
    axes[1].axvline(3, color="grey", linestyle="--")
    axes[1].set(
        xlabel="Timing/CFO-supported visits in interval overlap",
        ylabel="Receiver-offset residual RMS (Hz)",
    )
    axes[1].legend(fontsize=8)
    fig.suptitle(
        "Directional response and cross-receiver corroboration\n"
        "Interval-overlap links are candidates, not proven emitter continuity"
    )
    fig.savefig(args.output / "beam-and-continuity.png", dpi=170)
    plt.close(fig)

    points = (
        json.loads(args.exact.read_text())["calibration_points"]
        if args.exact
        else audit["geometry_proxy_points"]
    )
    enu = np.asarray([p["enu"] for p in points])
    response = np.asarray([p["proxy_db"] for p in points])
    fig = plt.figure(figsize=(12, 5), constrained_layout=True)
    sky = fig.add_subplot(121, projection="polar")
    scatter = sky.scatter(
        np.arctan2(enu[:, 0], enu[:, 1]),
        90 - np.degrees(np.arcsin(np.clip(enu[:, 2], -1, 1))),
        c=response,
        cmap="coolwarm",
        vmin=-5,
        vmax=5,
        s=7,
        alpha=0.6,
    )
    sky.set_theta_zero_location("N")
    sky.set_theta_direction(-1)
    sky.set_ylim(0, 90)
    sky.set_rticks([30, 60, 90], ["60° elev", "30°", "0°"])
    sky.set_title("Candidate-conditioned sky directions\nZenith at center; north up")
    fig.colorbar(scatter, ax=sky, label="10 log10(RX0 margin / RX1 margin), dB")
    response_axes = fig.add_subplot(122)
    response_axes.scatter(enu[:, 0], response, s=7, alpha=0.3)
    response_axes.axhline(0, color="grey", lw=0.7)
    response_axes.axvline(0, color="grey", lw=0.7)
    response_axes.set(
        xlabel="East direction cosine (negative west, positive east)",
        ylabel="GLRT margin-ratio proxy (dB)",
        title="Higher RX0/RX1 proxy toward east\nPhysical receiver-to-LNB mapping remains unknown",
    )
    selection = "exact-membership" if args.exact else "preliminary interval-selected"
    fig.suptitle(
        f"{len(points)} {selection} calibration points · not an unbiased field-of-view map"
    )
    fig.savefig(args.output / "sky-response.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    main()

"""Held-out controls for dual-LNB NORAD-candidate corroboration.

Input is a storage-independent JSON export containing persisted Doppler rank-1
and rank-2 scores, candidate ENU directions at paired-response epochs, and
clear-track calibration points.  The calibration is locked to points before a
declared cutoff.  Correlated response samples are reduced to one factor per
track/pass, and calibration is bootstrapped by whole pass.

This diagnostic never reports identity probabilities.  Doppler residuals and
the GLRT-margin response share detections, so their contrasts remain separate.
Timing/CFO continuity is provenance only.  Signal classification as Starlink
is also distinct from identifying an individual NORAD object.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np

OLD_FREEZE_UTC_NS = 1789999014000000000
MINIMUM_PAIRED_POINTS = 3


def profile_rms_contrast(rank1_rms: float, rank2_rms: float, *, floor: float) -> float:
    """Descriptive persisted-Doppler contrast; positive favors rank 1.

    This bounded transform is not a likelihood ratio because the effective
    number and independence of residuals are not established here.
    """

    values = np.asarray([rank1_rms, rank2_rms, floor], dtype=float)
    if not np.all(np.isfinite(values)) or rank1_rms < 0 or rank2_rms < 0 or floor <= 0:
        raise ValueError("RMS values must be finite and nonnegative; floor must be positive")
    return float(0.5 * np.log((rank2_rms**2 + floor**2) / (rank1_rms**2 + floor**2)))


def pass_balanced_student_support(
    residual_db: np.ndarray | list[float],
    *,
    scale_db: float,
    point_weights: np.ndarray | list[float] | None = None,
) -> float:
    """Robust Student-t mean log-kernel with total pass weight one."""

    residual = np.asarray(residual_db, dtype=float)
    if residual.ndim != 1 or residual.size == 0 or not np.all(np.isfinite(residual)):
        raise ValueError("residual_db must be a nonempty finite vector")
    if not math.isfinite(scale_db) or scale_db <= 0:
        raise ValueError("scale_db must be finite and positive")
    if point_weights is None:
        weight = np.full(residual.size, 1.0 / residual.size)
    else:
        weight = np.asarray(point_weights, dtype=float)
        if (
            weight.shape != residual.shape
            or not np.all(np.isfinite(weight))
            or np.any(weight < 0)
            or np.sum(weight) <= 0
        ):
            raise ValueError("point_weights must be finite, nonnegative, and match residuals")
        weight = weight / np.sum(weight)
    kernel = -2.5 * np.log1p((residual / scale_db) ** 2 / 4.0)
    return float(weight @ kernel)


def doppler_stratum(rank1_rms: float, rank2_rms: float) -> str:
    """Predeclared rank-1/rank-2 evaluation-RMS ratio strata."""

    if not all(math.isfinite(v) and v >= 0 for v in (rank1_rms, rank2_rms)):
        return "unsupported"
    ratio = rank2_rms / max(rank1_rms, 1e-12)
    if ratio < 1.5:
        return "weak-less-than-1.5"
    if ratio < 3.0:
        return "intermediate-1.5-to-3"
    return "clear-at-least-3"


def _lane(row: dict[str, Any]) -> tuple[int, str]:
    return int(row["channel"]), str(row["edge"])


def _calibration_group(point: dict[str, Any]) -> tuple[Any, ...]:
    # All lanes for one satellite in one scan move together.  Treating lanes as
    # separate bootstrap units would understate shared pass/session errors.
    return point["session_id"], int(point["number"])


def _fit_model(
    points: list[dict[str, Any]],
    lanes: list[tuple[int, str]],
    group_indices: list[int],
    *,
    include_up: bool,
) -> dict[str, Any] | None:
    """Fit lane intercepts plus one global horizontal or 3-D response vector."""

    groups: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for point in points:
        groups[_calibration_group(point)].append(point)
    keys = sorted(groups)
    selected = [keys[index] for index in group_indices]
    design, response, weights = [], [], []
    for key in selected:
        rows = groups[key]
        for point in rows:
            enu = np.asarray(point["enu"], dtype=float)
            if enu.shape != (3,) or not np.all(np.isfinite(enu)):
                continue
            direction = enu.tolist() if include_up else enu[:2].tolist()
            design.append([float(_lane(point) == lane) for lane in lanes] + direction)
            response.append(float(point["proxy_db"]))
            weights.append(1.0 / len(rows))
    direction_columns = 3 if include_up else 2
    if len(design) < len(lanes) + direction_columns:
        return None
    x = np.asarray(design, dtype=float)
    y = np.asarray(response, dtype=float)
    weight = np.asarray(weights, dtype=float)
    root_weight = np.sqrt(weight)
    beta, _, rank, _ = np.linalg.lstsq(x * root_weight[:, None], y * root_weight, rcond=None)
    if rank < x.shape[1]:
        return None
    residual = y - x @ beta
    scale = float(np.sqrt(np.sum(weight * residual**2) / np.sum(weight)))
    if not math.isfinite(scale) or scale <= 0:
        return None
    vector = beta[-direction_columns:]
    vector_enu = vector if include_up else np.r_[vector, 0.0]
    horizontal = float(np.hypot(vector[0], vector[1]))
    return {
        "lane_intercepts": {f"{lane[0]}:{lane[1]}": float(beta[i]) for i, lane in enumerate(lanes)},
        "response_vector_enu": vector_enu.tolist(),
        "model_family": "east-north-up-sensitivity" if include_up else "east-north-primary",
        "calibration_residual_scale_db": scale,
        "response_heading_deg": float(np.degrees(np.arctan2(vector[0], vector[1])) % 360),
        "empirical_up_component_angle_deg": (
            float(np.degrees(np.arctan2(vector[2], horizontal))) if include_up else 0.0
        ),
        "calibration_weighted_rms_db": scale,
    }


def fit_calibration_models(
    calibration_points: list[dict[str, Any]],
    *,
    cutoff_utc_ns: int,
    bootstrap_trials: int,
    session_start_utc_ns: dict[str, int] | None = None,
    seed: int = 20260921,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Fit nominal and whole-pass bootstrap global response models."""

    pair_ids = [point.get("pair_id") for point in calibration_points if point.get("pair_id")]
    if len(pair_ids) != len(set(pair_ids)):
        raise ValueError("calibration pair_id values must be deduplicated")

    if session_start_utc_ns is None:
        session_start_utc_ns = {}
        for point in calibration_points:
            session = str(point["session_id"])
            session_start_utc_ns[session] = min(
                session_start_utc_ns.get(session, int(point["utc_ns"])), int(point["utc_ns"])
            )
    calibration_sessions = {
        session for session, start in session_start_utc_ns.items() if start < cutoff_utc_ns
    }
    # Freeze by whole scan session, not by point time.  A session can belong to
    # calibration or confirmation, never both.
    points = [
        point
        for point in calibration_points
        if str(point["session_id"]) in calibration_sessions
        and np.isfinite(float(point["proxy_db"]))
    ]
    groups: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for point in points:
        groups[_calibration_group(point)].append(point)
    keys = sorted(groups)
    lanes = sorted({_lane(point) for point in points})
    if len(keys) < 4 or not lanes:
        raise ValueError("insufficient pre-cutoff calibration passes")
    nominal = _fit_model(points, lanes, list(range(len(keys))), include_up=False)
    if nominal is None:
        raise ValueError("pre-cutoff calibration design is rank deficient")
    nominal["model_id"] = "nominal"
    models = [nominal]
    nominal_3d = _fit_model(points, lanes, list(range(len(keys))), include_up=True)
    if nominal_3d is None:
        raise ValueError("pre-cutoff 3-D calibration sensitivity design is rank deficient")
    nominal_3d["model_id"] = "nominal-3d-sensitivity"
    models.append(nominal_3d)
    rng = np.random.default_rng(seed)
    attempts = 0
    complete_bootstraps = 0
    while complete_bootstraps < bootstrap_trials and attempts < bootstrap_trials * 10:
        attempts += 1
        sampled = rng.choice(len(keys), size=len(keys), replace=True).tolist()
        horizontal = _fit_model(points, lanes, sampled, include_up=False)
        three_dimensional = _fit_model(points, lanes, sampled, include_up=True)
        if horizontal is not None and three_dimensional is not None:
            complete_bootstraps += 1
            horizontal["model_id"] = f"bootstrap-en-{complete_bootstraps:03d}"
            three_dimensional["model_id"] = f"bootstrap-enu-{complete_bootstraps:03d}"
            models.extend([horizontal, three_dimensional])
    if complete_bootstraps < bootstrap_trials:
        raise ValueError("could not construct requested full-rank calibration bootstraps")
    sensitivity = models[2:]
    nominal_heading = nominal["response_heading_deg"]
    heading_delta = [
        ((model["response_heading_deg"] - nominal_heading + 180) % 360) - 180
        for model in sensitivity
    ]
    heading_quantile = (
        nominal_heading + np.quantile(heading_delta, [0.05, 0.5, 0.95])
    ) % 360
    three_dimensional = [
        model for model in sensitivity if model["model_family"] == "east-north-up-sensitivity"
    ]
    metadata = {
        "cutoff_utc_ns": cutoff_utc_ns,
        "point_count": len(points),
        "input_point_count": len(calibration_points),
        "pair_id_deduplication_checked": bool(pair_ids),
        "unique_session_satellite_pass_count": len(keys),
        "catalog_numbers": sorted({int(point["number"]) for point in points}),
        "lanes": [list(lane) for lane in lanes],
        "bootstrap_trials": bootstrap_trials,
        "empirical_response_heading_deg_q05_median_q95": heading_quantile.tolist(),
        "empirical_3d_up_component_angle_deg_q05_median_q95": np.quantile(
            [model["empirical_up_component_angle_deg"] for model in three_dimensional],
            [0.05, 0.5, 0.95],
        ).tolist(),
        "orientation_interpretation": (
            "empirical response-vector sensitivity, not measured mechanical boresight or tilt"
        ),
        "model_families": ["east-north-primary", "east-north-up-sensitivity"],
        "physical_rx_to_lnb_mapping": "unresolved; response vector is defined only as RX0/RX1",
    }
    return models, metadata


def _score_candidate(
    candidate: dict[str, Any],
    response: np.ndarray,
    lane: tuple[int, str],
    model: dict[str, Any],
) -> dict[str, float] | None:
    enu = np.asarray(candidate.get("enu", []), dtype=float)
    if enu.shape != (response.size, 3) or not np.all(np.isfinite(enu)):
        return None
    lane_key = f"{lane[0]}:{lane[1]}"
    if lane_key not in model["lane_intercepts"]:
        return None
    predicted = float(model["lane_intercepts"][lane_key]) + enu @ np.asarray(
        model["response_vector_enu"], dtype=float
    )
    residual = response - predicted
    return {
        "rms_db": float(np.sqrt(np.mean(residual**2))),
        "bias_db": float(np.mean(residual)),
        "robust_support": pass_balanced_student_support(
            residual, scale_db=float(model["calibration_residual_scale_db"])
        ),
    }


def score_track(
    row: dict[str, Any],
    models: list[dict[str, Any]],
    *,
    cutoff_utc_ns: int,
    session_start_utc_ns: int | None = None,
) -> dict[str, Any]:
    """Score one persisted rank-1/rank-2 pair under global calibration models."""

    candidates = row.get("candidates", [])[:2]
    base = {
        "visibility_status": "unobstructed-visibility-unknown",
        "identity_evidence_use": "descriptive-response-consistency-only",
        "reject_identity_on_response_mismatch": False,
        "reject_identity_on_missing_detection": False,
        "session_id": row["session_id"],
        "tracklet_id": row["tracklet_id"],
        "receiver_id": int(row["receiver_id"]),
        "channel": int(row["channel"]),
        "edge": row["edge"],
        "start_utc_ns": int(row["start_utc_ns"]),
        "pass_key": row["pass_key"],
        "session_start_utc_ns": (
            int(row["start_utc_ns"]) if session_start_utc_ns is None else session_start_utc_ns
        ),
        "confirmatory_after_prior_freeze": (
            int(row["start_utc_ns"]) if session_start_utc_ns is None else session_start_utc_ns
        )
        >= cutoff_utc_ns,
    }
    if len(candidates) < 2:
        return {**base, "state": "unsupported", "reason": "fewer-than-two-candidates"}
    doppler = {
        "rank1_training_rms_hz": candidates[0].get("training_rms_hz"),
        "rank2_training_rms_hz": candidates[1].get("training_rms_hz"),
        "rank1_evaluation_rms_hz": candidates[0].get("evaluation_rms_hz"),
        "rank2_evaluation_rms_hz": candidates[1].get("evaluation_rms_hz"),
    }
    try:
        rank1_rms = float(candidates[0]["evaluation_rms_hz"])
        rank2_rms = float(candidates[1]["evaluation_rms_hz"])
        doppler["evaluation_rms_ratio_rank2_over_rank1"] = rank2_rms / max(rank1_rms, 1e-12)
        doppler["stratum"] = doppler_stratum(rank1_rms, rank2_rms)
        doppler["profile_rms_contrast"] = profile_rms_contrast(
            rank1_rms, rank2_rms, floor=max(rank1_rms, 100.0)
        )
    except (KeyError, TypeError, ValueError):
        doppler["stratum"] = "unsupported"
    base["doppler"] = doppler
    base["rank1_catalog_number"] = int(candidates[0]["number"])
    base["rank2_catalog_number"] = int(candidates[1]["number"])
    pairs = row.get("pairs", [])
    base["continuity"] = {
        "paired_point_count": len(pairs),
        "distinct_visit_count": len({pair["visit_index"] for pair in pairs}),
        "rx0_tracklet_ids": sorted({pair["rx0_tracklet_id"] for pair in pairs}),
        "rx1_tracklet_ids": sorted({pair["rx1_tracklet_id"] for pair in pairs}),
        "role": "provenance-only-not-an-independent-identity-factor",
    }
    if len(pairs) < MINIMUM_PAIRED_POINTS:
        return {**base, "state": "unsupported", "reason": "fewer-than-three-paired-points"}
    if any(candidate.get("state") != "scored" for candidate in candidates):
        return {**base, "state": "unsupported", "reason": "candidate-orbit-not-scored"}
    response = np.asarray([pair["proxy_db"] for pair in pairs], dtype=float)
    if not np.all(np.isfinite(response)):
        return {**base, "state": "unsupported", "reason": "nonfinite-response"}
    contrasts, rms_differences, nominal_scores = [], [], None
    for index, model in enumerate(models):
        scores = [
            _score_candidate(candidate, response, _lane(row), model)
            for candidate in candidates
        ]
        if any(score is None for score in scores):
            continue
        assert scores[0] is not None and scores[1] is not None
        contrasts.append(scores[0]["robust_support"] - scores[1]["robust_support"])
        rms_differences.append(scores[1]["rms_db"] - scores[0]["rms_db"])
        if index == 0:
            nominal_scores = scores
    if nominal_scores is None or len(contrasts) != len(models):
        return {**base, "state": "unsupported", "reason": "unsupported-calibration-lane-or-enu"}
    bootstrap = np.asarray(contrasts[1:], dtype=float)
    q05, median, q95 = np.quantile(bootstrap, [0.05, 0.5, 0.95])
    if q05 > 0:
        category = "corroborates-rank-1"
    elif q95 < 0:
        category = "contradicts-rank-1"
    else:
        category = "orientation-calibration-uncertain"
    return {
        **base,
        "state": "scored",
        "beam_category": category,
        "beam_category_interpretation": (
            "response-model mismatch; obstruction or calibration may explain it; not ID evidence"
            if category == "contradicts-rank-1"
            else "conditional response consistency; unobstructed visibility is not established"
        ),
        "beam": {
            "rank1_nominal": nominal_scores[0],
            "rank2_nominal": nominal_scores[1],
            "nominal_robust_support_contrast": contrasts[0],
            "nominal_runner_minus_rank1_rms_db": rms_differences[0],
            "bootstrap_robust_contrast_q05_median_q95": [float(q05), float(median), float(q95)],
            "bootstrap_runner_minus_rank1_rms_db_q05_median_q95": np.quantile(
                rms_differences[1:], [0.05, 0.5, 0.95]
            ).tolist(),
            "factor_weight": "one normalized factor for this track/pass",
        },
    }


def _outcome_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    return dict(Counter(row.get("beam_category", "unsupported") for row in rows))


def _pass_outcomes(rows: list[dict[str, Any]]) -> dict[str, str]:
    grouped: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        grouped[row["pass_key"]].add(row.get("beam_category", "unsupported"))
    output = {}
    for key, states in grouped.items():
        informative = states - {"unsupported"}
        output[key] = next(iter(informative)) if len(informative) == 1 else (
            "unsupported" if not informative else "mixed-correlated-tracks"
        )
    return output


def _nominal_pass_sign_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    grouped: dict[str, set[bool]] = defaultdict(set)
    for row in rows:
        if row["state"] == "scored":
            grouped[row["pass_key"]].add(row["beam"]["nominal_robust_support_contrast"] > 0)
    return {
        "scored_unique_passes": len(grouped),
        "rank1_favored_only": sum(states == {True} for states in grouped.values()),
        "rank2_favored_only": sum(states == {False} for states in grouped.values()),
        "mixed_correlated_tracks": sum(len(states) > 1 for states in grouped.values()),
    }


def pass_level_nulls(
    source_rows: list[dict[str, Any]],
    scored_rows: list[dict[str, Any]],
    nominal_model: dict[str, Any],
    *,
    window_start_utc_ns: int,
    trials: int,
    seed: int = 2026092100,
) -> list[dict[str, Any]]:
    """Shuffle whole-pass response levels within lane and one-hour time block."""

    usable_source = {
        (row["session_id"], row["tracklet_id"]): row
        for row in source_rows
        if len(row.get("pairs", [])) >= MINIMUM_PAIRED_POINTS
    }
    units: dict[tuple[str, int, str], list[dict[str, Any]]] = defaultdict(list)
    for result in scored_rows:
        source = usable_source.get((result["session_id"], result["tracklet_id"]))
        if source is not None:
            units[(result["pass_key"], result["channel"], result["edge"])].append(source)
    means = {
        key: float(np.mean([pair["proxy_db"] for row in rows for pair in row["pairs"]]))
        for key, rows in units.items()
    }
    strata: dict[tuple[int, str, int], list[tuple[str, int, str]]] = defaultdict(list)
    for key, rows in units.items():
        start = min(int(row["start_utc_ns"]) for row in rows)
        block = (start - window_start_utc_ns) // (3600 * 10**9)
        strata[(key[1], key[2], int(block))].append(key)
    rng = np.random.default_rng(seed)
    outputs = []
    for trial in range(trials):
        shuffled = dict(means)
        for keys in strata.values():
            values = [means[key] for key in keys]
            permuted = rng.permutation(values)
            shuffled.update(zip(keys, permuted, strict=True))
        signs, pass_signs = [], defaultdict(set)
        for key, rows in units.items():
            shift = shuffled[key] - means[key]
            for row in rows:
                response = np.asarray([pair["proxy_db"] for pair in row["pairs"]]) + shift
                scores = [
                    _score_candidate(candidate, response, _lane(row), nominal_model)
                    for candidate in row["candidates"][:2]
                ]
                if len(scores) < 2 or any(score is None for score in scores):
                    continue
                assert scores[0] is not None and scores[1] is not None
                contrast = scores[0]["robust_support"] - scores[1]["robust_support"]
                signs.append(contrast > 0)
                pass_signs[key[0]].add(contrast > 0)
        outputs.append(
            {
                "seed": seed + trial,
                "rank1_favored_track_count": int(np.count_nonzero(signs)),
                "scored_track_count": len(signs),
                "rank1_favored_unique_pass_count": sum(
                    states == {True} for states in pass_signs.values()
                ),
                "mixed_unique_pass_count": sum(len(states) > 1 for states in pass_signs.values()),
                "unique_pass_count": len(pass_signs),
            }
        )
    return outputs


def analyze(
    source: dict[str, Any],
    *,
    cutoff_utc_ns: int = OLD_FREEZE_UTC_NS,
    bootstrap_trials: int = 100,
    null_trials: int = 100,
) -> dict[str, Any]:
    session_starts: dict[str, int] = {}
    for point in source["calibration_points"]:
        session = str(point["session_id"])
        session_starts[session] = min(
            session_starts.get(session, int(point["utc_ns"])), int(point["utc_ns"])
        )
    for row in source["tracks"]:
        session = str(row["session_id"])
        session_starts[session] = min(
            session_starts.get(session, int(row["start_utc_ns"])), int(row["start_utc_ns"])
        )
    models, calibration = fit_calibration_models(
        source["calibration_points"],
        cutoff_utc_ns=cutoff_utc_ns,
        bootstrap_trials=bootstrap_trials,
        session_start_utc_ns=session_starts,
    )
    rows = [
        score_track(
            row,
            models,
            cutoff_utc_ns=cutoff_utc_ns,
            session_start_utc_ns=session_starts[str(row["session_id"])],
        )
        for row in source["tracks"]
    ]
    scored = [row for row in rows if row["state"] == "scored"]
    confirmatory = [row for row in rows if row["confirmatory_after_prior_freeze"]]
    confirmatory_scored = [row for row in confirmatory if row["state"] == "scored"]
    calibration_numbers = set(calibration["catalog_numbers"])
    for row in rows:
        row["rank1_seen_in_calibration"] = row.get("rank1_catalog_number") in calibration_numbers
        row["rank2_seen_in_calibration"] = row.get("rank2_catalog_number") in calibration_numbers
    unseen_confirmatory = [
        row for row in confirmatory if not row["rank1_seen_in_calibration"]
    ]
    unseen_confirmatory_scored = [row for row in unseen_confirmatory if row["state"] == "scored"]
    pass_outcomes = _pass_outcomes(rows)
    confirmatory_pass_outcomes = _pass_outcomes(confirmatory)
    nulls = pass_level_nulls(
        source["tracks"],
        scored,
        models[0],
        window_start_utc_ns=int(source["window_start_utc_ns"]),
        trials=null_trials,
    )
    confirmatory_nulls = pass_level_nulls(
        source["tracks"],
        confirmatory_scored,
        models[0],
        window_start_utc_ns=int(source["window_start_utc_ns"]),
        trials=null_trials,
        seed=2026092200,
    )
    nominal_passes = _nominal_pass_sign_counts(rows)
    confirmatory_nominal_passes = _nominal_pass_sign_counts(confirmatory)
    actual_track_wins = sum(
        row["beam"]["nominal_robust_support_contrast"] > 0 for row in scored
    )
    actual_confirmatory_track_wins = sum(
        row["beam"]["nominal_robust_support_contrast"] > 0 for row in confirmatory_scored
    )

    def plus_one_tail(null_rows: list[dict[str, Any]], field: str, actual: int) -> float:
        return (1 + sum(row[field] >= actual for row in null_rows)) / (len(null_rows) + 1)
    return {
        "schema_version": 1,
        "scope": {
            "window_start_utc_ns": int(source["window_start_utc_ns"]),
            "window_end_utc_ns": int(source["window_end_utc_ns"]),
            "prior_report_freeze_utc_ns": cutoff_utc_ns,
            "confirmatory_definition": "whole scan session starts at or after prior report freeze",
            "temporal_status": (
                "previously unused late scans analyzed by a protocol implemented after capture; "
                "not prospective identity truth"
            ),
        },
        "calibration": calibration,
        "counts": {
            "all_tracks": len(rows),
            "all_unique_passes": len(pass_outcomes),
            "scored_tracks": len(scored),
            "nominal_rank1_favored_scored_tracks": actual_track_wins,
            "nominal_unique_pass_signs": nominal_passes,
            "track_outcomes": _outcome_counts(rows),
            "unique_pass_outcomes": dict(Counter(pass_outcomes.values())),
            "confirmatory_tracks": len(confirmatory),
            "confirmatory_unique_passes": len(confirmatory_pass_outcomes),
            "confirmatory_scored_tracks": len(confirmatory_scored),
            "confirmatory_nominal_rank1_favored_scored_tracks": (
                actual_confirmatory_track_wins
            ),
            "confirmatory_nominal_unique_pass_signs": confirmatory_nominal_passes,
            "confirmatory_track_outcomes": _outcome_counts(confirmatory),
            "confirmatory_unique_pass_outcomes": dict(
                Counter(confirmatory_pass_outcomes.values())
            ),
            "unseen_rank1_confirmatory_tracks": len(unseen_confirmatory),
            "unseen_rank1_confirmatory_scored_tracks": len(unseen_confirmatory_scored),
            "unseen_rank1_confirmatory_track_outcomes": _outcome_counts(
                unseen_confirmatory
            ),
            "unseen_rank1_confirmatory_unique_pass_outcomes": dict(
                Counter(_pass_outcomes(unseen_confirmatory).values())
            ),
            "doppler_strata": dict(
                Counter(row.get("doppler", {}).get("stratum", "unsupported") for row in rows)
            ),
        },
        "pass_level_response_mean_nulls": nulls,
        "confirmatory_pass_level_response_mean_nulls": confirmatory_nulls,
        "null_comparisons": {
            "all_track_plus_one_upper_tail": plus_one_tail(
                nulls, "rank1_favored_track_count", actual_track_wins
            ),
            "all_unique_pass_plus_one_upper_tail": plus_one_tail(
                nulls,
                "rank1_favored_unique_pass_count",
                nominal_passes["rank1_favored_only"],
            ),
            "confirmatory_track_plus_one_upper_tail": plus_one_tail(
                confirmatory_nulls,
                "rank1_favored_track_count",
                actual_confirmatory_track_wins,
            ),
            "confirmatory_unique_pass_plus_one_upper_tail": plus_one_tail(
                confirmatory_nulls,
                "rank1_favored_unique_pass_count",
                confirmatory_nominal_passes["rank1_favored_only"],
            ),
            "interpretation": (
                "descriptive permutation tail fractions; correlated tracks and absent identity "
                "truth prevent interpreting them as false-identification probabilities"
            ),
        },
        "tracks": rows,
        "limitations": [
            "geometric visibility does not establish an unobstructed path to either receiver",
            "unmodeled common or differential obstruction can attenuate or censor detections",
            "response mismatch or missing detections alone must not reject Starlink or NORAD ID",
            "contradicts-rank-1 is a legacy response-model category, not identity contradiction",
            "calibration labels are clear Doppler leaders, not independent NORAD truth",
            "agreement and contradiction counts are not accuracy or false-identity rates",
            "Doppler and response margins share GLRT-derived detections and are not multiplied",
            "timing/CFO continuity is provenance and is not an extra identity factor",
            "RX-to-physical-LNB mapping and absolute RF orientation remain uncalibrated",
            "Starlink signal classification does not identify an individual NORAD object",
        ],
    }


def render_plots(output: dict[str, Any], output_dir: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = [row for row in output["tracks"] if row["state"] == "scored"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    colors = {
        "corroborates-rank-1": "C0",
        "contradicts-rank-1": "C3",
        "orientation-calibration-uncertain": "0.5",
    }
    labels = {
        "corroborates-rank-1": "Conditional rank-1 consistency",
        "contradicts-rank-1": "Response mismatch; obstruction unresolved",
        "orientation-calibration-uncertain": "Calibration/model uncertain",
    }
    for category, color in colors.items():
        selected = [row for row in rows if row["beam_category"] == category]
        axes[0].scatter(
            [row["doppler"]["evaluation_rms_ratio_rank2_over_rank1"] for row in selected],
            [row["beam"]["bootstrap_robust_contrast_q05_median_q95"][1] for row in selected],
            c=color,
            s=22,
            alpha=0.7,
            label=labels[category],
        )
    axes[0].axhline(0, color="black", lw=1)
    axes[0].axvline(1.5, color="black", ls="--", lw=0.8)
    axes[0].axvline(3.0, color="black", ls="--", lw=0.8)
    axes[0].set(
        xlabel="Persisted Doppler evaluation RMS ratio (rank 2 / rank 1)",
        ylabel="Median bootstrapped beam support contrast",
        xscale="log",
    )
    axes[0].legend(fontsize=8)
    null_counts = [
        row["rank1_favored_track_count"]
        for row in output["pass_level_response_mean_nulls"]
    ]
    axes[1].hist(null_counts, bins="auto", color="0.6")
    actual = sum(
        row["beam"]["nominal_robust_support_contrast"] > 0 for row in rows
    )
    axes[1].axvline(actual, color="C1", lw=2, label="actual nominal sign wins")
    axes[1].set(
        xlabel="Tracks favoring persisted rank 1",
        ylabel="Pass-level response-mean shuffle trials",
    )
    axes[1].legend(fontsize=8)
    for axis in axes:
        axis.grid(alpha=0.2)
    fig.suptitle("Dual-LNB candidate corroboration controls (descriptive, no identity truth)")
    fig.savefig(output_dir / "candidate-controls.png", dpi=170)
    plt.close(fig)

    late_rows = [row for row in rows if row["confirmatory_after_prior_freeze"]]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    for category, color in colors.items():
        selected = [row for row in late_rows if row["beam_category"] == category]
        axes[0].scatter(
            [row["doppler"]["evaluation_rms_ratio_rank2_over_rank1"] for row in selected],
            [row["beam"]["bootstrap_robust_contrast_q05_median_q95"][1] for row in selected],
            c=color,
            s=26,
            alpha=0.75,
            label=labels[category],
        )
    axes[0].axhline(0, color="black", lw=1)
    axes[0].axvline(1.5, color="black", ls="--", lw=0.8)
    axes[0].axvline(3.0, color="black", ls="--", lw=0.8)
    axes[0].set(
        xlabel="Persisted Doppler evaluation RMS ratio (rank 2 / rank 1)",
        ylabel="Median bootstrapped beam support contrast",
        xscale="log",
    )
    axes[0].legend(fontsize=8)
    late_null_counts = [
        row["rank1_favored_track_count"]
        for row in output["confirmatory_pass_level_response_mean_nulls"]
    ]
    axes[1].hist(late_null_counts, bins="auto", color="0.6")
    late_actual = sum(
        row["beam"]["nominal_robust_support_contrast"] > 0 for row in late_rows
    )
    axes[1].axvline(late_actual, color="C1", lw=2, label="actual nominal sign wins")
    axes[1].set(
        xlabel="Post-cutoff tracks favoring persisted rank 1",
        ylabel="Pass-level response-mean shuffle trials",
    )
    axes[1].legend(fontsize=8)
    for axis in axes:
        axis.grid(alpha=0.2)
    fig.suptitle(
        "Post-cutoff confirmation: 12 complete scans\n"
        "Previously unused late scans; no independent NORAD identity truth"
    )
    fig.savefig(output_dir / "candidate-controls-late.png", dpi=170)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--old-freeze-utc-ns", type=int, default=OLD_FREEZE_UTC_NS)
    parser.add_argument("--bootstrap-trials", type=int, default=100)
    parser.add_argument("--null-trials", type=int, default=100)
    args = parser.parse_args()
    source = json.loads(args.input.read_text())
    output = analyze(
        source,
        cutoff_utc_ns=args.old_freeze_utc_ns,
        bootstrap_trials=args.bootstrap_trials,
        null_trials=args.null_trials,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "scoring.json").write_text(json.dumps(output, indent=2) + "\n")
    render_plots(output, args.output_dir)
    print(json.dumps(output["counts"], sort_keys=True))


if __name__ == "__main__":
    main()

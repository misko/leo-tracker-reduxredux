"""Show representative corroboration and counterexamples from the locked beam audit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from research_dual_lnb_identity_controls import fit_calibration_models


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.input.read_text())
    results = json.loads(args.results.read_text())
    starts: dict[str, int] = {}
    for row in results["tracks"]:
        starts[row["session_id"]] = row["session_start_utc_ns"]
    models, _ = fit_calibration_models(
        source["calibration_points"],
        cutoff_utc_ns=results["scope"]["prior_report_freeze_utc_ns"],
        bootstrap_trials=1,
        session_start_utc_ns=starts,
    )
    model = models[0]
    source_by_track = {(r["session_id"], r["tracklet_id"]): r for r in source["tracks"]}
    categories = ["corroborates-rank-1", "contradicts-rank-1", "orientation-calibration-uncertain"]
    labels = {
        "corroborates-rank-1": "Conditional response consistency",
        "contradicts-rank-1": "Response mismatch: obstruction unresolved",
        "orientation-calibration-uncertain": "Calibration/model uncertain",
    }
    fig, axes = plt.subplots(3, 2, figsize=(13, 12), constrained_layout=True)
    selected = []
    for index, category in enumerate(categories):
        eligible = [r for r in results["tracks"] if r.get("beam_category") == category]
        if not eligible:
            for ax in axes[index]:
                ax.text(0.5, 0.5, f"No {category} examples", transform=ax.transAxes, ha="center")
            continue
        # Explicit illustrative selection, not a representative random sample.
        row = max(
            eligible,
            key=lambda r: (
                r["confirmatory_after_prior_freeze"],
                r["continuity"]["paired_point_count"],
            ),
        )
        selected.append(row)
        original = source_by_track[row["session_id"], row["tracklet_id"]]
        pairs = original["pairs"]
        seconds = np.asarray([(p["utc_ns"] - row["start_utc_ns"]) / 1e9 for p in pairs])
        measured = np.asarray([p["proxy_db"] for p in pairs])
        axes[index, 0].plot(seconds, measured, "k.", label="Paired GLRT margin ratio")
        for candidate in original["candidates"][:2]:
            prediction = model["lane_intercepts"][f"{row['channel']}:{row['edge']}"] + np.asarray(
                candidate["enu"]
            ) @ np.asarray(model["response_vector_enu"])
            label = f"#{candidate['rank']} NORAD {candidate['number']}"
            axes[index, 0].plot(seconds, prediction, ".-", ms=2, label=label)
            axes[index, 1].plot(seconds, measured - prediction, ".", label=label)
        axes[index, 0].set_title(
            f"{labels[category]}\n{row['session_id']} · RX{row['receiver_id']} "
            f"CH{row['channel']} {row['edge']}"
        )
        doppler = row["doppler"]
        axes[index, 1].set_title(
            f"Doppler evaluation RMS: {doppler['rank1_evaluation_rms_hz']:.1f} / "
            f"{doppler['rank2_evaluation_rms_hz']:.1f} Hz\n"
            f"Beam nominal RMS: {row['beam']['rank1_nominal']['rms_db']:.2f} / "
            f"{row['beam']['rank2_nominal']['rms_db']:.2f} dB"
        )
        for ax in axes[index]:
            ax.set_xlabel("Seconds since this track starts")
            ax.legend(fontsize=8)
            ax.grid(alpha=0.2)
        axes[index, 0].set_ylabel("GLRT margin-ratio proxy (dB)")
        axes[index, 1].set_ylabel("Measured minus predicted proxy (dB)")
        axes[index, 1].axhline(0, color="grey", lw=0.7)
    fig.suptitle(
        "Illustrative longest paired example per outcome; late scans preferred\n"
        "Nominal locked calibration; these are not independently verified satellite IDs"
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=170)
    args.output.with_suffix(".json").write_text(json.dumps(selected, indent=2) + "\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Audit frozen fits against exact propagation; never refit or select on site error."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from benchmark_dual_lnb_fusion import doppler_hz, parse_element_sets, propagate

from leo.analysis.research.regional_doppler import Region
from leo.operations.tle_archive import TleArchiveReader


def interpolate(nodes, values, at):
    result = np.zeros_like(values[0])
    for i, node in enumerate(nodes):
        weight = np.ones_like(at)
        for j, other in enumerate(nodes):
            if j != i:
                weight *= (at - other) / (node - other)
        result += weight[:, None] * values[i]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    args = parser.parse_args()
    data = np.load(args.prepared)
    receipt = json.loads(args.receipt.read_text())
    archive = TleArchiveReader(args.tle_archive)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogues = {}
    out = {"refit": False, "models": {}}
    for prefix, arm in [
        ("baseline", "anchor-excluded-baseline"),
        ("fused", "uncertainty-aware-fusion"),
    ]:

        def get(name, prefix=prefix):
            return data[prefix + "__" + name]

        fit = receipt["fits"][arm]["result"]
        receiver = Region(**receipt["region"]).points([fit["x_km"][0]], [fit["x_km"][1]]).ecef_km[0]
        source, age, time = get("source"), get("age_h"), get("time_s")
        shifts = age * np.array([fit["rate_corrections_s_h"][str(x)] for x in source])
        snapshots = data[prefix + "_snapshot_digest"]
        errors = {key: np.empty(len(time)) for key in ("quadratic", "quartic")}
        for snapshot, number in sorted(set(zip(snapshots, source, strict=True))):
            rows = np.flatnonzero((snapshots == snapshot) & (source == number))
            if snapshot not in catalogues:
                catalogues[snapshot] = parse_element_sets(archive.read(references[snapshot]))
            catalogue = catalogues[snapshot]
            idx = list(catalogue.satellite_numbers).index(int(number))
            utc = np.rint(time[rows] * 1e9).astype(np.int64)
            exact = propagate(
                catalogue, idx, np.rint(time[rows] * 1e9 + shifts[rows] * 1e9).astype(np.int64)
            )
            states = {
                0: (get("p_km")[rows], get("v_km_s")[rows]),
                -1: (get("phase_p_minus_km")[rows], get("phase_v_minus_km_s")[rows]),
                1: (get("phase_p_plus_km")[rows], get("phase_v_plus_km_s")[rows]),
            }
            for node in (-2, 2):
                states[node] = propagate(catalogue, idx, utc + node * 1_000_000_000)
            exact_d = doppler_hz(receiver, *exact)
            for key, nodes in [("quadratic", [-1, 0, 1]), ("quartic", [-2, -1, 0, 1, 2])]:
                p, v = [
                    interpolate(nodes, [states[node][component] for node in nodes], shifts[rows])
                    for component in (0, 1)
                ]
                errors[key][rows] = doppler_hz(receiver, p, v) - exact_d
        summary = {
            "observations": len(time),
            "outside_original_1s_stencil": int(sum(abs(shifts) > 1)),
            "max_absolute_phase_s": float(max(abs(shifts))),
            "methods": {},
        }
        for key, error in errors.items():
            worst = int(np.argmax(abs(error)))
            summary["methods"][key] = {
                "rms_hz": float(np.sqrt(np.mean(error**2))),
                "max_absolute_hz": float(max(abs(error))),
                "passes_0_2hz_gate": bool(max(abs(error)) <= 0.2),
                "worst_norad": int(source[worst]),
                "worst_age_h": float(age[worst]),
                "worst_phase_s": float(shifts[worst]),
                "worst_observation_id": str(get("observation_id")[worst]),
            }
        out["models"][arm] = summary
        print(json.dumps({arm: summary}), flush=True)
        args.output.write_text(json.dumps(out, indent=2) + "\n")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Build and compare a full current-corpus Doppler/dual-LNB formal fit.

This is a bounded retrospective adapter for the cached LT3D-001A research
export.  It reconstructs exact published track points, uses one representative
for RX0/RX1 paths that have both the same review leader and observed timing
anchors, and retains single-receiver paths.  Both fitted arms receive the same
Doppler observations; the geometry arm adds one cross-NORAD-calibrated beam
representative per session/satellite pass.

The persisted tracking reviews and beam calibration are conditional on the
configured observer site.  Results are therefore local retrospective research,
not blind positioning evidence.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np

from leo.analysis.persistent_hop_trajectory import reconstruct_persistent_hop_trajectories
from leo.analysis.research.dual_lnb_tracking import DualLnbBeamData, EastWestBeamCalibration
from leo.analysis.research.formal_orbit import (
    FormalOrbitConfig,
    FormalOrbitData,
    doppler_hz,
    fit_formal_orbit,
)
from leo.analysis.research.regional_doppler import Region
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.contracts.scanner_tracking import TrackingCandidate, TrackingInput, TrackingProbe
from leo.operations.tle_archive import TleArchiveReader
from leo.scanner.persistent_hop import PersistentHopUtcTimingAuthorityV1
from leo.sky.frames import greenwich_mean_sidereal_time_rad, julian_day_from_utc_ns, teme_to_ecef
from leo.sky.propagation import parse_element_sets

SCHEMA = "org.leo.research.dual-lnb-full-corpus/v1"
DEFAULT_SITE = (37.84903264307456, -122.4856541910174)
DEFAULT_REGION = {
    "latitude_deg": 39.7392,
    "longitude_deg": -104.9903,
    "width_km": 14484.096,
    "height_km": 14484.096,
}


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def read_document(path: Path) -> dict[str, Any]:
    payload = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(payload)


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def tracking_input(value: dict[str, Any]) -> TrackingInput:
    timing = value.get("timing")
    return TrackingInput(
        session_id=str(value["session_id"]),
        capture_mode=value["capture_mode"],
        sample_rate_hz=int(value["sample_rate_hz"]),
        radio_id=str(value["radio_id"]),
        stream_generation=str(value["stream_generation"]),
        input_manifest_sha256=str(value["input_manifest_sha256"]),
        analysis_manifest_sha256=str(value["analysis_manifest_sha256"]),
        raw_recording_authority_digest=str(value["raw_recording_authority_digest"]),
        timing=(
            None if timing is None else PersistentHopUtcTimingAuthorityV1.model_validate(timing)
        ),
        qualified=bool(value["qualified"]),
        probes=tuple(
            TrackingProbe(
                visit_index=int(probe["visit_index"]),
                receiver_id=int(probe["receiver_id"]),
                probe_index=int(probe["probe_index"]),
                probe_start_ms=int(probe["probe_start_ms"]),
                channel=int(probe["channel"]),
                edge=str(probe["edge"]),
                actual_rf_hz=float(probe["actual_rf_hz"]),
                valid_start_counter=int(probe["valid_start_counter"]),
                payload_start_sample=int(probe["payload_start_sample"]),
                candidates=tuple(
                    TrackingCandidate(**candidate) for candidate in probe["candidates"]
                ),
            )
            for probe in value["probes"]
        ),
        probe_ms=int(value.get("probe_ms", 20)),
        capture_start_utc_ns=value.get("capture_start_utc_ns"),
        capture_end_utc_ns=value.get("capture_end_utc_ns"),
    )


def accepted_reviews(product: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    accepted: dict[str, Any] = {}
    rejected: dict[str, str] = {}
    for review in product.get("track_reviews", []):
        tracklet_id = str(review["tracklet_id"])
        candidates = review.get("candidates", [])
        if len(candidates) < 2:
            rejected[tracklet_id] = "review-has-no-runner-up"
            continue
        leader, runner = candidates[:2]
        leader_rms = float(leader["randomized_evaluation_rms_hz"])
        runner_rms = float(runner["randomized_evaluation_rms_hz"])
        if leader_rms > 150.0:
            rejected[tracklet_id] = "review-leader-rms-above-150-hz"
        elif runner_rms < 3.0 * max(leader_rms, 1.0):
            rejected[tracklet_id] = "review-runner-up-not-three-times-worse"
        else:
            accepted[tracklet_id] = leader
    return accepted, rejected


class DisjointSet:
    def __init__(self, values: list[str]):
        self.parent = {value: value for value in values}

    def root(self, value: str) -> str:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def join(self, left: str, right: str) -> None:
        a, b = self.root(left), self.root(right)
        if a != b:
            self.parent[b] = a


def timing_anchor_counts(geometry: list[dict[str, Any]]) -> Counter[tuple[str, str, str]]:
    return Counter(
        (str(row["session_id"]), str(row["tracklet_id"]), str(row["tracklet_id_rx1"]))
        for row in geometry
    )


def propagate(catalogue, index: int, utc_ns: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    jd, fraction = julian_day_from_utc_ns(utc_ns.astype(np.int64))
    error, position, velocity = catalogue.satellites[index].sgp4_array(jd, fraction)
    if np.any(error):
        raise ValueError("strict-causal catalogue propagation failed")
    return teme_to_ecef(position, velocity, greenwich_mean_sidereal_time_rad(jd, fraction))


def calibration_by_fold(geometry: list[dict[str, Any]]) -> dict[int, tuple[float, float, float]]:
    response = np.asarray([row["proxy_db"] for row in geometry], float)
    east = np.asarray([row["enu"][0] for row in geometry], float)
    lanes = sorted({(int(row["channel"]), str(row["edge"])) for row in geometry})
    lane = np.asarray([lanes.index((int(row["channel"]), str(row["edge"]))) for row in geometry])
    intercept = np.eye(len(lanes))[lane]
    folds = np.asarray([int(row["number"]) % 3 for row in geometry])
    groups = [
        (str(row["session_id"]), int(row["number"]), int(row["channel"]), str(row["edge"]))
        for row in geometry
    ]
    sizes = Counter(groups)
    weight = np.asarray([1.0 / sizes[group] for group in groups])
    design = np.column_stack([intercept, east])
    result = {}
    for fold in range(3):
        selected = folds != fold
        root = np.sqrt(weight[selected])
        beta = np.linalg.lstsq(
            design[selected] * root[:, None], response[selected] * root, rcond=None
        )[0]
        residual = response[selected] - design[selected] @ beta
        sigma = float(np.sqrt(np.average(residual**2, weights=weight[selected])))
        result[fold] = (float(beta[-1]), sigma, float(len(lanes)))
        for lane_index in range(len(lanes)):
            result[fold * 1000 + lane_index] = (float(beta[lane_index]), sigma, float(beta[-1]))
    return result


def build_corpus(
    source_dir: Path,
    geometry_document: dict[str, Any],
    archive_root: Path,
    *,
    max_scans: int,
    max_tracks: int,
) -> tuple[FormalOrbitData, DualLnbBeamData | None, dict[str, Any], dict[str, np.ndarray]]:
    geometry = list(geometry_document["geometry_proxy_points"])
    anchors = timing_anchor_counts(geometry)
    archive = TleArchiveReader(archive_root)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogue_cache: dict[str, Any] = {}
    arrays: dict[str, list[Any]] = {
        key: []
        for key in (
            "y_hz",
            "training",
            "segment",
            "track",
            "source",
            "age_h",
            "p_km",
            "v_km_s",
            "phase_p_minus_km",
            "phase_v_minus_km_s",
            "phase_p_plus_km",
            "phase_v_plus_km_s",
            "time_s",
            "observation_id",
        )
    }
    selected_rows: list[dict[str, Any]] = []
    selected_track_points: dict[tuple[str, str], list[tuple[int, int]]] = {}
    rejection_counts: Counter[str] = Counter()
    scan_rows = []
    paths = sorted(source_dir.glob("*.json.gz"))[:max_scans]
    for scan_index, path in enumerate(paths):
        document = read_document(path)
        product = document.get("tracking")
        raw_source = document.get("source")
        if not product or not raw_source:
            rejection_counts["missing-source-or-tracking"] += 1
            continue
        source = tracking_input(raw_source)
        candidates = project_scanner_candidates(source)
        trajectory = reconstruct_persistent_hop_trajectories(candidates)
        rebuilt = {track.tracklet_id: track for track in trajectory.tracklets}
        published = {str(track["tracklet_id"]): track for track in product.get("tracklets", [])}
        if set(rebuilt) != set(published):
            raise ValueError(f"reconstructed tracklet inventory differs: {path}")
        candidate_by_id = {candidate.candidate_id: candidate for candidate in candidates}
        accepted, rejected = accepted_reviews(product)
        rejection_counts.update(rejected.values())
        rejection_counts["unreviewed-tracklet"] += len(
            set(published) - set(accepted) - set(rejected)
        )
        eligible = set(accepted) & set(rebuilt)
        union = DisjointSet(sorted(eligible))
        session_id = str(document["session_id"])
        for (anchor_session, rx0, rx1), count in anchors.items():
            if (
                anchor_session != session_id
                or count < 3
                or rx0 not in eligible
                or rx1 not in eligible
            ):
                continue
            if int(accepted[rx0]["catalog_number"]) == int(accepted[rx1]["catalog_number"]):
                union.join(rx0, rx1)
        components: dict[str, list[str]] = {}
        for tracklet_id in eligible:
            components.setdefault(union.root(tracklet_id), []).append(tracklet_id)
        representatives = []
        for members in components.values():
            representatives.append(
                max(
                    members,
                    key=lambda item: (
                        published[item]["receiver_id"] == 0,
                        published[item]["observation_count"],
                        published[item]["end_utc_ns"] - published[item]["start_utc_ns"],
                        item,
                    ),
                )
            )
            rejection_counts["anchored-opposite-rx-deduplicated"] += len(members) - 1
        snapshot = product.get("original_tle_snapshot")
        if snapshot is None or int(snapshot["collected_utc_ns"]) >= int(
            source.timing.first_sample_estimate_utc_ns
        ):
            raise ValueError(f"tracking snapshot is not strictly available before capture: {path}")
        snapshot_digest = str(snapshot["digest"])
        if snapshot_digest not in references:
            raise ValueError(f"tracking snapshot absent from archive: {snapshot_digest}")
        if snapshot_digest not in catalogue_cache:
            catalogue_cache[snapshot_digest] = parse_element_sets(
                archive.read(references[snapshot_digest])
            )
        catalogue = catalogue_cache[snapshot_digest]
        numbers = list(catalogue.satellite_numbers)
        epoch = catalogue.element_epoch_utc_ns()
        added = 0
        for tracklet_id in sorted(representatives):
            if len(selected_rows) >= max_tracks:
                rejection_counts["global-track-bound"] += 1
                continue
            leader = accepted[tracklet_id]
            number = int(leader["catalog_number"])
            if number not in numbers:
                rejection_counts["leader-absent-from-snapshot"] += 1
                continue
            satellite_index = numbers.index(number)
            capture_ns = int(source.timing.first_sample_estimate_utc_ns)
            if int(epoch[satellite_index]) >= capture_ns:
                rejection_counts["leader-element-epoch-not-causal"] += 1
                continue
            tracklet = rebuilt[tracklet_id]
            points = [candidate_by_id[point.candidate_id] for point in tracklet.points]
            utc_ns = np.asarray([point.support_center_utc_ns for point in points], np.int64)
            states = [
                propagate(catalogue, satellite_index, utc_ns + shift * 1_000_000_000)
                for shift in (-1, 0, 1)
            ]
            segment = len(selected_rows)
            start = len(arrays["y_hz"])
            training = np.arange(len(points)) % 5 != 4
            for point_index, (candidate, point) in enumerate(
                zip(points, tracklet.points, strict=True)
            ):
                values = {
                    "y_hz": float(point.normalized_dealiased_cfo_hz),
                    "training": bool(training[point_index]),
                    "segment": segment,
                    "track": segment,
                    "source": number,
                    "age_h": (capture_ns - int(epoch[satellite_index])) / 3.6e12,
                    "p_km": states[1][0][point_index],
                    "v_km_s": states[1][1][point_index],
                    "phase_p_minus_km": states[0][0][point_index],
                    "phase_v_minus_km_s": states[0][1][point_index],
                    "phase_p_plus_km": states[2][0][point_index],
                    "phase_v_plus_km_s": states[2][1][point_index],
                    "time_s": candidate.support_center_utc_ns / 1e9,
                    "observation_id": f"{session_id}:{tracklet_id}:{point.candidate_id}",
                }
                for key, value in values.items():
                    arrays[key].append(value)
            stop = len(arrays["y_hz"])
            selected_track_points[(session_id, tracklet_id)] = [
                (row_index, int(points[point_index].support_center_utc_ns))
                for point_index, row_index in enumerate(range(start, stop))
            ]
            selected_rows.append(
                {
                    "segment": segment,
                    "session_id": session_id,
                    "tracklet_id": tracklet_id,
                    "receiver_id": int(published[tracklet_id]["receiver_id"]),
                    "number": number,
                    "observations": len(points),
                    "snapshot_digest": snapshot_digest,
                    "snapshot_collected_utc_ns": int(snapshot["collected_utc_ns"]),
                    "element_epoch_utc_ns": int(epoch[satellite_index]),
                    "row_start": start,
                    "row_stop": stop,
                }
            )
            added += 1
        scan_rows.append(
            {
                "session_id": session_id,
                "published_tracklets": len(published),
                "accepted_reviews": len(accepted),
                "selected_tracks": added,
            }
        )
        print(
            json.dumps(
                {
                    "phase": "export",
                    "scan": scan_index + 1,
                    "scan_count": len(paths),
                    "session_id": session_id,
                    "selected_tracks": added,
                    "total_tracks": len(selected_rows),
                }
            ),
            flush=True,
        )
    if not selected_rows:
        raise ValueError("no strict-causal reviewed tracks selected")
    typed = {key: np.asarray(value) for key, value in arrays.items()}
    typed["training"] = typed["training"].astype(bool)
    for key in ("segment", "track", "source"):
        typed[key] = typed[key].astype(np.int64)
    data = FormalOrbitData(**typed)

    lanes = sorted({(int(row["channel"]), str(row["edge"])) for row in geometry})
    calibration = calibration_by_fold(geometry)
    pass_rows: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for row in geometry:
        beam_key = (str(row["session_id"]), str(row["tracklet_id"]))
        if beam_key in selected_track_points:
            pass_rows.setdefault((beam_key[0], int(row["number"])), []).append(row)
    beam_row_indices = []
    beam_responses = []
    beam_calibrations = []
    beam_pass_ids = []
    beam_join_delta_s = []
    for (session_id, number), rows in sorted(pass_rows.items()):
        midpoint = sorted(rows, key=lambda row: int(row["utc_ns"]))[len(rows) // 2]
        points = selected_track_points[(session_id, str(midpoint["tracklet_id"]))]
        row_index, point_ns = min(points, key=lambda item: abs(item[1] - int(midpoint["utc_ns"])))
        delta_s = abs(point_ns - int(midpoint["utc_ns"])) / 1e9
        if delta_s > 2.0:
            rejection_counts["beam-representative-no-nearby-doppler-row"] += 1
            continue
        fold = number % 3
        lane_index = lanes.index((int(midpoint["channel"]), str(midpoint["edge"])))
        intercept, sigma, slope = calibration[fold * 1000 + lane_index]
        beam_row_indices.append(row_index)
        beam_responses.append(float(midpoint["proxy_db"]))
        beam_calibrations.append(
            EastWestBeamCalibration(
                intercept,
                abs(slope),
                max(sigma, 1.0),
                90.0,
                f"same-window-known-site-cross-norad-fold-{fold}",
                "glrt_margin_log_ratio",
            )
        )
        beam_pass_ids.append(f"{session_id}:{number}")
        beam_join_delta_s.append(delta_s)
    beam = None
    if beam_row_indices:
        indexes = np.asarray(beam_row_indices, np.int64)
        beam = DualLnbBeamData(
            data.p_km[indexes],
            np.asarray(beam_responses),
            tuple(beam_calibrations),
            tuple(beam_pass_ids),
            doppler_row_indices=indexes,
        )
    audit = {
        "input_scans": len(paths),
        "selected_scans": len(scan_rows),
        "selected_tracks": len(selected_rows),
        "selected_observations": len(data.y_hz),
        "selected_training_observations": int(np.count_nonzero(data.training)),
        "selected_evaluation_observations": int(np.count_nonzero(~data.training)),
        "selected_rx0_tracks": sum(row["receiver_id"] == 0 for row in selected_rows),
        "selected_rx1_tracks": sum(row["receiver_id"] == 1 for row in selected_rows),
        "selected_norads": len(np.unique(data.source)),
        "beam_passes": len(beam_row_indices),
        "beam_join_max_delta_s": max(beam_join_delta_s, default=None),
        "rejections": dict(sorted(rejection_counts.items())),
        "scans": scan_rows,
        "tracks": selected_rows,
    }
    return data, beam, audit, typed


def load_prepared(path: Path) -> tuple[FormalOrbitData, dict[str, np.ndarray]]:
    with np.load(path, allow_pickle=False) as stored:
        if str(stored["schema"].item()) != SCHEMA + "/states":
            raise ValueError("unsupported prepared full-corpus schema")
        arrays = {
            key: stored[key]
            for key in FormalOrbitData.__dataclass_fields__
            if key in stored.files
        }
    return FormalOrbitData(**arrays), arrays


def beam_from_prepared(
    data: FormalOrbitData, audit: dict[str, Any], geometry: list[dict[str, Any]]
) -> tuple[DualLnbBeamData | None, np.ndarray]:
    by_track = {
        (str(track["session_id"]), str(track["tracklet_id"])): list(
            range(int(track["row_start"]), int(track["row_stop"]))
        )
        for track in audit["tracks"]
    }
    pass_rows: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for row in geometry:
        key = (str(row["session_id"]), str(row["tracklet_id"]))
        if key in by_track:
            pass_rows.setdefault((key[0], int(row["number"])), []).append(row)
    lanes = sorted({(int(row["channel"]), str(row["edge"])) for row in geometry})
    calibration = calibration_by_fold(geometry)
    indexes = []
    response = []
    calibrations = []
    pass_ids = []
    beam_lanes = []
    for (session_id, number), rows in sorted(pass_rows.items()):
        representative = sorted(rows, key=lambda row: int(row["utc_ns"]))[len(rows) // 2]
        key = (session_id, str(representative["tracklet_id"]))
        row_index = min(
            by_track[key],
            key=lambda index: abs(data.time_s[index] * 1e9 - int(representative["utc_ns"])),
        )
        delta_s = abs(data.time_s[row_index] * 1e9 - int(representative["utc_ns"])) / 1e9
        if delta_s > 2.0:
            continue
        fold = number % 3
        lane_index = lanes.index((int(representative["channel"]), str(representative["edge"])))
        intercept, sigma, slope = calibration[fold * 1000 + lane_index]
        indexes.append(row_index)
        response.append(float(representative["proxy_db"]))
        calibrations.append(
            EastWestBeamCalibration(
                intercept,
                abs(slope),
                max(sigma, 1.0),
                90.0,
                f"same-window-known-site-cross-norad-fold-{fold}",
                "glrt_margin_log_ratio",
            )
        )
        pass_ids.append(f"{session_id}:{number}")
        beam_lanes.append(lane_index)
    if not indexes:
        return None, np.asarray([], np.int64)
    index_array = np.asarray(indexes, np.int64)
    return (
        DualLnbBeamData(
            data.p_km[index_array],
            np.asarray(response),
            tuple(calibrations),
            tuple(pass_ids),
            doppler_row_indices=index_array,
        ),
        np.asarray(beam_lanes, np.int64),
    )


def exact_phase_verification(
    data: FormalOrbitData,
    audit: dict[str, Any],
    result,
    region: Region,
    archive_root: Path,
) -> dict[str, Any]:
    archive = TleArchiveReader(archive_root)
    references = {item.digest: item for item in archive.list_snapshots()}
    cache: dict[str, Any] = {}
    receiver = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
    differences = []
    checked = 0
    for track in audit["tracks"]:
        rows = np.arange(int(track["row_start"]), int(track["row_stop"]))
        number = int(track["number"])
        digest_value = str(track["snapshot_digest"])
        if digest_value not in references:
            raise ValueError(f"verification snapshot absent from archive: {digest_value}")
        if digest_value not in cache:
            cache[digest_value] = parse_element_sets(archive.read(references[digest_value]))
        catalogue = cache[digest_value]
        satellite_index = list(catalogue.satellite_numbers).index(number)
        rate = float(result.rate_corrections_s_h[str(number)])
        phase = data.age_h[rows] * rate
        utc_ns = np.rint(data.time_s[rows] * 1e9 + phase * 1e9).astype(np.int64)
        exact_p, exact_v = propagate(catalogue, satellite_index, utc_ns)
        approximate_p = (
            data.p_km[rows]
            + 0.5 * (data.phase_p_plus_km[rows] - data.phase_p_minus_km[rows]) * phase[:, None]
            + 0.5
            * (
                data.phase_p_plus_km[rows]
                + data.phase_p_minus_km[rows]
                - 2 * data.p_km[rows]
            )
            * np.square(phase[:, None])
        )
        approximate_v = (
            data.v_km_s[rows]
            + 0.5
            * (data.phase_v_plus_km_s[rows] - data.phase_v_minus_km_s[rows])
            * phase[:, None]
            + 0.5
            * (
                data.phase_v_plus_km_s[rows]
                + data.phase_v_minus_km_s[rows]
                - 2 * data.v_km_s[rows]
            )
            * np.square(phase[:, None])
        )
        differences.extend(
            np.asarray(
                doppler_hz(receiver, exact_p, exact_v)
                - doppler_hz(receiver, approximate_p, approximate_v)
            ).tolist()
        )
        checked += len(rows)
    values = np.asarray(differences)
    return {
        "observations": checked,
        "rms_difference_hz": float(np.sqrt(np.mean(np.square(values)))),
        "p99_absolute_difference_hz": float(np.percentile(np.abs(values), 99)),
        "maximum_absolute_difference_hz": float(np.max(np.abs(values))),
        "passes_0_2_hz_maximum": bool(np.max(np.abs(values)) < 0.2),
    }


def extension_inventory(
    source_dir: Path,
    geometry_document: dict[str, Any],
    *,
    maximum_receiver_lag_s: float,
) -> dict[str, Any]:
    """Reconstruct exact point provenance for every anchored RX0/RX1 link."""
    links = [
        row
        for row in geometry_document["review_links"]
        if bool(row["same_review_leader"]) and bool(row["anchored_candidate_link"])
    ]
    wanted = {str(row["session_id"]) for row in links}
    geometry_by_link: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for row in geometry_document["geometry_proxy_points"]:
        key = (
            str(row["session_id"]),
            str(row["tracklet_id"]),
            str(row["tracklet_id_rx1"]),
        )
        geometry_by_link.setdefault(key, []).append(row)
    scans = {}
    for path in sorted(source_dir.glob("*.json.gz")):
        document = read_document(path)
        session_id = str(document["session_id"])
        if session_id in wanted:
            scans[session_id] = (path, document)
    rows = []
    for link in sorted(links, key=lambda row: (str(row["session_id"]), str(row["left"]))):
        session_id = str(link["session_id"])
        if session_id not in scans:
            raise ValueError(f"anchored-link session absent from cached corpus: {session_id}")
        path, document = scans[session_id]
        candidates = project_scanner_candidates(tracking_input(document["source"]))
        candidate_by_id = {candidate.candidate_id: candidate for candidate in candidates}
        tracks = {
            track.tracklet_id: track
            for track in reconstruct_persistent_hop_trajectories(candidates).tracklets
        }
        left_id, right_id = str(link["left"]), str(link["right"])
        if left_id not in tracks or right_id not in tracks:
            raise ValueError(f"anchored track absent after reconstruction: {session_id}")
        left = [candidate_by_id[point.candidate_id] for point in tracks[left_id].points]
        right = [candidate_by_id[point.candidate_id] for point in tracks[right_id].points]
        if {candidate.receiver_id for candidate in left} != {0}:
            raise ValueError(f"left anchored track is not RX0: {session_id}:{left_id}")
        if {candidate.receiver_id for candidate in right} != {1}:
            raise ValueError(f"right anchored track is not RX1: {session_id}:{right_id}")
        anchor_rows = geometry_by_link.get((session_id, left_id, right_id), [])
        anchors = []
        for anchor in sorted(anchor_rows, key=lambda row: int(row["utc_ns"])):
            utc_ns = int(anchor["utc_ns"])
            left_point = min(left, key=lambda item: abs(item.support_center_utc_ns - utc_ns))
            right_point = min(right, key=lambda item: abs(item.support_center_utc_ns - utc_ns))
            anchors.append(
                {
                    "rx0_visit_index": int(left_point.visit_index),
                    "rx1_visit_index": int(right_point.visit_index),
                    "role": "fit" if left_point.visit_index % 2 == 0 else "validation",
                    "geometry_utc_ns": utc_ns,
                    "rx0_geometry_delta_s": (left_point.support_center_utc_ns - utc_ns) / 1e9,
                    "rx1_geometry_delta_s": (right_point.support_center_utc_ns - utc_ns) / 1e9,
                    "rx0_candidate_id": left_point.candidate_id,
                    "rx1_candidate_id": right_point.candidate_id,
                    "rx0_support_center_utc_ns": int(left_point.support_center_utc_ns),
                    "rx1_support_center_utc_ns": int(right_point.support_center_utc_ns),
                    "receiver_lag_s": (
                        right_point.support_center_utc_ns - left_point.support_center_utc_ns
                    )
                    / 1e9,
                }
            )
        left_start = min(point.support_center_utc_ns for point in left)
        left_stop = max(point.support_center_utc_ns for point in left)
        exterior = [
            {
                "candidate_id": point.candidate_id,
                "support_center_utc_ns": int(point.support_center_utc_ns),
                "visit_index": int(point.visit_index),
                "side": "before" if point.support_center_utc_ns < left_start else "after",
            }
            for point in right
            if point.support_center_utc_ns < left_start or point.support_center_utc_ns > left_stop
        ]
        fit_count = sum(row["role"] == "fit" for row in anchors)
        validation_count = len(anchors) - fit_count
        maximum_lag = max((abs(row["receiver_lag_s"]) for row in anchors), default=float("inf"))
        rows.append(
            {
                "session_id": session_id,
                "source_path": str(path),
                "rx0_tracklet_id": left_id,
                "rx1_tracklet_id": right_id,
                "catalog_number": int(link["left_number"]),
                "channel": int(link["channel"]),
                "edge": str(link["edge"]),
                "same_review_leader": True,
                "reported_extension_s": float(link["extension_s"]),
                "rx0_points": len(left),
                "rx1_points": len(right),
                "anchors": anchors,
                "fit_anchor_count": fit_count,
                "validation_anchor_count": validation_count,
                "maximum_absolute_receiver_lag_s": maximum_lag,
                "receiver_lag_gate_pass": maximum_lag <= maximum_receiver_lag_s,
                "same_visit_anchors": sum(
                    row["rx0_visit_index"] == row["rx1_visit_index"] for row in anchors
                ),
                "exterior_rx1_points": exterior,
                "exterior_rx1_point_count": len(exterior),
                "has_positive_time_extension": float(link["extension_s"]) > 0.0,
                "helper_anchor_count_pass": fit_count >= 3 and validation_count >= 2,
            }
        )
    if len(rows) != len(links):
        raise ValueError("anchored link inventory is incomplete")
    return {
        "schema": SCHEMA + "/anchored-rx1-extension-inventory/v1",
        "maximum_receiver_lag_s": maximum_receiver_lag_s,
        "links": rows,
        "summary": {
            "anchored_links": len(rows),
            "positive_reported_extensions": sum(row["has_positive_time_extension"] for row in rows),
            "links_with_exterior_rx1_points": sum(
                row["exterior_rx1_point_count"] > 0 for row in rows
            ),
            "total_exterior_rx1_points": sum(row["exterior_rx1_point_count"] for row in rows),
            "receiver_lag_gate_failures": sum(not row["receiver_lag_gate_pass"] for row in rows),
            "helper_anchor_count_failures": sum(
                not row["helper_anchor_count_pass"] for row in rows
            ),
            "maximum_absolute_receiver_lag_s": max(
                row["maximum_absolute_receiver_lag_s"] for row in rows
            ),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepared-output", type=Path)
    parser.add_argument("--reuse-prepared", type=Path)
    parser.add_argument("--reuse-selection", type=Path)
    parser.add_argument("--region", default=json.dumps(DEFAULT_REGION))
    parser.add_argument("--initial", default="[0,0]")
    parser.add_argument("--site", default=json.dumps(DEFAULT_SITE))
    parser.add_argument("--max-scans", type=int, default=78)
    parser.add_argument("--max-tracks", type=int, default=4096)
    parser.add_argument("--max-nfev", type=int, default=200)
    parser.add_argument("--permutations", type=int, default=0)
    parser.add_argument("--export-only", action="store_true")
    parser.add_argument("--baseline-only", action="store_true")
    parser.add_argument("--skip-baseline", action="store_true")
    parser.add_argument("--extension-inventory-only", action="store_true")
    parser.add_argument("--receiver-lag-gate-s", type=float, default=1e-6)
    args = parser.parse_args()
    if (
        not 1 <= args.max_scans <= 256
        or not 1 <= args.max_tracks <= 20_000
        or not 0 <= args.permutations <= 20
    ):
        parser.error("scan/track work bounds are invalid")
    if (args.reuse_prepared is None) != (args.reuse_selection is None):
        parser.error("prepared-state reuse requires both --reuse-prepared and --reuse-selection")
    if args.extension_inventory_only:
        geometry_document = read_document(args.geometry)
        output = extension_inventory(
            args.input,
            geometry_document,
            maximum_receiver_lag_s=args.receiver_lag_gate_s,
        )
        output["inputs"] = {
            "geometry": {"path": str(args.geometry), "digest": digest(args.geometry)},
            "source_directory": str(args.input),
        }
        write_json(args.output, output)
        print(json.dumps(output["summary"], sort_keys=True), flush=True)
        return
    if args.reuse_prepared is not None:
        data, arrays = load_prepared(args.reuse_prepared)
        previous = read_document(args.reuse_selection)
        if previous.get("schema") != SCHEMA:
            raise ValueError("selection receipt has the wrong schema")
        if previous["inputs"]["prepared_states"]["digest"] != digest(args.reuse_prepared):
            raise ValueError("prepared-state digest differs from selection receipt")
        audit = previous["audit"]
        geometry_document = read_document(args.geometry)
        beam, beam_lanes = beam_from_prepared(
            data, audit, list(geometry_document["geometry_proxy_points"])
        )
        prepared = args.reuse_prepared
    else:
        geometry_document = read_document(args.geometry)
        data, beam, audit, arrays = build_corpus(
            args.input,
            geometry_document,
            args.tle_archive,
            max_scans=args.max_scans,
            max_tracks=args.max_tracks,
        )
        prepared = args.prepared_output or args.output.with_suffix(".npz")
        np.savez_compressed(  # type: ignore[arg-type]
            prepared, schema=np.asarray(SCHEMA + "/states"), **arrays
        )
        beam, beam_lanes = beam_from_prepared(
            data, audit, list(geometry_document["geometry_proxy_points"])
        )
    output: dict[str, Any] = {
        "schema": SCHEMA,
        "scope": "conditional same-window known-site identity and beam calibration research",
        "strictly_causal_tle_availability_and_element_epochs": True,
        "new_rf_collection": False,
        "same_doppler_observations_in_all_fit_arms": True,
        "simultaneous_rx0_rx1_double_counted": False,
        "identity_assumption": (
            "Persisted review leader accepted only with <=150 Hz heldout RMS and a runner-up "
            "at least three times worse; identities remain conditional on the configured observer."
        ),
        "beam_assumption": (
            "GLRT margin log-ratio is an explicitly experimental proxy, calibrated at the known "
            "site on other NORAD folds within the same time window."
        ),
        "receiver_fusion_followup": (
            "Estimate RX1-to-RX0 offset/drift only from simultaneous anchors, replace overlapping "
            "RX0 rows rather than duplicate them, and share one offset across the fused curve."
        ),
        "inputs": {
            "geometry": {"path": str(args.geometry), "digest": digest(args.geometry)},
            "source_directory": str(args.input),
            "prepared_states": {"path": str(prepared), "digest": digest(prepared)},
        },
        "configuration": {
            "region": json.loads(args.region),
            "initial_x_km": json.loads(args.initial),
            "evaluation_site": json.loads(args.site),
            "max_scans": args.max_scans,
            "max_tracks": args.max_tracks,
            "max_nfev": args.max_nfev,
        },
        "audit": audit,
        "fits": [],
    }
    write_json(args.output, output)
    compact_audit = {key: value for key, value in audit.items() if key not in ("scans", "tracks")}
    print(json.dumps({"phase": "selection-complete", **compact_audit}), flush=True)
    if args.export_only:
        return
    region = Region(**json.loads(args.region))
    config = FormalOrbitConfig(max_nfev=args.max_nfev)
    site = np.asarray(json.loads(args.site), float)
    trials: list[tuple[str, DualLnbBeamData | None, int | None]] = []
    if not args.skip_baseline:
        trials.append(("doppler-only", None, None))
    if not args.baseline_only and beam is not None:
        trials.append(("doppler-plus-beam-proxy", beam, None))
        for permutation in range(args.permutations):
            seed = 20260921 + permutation
            rng = np.random.default_rng(seed)
            shuffled = beam.response_db.copy()
            for lane_index in np.unique(beam_lanes):
                lane_rows = np.flatnonzero(beam_lanes == lane_index)
                shuffled[lane_rows] = shuffled[rng.permutation(lane_rows)]
            trials.append(
                (
                    "doppler-plus-shuffled-beam",
                    DualLnbBeamData(
                        beam.satellite_position_ecef_km,
                        shuffled,
                        beam.calibration,
                        beam.pass_ids,
                        doppler_row_indices=beam.doppler_row_indices,
                    ),
                    seed,
                )
            )
    for name, evidence, permutation_seed in trials:
        print(json.dumps({"phase": "fit-start", "model": name}), flush=True)
        result = fit_formal_orbit(
            data, region, json.loads(args.initial), config, beam_data=evidence
        )
        error_m = float(
            np.linalg.norm(
                region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
                - Region(float(site[0]), float(site[1]), 1.0, 1.0).points([0.0], [0.0]).ecef_km[0]
            )
            * 1000
        )
        verification = exact_phase_verification(data, audit, result, region, args.tle_archive)
        output["fits"].append(
            {
                "model": name,
                "permutation_seed": permutation_seed,
                "horizontal_chord_error_m": error_m,
                "exact_phase_verification": verification,
                "result": asdict(result),
            }
        )
        write_json(args.output, output)
        print(json.dumps({"phase": "fit-complete", "model": name, "error_m": error_m}), flush=True)


if __name__ == "__main__":
    main()

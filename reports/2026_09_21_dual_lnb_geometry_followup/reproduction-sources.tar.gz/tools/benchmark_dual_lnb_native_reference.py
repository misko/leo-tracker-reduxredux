#!/usr/bin/env python3
"""Compare frozen matched baseline with coverage-selected native RX1 paths."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import asdict
from importlib import import_module
from pathlib import Path

import numpy as np

from leo.analysis.persistent_hop_trajectory import reconstruct_persistent_hop_trajectories
from leo.analysis.research.dual_lnb_fusion import (
    FusedObservation,
    SimultaneousAnchor,
    fuse_anchored_paths,
    fusion_covariance_block,
)
from leo.analysis.research.formal_orbit import FormalOrbitConfig, FormalOrbitData
from leo.analysis.research.regional_doppler import Region
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.propagation import parse_element_sets

SCHEMA = "org.leo.research.dual-lnb-native-reference-benchmark/v1"
try:
    _BASE = import_module("tools.benchmark_dual_lnb_fusion")
except ModuleNotFoundError:
    _BASE = import_module("benchmark_dual_lnb_fusion")
SITE = _BASE.SITE
_append_formal_data = _BASE._append_formal_data
_candidate_id = _BASE._candidate_id
_common_evaluation_rms = _BASE._common_evaluation_rms
_fit = _BASE._fit
_fusion_observation = _BASE._fusion_observation
_save_preparation = _BASE._save_preparation
_subset_formal_data = _BASE._subset_formal_data
covariance_from_ids = _BASE.covariance_from_ids
load_prepared = _BASE.load_prepared
propagate = _BASE.propagate
read_document = _BASE.read_document
tracking_input = _BASE.tracking_input


def _candidate_rows(path, anchor_candidate_ids):
    return [
        point for point in path if _candidate_id(point.observation_id) not in anchor_candidate_ids
    ]


def _native_point(point):
    return FusedObservation(
        point.time_s,
        point.normalized_cfo_hz,
        point.measurement_sigma_hz,
        point.measurement_sigma_hz,
        0.0,
        point.receiver_id,
        point.observation_id,
        point.path_id,
        point.source_digest,
        point.normalized_cfo_hz,
        0.0,
        None,
        None,
    )


def _snapshot_rows(selection, count):
    result = np.full(count, "", dtype=object)
    for row in selection["audit"]["tracks"]:
        start, stop = int(row["row_start"]), int(row["row_stop"])
        if not 0 <= start < stop <= count or any(result[start:stop] != ""):
            raise ValueError("invalid or overlapping snapshot row spans")
        result[start:stop] = str(row["snapshot_digest"])
    if any(result == ""):
        raise ValueError("snapshot provenance does not cover all observations")
    return result


def _prepare(args, data, selection, inventory, frozen_receipt):
    audit_tracks = {
        (str(item["session_id"]), str(item["tracklet_id"])): item
        for item in selection["audit"]["tracks"]
    }
    base_snapshot = _snapshot_rows(selection, len(data.y_hz))
    base_candidate_ids = {_candidate_id(str(value)) for value in data.observation_id}
    frozen_links = {
        (
            str(item["session_id"]),
            str(item["rx0_tracklet_id"]),
            str(item["rx1_tracklet_id"]),
        )
        for item in frozen_receipt["selection"]["accepted_links"]
    }
    selected = [
        row
        for row in inventory["links"]
        if (
            str(row["session_id"]),
            str(row["rx0_tracklet_id"]),
            str(row["rx1_tracklet_id"]),
        )
        in frozen_links
    ]
    if len(selected) != len(frozen_links):
        raise ValueError("frozen accepted links are absent from inventory")
    total_rx0 = sum(int(row["rx0_points"]) for row in selected)
    total_rx1 = sum(int(row["rx1_points"]) for row in selected)
    if total_rx1 <= total_rx0:
        raise ValueError("RX1 is not the higher-coverage receiver in frozen links")

    by_session = {}
    for row in selected:
        by_session.setdefault(str(row["session_id"]), []).append(row)
    archive = TleArchiveReader(args.tle_archive)
    references = {item.digest: item for item in archive.list_snapshots()}
    catalogue_cache = {}
    replacements = []
    covariance_specs = []
    accepted = []
    removed_rx0_candidate_ids = set()
    anchor_candidate_ids = set()
    appended_candidate_ids = set()
    rejections: Counter[str] = Counter()

    for session_id, links in sorted(by_session.items()):
        document = read_document(Path(links[0]["source_path"]))
        source = tracking_input(document["source"])
        candidates = project_scanner_candidates(source)
        candidate_by_id = {str(candidate.candidate_id): candidate for candidate in candidates}
        trajectory = reconstruct_persistent_hop_trajectories(candidates)
        track_by_id = {str(track.tracklet_id): track for track in trajectory.tracklets}
        product = document["tracking"]
        persisted_ids = {str(track["tracklet_id"]) for track in product["tracklets"]}
        if set(track_by_id) != persisted_ids:
            raise ValueError("reconstructed track IDs differ from persisted inventory")
        snapshot = product["original_tle_snapshot"]
        snapshot_digest = str(snapshot["digest"])
        if snapshot_digest not in references:
            raise ValueError("native-reference snapshot absent from archive")
        if snapshot_digest not in catalogue_cache:
            catalogue_cache[snapshot_digest] = parse_element_sets(
                archive.read(references[snapshot_digest])
            )
        catalogue = catalogue_cache[snapshot_digest]
        capture_ns = int(source.timing.first_sample_estimate_utc_ns)
        if int(snapshot["collected_utc_ns"]) >= capture_ns:
            raise ValueError("native-reference snapshot was not available before capture")

        for link in links:
            rx0_id = str(link["rx0_tracklet_id"])
            rx1_id = str(link["rx1_tracklet_id"])
            audit_key = (session_id, rx0_id)
            if audit_key not in audit_tracks:
                raise ValueError("frozen RX0 reference is absent from prepared baseline")
            number = int(link["catalog_number"])
            rx0_path = tuple(
                _fusion_observation(
                    session_id, rx0_id, number, candidate_by_id[point.candidate_id], point
                )
                for point in track_by_id[rx0_id].points
            )
            rx1_path = tuple(
                _fusion_observation(
                    session_id, rx1_id, number, candidate_by_id[point.candidate_id], point
                )
                for point in track_by_id[rx1_id].points
            )
            lookup0 = {item.observation_id: item for item in rx0_path}
            lookup1 = {item.observation_id: item for item in rx1_path}
            anchors = []
            for anchor in link["anchors"]:
                id0 = f"{session_id}:{rx0_id}:{anchor['rx0_candidate_id']}"
                id1 = f"{session_id}:{rx1_id}:{anchor['rx1_candidate_id']}"
                if id0 not in lookup0 or id1 not in lookup1:
                    raise ValueError("frozen anchor candidate is absent from reconstructed path")
                anchors.append(
                    SimultaneousAnchor(
                        f"{session_id}:{anchor['rx0_visit_index']}:{rx0_id}:{rx1_id}",
                        lookup0[id0],
                        lookup1[id1],
                        str(anchor["role"]),
                    )
                )
            old_direction = fuse_anchored_paths(rx0_path, rx1_path, tuple(anchors))
            if old_direction.state != "fused" or old_direction.calibration is None:
                raise ValueError("frozen accepted link no longer passes calibration protocol")
            inverse = fuse_anchored_paths(
                rx0_path, rx1_path, tuple(anchors), reference_receiver_id=1
            )
            inverse_block = fusion_covariance_block(inverse)
            local_anchors = {
                _candidate_id(value)
                for value in (
                    *old_direction.calibration.fit_observation_ids,
                    *old_direction.calibration.validation_observation_ids,
                )
            }
            native = [_native_point(point) for point in _candidate_rows(rx1_path, local_anchors)]
            corrected = (
                [point for point in inverse.points if point.calibration_group_id is not None]
                if inverse.state == "fused"
                else []
            )
            replacement = [*native, *corrected]
            replacement_candidate_ids = {
                _candidate_id(point.source_observation_id) for point in replacement
            }
            own_rx0_candidate_ids = {_candidate_id(point.observation_id) for point in rx0_path}
            conflict = replacement_candidate_ids & (
                base_candidate_ids - own_rx0_candidate_ids - local_anchors
            )
            if conflict:
                rejections["replacement-candidate-already-in-other-baseline-track"] += 1
                continue
            if replacement_candidate_ids & appended_candidate_ids:
                rejections["replacement-candidate-already-appended"] += 1
                continue
            satellite_index = list(catalogue.satellite_numbers).index(number)
            element_epoch = int(catalogue.element_epoch_utc_ns()[satellite_index])
            if element_epoch >= capture_ns:
                raise ValueError("native-reference element epoch was not causal")
            segment = int(audit_tracks[audit_key]["segment"])
            rx0_order = {
                str(point.candidate_id): index
                for index, point in enumerate(track_by_id[rx0_id].points)
            }
            rx1_order = {
                str(point.candidate_id): index
                for index, point in enumerate(track_by_id[rx1_id].points)
            }
            link_rows = []
            for point in replacement:
                candidate_id = _candidate_id(point.source_observation_id)
                candidate = candidate_by_id[candidate_id]
                utc_ns = np.asarray([candidate.support_center_utc_ns], np.int64)
                states = [
                    propagate(catalogue, satellite_index, utc_ns + shift * 1_000_000_000)
                    for shift in (-1, 0, 1)
                ]
                order = rx1_order if point.source_receiver_id == 1 else rx0_order
                link_rows.append(
                    {
                        "y_hz": point.normalized_cfo_hz,
                        "training": order[candidate_id] % 5 != 4,
                        "segment": segment,
                        "track": segment,
                        "source": number,
                        "age_h": (capture_ns - element_epoch) / 3.6e12,
                        "p_km": states[1][0][0],
                        "v_km_s": states[1][1][0],
                        "phase_p_minus_km": states[0][0][0],
                        "phase_v_minus_km_s": states[0][1][0],
                        "phase_p_plus_km": states[2][0][0],
                        "phase_v_plus_km_s": states[2][1][0],
                        "time_s": candidate.support_center_utc_ns / 1e9,
                        "observation_id": point.source_observation_id,
                        "snapshot_digest": snapshot_digest,
                    }
                )
            replacements.extend(link_rows)
            if inverse_block is not None:
                covariance_specs.append(inverse_block)
            appended_candidate_ids.update(replacement_candidate_ids)
            removed_rx0_candidate_ids.update(own_rx0_candidate_ids)
            anchor_candidate_ids.update(local_anchors)
            accepted.append(
                {
                    "session_id": session_id,
                    "number": number,
                    "rx0_tracklet_id": rx0_id,
                    "rx1_tracklet_id": rx1_id,
                    "rx0_path_points": len(rx0_path),
                    "rx1_path_points": len(rx1_path),
                    "native_rx1_points_after_anchor_exclusion": len(native),
                    "corrected_rx0_extension_points": len(corrected),
                    "inverse_extension_state": inverse.state,
                    "inverse_extension_reason": inverse.reason,
                    "calibration_group_id": old_direction.calibration.calibration_group_id,
                }
            )

    baseline_keep = np.asarray(
        [_candidate_id(str(value)) not in anchor_candidate_ids for value in data.observation_id]
    )
    baseline = _subset_formal_data(data, baseline_keep)
    if len(baseline.y_hz) != frozen_receipt["selection"]["matched_baseline_observations"]:
        raise ValueError("native-reference preparation changed matched baseline membership")
    baseline_snapshot = base_snapshot[baseline_keep]
    variant_keep = np.asarray(
        [
            _candidate_id(str(value)) not in removed_rx0_candidate_ids
            for value in baseline.observation_id
        ]
    )
    variant_base = _subset_formal_data(baseline, variant_keep)
    variant_snapshot_base = baseline_snapshot[variant_keep]
    temporary = _append_formal_data(variant_base, replacements, [])
    blocks = [covariance_from_ids(block, temporary.observation_id) for block in covariance_specs]
    variant = FormalOrbitData(
        **{
            name: getattr(temporary, name)
            for name in FormalOrbitData.__dataclass_fields__
            if name != "extra_covariance"
        },
        extra_covariance=tuple(blocks),
    )
    variant_snapshot = np.concatenate(
        (
            variant_snapshot_base,
            np.asarray([row["snapshot_digest"] for row in replacements], object),
        )
    )
    return (
        baseline,
        variant,
        baseline_snapshot,
        variant_snapshot,
        {
            "reference_receiver_id": 1,
            "reference_choice": "greater-total-path-point-coverage-in-frozen-links",
            "frozen_link_rx0_points": total_rx0,
            "frozen_link_rx1_points": total_rx1,
            "frozen_accepted_links": len(frozen_links),
            "accepted_links": accepted,
            "rejections": dict(sorted(rejections.items())),
            "anchor_candidate_ids_excluded": len(anchor_candidate_ids),
            "matched_baseline_observations": len(baseline.y_hz),
            "removed_native_rx0_observations": int(np.count_nonzero(~variant_keep)),
            "added_native_rx1_observations": sum(
                item["native_rx1_points_after_anchor_exclusion"] for item in accepted
            ),
            "added_corrected_rx0_extension_observations": sum(
                item["corrected_rx0_extension_points"] for item in accepted
            ),
            "native_reference_observations": len(variant.y_hz),
            "covariance_blocks": len(blocks),
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--frozen-receipt", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepared-output", type=Path)
    parser.add_argument("--max-nfev", type=int, default=200)
    args = parser.parse_args()
    data, _ = load_prepared(args.prepared)
    frozen_receipt = read_document(args.frozen_receipt)
    baseline, variant, baseline_snapshot, variant_snapshot, audit = _prepare(
        args,
        data,
        read_document(args.selection),
        read_document(args.inventory),
        frozen_receipt,
    )
    region = Region(SITE[0], SITE[1], 200.0, 200.0)
    output = {
        "schema": SCHEMA,
        "new_rf_collection": False,
        "known_site_used_for_evaluation_only": False,
        "conditional_local_site_centered_region": True,
        "site_conditioned_identity_labels": True,
        "truth_used_for_reference_choice": False,
        "region": asdict(region),
        "initial_x_km": [20.0, -20.0],
        "selection": audit,
        "fits": {"anchor-excluded-baseline": frozen_receipt["fits"]["anchor-excluded-baseline"]},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    if args.prepared_output is not None:
        args.prepared_output.parent.mkdir(parents=True, exist_ok=True)
        _save_preparation(
            args.prepared_output, baseline, variant, baseline_snapshot, variant_snapshot
        )
    print(json.dumps({"phase": "fit-start", "model": "native-rx1-reference"}), flush=True)
    fit = _fit(
        variant,
        variant_snapshot,
        region,
        FormalOrbitConfig(max_nfev=args.max_nfev),
        [20.0, -20.0],
        args.tle_archive,
    )
    # Changed segments now have RX1 offsets; applying them to original RX0 CFO
    # would produce a meaningless residual. Compare only unchanged segments.
    changed_segments = set(baseline.segment) - {
        int(segment)
        for segment in baseline.segment
        if set(baseline.observation_id[baseline.segment == segment])
        <= set(variant.observation_id[variant.segment == segment])
    }
    common = _subset_formal_data(baseline, ~np.isin(baseline.segment, list(changed_segments)))
    fit["common_unchanged_evaluation_observations"] = int(sum(~common.training))
    fit["common_unchanged_evaluation_rms_hz"] = _common_evaluation_rms(
        common, fit["result"], region
    )
    fit["baseline_common_unchanged_evaluation_rms_hz"] = _common_evaluation_rms(
        common, frozen_receipt["fits"]["anchor-excluded-baseline"]["result"], region
    )
    output["fits"]["native-rx1-reference"] = fit
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "phase": "fit-complete",
                "model": "native-rx1-reference",
                "error_m": fit["horizontal_chord_error_m"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()

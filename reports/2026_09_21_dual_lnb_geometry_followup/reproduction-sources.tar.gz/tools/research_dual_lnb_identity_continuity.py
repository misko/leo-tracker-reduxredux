#!/usr/bin/env python3
"""Audit cross-receiver path continuity without promoting it to identity truth.

The audit reconstructs timing/CFO links from cached scanner products, compares
the independently reviewed Doppler leaders on both receiver paths, and records
where a dual-LNB geometry label exists.  It never changes a review leader and
does not use the known receiver coordinate to select links.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
from research_dual_lnb_geometry import detections

from leo.analysis.research.dual_lnb_tracking import (
    fit_receiver_offset,
    match_dual_lnb,
    timing_edges,
    wrapped,
)

SCHEMA = "org.leo.research.dual-lnb-identity-continuity/v1"


def read_document(path: Path) -> dict[str, Any]:
    payload = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(payload)


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def clear_reviewed_tracks(product: dict[str, Any]) -> dict[str, dict[str, Any]]:
    tracks = {str(row["tracklet_id"]): row for row in product.get("tracklets", [])}
    result: dict[str, dict[str, Any]] = {}
    for review in product.get("track_reviews", []):
        tracklet_id = str(review["tracklet_id"])
        candidates = review.get("candidates", [])
        if tracklet_id not in tracks or len(candidates) < 2:
            continue
        leader, runner = candidates[:2]
        leader_rms = float(leader["randomized_evaluation_rms_hz"])
        runner_rms = float(runner["randomized_evaluation_rms_hz"])
        if leader_rms > 150 or runner_rms < 3 * max(leader_rms, 1):
            continue
        result[tracklet_id] = {
            **tracks[tracklet_id],
            "review_start_s": float(review["start_s"]),
            "review_end_s": float(review["end_s"]),
            "leader_number": int(leader["catalog_number"]),
            "leader_evaluation_rms_hz": leader_rms,
            "runner_number": int(runner["catalog_number"]),
            "runner_evaluation_rms_hz": runner_rms,
            "leader_runner_rms_ratio": runner_rms / max(leader_rms, 1),
        }
    return result


def _containing_track(
    tracks: dict[str, dict[str, Any]], receiver: int, channel: int, edge: str, time_s: float
) -> str | None:
    matches = [
        tracklet_id
        for tracklet_id, row in tracks.items()
        if int(row["receiver_id"]) == receiver
        and int(row["channel"]) == channel
        and str(row["edge"]) == edge
        and row["review_start_s"] - 0.03 <= time_s <= row["review_end_s"] + 0.03
    ]
    return matches[0] if len(matches) == 1 else None


def _pair_candidates(tracks: dict[str, dict[str, Any]]) -> list[tuple[str, str]]:
    left = [(key, row) for key, row in tracks.items() if int(row["receiver_id"]) == 0]
    right = [(key, row) for key, row in tracks.items() if int(row["receiver_id"]) == 1]
    result = []
    for left_id, a in left:
        for right_id, b in right:
            if (int(a["channel"]), str(a["edge"])) != (
                int(b["channel"]),
                str(b["edge"]),
            ):
                continue
            overlap = min(a["review_end_s"], b["review_end_s"]) - max(
                a["review_start_s"], b["review_start_s"]
            )
            # Keep near handoffs as well as overlap so missing continuity support
            # remains visible instead of disappearing from the inventory.
            if overlap >= -4.0:
                result.append((left_id, right_id))
    return sorted(result)


def audit_scan(
    document: dict[str, Any], geometry_counts: Counter[tuple[str, str, str]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, int]]:
    session_id = str(document["session_id"])
    product = document.get("tracking") or {}
    source = document.get("source")
    tracks = clear_reviewed_tracks(product)
    if source is None:
        return [], list(tracks.values()), {"missing_source": 1}

    raw_edges = timing_edges(detections(source), float(source["sample_rate_hz"]))
    offset = fit_receiver_offset([edge for edge in raw_edges if edge[0].visit % 2 == 0])
    cfo_matches = match_dual_lnb(raw_edges, offset)
    timing_by_pair: dict[tuple[str, str], list[Any]] = defaultdict(list)
    cfo_by_pair: dict[tuple[str, str], list[Any]] = defaultdict(list)
    ambiguous_timing_edges = 0
    for edge in raw_edges:
        left, right = edge[:2]
        left_id = _containing_track(tracks, 0, left.channel, left.edge, left.time_s)
        right_id = _containing_track(tracks, 1, right.channel, right.edge, right.time_s)
        if left_id is None or right_id is None:
            ambiguous_timing_edges += 1
            continue
        timing_by_pair[(left_id, right_id)].append(edge)
    for edge in cfo_matches:
        left, right = edge[:2]
        left_id = _containing_track(tracks, 0, left.channel, left.edge, left.time_s)
        right_id = _containing_track(tracks, 1, right.channel, right.edge, right.time_s)
        if left_id is not None and right_id is not None:
            cfo_by_pair[(left_id, right_id)].append(edge)

    links = []
    paired_track_ids: Counter[str] = Counter()
    for left_id, right_id in _pair_candidates(tracks):
        a, b = tracks[left_id], tracks[right_id]
        timing = timing_by_pair[(left_id, right_id)]
        matched = cfo_by_pair[(left_id, right_id)]
        residual = (
            np.asarray(
                [wrapped(edge[2] - offset.predict(edge[0].time_s)) for edge in matched],
                float,
            )
            if offset is not None and matched
            else np.asarray([], float)
        )
        timing_visits = sorted({int(edge[0].visit) for edge in timing})
        matched_visits = sorted({int(edge[0].visit) for edge in matched})
        overlap = min(a["review_end_s"], b["review_end_s"]) - max(
            a["review_start_s"], b["review_start_s"]
        )
        rx1_left = max(float(a["review_start_s"] - b["review_start_s"]), 0.0)
        rx1_right = max(float(b["review_end_s"] - a["review_end_s"]), 0.0)
        rx0_left = max(float(b["review_start_s"] - a["review_start_s"]), 0.0)
        rx0_right = max(float(a["review_end_s"] - b["review_end_s"]), 0.0)
        geometry_points = geometry_counts[(session_id, left_id, right_id)]
        same_leader = a["leader_number"] == b["leader_number"]
        link = {
            "session_id": session_id,
            "rx0_tracklet_id": left_id,
            "rx1_tracklet_id": right_id,
            "channel": int(a["channel"]),
            "edge": str(a["edge"]),
            "rx0_leader_number": int(a["leader_number"]),
            "rx1_leader_number": int(b["leader_number"]),
            "same_review_leader": same_leader,
            "rx0_leader_evaluation_rms_hz": float(a["leader_evaluation_rms_hz"]),
            "rx1_leader_evaluation_rms_hz": float(b["leader_evaluation_rms_hz"]),
            "rx0_runner_number": int(a["runner_number"]),
            "rx1_runner_number": int(b["runner_number"]),
            "rx0_leader_runner_rms_ratio": float(a["leader_runner_rms_ratio"]),
            "rx1_leader_runner_rms_ratio": float(b["leader_runner_rms_ratio"]),
            "overlap_s": float(overlap),
            "gap_s": max(float(-overlap), 0.0),
            "rx1_left_extension_s": rx1_left,
            "rx1_right_extension_s": rx1_right,
            "rx0_left_extension_s": rx0_left,
            "rx0_right_extension_s": rx0_right,
            "timing_anchor_visits": len(timing_visits),
            "timing_anchor_edges": len(timing),
            "cfo_supported_anchor_visits": len(matched_visits),
            "cfo_supported_anchor_edges": len(matched),
            "receiver_offset_residual_rms_hz": (
                float(np.sqrt(np.mean(np.square(residual)))) if len(residual) else None
            ),
            "maximum_epoch_skew_us": (
                max(float(edge[3]) / float(source["sample_rate_hz"]) for edge in timing) * 1e6
                if timing
                else None
            ),
            "normalized_rate_difference_hz_s": abs(
                float(a["normalized_rate_hz_per_s"])
                - float(b["normalized_rate_hz_per_s"])
            ),
            "geometry_proxy_points": geometry_points,
            "geometry_covered": geometry_points > 0,
            "continuity_supported": len(matched_visits) >= 3,
            "interpretation": (
                "physical cross-receiver path continuity; identity remains conditional on "
                "the two independent Doppler reviews"
            ),
        }
        links.append(link)
        paired_track_ids.update((left_id, right_id))

    track_rows = []
    for tracklet_id, row in sorted(tracks.items()):
        geometry_points = sum(
            count
            for (geometry_session, left_id, right_id), count in geometry_counts.items()
            if geometry_session == session_id and tracklet_id in (left_id, right_id)
        )
        track_rows.append(
            {
                "session_id": session_id,
                "tracklet_id": tracklet_id,
                "receiver_id": int(row["receiver_id"]),
                "channel": int(row["channel"]),
                "edge": str(row["edge"]),
                "leader_number": int(row["leader_number"]),
                "leader_evaluation_rms_hz": float(row["leader_evaluation_rms_hz"]),
                "runner_number": int(row["runner_number"]),
                "leader_runner_rms_ratio": float(row["leader_runner_rms_ratio"]),
                "candidate_opposite_rx_pairs": paired_track_ids[tracklet_id],
                "geometry_proxy_points": geometry_points,
                "geometry_covered": geometry_points > 0,
            }
        )
    diagnostics = {
        "ambiguous_or_unreviewed_timing_edges": ambiguous_timing_edges,
        "receiver_offset_available": int(offset is not None),
    }
    return links, track_rows, diagnostics


def build_audit(
    paths: list[Path], geometry_document: dict[str, Any], *, start_ns: int, end_ns: int
) -> dict[str, Any]:
    geometry = geometry_document.get("geometry_proxy_points", [])
    geometry_counts = Counter(
        (str(row["session_id"]), str(row["tracklet_id"]), str(row["tracklet_id_rx1"]))
        for row in geometry
    )
    links: list[dict[str, Any]] = []
    tracks: list[dict[str, Any]] = []
    scan_diagnostics = []
    included_paths = []
    complete_tracking_scans = 0
    pending_tracking_sessions = []
    for path in paths:
        document = read_document(path)
        created = int(document["created_utc_ns"])
        if not start_ns <= created < end_ns:
            continue
        scan_links, scan_tracks, diagnostics = audit_scan(document, geometry_counts)
        if document.get("tracking_state") == "complete" and document.get("tracking") is not None:
            complete_tracking_scans += 1
        else:
            pending_tracking_sessions.append(str(document["session_id"]))
        links.extend(scan_links)
        tracks.extend(scan_tracks)
        included_paths.append(path)
        scan_diagnostics.append(
            {"session_id": str(document["session_id"]), **diagnostics}
        )
    links.sort(key=lambda row: (row["session_id"], row["rx0_tracklet_id"], row["rx1_tracklet_id"]))
    tracks.sort(key=lambda row: (row["session_id"], row["tracklet_id"]))
    reconstructed_keys = {
        (row["session_id"], row["rx0_tracklet_id"], row["rx1_tracklet_id"]) for row in links
    }
    geometry_link_keys = {
        (str(row["session_id"]), str(row["left"]), str(row["right"]))
        for row in geometry_document.get("review_links", [])
    }
    counts = Counter(
        "same_leader" if row["same_review_leader"] else "different_leaders" for row in links
    )
    return {
        "schema": SCHEMA,
        "window_start_utc_ns": start_ns,
        "window_end_utc_ns": end_ns,
        "input_scan_documents": len(included_paths),
        "complete_tracking_scans": complete_tracking_scans,
        "pending_tracking_sessions": sorted(pending_tracking_sessions),
        "input_digests": [
            {"path": str(path), "digest": digest(path)} for path in included_paths
        ],
        "geometry_input_points": len(geometry),
        "summary": {
            "clear_reviewed_tracks": len(tracks),
            "same_lane_pairs_with_overlap_or_gap_le_4_s": len(links),
            "geometry_review_link_inventory": len(geometry_link_keys),
            "review_link_inventory_matches_geometry": reconstructed_keys == geometry_link_keys,
            "same_review_leader_pairs": counts["same_leader"],
            "different_review_leader_pairs": counts["different_leaders"],
            "continuity_supported_pairs": sum(row["continuity_supported"] for row in links),
            "continuity_supported_same_leader_pairs": sum(
                row["continuity_supported"] and row["same_review_leader"] for row in links
            ),
            "continuity_supported_different_leader_pairs": sum(
                row["continuity_supported"] and not row["same_review_leader"] for row in links
            ),
            "geometry_covered_pairs": sum(row["geometry_covered"] for row in links),
            "same_leader_pairs_missing_geometry": sum(
                row["same_review_leader"] and not row["geometry_covered"] for row in links
            ),
            "continuity_supported_rx1_extension_pairs": sum(
                row["continuity_supported"]
                and (row["rx1_left_extension_s"] > 0 or row["rx1_right_extension_s"] > 0)
                for row in links
            ),
        },
        "links": links,
        "tracks": tracks,
        "scan_diagnostics": scan_diagnostics,
        "interpretation": (
            "Timing/CFO support establishes cross-receiver path continuity. Agreement of two "
            "conditional Doppler review leaders corroborates an identity but is not independent "
            "satellite ground truth. Geometry coverage is reported separately and never gates "
            "links."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--window-start-utc-ns", type=int)
    parser.add_argument("--window-end-utc-ns", type=int)
    args = parser.parse_args()
    geometry = read_document(args.geometry)
    start = args.window_start_utc_ns or geometry.get("window_start_utc_ns")
    end = args.window_end_utc_ns or geometry.get("window_end_utc_ns")
    if start is None or end is None or int(start) >= int(end):
        parser.error("a valid closed UTC-nanosecond window is required")
    result = build_audit(
        sorted(args.input.glob("*.json.gz")), geometry, start_ns=int(start), end_ns=int(end)
    )
    result["geometry_input"] = {"path": str(args.geometry), "digest": digest(args.geometry)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps(result["summary"], sort_keys=True), flush=True)


if __name__ == "__main__":
    main()

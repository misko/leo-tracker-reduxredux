"""Read-only, resumable export of a frozen adaptive geometry research window."""

import argparse
import gzip
import json
from dataclasses import asdict
from pathlib import Path

from leo.storage.adaptive_hop import AdaptiveHopIqStore
from leo.storage.scanner_tracking import ScannerTrackingStore
from leo.storage.scanner_tracking_source import ScannerTrackingInputStore


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bulk-root", type=Path, default=Path("/srv/bulk/leo"))
    parser.add_argument("--end-utc-ns", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    captures = AdaptiveHopIqStore(args.bulk_root, read_only=True)
    tracking = ScannerTrackingStore(args.bulk_root)
    inputs = ScannerTrackingInputStore(args.bulk_root)
    rows = []
    try:
        for _, sid in captures.publication_index():
            capture = captures.inspect(sid)
            m = capture.manifest
            if not args.end_utc_ns - 8 * 3600 * 10**9 <= m.created_utc_ns < args.end_utc_ns:
                continue
            destination = args.output / (sid + ".json.gz")
            if destination.exists():
                with gzip.open(destination, "rt") as stream:
                    row = json.load(stream)
            else:
                row = dict(
                    session_id=sid,
                    created_utc_ns=m.created_utc_ns,
                    input_digest=capture.manifest_sha256,
                    geometry=getattr(m, "receiver_geometry", None).model_dump(mode="json")
                    if getattr(m, "receiver_geometry", None)
                    else None,
                    timing=m.timing.model_dump(mode="json") if m.timing else None,
                    visits=m.receipt.complete_visit_count,
                )
                status = tracking.status(sid)
                row["tracking_state"] = status.state
                row["tracking"] = status.product.model_dump(mode="json") if status.product else None
                try:
                    source = inputs.load(sid)
                    row["source"] = asdict(source)
                    # The timing contract is not a dataclass.
                    row["source"]["timing"] = (
                        source.timing.model_dump(mode="json") if source.timing else None
                    )
                except Exception as error:
                    row["analysis_error"] = f"{type(error).__name__}: {error}"
                with gzip.open(destination, "wt") as stream:
                    json.dump(row, stream)
            summary = {
                k: v
                for k, v in row.items()
                if k not in ("source", "tracking", "geometry", "timing")
            }
            summary["six_hour_cohort"] = m.created_utc_ns >= args.end_utc_ns - 6 * 3600 * 10**9
            summary["tracklets"] = len((row.get("tracking") or {}).get("tracklets", []))
            summary["probes"] = len((row.get("source") or {}).get("probes", []))
            rows.append(summary)
            print(json.dumps(summary), flush=True)
    finally:
        captures.close()
        inputs.close()
    (args.output / "inventory.json").write_text(
        json.dumps(dict(end_utc_ns=args.end_utc_ns, scans=rows), indent=2) + "\n"
    )


if __name__ == "__main__":
    main()

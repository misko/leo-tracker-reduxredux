"""Local, conditional Doppler-vs-beam ablation; not a blind location benchmark."""

import argparse
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path

import numpy as np

from leo.analysis.research.dual_lnb_tracking import DualLnbBeamData, EastWestBeamCalibration
from leo.analysis.research.formal_orbit import FormalOrbitConfig, FormalOrbitData, fit_formal_orbit
from leo.analysis.research.regional_doppler import Region
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.frames import greenwich_mean_sidereal_time_rad, julian_day_from_utc_ns, teme_to_ecef
from leo.sky.propagation import parse_element_sets

SITE = (37.84903264307456, -122.4856541910174)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--permutations", type=int, default=1)
    args = parser.parse_args()
    if args.permutations < 1:
        parser.error("--permutations must be positive")
    doc = json.loads(args.input.read_text())
    rows = doc["geometry_proxy_points"]
    archive = TleArchiveReader(Path("/var/lib/leo/tle"))
    refs = {s.digest: s for s in archive.list_snapshots()}
    cache = {}
    states = np.empty((3, len(rows), 2, 3))
    ages = np.empty(len(rows))
    for i, r in enumerate(rows):
        digest = r["catalogue_digest"]
        if digest not in cache:
            cache[digest] = parse_element_sets(archive.read(refs[digest]))
        cat = cache[digest]
        k = list(cat.satellite_numbers).index(r["number"])
        ages[i] = (r["utc_ns"] - cat.element_epoch_utc_ns()[k]) / 3.6e12
        for j, offset in enumerate((-1, 0, 1)):
            jd, fr = julian_day_from_utc_ns(r["utc_ns"] + offset * 10**9)
            err, p, v = cat.satellites[k].sgp4_array(jd, fr)
            if np.any(err):
                raise ValueError("propagation error")
            p, v = teme_to_ecef(p, v, greenwich_mean_sidereal_time_rad(jd, fr))
            states[j, i] = [p[0], v[0]]
    y = np.array([r["measured_hz"] for r in rows])
    response = np.array([r["proxy_db"] for r in rows])
    folds = np.array([r["number"] % 3 for r in rows])
    enu = np.array([r["enu"] for r in rows])
    lanes = sorted({(r["channel"], r["edge"]) for r in rows})
    lane = np.array([lanes.index((r["channel"], r["edge"])) for r in rows])
    intercept = np.eye(len(lanes))[lane]
    groups = [(r["session_id"], r["number"], r["channel"], r["edge"]) for r in rows]
    size = Counter(groups)
    weight = np.array([1 / size[g] for g in groups])
    times = np.array([r["utc_ns"] / 1e9 for r in rows])
    times -= times.min()
    # Explicitly local: use known site only to define/evaluate this ablation.
    region = Region(*SITE, 200, 200)
    results = []
    for fold in range(3):
        calibration_rows = folds != fold
        test = np.flatnonzero(folds == fold)
        design = np.column_stack([intercept, enu[:, 0]])
        w = np.sqrt(weight[calibration_rows])
        beta = np.linalg.lstsq(
            design[calibration_rows] * w[:, None], response[calibration_rows] * w, rcond=None
        )[0]
        residual = response[calibration_rows] - design[calibration_rows] @ beta
        sigma = float(np.sqrt(np.average(residual**2, weights=weight[calibration_rows])))
        labels = np.array([r["session_id"] + r["tracklet_id"] for r in rows])[test]
        _, segment = np.unique(labels, return_inverse=True)
        training = np.zeros(len(test), bool)
        for group in np.unique(segment):
            idx = np.flatnonzero(segment == group)
            training[idx] = np.arange(len(idx)) % 5 != 4
        data = FormalOrbitData(
            y[test],
            training,
            segment,
            segment,
            np.array([r["number"] for r in rows])[test],
            ages[test],
            states[1, test, 0],
            states[1, test, 1],
            states[0, test, 0],
            states[0, test, 1],
            states[2, test, 0],
            states[2, test, 1],
            times[test],
        )
        # One actual midpoint observation per session/satellite, not per channel.
        pass_index = {}
        for i in test[training]:
            pass_index.setdefault((rows[i]["session_id"], rows[i]["number"]), []).append(i)
        beam_indexes = [
            sorted(
                ii,
                key=lambda i: (
                    times[i],
                    rows[i]["channel"],
                    rows[i]["edge"],
                    rows[i]["tracklet_id"],
                ),
            )[len(ii) // 2]
            for ii in pass_index.values()
        ]
        test_row = np.full(len(rows), -1, dtype=int)
        test_row[test] = np.arange(len(test))
        beam_doppler_indexes = test_row[beam_indexes]
        calibrations = tuple(
            EastWestBeamCalibration(
                float(beta[lane[i]]),
                abs(float(beta[-1])),
                max(sigma, 1.0),
                90,
                f"lt3d-fold-{fold}-known-site",
                "glrt_margin_log_ratio",
            )
            for i in beam_indexes
        )
        beam = DualLnbBeamData(
            states[1, beam_indexes, 0],
            response[beam_indexes],
            calibrations,
            tuple(f"{rows[i]['session_id']}/{rows[i]['number']}" for i in beam_indexes),
            doppler_row_indices=beam_doppler_indexes,
        )
        cfg = FormalOrbitConfig(max_nfev=200)
        selected_lane = lane[beam_indexes]
        trials = [
            ("doppler-only", None, None),
            ("doppler-plus-beam-proxy", beam, None),
        ]
        for permutation in range(args.permutations):
            seed = 20260921 + fold + 3 * permutation
            rng = np.random.default_rng(seed)
            shuffled = beam.response_db.copy()
            for lane_id in np.unique(selected_lane):
                indexes = np.flatnonzero(selected_lane == lane_id)
                shuffled[indexes] = shuffled[rng.permutation(indexes)]
            null_beam = DualLnbBeamData(
                beam.satellite_position_ecef_km,
                shuffled,
                beam.calibration,
                beam.pass_ids,
                doppler_row_indices=beam.doppler_row_indices,
            )
            trials.append(("doppler-plus-shuffled-beam", null_beam, seed))
        for name, evidence, permutation_seed in trials:
            result = fit_formal_orbit(data, region, [20.0, -20.0], cfg, beam_data=evidence)
            # Verify the fitted quadratic orbit approximation against exact SGP4.
            from leo.analysis.research.formal_orbit import doppler_hz

            receiver = region.points([result.x_km[0]], [result.x_km[1]]).ecef_km[0]
            exact = []
            quadratic = []
            corrected_positions = {}
            for i in test:
                r = rows[i]
                phase = ages[i] * result.rate_corrections_s_h[str(r["number"])]
                cat = cache[r["catalogue_digest"]]
                k = list(cat.satellite_numbers).index(r["number"])
                jd, fr = julian_day_from_utc_ns(r["utc_ns"] + round(phase * 1e9))
                err, p, v = cat.satellites[k].sgp4_array(jd, fr)
                if np.any(err):
                    raise ValueError("exact fitted propagation failed")
                p, v = teme_to_ecef(p, v, greenwich_mean_sidereal_time_rad(jd, fr))
                corrected_positions[i] = p[0]
                exact.append(float(doppler_hz(receiver, p, v)[0]))
                approx = (
                    states[1, i]
                    + 0.5 * (states[2, i] - states[0, i]) * phase
                    + 0.5 * (states[2, i] + states[0, i] - 2 * states[1, i]) * phase**2
                )
                quadratic.append(float(doppler_hz(receiver, approx[0], approx[1])))
            discrepancy = np.array(exact) - quadratic
            frozen_orbit_change_db = []
            for i, calibration in zip(beam_indexes, calibrations, strict=True):
                nominal = states[1, i, 0] - receiver
                corrected = corrected_positions[i] - receiver
                nominal /= np.linalg.norm(nominal)
                corrected /= np.linalg.norm(corrected)
                frozen_orbit_change_db.append(
                    np.linalg.norm(corrected - nominal)
                    * abs(calibration.slope_db_per_direction_cosine)
                )
            frozen_orbit_max_db = float(np.max(frozen_orbit_change_db))
            out = dict(
                fold=fold,
                model=name,
                permutation_seed=permutation_seed,
                observations=len(test),
                beam_passes=len(beam_indexes),
                local_error_m=float(np.linalg.norm(result.x_km) * 1000),
                result=asdict(result),
                beam_calibration_sigma_db=sigma,
                beam_slope_db=float(beta[-1]),
                exact_propagation_max_difference_hz=float(np.max(abs(discrepancy))),
                exact_propagation_rms_difference_hz=float(np.sqrt(np.mean(discrepancy**2))),
                exact_propagation_pass=bool(np.max(abs(discrepancy)) < 0.1),
                beam_frozen_orbit_max_db=frozen_orbit_max_db,
                beam_frozen_orbit_max_sigma=frozen_orbit_max_db / max(sigma, 1.0),
            )
            results.append(out)
            print(json.dumps(out), flush=True)
            args.output.write_text(
                json.dumps(
                    dict(
                        scope="conditional local known-site calibration; not blind positioning",
                        trials=results,
                    ),
                    indent=2,
                )
                + "\n"
            )


if __name__ == "__main__":
    main()

"""Join exhaustive tracking, exact pairing and geometry scores into report tables."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pairs", type=Path, required=True)
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    exact = json.loads(args.pairs.read_text())
    scored = json.loads(args.scores.read_text())
    tracks = {(r["session_id"], r["tracklet_id"]): r for r in exact["tracks"]}
    groups: dict[tuple[str, str, str], dict[int, dict]] = defaultdict(dict)
    for row in exact["tracks"]:
        for pair in row["pairs"]:
            key = row["session_id"], pair["rx0_tracklet_id"], pair["rx1_tracklet_id"]
            groups[key][pair["visit_index"]] = pair
    links = []
    for (session, rx0, rx1), visits in sorted(groups.items()):
        left, right = tracks[session, rx0], tracks[session, rx1]
        a, b = left["candidates"], right["candidates"]
        state = (
            "unreviewed-side"
            if not a or not b
            else ("same-leader" if a[0]["number"] == b[0]["number"] else "different-leader")
        )
        links.append(
            {
                "session_id": session,
                "rx0_tracklet_id": rx0,
                "rx1_tracklet_id": rx1,
                "channel": left["channel"],
                "edge": left["edge"],
                "distinct_paired_visits": len(visits),
                "review_agreement": state,
                "rx0_candidates": [{k: v for k, v in c.items() if k != "enu"} for c in a],
                "rx1_candidates": [{k: v for k, v in c.items() if k != "enu"} for c in b],
            }
        )
    flat = []
    for row in scored["tracks"]:
        item = {
            k: row.get(k)
            for k in [
                "session_id",
                "tracklet_id",
                "receiver_id",
                "channel",
                "edge",
                "pass_key",
                "confirmatory_after_prior_freeze",
                "rank1_catalog_number",
                "rank2_catalog_number",
                "state",
                "reason",
                "beam_category",
                "visibility_status",
                "identity_evidence_use",
                "reject_identity_on_response_mismatch",
                "reject_identity_on_missing_detection",
            ]
        }
        item.update(row.get("doppler", {}))
        item["paired_points"] = row.get("continuity", {}).get("paired_point_count", 0)
        beam = row.get("beam", {})
        for rank in [1, 2]:
            item[f"rank{rank}_beam_rms_db"] = beam.get(f"rank{rank}_nominal", {}).get("rms_db")
        flat.append(item)
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "all_track_geometry_scores.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=sorted({k for r in flat for k in r}))
        writer.writeheader()
        writer.writerows(flat)
    output = {
        "all_pair_groups": dict(Counter(r["review_agreement"] for r in links)),
        "three_or_more_visits": dict(
            Counter(r["review_agreement"] for r in links if r["distinct_paired_visits"] >= 3)
        ),
        "interpretation": "Exact shared detections; correlated pair groups, not identity truth.",
        "links": links,
    }
    (args.output / "exact_continuity.json").write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()

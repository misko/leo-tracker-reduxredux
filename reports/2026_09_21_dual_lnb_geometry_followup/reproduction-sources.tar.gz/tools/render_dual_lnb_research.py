"""Render bounded audit artifacts and tables from frozen research results."""

import argparse
import json
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    doc = json.loads((args.input / "results.json").read_text())
    aligned_path = args.input / "position-aligned-permutations.json"
    ablation_path = aligned_path if aligned_path.exists() else args.input / "position-ablation.json"
    ablation = json.loads(ablation_path.read_text())
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), layout="constrained")
    series = [
        ("doppler-only", "Doppler only", "o-"),
        ("doppler-plus-beam-proxy", "Doppler + real proxy", "s-"),
    ]
    for name, label, style in series:
        trials = sorted(
            [r for r in ablation["trials"] if r["model"] == name], key=lambda r: r["fold"]
        )
        axes[0].plot(
            [r["fold"] for r in trials],
            [r["local_error_m"] for r in trials],
            style,
            label=label,
        )
        axes[1].plot(
            [r["fold"] for r in trials],
            [r["result"]["evaluation_rms_hz"] for r in trials],
            style,
            label=label,
        )
    nulls = [r for r in ablation["trials"] if r["model"] == "doppler-plus-shuffled-beam"]
    if nulls:
        folds = sorted({r["fold"] for r in nulls})
        for axis, getter in [
            (axes[0], lambda r: r["local_error_m"]),
            (axes[1], lambda r: r["result"]["evaluation_rms_hz"]),
        ]:
            values = [np.array([getter(r) for r in nulls if r["fold"] == fold]) for fold in folds]
            median = np.array([np.median(value) for value in values])
            low = median - np.array([np.min(value) for value in values])
            high = np.array([np.max(value) for value in values]) - median
            axis.errorbar(
                folds,
                median,
                yerr=np.vstack([low, high]),
                marker="^",
                linestyle="--",
                capsize=4,
                label="20 shuffled proxies: median and range",
            )
    axes[0].axhline(1000, color="grey", linestyle="--", linewidth=1)
    axes[0].set(
        xlabel="Satellite-disjoint fold", ylabel="Local position error (m)", xticks=[0, 1, 2]
    )
    axes[1].set(
        xlabel="Satellite-disjoint fold", ylabel="Evaluation Doppler RMS (Hz)", xticks=[0, 1, 2]
    )
    for a in axes:
        a.legend(fontsize=8)
        a.grid(alpha=0.2)
    fig.suptitle(
        "Phase-aligned conditional local ablation · known-site calibration · not blind positioning"
    )
    fig.savefig(args.output / "position-ablation.png", dpi=160)
    plt.close(fig)
    if nulls:
        folds = sorted({r["fold"] for r in nulls})
        baseline = {
            r["fold"]: r
            for r in ablation["trials"]
            if r["model"] == "doppler-only"
        }
        real = {
            r["fold"]: r
            for r in ablation["trials"]
            if r["model"] == "doppler-plus-beam-proxy"
        }
        fig, axes = plt.subplots(1, 2, figsize=(13, 5), layout="constrained")
        position_null = [
            [r["local_error_m"] for r in nulls if r["fold"] == fold] for fold in folds
        ]
        rms_null = [
            [r["result"]["evaluation_rms_hz"] for r in nulls if r["fold"] == fold]
            for fold in folds
        ]
        for axis, values, base_values, real_values, ylabel in [
            (
                axes[0],
                position_null,
                [baseline[fold]["local_error_m"] for fold in folds],
                [real[fold]["local_error_m"] for fold in folds],
                "Local position error (m)",
            ),
            (
                axes[1],
                rms_null,
                [baseline[fold]["result"]["evaluation_rms_hz"] for fold in folds],
                [real[fold]["result"]["evaluation_rms_hz"] for fold in folds],
                "Held-out Doppler RMS (Hz)",
            ),
        ]:
            axis.boxplot(values, positions=folds, widths=0.45, showfliers=False)
            axis.scatter(folds, base_values, marker="o", s=55, label="Doppler only", zorder=3)
            axis.scatter(folds, real_values, marker="*", s=120, label="Real proxy", zorder=4)
            axis.set(xlabel="Satellite-disjoint fold", ylabel=ylabel, xticks=folds)
            axis.grid(alpha=0.2)
            axis.legend(fontsize=8)
        fig.suptitle(
            "Real phase-aligned proxy against 20 within-lane permutations per fold"
        )
        fig.savefig(args.output / "position-permutation-null.png", dpi=160)
        plt.close(fig)
    groups = defaultdict(list)
    for point in doc["geometry_proxy_points"]:
        groups[(point["session_id"], point["number"], point["channel"], point["edge"])].append(
            point
        )
    selected = sorted(groups, key=lambda k: (-len(groups[k]), k))[:3]
    fig, axes = plt.subplots(3, 2, figsize=(13, 10), layout="constrained")
    for panels, key in zip(axes, selected, strict=True):
        points = sorted(groups[key], key=lambda r: r["time_s"])
        t = [r["time_s"] for r in points]
        for rx in (0, 1):
            panels[0].scatter(t, [r[f"margin{rx}"] for r in points], s=12, label=f"RX{rx}")
        panels[0].set(
            title=f"{key[0]} · candidate {key[1]} · CH{key[2]} {key[3]}",
            ylabel="GLRT margin",
            xlabel="Capture time (s)",
        )
        panels[0].legend()
        panels[1].scatter(t, [r["proxy_db"] for r in points], s=12, label="Measured detector ratio")
        panels[1].set(ylabel="10 log10(margin RX0/RX1), not RF power", xlabel="Capture time (s)")
        other = panels[1].twinx()
        other.plot(t, [r["enu"][0] for r in points], color="orange", label="East direction cosine")
        other.set_ylabel("Candidate east direction cosine", color="orange")
    fig.suptitle(
        "Three passes with the most paired labelled observations · selection by count only"
    )
    fig.savefig(args.output / "response-examples.png", dpi=160)
    plt.close(fig)
    links = sorted(
        [
            r
            for r in doc["review_links"]
            if r["anchored_candidate_link"] and not r["current_slope_gate"]
        ],
        key=lambda r: -r["extension_s"],
    )
    fig, ax = plt.subplots(figsize=(12, 5), layout="constrained")
    for i, r in enumerate(links):
        ax.plot(
            [r["start0_s"], r["end0_s"]],
            [i + 0.12] * 2,
            "o-",
            color="C0",
            label="RX0" if i == 0 else None,
        )
        ax.plot(
            [r["start1_s"], r["end1_s"]],
            [i - 0.12] * 2,
            "o-",
            color="C1",
            label="RX1" if i == 0 else None,
        )
    ax.set(
        yticks=range(len(links)),
        yticklabels=[
            (
                f"{r['session_id']}\nCH{r['channel']} {r['edge']} · candidate {r['left_number']}\n"
                f"{r['simultaneous_anchors']} anchors, +{r['extension_s']:.1f}s"
            )
            for r in links
        ],
        xlabel="Capture time (s)",
        xlim=(0, 300),
    )
    ax.legend()
    ax.grid(alpha=0.2)
    ax.set_title("Four additional candidate links with simultaneous timing/frequency anchors")
    fig.savefig(args.output / "handoff-opportunities.png", dpi=160)
    plt.close(fig)
    lines = [
        "# Scan inventory",
        "",
        (
            "Product states are frozen at read-only export time. "
            "The capture window ends 2026-09-21 13:56:54 UTC."
        ),
        "",
        "| Capture UTC | Session | Metrics | Tracking | Tracklets | Reviews | Paired detections |",
        "|---|---|---|---|---:|---:|---:|",
    ]
    for r in sorted(doc["scans"], key=lambda r: r.get("created_utc_ns", 0)):
        if "created_utc_ns" not in r:
            continue
        when = datetime.fromtimestamp(r["created_utc_ns"] / 1e9, UTC).strftime("%H:%M:%S")
        lines.append(
            f"| {when} | `{r['session_id']}` | {'complete' if 'offset' in r else 'unavailable'} | "
            f"{r.get('tracking_state', 'unknown')} | {r.get('tracklets', 0)} | "
            f"{r.get('reviews', 0)} | {r.get('unique_pairs', 0)} |"
        )
    (args.output / "scan-inventory.md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()

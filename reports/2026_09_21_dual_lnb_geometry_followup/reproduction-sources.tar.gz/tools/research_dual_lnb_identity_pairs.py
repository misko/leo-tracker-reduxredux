#!/usr/bin/env python3
"""Export exact cross-receiver pairs and candidate geometry for ID controls."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from importlib import import_module
from pathlib import Path
from typing import Any

import numpy as np
from research_dual_lnb_geometry import detections

from leo.analysis.persistent_hop_trajectory import reconstruct_persistent_hop_trajectories
from leo.analysis.research.dual_lnb_tracking import (
    fit_receiver_offset,
    match_dual_lnb,
    timing_edges,
)
from leo.analysis.research.formal_orbit import doppler_hz
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.frames import (
    geodetic_to_ecef_km,
    greenwich_mean_sidereal_time_rad,
    julian_day_from_utc_ns,
    teme_to_ecef,
)
from leo.sky.propagation import parse_element_sets

CALIBRATION_SITE = (37.84903264307456, -122.4856541910174, 0.0)
_FULL_CORPUS = import_module("research_dual_lnb_full_corpus")
read_document = _FULL_CORPUS.read_document
tracking_input = _FULL_CORPUS.tracking_input


def _candidate_key(candidate) -> tuple[int, int, int, str, int]:
    return (
        int(candidate.visit_index),
        int(candidate.receiver_id),
        int(candidate.channel),
        str(candidate.edge),
        int(candidate.candidate_rank),
    )


def _detection_key(detection) -> tuple[int, int, int, str, int]:
    return (
        int(detection.visit),
        int(detection.receiver),
        int(detection.channel),
        str(detection.edge),
        int(detection.rank),
    )


def _directions(catalogue, number: int, utc_ns: np.ndarray) -> np.ndarray:
    numbers = list(catalogue.satellite_numbers)
    if number not in numbers:
        raise ValueError("candidate-absent-from-causal-snapshot")
    jd, fraction = julian_day_from_utc_ns(utc_ns)
    error, position, velocity = catalogue.satellites[numbers.index(number)].sgp4_array(
        jd, fraction
    )
    if np.any(error):
        raise ValueError("candidate-propagation-failed")
    position, _ = teme_to_ecef(
        position, velocity, greenwich_mean_sidereal_time_rad(jd, fraction)
    )
    latitude = np.deg2rad(CALIBRATION_SITE[0])
    longitude = np.deg2rad(CALIBRATION_SITE[1])
    receiver = geodetic_to_ecef_km(*CALIBRATION_SITE)
    unit = position - receiver
    unit /= np.linalg.norm(unit, axis=1)[:, None]
    east = np.array([-np.sin(longitude), np.cos(longitude), 0.0])
    north = np.array(
        [
            -np.sin(latitude) * np.cos(longitude),
            -np.sin(latitude) * np.sin(longitude),
            np.cos(latitude),
        ]
    )
    up = np.array(
        [
            np.cos(latitude) * np.cos(longitude),
            np.cos(latitude) * np.sin(longitude),
            np.sin(latitude),
        ]
    )
    return unit @ np.array([east, north, up]).T


def _candidate_output(value, pairs, catalogue, capture_ns):
    number = int(value["catalog_number"])
    output = {
        "rank": int(value["rank"]),
        "number": number,
        "training_rms_hz": float(value["fit_rms_hz"]),
        "evaluation_rms_hz": float(value["randomized_evaluation_rms_hz"]),
        "state": "scored",
        "enu": [],
    }
    try:
        reason = _candidate_epoch_reason(catalogue, number, capture_ns)
        if reason is not None:
            raise ValueError(reason)
        if pairs:
            utc_ns = np.asarray([row["utc_ns"] for row in pairs], np.int64)
            output["enu"] = [
                [float(component) for component in direction]
                for direction in _directions(catalogue, number, utc_ns)
            ]
    except ValueError as error:
        output["state"] = str(error)
        output["enu"] = []
    return output


def _candidate_epoch_reason(catalogue, number: int, capture_ns: int) -> str | None:
    numbers = list(catalogue.satellite_numbers)
    if number not in numbers:
        return "candidate-absent-from-causal-snapshot"
    if int(catalogue.element_epoch_utc_ns()[numbers.index(number)]) >= capture_ns:
        return "candidate-element-epoch-not-before-capture"
    return None


def _unique_pair_records(records):
    counts = Counter(record["pair_id"] for record in records)
    return [record for record in records if counts[record["pair_id"]] == 1], sum(
        count for count in counts.values() if count > 1
    )


def _leader_prediction_hz(catalogue, review_candidate, utc_ns: int, site):
    number = int(review_candidate["catalog_number"])
    numbers = list(catalogue.satellite_numbers)
    jd, fraction = julian_day_from_utc_ns(
        utc_ns + round(float(review_candidate["selected_tau_s"]) * 1e9)
    )
    error, position, velocity = catalogue.satellites[numbers.index(number)].sgp4_array(
        jd, fraction
    )
    if np.any(error):
        raise ValueError("leader-prediction-propagation-failed")
    position, velocity = teme_to_ecef(
        position, velocity, greenwich_mean_sidereal_time_rad(jd, fraction)
    )
    receiver = geodetic_to_ecef_km(
        float(site["latitude_deg"]),
        float(site["longitude_deg"]),
        float(site["altitude_m"]),
    )
    return float(doppler_hz(receiver, position, velocity)[0]) + float(
        review_candidate["fitted_offset_hz"]
    )


def _clear_review(review):
    candidates = review.get("candidates", [])
    if len(candidates) < 2:
        return False
    leader = float(candidates[0]["randomized_evaluation_rms_hz"])
    runner = float(candidates[1]["randomized_evaluation_rms_hz"])
    return leader <= 150 and runner >= 3 * max(leader, 1)


def tracks_for_scan(document, catalogue):
    product = document["tracking"]
    raw_source = document["source"]
    source = tracking_input(raw_source)
    candidates = project_scanner_candidates(source)
    candidate_by_key = {_candidate_key(candidate): candidate for candidate in candidates}
    if len(candidate_by_key) != len(candidates):
        raise ValueError("projected candidate membership key is not unique")
    trajectory = reconstruct_persistent_hop_trajectories(candidates)
    rebuilt_ids = {str(track.tracklet_id) for track in trajectory.tracklets}
    persisted_ids = {str(track["tracklet_id"]) for track in product["tracklets"]}
    if rebuilt_ids != persisted_ids:
        raise ValueError("reconstructed track IDs differ from persisted inventory")
    membership: dict[str, dict[str, float]] = defaultdict(dict)
    for track in trajectory.tracklets:
        for point in track.points:
            membership[point.candidate_id][str(track.tracklet_id)] = float(
                point.normalized_dealiased_cfo_hz
            )

    reviews = {str(row["tracklet_id"]): row for row in product.get("track_reviews", [])}
    track_summaries = {str(row["tracklet_id"]): row for row in product["tracklets"]}
    pairs_by_track: dict[str, list[dict[str, Any]]] = defaultdict(list)
    edges = timing_edges(detections(raw_source), float(raw_source["sample_rate_hz"]))
    offset = fit_receiver_offset([edge for edge in edges if edge[0].visit % 2 == 0])
    matches = match_dual_lnb(edges, offset)
    counts: Counter[str] = Counter()
    counts["projected_candidates"] = len(candidates)
    counts["reconstructed_tracks"] = len(trajectory.tracklets)
    counts["timing_frequency_matches"] = len(matches)
    records = []
    session_id = str(document["session_id"])
    for left, right, _, _ in matches:
        left_candidate = candidate_by_key.get(_detection_key(left))
        right_candidate = candidate_by_key.get(_detection_key(right))
        if left_candidate is None or right_candidate is None:
            counts["missing_projected_candidate"] += 1
            continue
        left_members = membership.get(str(left_candidate.candidate_id), {})
        right_members = membership.get(str(right_candidate.candidate_id), {})
        if not left_members or not right_members:
            counts["matched_candidate_outside_track"] += 1
            continue
        if len(left_members) != 1 or len(right_members) != 1:
            counts["matched_candidate_ambiguous_track_membership"] += 1
            continue
        left_track, left_y = next(iter(left_members.items()))
        right_track, right_y = next(iter(right_members.items()))
        pair = {
            "utc_ns": int(
                round(
                    (
                        left_candidate.support_center_utc_ns
                        + right_candidate.support_center_utc_ns
                    )
                    / 2
                )
            ),
            "proxy_db": float(10 * np.log10(left.margin / right.margin)),
            "visit_index": int(left.visit),
            "rx0_tracklet_id": left_track,
            "rx1_tracklet_id": right_track,
        }
        pair_id = f"{session_id}:{left.visit}:{left_track}:{right_track}"
        records.append(
            {
                "pair_id": pair_id,
                "pair": pair,
                "left_candidate": left_candidate,
                "right_candidate": right_candidate,
                "left_y_hz": left_y,
                "right_y_hz": right_y,
            }
        )
    records, duplicate_rows = _unique_pair_records(records)
    counts["duplicate_pair_rows_excluded"] = duplicate_rows
    calibration = []
    capture_ns = int(raw_source["timing"]["first_sample_estimate_utc_ns"])
    for record in records:
        pair = record["pair"]
        left_track = pair["rx0_tracklet_id"]
        right_track = pair["rx1_tracklet_id"]
        pairs_by_track[left_track].append(pair)
        pairs_by_track[right_track].append(pair)
        counts["matches_with_exact_track_membership"] += 1
        left_review = reviews.get(left_track)
        right_review = reviews.get(right_track)
        if left_review is None or right_review is None:
            counts["calibration_excluded_missing_review"] += 1
            continue
        if not _clear_review(left_review) or not _clear_review(right_review):
            counts["calibration_excluded_unclear_leader"] += 1
            continue
        left_leader = left_review["candidates"][0]
        right_leader = right_review["candidates"][0]
        number = int(left_leader["catalog_number"])
        if number != int(right_leader["catalog_number"]):
            counts["calibration_excluded_different_leader"] += 1
            continue
        reason = _candidate_epoch_reason(catalogue, number, capture_ns)
        if reason is not None:
            counts[f"calibration_excluded_{reason}"] += 1
            continue
        try:
            left_prediction = _leader_prediction_hz(
                catalogue,
                left_leader,
                int(record["left_candidate"].support_center_utc_ns),
                product["observer_site"],
            )
            right_prediction = _leader_prediction_hz(
                catalogue,
                right_leader,
                int(record["right_candidate"].support_center_utc_ns),
                product["observer_site"],
            )
        except ValueError:
            counts["calibration_excluded_prediction_failure"] += 1
            continue
        if (
            abs(float(record["left_y_hz"]) - left_prediction) > 500
            or abs(float(record["right_y_hz"]) - right_prediction) > 500
        ):
            counts["calibration_excluded_leader_residual_above_500_hz"] += 1
            continue
        try:
            direction = _directions(
                catalogue, number, np.asarray([pair["utc_ns"]], np.int64)
            )[0]
        except ValueError:
            counts["calibration_excluded_geometry_failure"] += 1
            continue
        calibration.append(
            {
                "session_id": session_id,
                "number": number,
                "channel": int(track_summaries[left_track]["channel"]),
                "edge": str(track_summaries[left_track]["edge"]),
                "utc_ns": pair["utc_ns"],
                "enu": [float(value) for value in direction],
                "proxy_db": pair["proxy_db"],
                "pair_id": record["pair_id"],
            }
        )
    output = []
    for tracklet_id, track in sorted(track_summaries.items()):
        pairs = sorted(
            pairs_by_track[tracklet_id],
            key=lambda row: (row["utc_ns"], row["rx0_tracklet_id"], row["rx1_tracklet_id"]),
        )
        review = reviews.get(tracklet_id)
        candidate_values = [] if review is None else review.get("candidates", [])[:2]
        candidates_output = (
            [_candidate_output(value, pairs, catalogue, capture_ns) for value in candidate_values]
            if len(candidate_values) == 2
            else []
        )
        rank1 = candidates_output[0]["number"] if candidates_output else None
        output.append(
            {
                "session_id": session_id,
                "tracklet_id": tracklet_id,
                "receiver_id": int(track["receiver_id"]),
                "channel": int(track["channel"]),
                "edge": str(track["edge"]),
                "start_utc_ns": int(track["start_utc_ns"]),
                "pass_key": (
                    f"{session_id}:{rank1}"
                    if rank1 is not None
                    else f"{session_id}:unsupported:{tracklet_id}"
                ),
                "candidates": candidates_output,
                "pairs": pairs,
                "direction_site": {
                    "latitude_deg": CALIBRATION_SITE[0],
                    "longitude_deg": CALIBRATION_SITE[1],
                    "altitude_m": CALIBRATION_SITE[2],
                },
                "direction_time_basis": "paired response UTC; nominal causal TLE without tau",
                "doppler_review_site": product["observer_site"],
            }
        )
    counts["persisted_tracks"] = len(output)
    counts["tracks_with_exact_pairs"] = sum(bool(row["pairs"]) for row in output)
    counts["tracks_with_top_two"] = sum(len(row["candidates"]) == 2 for row in output)
    counts["exact_calibration_points"] = len(calibration)
    return output, calibration, dict(counts)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--geometry", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--window-start-utc-ns", type=int, required=True)
    parser.add_argument("--window-end-utc-ns", type=int, required=True)
    args = parser.parse_args()
    if args.window_start_utc_ns >= args.window_end_utc_ns:
        parser.error("window start must precede end")
    geometry = read_document(args.geometry)
    archive = TleArchiveReader(args.tle_archive)
    references = {reference.digest: reference for reference in archive.list_snapshots()}
    catalogues = {}
    tracks = []
    exact_calibration = []
    scan_audit = []
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    for path in sorted(args.input.glob("*.json.gz")):
        document = read_document(path)
        created = int(document["created_utc_ns"])
        if not args.window_start_utc_ns <= created < args.window_end_utc_ns:
            continue
        product = document.get("tracking")
        if product is None or document.get("source") is None:
            continue
        cache_path = args.cache_dir / f"{document['session_id']}.json"
        if cache_path.exists():
            cached = json.loads(cache_path.read_text())
            if (
                cached.get("cache_version") == 1
                and cached.get("input_digest") == document.get("input_digest")
            ):
                tracks.extend(cached["tracks"])
                exact_calibration.extend(cached["calibration_points"])
                scan_audit.append(cached["audit"])
                print(
                    json.dumps(
                        {"phase": "scan-cache", "session_id": str(document["session_id"])}
                    ),
                    flush=True,
                )
                continue
        snapshot = product["original_tle_snapshot"]
        capture_ns = int(document["source"]["timing"]["first_sample_estimate_utc_ns"])
        if int(snapshot["collected_utc_ns"]) >= capture_ns:
            raise ValueError("identity snapshot was not available before capture")
        snapshot_digest = str(snapshot["digest"])
        if snapshot_digest not in references:
            raise ValueError(f"causal snapshot absent from archive: {snapshot_digest}")
        if snapshot_digest not in catalogues:
            catalogues[snapshot_digest] = parse_element_sets(
                archive.read(references[snapshot_digest])
            )
        scan_tracks, scan_calibration, counts = tracks_for_scan(
            document, catalogues[snapshot_digest]
        )
        tracks.extend(scan_tracks)
        exact_calibration.extend(scan_calibration)
        audit = {"session_id": str(document["session_id"]), **counts}
        scan_audit.append(audit)
        cache_path.write_text(
            json.dumps(
                {
                    "cache_version": 1,
                    "input_digest": document.get("input_digest"),
                    "tracks": scan_tracks,
                    "calibration_points": scan_calibration,
                    "audit": audit,
                },
                sort_keys=True,
                allow_nan=False,
            )
            + "\n"
        )
        print(
            json.dumps(
                {
                    "phase": "scan",
                    "session_id": str(document["session_id"]),
                    **counts,
                }
            ),
            flush=True,
        )
    tracks.sort(key=lambda row: (row["session_id"], row["tracklet_id"]))
    exact_calibration.sort(key=lambda row: (row["session_id"], row["utc_ns"], row["pair_id"]))
    output = {
        "window_start_utc_ns": args.window_start_utc_ns,
        "window_end_utc_ns": args.window_end_utc_ns,
        "tracks": tracks,
        "calibration_points": exact_calibration,
        "calibration_audit": {
            "surveyed_site": {
                "latitude_deg": CALIBRATION_SITE[0],
                "longitude_deg": CALIBRATION_SITE[1],
                "altitude_m": CALIBRATION_SITE[2],
            },
            "fresh_audit_geometry_points_not_used": len(geometry["geometry_proxy_points"]),
            "scans": scan_audit,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "tracks": len(tracks),
                "tracks_with_pairs": sum(bool(row["pairs"]) for row in tracks),
                "pairs": sum(len(row["pairs"]) for row in tracks),
                "calibration_points": len(output["calibration_points"]),
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()

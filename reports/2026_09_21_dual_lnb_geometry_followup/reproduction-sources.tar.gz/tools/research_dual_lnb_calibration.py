"""Prospective beam-proxy calibration transfer on chronological capture blocks.

This is a known-site detector-response experiment, not a position benchmark.
It never reads or scores receiver coordinate error. Calibration fits use only
captures earlier than the held-out block, while catalogue-derived ENU direction
is taken from the frozen geometry research export.
"""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

plt.switch_backend("Agg")


MODEL_NAMES = ("linear-east", "linear-east-north", "robust-quadratic")


def design_matrix(rows, lanes, model):
    lane_index = {lane: i for i, lane in enumerate(lanes)}
    lane = np.array([lane_index[(r["channel"], r["edge"])] for r in rows])
    intercept = np.eye(len(lanes))[lane]
    enu = np.array([r["enu"] for r in rows], dtype=float)
    east, north = enu[:, 0], enu[:, 1]
    if model == "linear-east":
        features = [east]
    elif model == "linear-east-north":
        features = [east, north]
    elif model == "robust-quadratic":
        # Fixed before evaluation: a local second-order horizontal response
        # surface. Robust fitting limits isolated detector fades.
        features = [east, north, east * east, east * north, north * north]
    else:
        raise ValueError(f"unknown model: {model}")
    return np.column_stack([intercept, *features])


def group_weights(rows):
    """Give every session/satellite/RF-lane group equal total weight."""
    groups = [(r["session_id"], r["number"], r["channel"], r["edge"]) for r in rows]
    sizes = Counter(groups)
    return np.array([1.0 / sizes[group] for group in groups])


def weighted_fit(design, response, weight, *, robust=False):
    if not np.all(np.isfinite(design)) or not np.all(np.isfinite(response)):
        raise ValueError("calibration inputs must be finite")
    robust_weight = np.ones(len(response))
    beta = np.zeros(design.shape[1])
    iterations = 1
    for iterations in range(1, 51 if robust else 2):
        root = np.sqrt(weight * robust_weight)
        updated = np.linalg.lstsq(design * root[:, None], response * root, rcond=None)[0]
        if robust and iterations > 1 and np.max(abs(updated - beta)) < 1e-9:
            beta = updated
            break
        beta = updated
        if not robust:
            break
        residual = response - design @ beta
        center = float(np.median(residual))
        scale = max(1e-6, 1.4826 * float(np.median(abs(residual - center))))
        z = abs(residual - center) / (1.345 * scale)
        robust_weight = np.where(z <= 1, 1.0, 1.0 / z)
    return beta, iterations


def weighted_metrics(residual, weight):
    total = float(np.sum(weight))
    mean = float(np.sum(weight * residual) / total)
    centered = residual - mean
    return {
        "weighted_rms_db": float(np.sqrt(np.sum(weight * residual**2) / total)),
        "weighted_bias_db": mean,
        "weighted_scatter_db": float(np.sqrt(np.sum(weight * centered**2) / total)),
        "weighted_mae_db": float(np.sum(weight * abs(residual)) / total),
        "point_rms_db": float(np.sqrt(np.mean(residual**2))),
    }


def grouped_bias(rows, residual, key):
    values = defaultdict(list)
    for row, value in zip(rows, residual, strict=True):
        values[key(row)].append(float(value))
    summaries = [
        {
            "group": "/".join(map(str, group if isinstance(group, tuple) else (group,))),
            "points": len(group_values),
            "bias_db": float(np.mean(group_values)),
            "rms_db": float(np.sqrt(np.mean(np.square(group_values)))),
        }
        for group, group_values in values.items()
    ]
    biases = np.array([r["bias_db"] for r in summaries])
    return {
        "groups": len(summaries),
        "bias_rms_db": float(np.sqrt(np.mean(biases**2))),
        "bias_median_abs_db": float(np.median(abs(biases))),
        "bias_p90_abs_db": float(np.quantile(abs(biases), 0.9)),
        "largest_abs_bias": sorted(summaries, key=lambda r: (-abs(r["bias_db"]), r["group"]))[
            :10
        ],
    }


def explained_group_fraction(rows, residual, key, weight):
    global_mean = float(np.average(residual, weights=weight))
    centered = residual - global_mean
    total = float(np.sum(weight * centered**2))
    if total == 0:
        return 0.0
    grouped = defaultdict(list)
    for i, row in enumerate(rows):
        grouped[key(row)].append(i)
    within = 0.0
    for indexes in grouped.values():
        indexes = np.array(indexes)
        mean = float(np.average(residual[indexes], weights=weight[indexes]))
        within += float(np.sum(weight[indexes] * (residual[indexes] - mean) ** 2))
    return float(max(0.0, min(1.0, 1.0 - within / total)))


def cluster_bootstrap(rows, residual, weight, *, repetitions, seed):
    """Resample held-out sessions, preserving every within-session correlation."""
    by_session = defaultdict(list)
    for i, row in enumerate(rows):
        by_session[row["session_id"]].append(i)
    sessions = sorted(by_session)
    contributions = []
    for session in sessions:
        indexes = np.array(by_session[session])
        contributions.append(
            (
                float(np.sum(weight[indexes])),
                float(np.sum(weight[indexes] * residual[indexes])),
                float(np.sum(weight[indexes] * residual[indexes] ** 2)),
            )
        )
    contributions = np.array(contributions)
    rng = np.random.default_rng(seed)
    rms = np.empty(repetitions)
    mean = np.empty(repetitions)
    for i in range(repetitions):
        sample = contributions[rng.integers(0, len(sessions), len(sessions))]
        denominator = sample[:, 0].sum()
        mean[i] = sample[:, 1].sum() / denominator
        rms[i] = np.sqrt(sample[:, 2].sum() / denominator)
    weighted_mean = np.average(residual, weights=weight)
    residual_variance = float(np.average((residual - weighted_mean) ** 2, weights=weight))
    mean_variance = float(np.var(mean, ddof=1))
    return {
        "sessions": len(sessions),
        "repetitions": repetitions,
        "weighted_rms_95_db": [float(x) for x in np.quantile(rms, [0.025, 0.975])],
        "weighted_bias_95_db": [float(x) for x in np.quantile(mean, [0.025, 0.975])],
        "cluster_mean_se_db": float(np.sqrt(mean_variance)),
        "effective_independent_points_for_mean": (
            float(residual_variance / mean_variance) if mean_variance > 0 else None
        ),
    }


def chronological_blocks(rows, count=4):
    session_times = defaultdict(list)
    for row in rows:
        session_times[row["session_id"]].append(row["utc_ns"])
    sessions = sorted(session_times, key=lambda s: (np.median(session_times[s]), s))
    blocks = [list(block) for block in np.array_split(sessions, count)]
    return blocks, session_times


def fold_metrics(train, test, model):
    lanes = sorted({(r["channel"], r["edge"]) for r in train})
    supported = [r for r in test if (r["channel"], r["edge"]) in set(lanes)]
    train_design = design_matrix(train, lanes, model)
    test_design = design_matrix(supported, lanes, model)
    train_response = np.array([r["proxy_db"] for r in train])
    test_response = np.array([r["proxy_db"] for r in supported])
    train_weight = group_weights(train)
    test_weight = group_weights(supported)
    beta, iterations = weighted_fit(
        train_design,
        train_response,
        train_weight,
        robust=model == "robust-quadratic",
    )
    residual = test_response - test_design @ beta
    return (
        beta,
        residual,
        test_weight,
        iterations,
        weighted_metrics(residual, test_weight),
        supported,
        lanes,
    )


def render_report(result, output):
    lines = [
        "# Prospective dual-LNB calibration transfer",
        "",
        result["interpretation"],
        "",
        result["geometry_note"],
        "",
        result["finding"],
        "",
        "Calibration is fit only on capture blocks preceding the evaluation block. "
        "No receiver coordinate error is read or used for tuning.",
        "",
        "| Model | OOF weighted RMS | OOF bias | Session-bias RMS | Satellite-bias RMS | "
        "Session residual fraction | Satellite residual fraction |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for model in result["aggregate"]:
        lines.append(
            f"| {model['model']} | {model['metrics']['weighted_rms_db']:.3f} dB | "
            f"{model['metrics']['weighted_bias_db']:+.3f} dB | "
            f"{model['session_bias']['bias_rms_db']:.3f} dB | "
            f"{model['satellite_bias']['bias_rms_db']:.3f} dB | "
            f"{model['session_residual_fraction']:.1%} | "
            f"{model['satellite_residual_fraction']:.1%} |"
        )
    lines.extend(
        [
            "",
            "The session-cluster bootstrap preserves all within-session correlation. "
            "Its effective point count describes uncertainty of the mean residual, not "
            "independent RF observations or calibrated position accuracy.",
            "",
            "## Chronological folds",
            "",
            "| Evaluation block | Training sessions | Evaluation sessions | Supported points | "
            "Model | RMS | Bias |",
            "|---:|---:|---:|---:|---|---:|---:|",
        ]
    )
    for fold in result["folds"]:
        for model in fold["models"]:
            lines.append(
                f"| {fold['evaluation_block']} | {fold['training_sessions']} | "
                f"{fold['evaluation_sessions']} | {fold['supported_evaluation_points']} / "
                f"{fold['evaluation_points']} | {model['model']} | "
                f"{model['metrics']['weighted_rms_db']:.3f} dB | "
                f"{model['metrics']['weighted_bias_db']:+.3f} dB |"
            )
    lines.extend(
        [
            "",
            "![Chronological calibration transfer](calibration-transfer.png)",
            "",
            "Detailed coefficients, bootstrap intervals, and the largest held-out session "
            "and satellite biases are retained in `calibration-results.json`.",
        ]
    )
    (output / "calibration-report.md").write_text("\n".join(lines) + "\n")


def render_figure(result, output):
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), layout="constrained")
    for model in MODEL_NAMES:
        folds = [f for f in result["folds"]]
        values = [next(m for m in f["models"] if m["model"] == model) for f in folds]
        x = [f["evaluation_block"] for f in folds]
        axes[0].plot(x, [v["metrics"]["weighted_rms_db"] for v in values], "o-", label=model)
        axes[1].plot(x, [v["metrics"]["weighted_bias_db"] for v in values], "o-", label=model)
    axes[0].set(xlabel="Chronological evaluation block", ylabel="Weighted proxy RMS (dB)")
    axes[1].axhline(0, color="grey", linewidth=1)
    axes[1].set(xlabel="Chronological evaluation block", ylabel="Weighted residual bias (dB)")
    for axis in axes:
        axis.grid(alpha=0.2)
        axis.legend(fontsize=8)
    fig.suptitle("Known-site calibration transfer: train on earlier captures, evaluate later")
    fig.savefig(output / "calibration-transfer.png", dpi=160)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument(
        "--geometry-basis",
        choices=("nominal-sgp4", "fixed-site-doppler-phase-aligned"),
        default="nominal-sgp4",
    )
    parser.add_argument("--nominal-phase-bound-db", type=float)
    parser.add_argument("--nominal-phase-bound-sigma", type=float)
    args = parser.parse_args()
    if args.bootstrap < 100:
        parser.error("--bootstrap must be at least 100")
    bounds = (args.nominal_phase_bound_db, args.nominal_phase_bound_sigma)
    if any(value is not None and (not np.isfinite(value) or value < 0) for value in bounds):
        parser.error("nominal phase mismatch bounds must be finite and nonnegative")
    if args.geometry_basis == "nominal-sgp4" and any(value is None for value in bounds):
        parser.error("nominal SGP4 geometry requires both nominal phase mismatch bounds")
    args.output.mkdir(parents=True, exist_ok=True)
    document = json.loads(args.input.read_text())
    rows = document["geometry_proxy_points"]
    if len(rows) < 100 or any(not np.isfinite(r["proxy_db"]) for r in rows):
        raise ValueError("insufficient finite geometry proxy points")
    lanes = sorted({(r["channel"], r["edge"]) for r in rows})
    blocks, session_times = chronological_blocks(rows)
    block_rows = [
        [r for r in rows if r["session_id"] in set(block)]
        for block in blocks
    ]
    folds = []
    out_of_fold = {model: [] for model in MODEL_NAMES}
    for evaluation_block in range(1, len(blocks)):
        train = [r for block in block_rows[:evaluation_block] for r in block]
        test = block_rows[evaluation_block]
        models = []
        for model in MODEL_NAMES:
            beta, residual, weight, iterations, metrics, supported, fitted_lanes = fold_metrics(
                train, test, model
            )
            models.append(
                {
                    "model": model,
                    "coefficients": beta.tolist(),
                    "fitted_lanes": [list(lane) for lane in fitted_lanes],
                    "fit_iterations": iterations,
                    "metrics": metrics,
                }
            )
            out_of_fold[model].extend(
                (row, float(value), float(row_weight))
                for row, value, row_weight in zip(supported, residual, weight, strict=True)
            )
        folds.append(
            {
                "evaluation_block": evaluation_block,
                "training_blocks": list(range(evaluation_block)),
                "training_sessions": sum(len(block) for block in blocks[:evaluation_block]),
                "evaluation_sessions": len(blocks[evaluation_block]),
                "training_points": len(train),
                "evaluation_points": len(test),
                "supported_evaluation_points": len(supported),
                "unsupported_evaluation_points": len(test) - len(supported),
                "models": models,
            }
        )
    aggregate = []
    for model_index, model in enumerate(MODEL_NAMES):
        triples = out_of_fold[model]
        heldout_rows = [row for row, _, _ in triples]
        residual = np.array([value for _, value, _ in triples])
        weight = np.array([value for _, _, value in triples])
        aggregate.append(
            {
                "model": model,
                "metrics": weighted_metrics(residual, weight),
                "session_bias": grouped_bias(heldout_rows, residual, lambda r: r["session_id"]),
                "satellite_bias": grouped_bias(heldout_rows, residual, lambda r: r["number"]),
                "session_residual_fraction": explained_group_fraction(
                    heldout_rows, residual, lambda r: r["session_id"], weight
                ),
                "satellite_residual_fraction": explained_group_fraction(
                    heldout_rows, residual, lambda r: r["number"], weight
                ),
                "session_cluster_bootstrap": cluster_bootstrap(
                    heldout_rows,
                    residual,
                    weight,
                    repetitions=args.bootstrap,
                    seed=20260921 + model_index,
                ),
            }
        )
    block_summary = []
    for index, (block, block_data) in enumerate(zip(blocks, block_rows, strict=True)):
        times = [t for session in block for t in session_times[session]]
        block_summary.append(
            {
                "block": index,
                "sessions": len(block),
                "points": len(block_data),
                "start_utc_ns": int(min(times)),
                "end_utc_ns": int(max(times)),
                "session_ids": block,
            }
        )
    result = {
        "scope": "known-site beam calibration transfer; not positioning or blind localization",
        "geometry_basis": args.geometry_basis,
        "input_phase_alignment": document.get("phase_alignment"),
        "nominal_phase_mismatch_bound": {
            "max_db": args.nominal_phase_bound_db,
            "max_residual_sigma": args.nominal_phase_bound_sigma,
        },
        "input": {
            "points": len(rows),
            "sessions": len({r["session_id"] for r in rows}),
            "satellites": len({r["number"] for r in rows}),
            "lanes": [list(lane) for lane in lanes],
        },
        "models": {
            "linear-east": "per-lane intercepts plus shared east direction cosine",
            "linear-east-north": "per-lane intercepts plus shared east and north cosines",
            "robust-quadratic": (
                "Huber IRLS with per-lane intercepts and a fixed second-order east/north surface"
            ),
        },
        "blocks": block_summary,
        "folds": folds,
        "aggregate": aggregate,
        "interpretation": (
            "Chronological transfer measures whether an earlier known-site detector-response "
            "calibration predicts later captures. Catalogue directions and clear review leaders "
            "remain selection-conditioned; no coordinate error is used."
        ),
        "geometry_note": (
            (
                "Aligned diagnostic: ENU directions use a response-excluded, fixed-known-site "
                "linearized ridge Doppler profile. This lean approximation is research-only, "
                "not the validated production nuisance profiler or a deployable calibration."
            )
            if args.geometry_basis == "fixed-site-doppler-phase-aligned"
            else (
                "Diagnostic only: ENU directions use nominal SGP4. Prior phase-aligned analysis "
                f"bounds the resulting response change at {args.nominal_phase_bound_db} dB / "
                f"{args.nominal_phase_bound_sigma} residual sigma; this is not a deployable "
                "phase-consistent calibration."
            )
        ),
        "finding": (
            "The forward-transfer east+north model has "
            f"{aggregate[1]['metrics']['weighted_rms_db']:.3f} "
            f"dB weighted RMS. Session means account descriptively for "
            f"{aggregate[1]['session_residual_fraction']:.1%} of residual variation, versus "
            f"{aggregate[1]['satellite_residual_fraction']:.1%} for satellite grouping. "
            "The latter is confounded by which satellites occur in which sessions. Session drift "
            "is material but does not dominate the residual variance in this diagnostic. The "
            "robust quadratic surface does not improve consistently across future blocks."
        ),
    }
    (args.output / "calibration-results.json").write_text(json.dumps(result, indent=2) + "\n")
    render_report(result, args.output)
    render_figure(result, args.output)


if __name__ == "__main__":
    main()

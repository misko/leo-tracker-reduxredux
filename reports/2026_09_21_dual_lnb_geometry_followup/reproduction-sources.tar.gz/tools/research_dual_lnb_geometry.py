"""Offline LT3D-001A audit, receiver association replay, and beam-proxy falsification."""

import argparse
import gzip
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from leo.analysis.research.dual_lnb_tracking import (
    LnbDetection,
    fit_receiver_offset,
    match_dual_lnb,
    timing_edges,
    wrapped,
)
from leo.operations.tle_archive import TleArchiveReader
from leo.sky.frames import (
    geodetic_to_ecef_km,
    greenwich_mean_sidereal_time_rad,
    julian_day_from_utc_ns,
    teme_to_ecef,
)
from leo.sky.propagation import parse_element_sets

SITE = (37.84903264307456, -122.4856541910174)
REFERENCE = 11.2e9
END = 1789999014000000000


def detections(source):
    fs = source["sample_rate_hz"]
    origin = source["timing"]["session_start_device_sample_counter"]
    return [
        LnbDetection(
            p["visit_index"],
            p["receiver_id"],
            p["channel"],
            p["edge"],
            (p["valid_start_counter"] - origin) / fs,
            c["fractional_tracking_cfo_hz"],
            c["integer_epoch_sample"] + c["fractional_epoch_offset_samples"],
            c["fractional_margin"],
            c["candidate_rank"],
        )
        for p in source["probes"]
        for c in p["candidates"]
        if c["passed_fractional_margin_gate"]
    ]


def orbit(catalogue, number, utc_ns):
    index = list(catalogue.satellite_numbers).index(number)
    jd, fr = julian_day_from_utc_ns(np.asarray(utc_ns, np.int64))
    error, p, v = catalogue.satellites[index].sgp4_array(jd, fr)
    p, v = teme_to_ecef(p, v, greenwich_mean_sidereal_time_rad(jd, fr))
    receiver = geodetic_to_ecef_km(*SITE, 0.0)
    delta = p - receiver
    unit = delta / np.linalg.norm(delta, axis=1)[:, None]
    lat, lon = np.deg2rad(SITE)
    east = np.array([-np.sin(lon), np.cos(lon), 0.0])
    north = np.array([-np.sin(lat) * np.cos(lon), -np.sin(lat) * np.sin(lon), np.cos(lat)])
    up = np.array([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])
    cfo = -REFERENCE / 299792.458 * np.sum(unit * v, axis=1)
    cfo[error != 0] = np.nan
    return cfo, unit @ np.array([east, north, up]).T


def labels_for_pairs(row, pairs, catalogue):
    """Review-label consistency check, not independent emitter ground truth."""
    product = row["tracking"]
    tracks = {t["tracklet_id"]: t for t in product["tracklets"]}
    start = row["source"]["timing"]["first_sample_estimate_utc_ns"]
    labels = [[{}, {}] for _ in pairs]
    for review in product["track_reviews"]:
        candidates = review["candidates"]
        if len(candidates) < 2:
            continue
        top, second = candidates[:2]
        numbers = list(catalogue.satellite_numbers)
        if (
            top["catalog_number"] not in numbers
            or catalogue.element_epoch_utc_ns()[numbers.index(top["catalog_number"])] >= start
        ):
            continue
        if top["randomized_evaluation_rms_hz"] > 150 or second[
            "randomized_evaluation_rms_hz"
        ] < 3 * max(top["randomized_evaluation_rms_hz"], 1):
            continue
        track = tracks[review["tracklet_id"]]
        rx = track["receiver_id"]
        indexes = [
            i
            for i, pair in enumerate(pairs)
            if pair[rx].channel == track["channel"]
            and pair[rx].edge == track["edge"]
            and review["start_s"] - 0.03 <= pair[rx].time_s <= review["end_s"] + 0.03
        ]
        if not indexes:
            continue
        times = np.array([pairs[i][rx].time_s for i in indexes])
        utc = start + np.rint((times + top["selected_tau_s"]) * 1e9).astype(np.int64)
        try:
            predicted, _ = orbit(catalogue, top["catalog_number"], utc)
            _, enu = orbit(
                catalogue, top["catalog_number"], start + np.rint(times * 1e9).astype(np.int64)
            )
        except ValueError:
            continue
        predicted = (predicted + top["fitted_offset_hz"]) * track["actual_rf_hz"] / REFERENCE
        for i, expected, direction in zip(indexes, predicted, enu, strict=True):
            if abs(wrapped(pairs[i][rx].cfo_hz - expected)) < 500:
                raw = pairs[i][rx].cfo_hz
                lifted = raw + round((expected - raw) / (1 / 4.4e-6)) * (1 / 4.4e-6)
                labels[i][rx][top["catalog_number"]] = dict(
                    enu=direction.tolist(),
                    measured_hz=lifted * REFERENCE / track["actual_rf_hz"],
                    tracklet_id=review["tracklet_id"],
                )
    return labels


def analyze(row, catalogue, *, end_utc_ns=END):
    source = row.get("source")
    if source is None:
        return (
            {
                "session_id": row["session_id"],
                "error": row.get("analysis_error"),
                "created_utc_ns": row["created_utc_ns"],
                "tracking_state": row["tracking_state"],
                "visits": row["visits"],
                "six_hour_cohort": row["created_utc_ns"] >= end_utc_ns - 6 * 3600 * 10**9,
            },
            [],
            [],
        )
    ds = detections(source)
    edges = timing_edges(ds, source["sample_rate_hz"])
    offset = fit_receiver_offset([e for e in edges if e[0].visit % 2 == 0])
    pairs = match_dual_lnb(edges, offset)
    evaluation = [e for e in pairs if e[0].visit % 2]
    residuals = [float(wrapped(e[2] - offset.predict(e[0].time_s))) for e in evaluation]
    # Nulls preserve candidate counts/lane and deliberately break simultaneity.
    null_pairs = []
    for shift in (17, 53):
        right_by = {(d.visit, d.channel, d.edge): [] for d in ds if d.receiver == 1}
        for d in ds:
            if d.receiver == 1:
                right_by[(d.visit, d.channel, d.edge)].append(d)
        shifted = [d for d in ds if d.receiver == 0]
        lane_visits = {}
        for p in source["probes"]:
            if p["receiver_id"] == 1:
                lane_visits.setdefault((p["channel"], p["edge"]), []).append(p["visit_index"])
        for visit, ch, edge in sorted({(d.visit, d.channel, d.edge) for d in shifted}):
            visits = lane_visits[(ch, edge)]
            target = visits[(visits.index(visit) + shift) % len(visits)]
            for d in right_by.get((target, ch, edge), []):
                shifted.append(
                    LnbDetection(
                        visit, 1, ch, edge, d.time_s, d.cfo_hz, d.epoch_samples, d.margin, d.rank
                    )
                )
        null_pairs.append(
            len(match_dual_lnb(timing_edges(shifted, source["sample_rate_hz"]), offset))
        )
    probe_flags = {}
    for p in source["probes"]:
        probe_flags.setdefault(p["visit_index"], {})[p["receiver_id"]] = any(
            c["passed_fractional_margin_gate"] for c in p["candidates"]
        )
    counts = Counter(
        "both"
        if v.get(0) and v.get(1)
        else "rx0_only"
        if v.get(0)
        else "rx1_only"
        if v.get(1)
        else "neither"
        for v in probe_flags.values()
    )
    labels = (
        labels_for_pairs(row, pairs, catalogue)
        if catalogue is not None and row.get("tracking")
        else [[{}, {}] for _ in pairs]
    )
    geometry = []
    agree = disagree = 0
    for pair, label in zip(pairs, labels, strict=True):
        if len(label[0]) != 1 or len(label[1]) != 1:
            continue
        n0, n1 = next(iter(label[0])), next(iter(label[1]))
        if n0 != n1:
            disagree += 1
            continue
        agree += 1
        a, b, _, _ = pair
        geometry.append(
            dict(
                session_id=row["session_id"],
                number=n0,
                channel=a.channel,
                edge=a.edge,
                time_s=a.time_s,
                enu=label[0][n0]["enu"],
                measured_hz=label[0][n0]["measured_hz"],
                tracklet_id=label[0][n0]["tracklet_id"],
                tracklet_id_rx1=label[1][n1]["tracklet_id"],
                utc_ns=start_utc(row) + round(a.time_s * 1e9),
                catalogue_digest=row["tracking"]["original_tle_snapshot"]["digest"],
                proxy_db=float(10 * np.log10(a.margin / b.margin)),
                margin0=a.margin,
                margin1=b.margin,
            )
        )
    product = row.get("tracking") or {}
    summary = dict(
        session_id=row["session_id"],
        created_utc_ns=row["created_utc_ns"],
        six_hour_cohort=row["created_utc_ns"] >= end_utc_ns - 6 * 3600 * 10**9,
        tracking_state=row["tracking_state"],
        visits=row["visits"],
        tracklets=len(product.get("tracklets", [])),
        reviews=len(product.get("track_reviews", [])),
        detections_by_rx=[sum(d.receiver == rx for d in ds) for rx in (0, 1)],
        visibility=dict(counts),
        timing_edges=len(edges),
        unique_pairs=len(pairs),
        offset=asdict(offset) if offset else None,
        evaluation_pairs=len(evaluation),
        evaluation_rms_hz=float(np.sqrt(np.mean(np.square(residuals)))) if residuals else None,
        shifted_null_pairs=null_pairs,
        review_agree=agree,
        review_disagree=disagree,
    )
    details = [
        dict(
            time_s=a.time_s,
            channel=a.channel,
            edge=a.edge,
            delta_hz=delta,
            residual_hz=float(wrapped(delta - offset.predict(a.time_s))),
            margin0=a.margin,
            margin1=b.margin,
        )
        for a, b, delta, _ in pairs
    ]
    return summary, geometry, details


def start_utc(row):
    return row["source"]["timing"]["first_sample_estimate_utc_ns"]


def review_links(row):
    """Audit slope-only hypotheses against clear independent per-path review leaders.

    Review identities are a consistency reference, never verified ground truth.
    """
    p = row.get("tracking") or {}
    by_id = {t["tracklet_id"]: t for t in p.get("tracklets", [])}
    selected = []
    for r in p.get("track_reviews", []):
        if len(r["candidates"]) < 2:
            continue
        a, b = r["candidates"][:2]
        if a["randomized_evaluation_rms_hz"] > 150 or b["randomized_evaluation_rms_hz"] < 3 * max(
            a["randomized_evaluation_rms_hz"], 1
        ):
            continue
        selected.append(
            dict(
                **by_id[r["tracklet_id"]],
                number=a["catalog_number"],
                start_s=r["start_s"],
                end_s=r["end_s"],
            )
        )
    output = []
    for a in selected:
        if a["receiver_id"] != 0:
            continue
        for b in selected:
            if b["receiver_id"] != 1 or (a["channel"], a["edge"]) != (b["channel"], b["edge"]):
                continue
            overlap = min(a["end_s"], b["end_s"]) - max(a["start_s"], b["start_s"])
            rate = abs(a["normalized_rate_hz_per_s"] - b["normalized_rate_hz_per_s"])
            if overlap < -4:
                continue
            union = max(a["end_s"], b["end_s"]) - min(a["start_s"], b["start_s"])
            output.append(
                dict(
                    session_id=row["session_id"],
                    left=a["tracklet_id"],
                    right=b["tracklet_id"],
                    channel=a["channel"],
                    edge=a["edge"],
                    left_number=a["number"],
                    right_number=b["number"],
                    same_review_leader=a["number"] == b["number"],
                    overlap_s=overlap,
                    rate_difference_hz_s=rate,
                    current_slope_gate=overlap >= 8 and rate <= 250,
                    extension_s=union - max(a["end_s"] - a["start_s"], b["end_s"] - b["start_s"]),
                    start0_s=a["start_s"],
                    end0_s=a["end_s"],
                    start1_s=b["start_s"],
                    end1_s=b["end_s"],
                )
            )
    return output


def regression(rows):
    """Satellite-disjoint cross-validation; all response fits are explicitly proxies."""
    if not rows:
        return []
    y = np.array([r["proxy_db"] for r in rows])
    enu = np.array([r["enu"] for r in rows])
    lanes = sorted({(r["channel"], r["edge"]) for r in rows})
    lane = np.array([lanes.index((r["channel"], r["edge"])) for r in rows])
    intercept = np.eye(len(lanes))[lane]
    # Equal weight per session/satellite/lane prevents dense passes dominating.
    groups = [(r["session_id"], r["number"], r["channel"], r["edge"]) for r in rows]
    sizes = Counter(groups)
    weight = np.array([1 / sizes[g] for g in groups])
    folds = np.array([r["number"] % 3 for r in rows])
    outputs = []
    for fold in range(3):
        train, test = folds != fold, folds == fold
        for name, design in [
            ("lane-offset-only", intercept),
            ("east-west", np.column_stack([intercept, enu[:, 0]])),
            ("east-north", np.column_stack([intercept, enu[:, :2]])),
        ]:
            if not np.any(test) or np.linalg.matrix_rank(design[train]) < design.shape[1]:
                continue
            root = np.sqrt(weight[train])
            beta = np.linalg.lstsq(design[train] * root[:, None], y[train] * root, rcond=None)[0]
            residual = y[test] - design[test] @ beta
            outputs.append(
                dict(
                    fold=fold,
                    model=name,
                    coefficients=beta.tolist(),
                    evaluation_proxy_rms_db=float(
                        np.sqrt(np.average(residual**2, weights=weight[test]))
                    ),
                    test_points=int(test.sum()),
                    test_satellites=len(
                        set(r["number"] for r, f in zip(rows, folds, strict=True) if f == fold)
                    ),
                )
            )
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--end-utc-ns", type=int, default=END)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    archive = TleArchiveReader(Path("/var/lib/leo/tle"))
    refs = {s.digest: s for s in archive.list_snapshots()}
    catalogues = {}
    summaries = []
    geometry = []
    all_details = {}
    links = []
    for path in sorted(args.input.glob("*.json.gz")):
        with gzip.open(path, "rt") as f:
            row = json.load(f)
        if not args.end_utc_ns - 8 * 3600 * 10**9 <= row["created_utc_ns"] < args.end_utc_ns:
            continue
        snapshot = (row.get("tracking") or {}).get("original_tle_snapshot")
        catalogue = None
        if snapshot and snapshot["collected_utc_ns"] < row["created_utc_ns"]:
            digest = snapshot["digest"]
            if digest not in catalogues:
                catalogues[digest] = parse_element_sets(archive.read(refs[digest]))
            catalogue = catalogues[digest]
        summary, points, details = analyze(row, catalogue, end_utc_ns=args.end_utc_ns)
        summaries.append(summary)
        geometry.extend(points)
        all_details[row["session_id"]] = details
        anchors = Counter((p["tracklet_id"], p["tracklet_id_rx1"]) for p in points)
        for link in review_links(row):
            link["simultaneous_anchors"] = anchors[(link["left"], link["right"])]
            link["anchored_candidate_link"] = link["simultaneous_anchors"] >= 3
            link["observed_duration_extension_s"] = link["extension_s"] - max(
                0.0, -link["overlap_s"]
            )
            links.append(link)
        print(row["session_id"], summary.get("unique_pairs"), len(points), flush=True)
    outputs = dict(
        window_start_utc_ns=args.end_utc_ns - 8 * 3600 * 10**9,
        window_end_utc_ns=args.end_utc_ns,
        scans=summaries,
        geometry_proxy_points=geometry,
        beam_proxy_cross_validation=regression(geometry),
        paired_diagnostics=all_details,
        review_links=links,
        interpretation=(
            "research only; GLRT margin ratio is not calibrated RF power; "
            "review labels are conditional"
        ),
    )
    (args.output / "results.json").write_text(json.dumps(outputs, indent=2) + "\n")
    good = [s for s in summaries if s.get("offset")]
    fig, axes = plt.subplots(2, 2, figsize=(13, 9), layout="constrained")
    x = np.array(
        [(s["created_utc_ns"] - (args.end_utc_ns - 8 * 3600 * 10**9)) / 3.6e12 for s in good]
    )
    for rx in (0, 1):
        axes[0, 0].scatter(x, [s["detections_by_rx"][rx] for s in good], s=12, label=f"RX{rx}")
    axes[0, 0].set(xlabel="Hours after window start", ylabel="Passed GLRT candidates")
    axes[0, 0].legend()
    axes[0, 1].scatter(x, [s["unique_pairs"] for s in good], s=12, label="Simultaneous matches")
    axes[0, 1].scatter(
        x, [max(s["shifted_null_pairs"]) for s in good], s=12, label="Shifted-visit null (max)"
    )
    axes[0, 1].set(xlabel="Hours after window start", ylabel="Matched pairs")
    axes[0, 1].legend()
    axes[1, 0].scatter(x, [s["offset"]["intercept_hz"] for s in good], s=12)
    axes[1, 0].set(
        xlabel="Hours after window start", ylabel="RX1−RX0 offset, modulo pilot alias (Hz)"
    )
    axes[1, 1].scatter(x, [s["evaluation_rms_hz"] for s in good], s=12)
    axes[1, 1].set(xlabel="Hours after window start", ylabel="Odd-visit matched offset RMS (Hz)")
    fig.suptitle("LT3D-001A: eight-hour dual-receiver audit")
    fig.savefig(args.output / "audit.png", dpi=160)
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), layout="constrained")
    if geometry:
        axes[0].scatter(
            [p["enu"][0] for p in geometry], [p["proxy_db"] for p in geometry], s=2, alpha=0.2
        )
    axes[0].set(
        xlabel="Candidate east direction cosine (known-site diagnostic)",
        ylabel="10 log10(GLRT margin RX0/RX1), not RF power",
    )
    for name in ["lane-offset-only", "east-west", "east-north"]:
        r = [r for r in outputs["beam_proxy_cross_validation"] if r["model"] == name]
        axes[1].plot(
            [q["fold"] for q in r], [q["evaluation_proxy_rms_db"] for q in r], "o-", label=name
        )
    axes[1].set(xlabel="Satellite-disjoint evaluation fold", ylabel="Evaluation proxy RMS (dB)")
    axes[1].legend()
    fig.suptitle("Does detector-response asymmetry generalize across satellite candidates?")
    fig.savefig(args.output / "beam-proxy.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()

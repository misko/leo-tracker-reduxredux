#!/usr/bin/env python3
"""Compare retrospective TLE review ranks at two nearby known sites."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import numpy as np

from leo.analysis.nearest_neighbour_association import (
    deterministic_randomized_observation_partition,
)
from leo.analysis.persistent_hop_trajectory import (
    PersistentHopTrajectoryConfig,
    persistent_hop_tracklet_graph,
    reconstruct_persistent_hop_trajectories,
)
from leo.analysis.research.scanner_tle_screen import rank_curves
from leo.application.scanner_trajectory import project_scanner_candidates
from leo.contracts.catalogue_association import CataloguePredictionSupportV1
from leo.contracts.digests import canonical_digest
from leo.contracts.scanner_tracking import TrackingCandidate, TrackingInput, TrackingProbe
from leo.contracts.sky import ObserverSiteV1
from leo.operations.tle_archive import TleArchiveReader
from leo.scanner.persistent_hop import PersistentHopUtcTimingAuthorityV1
from leo.sky.doppler import doppler_shift_hz
from leo.sky.propagation import parse_element_sets, propagate_grid
from leo.sky.sampling import SamplingGrid
from leo.sky.screening import observe_grid
from leo.sky.sites import resolve_preset

SCHEMA = "org.leo.research.identity-site-sensitivity/v1"
PERSISTED_SITE = ObserverSiteV1(
    latitude_deg=37.858988,
    longitude_deg=-122.478103,
    altitude_m=-29.0,
    label="persisted-spinnaker-review-site",
)
USER_SITE = ObserverSiteV1(
    latitude_deg=37.84903264307456,
    longitude_deg=-122.4856541910174,
    altitude_m=0.0,
    label="user-site",
)


def digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def read_document(path: Path) -> dict[str, Any]:
    payload = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(payload)


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def tracking_input(value: dict[str, Any]) -> TrackingInput:
    return TrackingInput(
        session_id=str(value["session_id"]),
        capture_mode=value["capture_mode"],
        sample_rate_hz=int(value["sample_rate_hz"]),
        radio_id=str(value["radio_id"]),
        stream_generation=str(value["stream_generation"]),
        input_manifest_sha256=str(value["input_manifest_sha256"]),
        analysis_manifest_sha256=str(value["analysis_manifest_sha256"]),
        raw_recording_authority_digest=str(value["raw_recording_authority_digest"]),
        timing=PersistentHopUtcTimingAuthorityV1.model_validate(value["timing"]),
        qualified=bool(value["qualified"]),
        probes=tuple(
            TrackingProbe(
                visit_index=int(probe["visit_index"]),
                receiver_id=int(probe["receiver_id"]),
                probe_index=int(probe["probe_index"]),
                probe_start_ms=int(probe["probe_start_ms"]),
                channel=int(probe["channel"]),
                edge=str(probe["edge"]),
                actual_rf_hz=float(probe["actual_rf_hz"]),
                valid_start_counter=int(probe["valid_start_counter"]),
                payload_start_sample=int(probe["payload_start_sample"]),
                candidates=tuple(TrackingCandidate(**row) for row in probe["candidates"]),
            )
            for probe in value["probes"]
        ),
        probe_ms=int(value.get("probe_ms", 20)),
        capture_start_utc_ns=value.get("capture_start_utc_ns"),
        capture_end_utc_ns=value.get("capture_end_utc_ns"),
    )


def graph_for_track(trajectory, tracklet_id: str):
    for hypothesis in trajectory.hypotheses:
        if tracklet_id in hypothesis.tracklet_ids:
            return persistent_hop_tracklet_graph(hypothesis, tracklet_id)
    raise ValueError(f"track absent from reconstructed hypotheses: {tracklet_id}")


def score_site(
    *,
    site: ObserverSiteV1,
    catalogue,
    starlink_indices: list[int],
    numbers: np.ndarray,
    names: list[str],
    coarse_propagated,
    coarse_grid: SamplingGrid,
    exact_grid: SamplingGrid,
    taus: np.ndarray,
    t: np.ndarray,
    measured: np.ndarray,
    training_mask: np.ndarray,
) -> dict[str, Any]:
    coarse = observe_grid(coarse_propagated, site, coarse_grid)
    usable = coarse.usable & (np.min(coarse.altitude_km, axis=1) > 120)
    visible = usable & (np.max(coarse.elevation_deg, axis=1) >= -1)
    population = np.flatnonzero(visible)
    catalogue_indices = np.asarray([starlink_indices[index] for index in population], dtype=int)
    exact = observe_grid(
        propagate_grid(catalogue, exact_grid, catalogue_indices.tolist()), site, exact_grid
    )
    bank = doppler_shift_hz(11_200_000_000.0, exact.range_rate_km_s).reshape(
        len(population), len(taus), len(t)
    )
    elevation = exact.elevation_deg.reshape(bank.shape)
    keep = exact.usable & (np.max(elevation, axis=(1, 2)) >= 0)
    population = population[keep]
    bank = bank[keep]
    ranking = rank_curves(measured, bank, training_mask=training_mask)
    candidates = []
    for rank, index in enumerate(ranking["order"][:5], start=1):
        tau_index = int(ranking["tau_indices"][index])
        candidates.append(
            {
                "rank": rank,
                "catalog_number": int(numbers[population[index]]),
                "name": names[population[index]],
                "selected_tau_s": float(taus[tau_index]),
                "fitted_offset_hz": float(ranking["offsets"][index]),
                "training_rms_hz": float(ranking["training_rms"][index]),
                "evaluation_rms_hz": float(ranking["heldout_rms"][index]),
            }
        )
    return {"candidate_population": len(population), "candidates": candidates}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--tle-archive", type=Path, default=Path("/var/lib/leo/tle"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--maximum-tracks", type=int, default=20)
    args = parser.parse_args()
    if not 1 <= args.maximum_tracks <= 20:
        parser.error("maximum tracks must be between one and twenty")

    selection = read_document(args.selection)
    chosen = sorted(
        selection["audit"]["tracks"],
        key=lambda row: (str(row["session_id"]), str(row["tracklet_id"])),
    )[: args.maximum_tracks]
    with np.load(args.prepared, allow_pickle=False) as prepared:
        prepared_ids = prepared["observation_id"].astype(str)
        prepared_y = prepared["y_hz"].astype(float)
        prepared_time_s = prepared["time_s"].astype(float)
    archive = TleArchiveReader(args.tle_archive)
    trajectory_config = PersistentHopTrajectoryConfig()
    rows = []
    for session_id in sorted({str(row["session_id"]) for row in chosen}):
        document = read_document(args.cache / f"{session_id}.json.gz")
        source = tracking_input(document["source"])
        product = document["tracking"]
        recorded_site = product["observer_site"]
        if any(
            float(recorded_site[key]) != getattr(PERSISTED_SITE, key)
            for key in ("latitude_deg", "longitude_deg", "altitude_m")
        ):
            raise ValueError("persisted review site differs from expected authority")
        trajectory = reconstruct_persistent_hop_trajectories(
            project_scanner_candidates(source), config=trajectory_config
        )
        reviews = {str(review["tracklet_id"]): review for review in product["track_reviews"]}
        start = int(source.timing.first_sample_estimate_utc_ns)
        snapshot = archive.select_latest_before(start - 505_000_000_000)
        catalogue = parse_element_sets(archive.read(snapshot))
        if snapshot.digest != str(product["original_tle_snapshot"]["digest"]):
            raise ValueError("standard review snapshot differs from persisted tracking snapshot")
        starlink = [
            index
            for index, name in enumerate(catalogue.names)
            if name.upper().startswith("STARLINK") and not name.upper().endswith(" DEB")
        ]
        numbers = np.asarray([catalogue.satellite_numbers[index] for index in starlink], int)
        names = [catalogue.names[index] for index in starlink]
        coarse_grid = SamplingGrid(
            tuple(start + offset * 1_000_000_000 for offset in range(-507, 809)), 507, 1.0
        )
        coarse_propagated = propagate_grid(catalogue, coarse_grid, starlink)
        selection_digest = canonical_digest(
            {
                "algorithm": "scanner-shared-tracking-v12",
                "utc_qualification_limit_ns": 2_000_000_000,
                "trajectory": trajectory_config.digest,
                "group_limit": 4,
                "selection": "eligible-first-longest-support-v1",
                "catalogue": "exclude-labelled-debris-and-sgp4-failures-before-response-v1",
                "observer": resolve_preset("spinnaker-sausalito").model_dump(mode="json"),
            }
        )
        for selected in [row for row in chosen if str(row["session_id"]) == session_id]:
            tracklet_id = str(selected["tracklet_id"])
            graph = graph_for_track(trajectory, tracklet_id)
            observations = sorted(graph.observations, key=lambda row: row.support_center_utc_ns)
            ids = tuple(row.observation_id for row in observations)
            times = np.asarray([(row.support_center_utc_ns - start) / 1e9 for row in observations])
            measured = np.asarray([row.measured_cfo_hz for row in observations])
            frozen_rows = np.arange(int(selected["row_start"]), int(selected["row_stop"]))
            frozen_ids = prepared_ids[frozen_rows].tolist()
            expected_prefix = f"{session_id}:{tracklet_id}:"
            if (
                any(not value.startswith(expected_prefix) for value in frozen_ids)
                or not np.array_equal(measured, prepared_y[frozen_rows])
                or not np.allclose(
                    np.asarray([row.support_center_utc_ns / 1e9 for row in observations]),
                    prepared_time_s[frozen_rows],
                    rtol=0.0,
                    atol=5e-7,
                )
            ):
                raise ValueError(f"frozen position rows differ from exact track: {tracklet_id}")
            support = CataloguePredictionSupportV1.from_graph(graph)
            split_seed = canonical_digest(
                {
                    "policy": "persistent-hop-fixed-orbit-randomized-residual-v1",
                    "response_free_support_digest": support.content_digest,
                    "selection_protocol_digest": selection_digest,
                }
            )
            training_ids, evaluation_ids = deterministic_randomized_observation_partition(
                ids, training_fraction=0.6, split_seed=split_seed
            )
            training_set = set(training_ids)
            training_mask = np.asarray([value in training_set for value in ids], bool)
            taus = np.arange(-5.0, 6.0)
            exact_times = tuple(
                start + round(float(value) * 1e9)
                for value in (times[None, :] + taus[:, None]).ravel()
            )
            exact_grid = SamplingGrid(exact_times, len(exact_times) // 2, 1.0)
            scores = {
                "persisted_site": score_site(
                    site=PERSISTED_SITE,
                    catalogue=catalogue,
                    starlink_indices=starlink,
                    numbers=numbers,
                    names=names,
                    coarse_propagated=coarse_propagated,
                    coarse_grid=coarse_grid,
                    exact_grid=exact_grid,
                    taus=taus,
                    t=times,
                    measured=measured,
                    training_mask=training_mask,
                ),
                "user_site": score_site(
                    site=USER_SITE,
                    catalogue=catalogue,
                    starlink_indices=starlink,
                    numbers=numbers,
                    names=names,
                    coarse_propagated=coarse_propagated,
                    coarse_grid=coarse_grid,
                    exact_grid=exact_grid,
                    taus=taus,
                    t=times,
                    measured=measured,
                    training_mask=training_mask,
                ),
            }
            persisted_review = reviews[tracklet_id]
            stored_top_two = [
                {
                    "catalog_number": int(item["catalog_number"]),
                    "selected_tau_s": float(item["selected_tau_s"]),
                    "fitted_offset_hz": float(item["fitted_offset_hz"]),
                    "training_rms_hz": float(item["fit_rms_hz"]),
                    "evaluation_rms_hz": float(item["randomized_evaluation_rms_hz"]),
                }
                for item in persisted_review["candidates"][:2]
            ]
            calculated_top_two = scores["persisted_site"]["candidates"][:2]
            if [row["catalog_number"] for row in stored_top_two] != [
                row["catalog_number"] for row in calculated_top_two
            ]:
                raise ValueError(f"persisted-site top-two reproduction failed: {tracklet_id}")
            for stored, calculated in zip(stored_top_two, calculated_top_two, strict=True):
                for key in (
                    "selected_tau_s",
                    "fitted_offset_hz",
                    "training_rms_hz",
                    "evaluation_rms_hz",
                ):
                    if not np.isclose(stored[key], calculated[key], rtol=0.0, atol=1e-8):
                        raise ValueError(
                            f"persisted-site score reproduction failed: {tracklet_id}:{key}"
                        )
            rows.append(
                {
                    "session_id": session_id,
                    "tracklet_id": tracklet_id,
                    "receiver_id": int(selected["receiver_id"]),
                    "observations": len(ids),
                    "frozen_observation_ids": frozen_ids,
                    "training_observation_ids": list(training_ids),
                    "evaluation_observation_ids": list(evaluation_ids),
                    "tle_snapshot_digest": snapshot.digest,
                    "stored_top_two": stored_top_two,
                    **scores,
                    "leader_changed": (
                        scores["persisted_site"]["candidates"][0]["catalog_number"]
                        != scores["user_site"]["candidates"][0]["catalog_number"]
                    ),
                    "top_two_order_changed": (
                        [
                            row["catalog_number"]
                            for row in scores["persisted_site"]["candidates"][:2]
                        ]
                        != [row["catalog_number"] for row in scores["user_site"]["candidates"][:2]]
                    ),
                }
            )
            print(json.dumps({"track": len(rows), "tracklet_id": tracklet_id}), flush=True)
    output = {
        "schema": SCHEMA,
        "scope": "bounded known-site sensitivity diagnostic; no identity truth claim",
        "inputs": {
            "selection": {"path": str(args.selection), "digest": digest(args.selection)},
            "prepared": {"path": str(args.prepared), "digest": digest(args.prepared)},
            "cache": str(args.cache),
        },
        "protocol": {
            "selection": "first tracks ordered by session_id then tracklet_id",
            "maximum_tracks": args.maximum_tracks,
            "split": (
                "persisted-site deterministic randomized 60/40 partition, reused at both sites"
            ),
            "tau_grid_s": list(np.arange(-5.0, 6.0)),
            "nuisance": "training-only offset and tau refitted independently at each site",
            "observations": "unchanged exact reconstructed points verified against frozen NPZ rows",
            "persisted_site": PERSISTED_SITE.model_dump(mode="json"),
            "user_site": USER_SITE.model_dump(mode="json"),
        },
        "summary": {
            "tracks": len(rows),
            "leader_changes": sum(row["leader_changed"] for row in rows),
            "top_two_order_changes": sum(row["top_two_order_changed"] for row in rows),
            "persisted_top_two_reproduced": len(rows),
            "candidate_population_changes": sum(
                row["persisted_site"]["candidate_population"]
                != row["user_site"]["candidate_population"]
                for row in rows
            ),
        },
        "tracks": rows,
    }
    write_json(args.output, output)
    print(json.dumps(output["summary"], sort_keys=True), flush=True)


if __name__ == "__main__":
    main()

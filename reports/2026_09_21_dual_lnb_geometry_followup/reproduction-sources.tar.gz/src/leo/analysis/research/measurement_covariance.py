"""Additional shared measurement uncertainty for conditional research fits.

These blocks add uncertainty to existing measurement noise, rather than replace
it. Calibration observations must be disjoint from fitted observations unless
their cross-covariance is explicitly included in the supplied block.
"""

from dataclasses import dataclass

import numpy as np
from scipy import sparse
from scipy.linalg import solve_triangular


@dataclass(frozen=True)
class TrackMeasurementCovariance:
    observation_indices: np.ndarray
    covariance_hz2: np.ndarray
    calibration_id: str

    def __post_init__(self):
        indices = np.asarray(self.observation_indices)
        covariance = np.asarray(self.covariance_hz2)
        if (
            indices.ndim != 1
            or not len(indices)
            or not np.issubdtype(indices.dtype, np.integer)
            or np.any(indices < 0)
            or np.any(np.diff(indices) <= 0)
            or not isinstance(self.calibration_id, str)
            or not self.calibration_id
        ):
            raise ValueError("covariance requires sorted unique indices and a calibration ID")
        if (
            covariance.shape != (len(indices), len(indices))
            or not np.issubdtype(covariance.dtype, np.number)
            or not np.isrealobj(covariance)
            or not np.all(np.isfinite(covariance))
            or not np.allclose(covariance, covariance.T, rtol=1e-10, atol=1e-10)
        ):
            raise ValueError("measurement covariance must be finite and symmetric")
        scale = max(1.0, float(np.max(np.abs(covariance))))
        if np.min(np.linalg.eigvalsh(covariance)) < -1e-10 * scale:
            raise ValueError("measurement covariance must be positive semidefinite")
        indices = np.array(indices, dtype=np.int64, copy=True)
        covariance = np.array(covariance, dtype=float, copy=True)
        indices.setflags(write=False)
        covariance.setflags(write=False)
        object.__setattr__(self, "observation_indices", indices)
        object.__setattr__(self, "covariance_hz2", covariance)


def validate_track_covariances(blocks, track, segment, source):
    used_tracks = set()
    used_calibrations = set()
    for block in blocks:
        idx = block.observation_indices
        if np.any(idx >= len(track)):
            raise ValueError("measurement covariance index out of bounds")
        if any(len(np.unique(np.asarray(x)[idx])) != 1 for x in (track, segment, source)):
            raise ValueError(
                "measurement covariance must stay within one track, segment and source"
            )
        label = np.asarray(track)[idx[0]]
        if label in used_tracks or block.calibration_id in used_calibrations:
            raise ValueError("combine shared calibration uncertainty into a single track block")
        used_tracks.add(label)
        used_calibrations.add(block.calibration_id)


def augment_track_whitening(base, logdet, blocks, rows, track, sigma_hz):
    """Whiten R + K/sigma² while preserving shared, off-diagonal uncertainty.

    ``base`` whitens the normalized baseline covariance R for fitting ``rows``.
    The returned log determinant is for R + K/sigma². Existing likelihoods must
    retain their n*log(sigma) normalization. No blocks returns the original
    operator unchanged.
    """
    if not blocks:
        return base, logdet
    if not np.isfinite(sigma_hz) or sigma_hz <= 0:
        raise ValueError("measurement scale must be finite and positive")
    lookup = {int(global_row): local for local, global_row in enumerate(rows)}
    replacement_rows, replacement_cols, replacement_values = [], [], []
    replaced = np.zeros(len(rows), bool)
    for block in blocks:
        selected = [i for i, row in enumerate(block.observation_indices) if int(row) in lookup]
        if not selected:
            continue
        global_indices = block.observation_indices[selected]
        label = np.asarray(track)[global_indices[0]]
        local_rows = np.flatnonzero(np.asarray(track)[rows] == label)
        local_positions = {int(row): i for i, row in enumerate(local_rows)}
        positions = [local_positions[lookup[int(row)]] for row in global_indices]
        extra = np.zeros((len(local_rows), len(local_rows)))
        extra[np.ix_(positions, positions)] = block.covariance_hz2[np.ix_(selected, selected)]
        current = base[local_rows][:, local_rows].toarray()
        transformed = np.eye(len(local_rows)) + current @ extra @ current.T / sigma_hz**2
        transformed = (transformed + transformed.T) / 2
        lower = np.linalg.cholesky(transformed)
        updated = solve_triangular(lower, current, lower=True, check_finite=False)
        logdet += float(2 * np.log(np.diag(lower)).sum())
        rr, cc = np.nonzero(updated)
        replacement_rows.extend(local_rows[rr])
        replacement_cols.extend(local_rows[cc])
        replacement_values.extend(updated[rr, cc])
        replaced[local_rows] = True
    original = base.tocoo()
    keep = ~replaced[original.row]
    operator = sparse.csr_matrix(
        (
            np.r_[original.data[keep], replacement_values],
            (
                np.r_[original.row[keep], replacement_rows],
                np.r_[original.col[keep], replacement_cols],
            ),
        ),
        shape=base.shape,
    )
    return operator, logdet

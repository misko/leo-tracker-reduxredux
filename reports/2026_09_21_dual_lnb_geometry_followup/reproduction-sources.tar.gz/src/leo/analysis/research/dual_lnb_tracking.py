"""Conservative dual-LNB association and an explicitly calibrated beam factor.

Receiver frequency offset is learned without satellite identities or geometry.
GLRT margins are never interpreted as antenna powers. A beam factor requires
separate calibration; the unknown cable mapping remains a global hypothesis.
"""

from dataclasses import dataclass

import numpy as np

ALIAS_HZ = 1 / 4.4e-6


def wrapped(value, period=ALIAS_HZ):
    return (np.asarray(value) + period / 2) % period - period / 2


@dataclass(frozen=True)
class LnbDetection:
    visit: int
    receiver: int
    channel: int
    edge: str
    time_s: float
    cfo_hz: float
    epoch_samples: float
    margin: float
    rank: int


@dataclass(frozen=True)
class ReceiverOffset:
    intercept_hz: float
    drift_hz_s: float
    reference_s: float
    fit_pairs: int
    fit_rms_hz: float
    fit_visit_count: int

    def __post_init__(self):
        if (
            not np.all(
                np.isfinite([self.intercept_hz, self.drift_hz_s, self.reference_s, self.fit_rms_hz])
            )
            or self.fit_rms_hz < 0
            or self.fit_pairs < 3
            or not 3 <= self.fit_visit_count <= self.fit_pairs
        ):
            raise ValueError("receiver offset requires finite parameters and fitted support")

    def predict(self, time_s):
        return self.intercept_hz + self.drift_hz_s * (np.asarray(time_s) - self.reference_s)


def timing_edges(detections, sample_rate_hz, *, timing_gate_samples=9.0):
    """One simultaneous visit/lane only; alias duplicates collapse before pairing."""
    if (
        not np.all(np.isfinite([sample_rate_hz, timing_gate_samples]))
        or sample_rate_hz <= 0
        or timing_gate_samples <= 0
    ):
        raise ValueError("sample rate and timing gate must be positive")
    by_visit = {}
    for d in detections:
        if d.receiver not in (0, 1) or not np.all(
            np.isfinite([d.time_s, d.cfo_hz, d.epoch_samples, d.margin])
        ):
            raise ValueError("invalid receiver detection")
        by_visit.setdefault((d.visit, d.channel, d.edge), {0: [], 1: []})[d.receiver].append(d)
    period = sample_rate_hz / 750
    edges = []
    for lanes in by_visit.values():
        unique = {}
        for rx, rows in lanes.items():
            keep = []
            for d in sorted(rows, key=lambda r: (-r.margin, r.rank)):
                if not any(
                    abs(wrapped(d.cfo_hz - k.cfo_hz)) < 1000
                    and abs(wrapped(d.epoch_samples - k.epoch_samples, period))
                    <= timing_gate_samples
                    for k in keep
                ):
                    keep.append(d)
            unique[rx] = keep
        for left in unique[0]:
            for right in unique[1]:
                timing = float(abs(wrapped(right.epoch_samples - left.epoch_samples, period)))
                if timing <= timing_gate_samples:
                    edges.append((left, right, float(wrapped(right.cfo_hz - left.cfo_hz)), timing))
    return edges


def fit_receiver_offset(edges, *, gate_hz=1500.0, minimum_pairs=12):
    """Fit a common LNB offset/drift from caller-specified fitting visits only."""
    if not np.isfinite(gate_hz) or gate_hz <= 0 or minimum_pairs < 3:
        raise ValueError("invalid fit controls")
    if len(edges) < minimum_pairs:
        return None
    delta = np.array([e[2] for e in edges])
    # Circular mode avoids assuming identical LNB local oscillators.
    grid = np.linspace(-ALIAS_HZ / 2, ALIAS_HZ / 2, 256, endpoint=False)
    counts = [np.count_nonzero(abs(wrapped(delta - x)) < gate_hz) for x in grid]
    anchor = grid[int(np.argmax(counts))]
    mask = abs(wrapped(delta - anchor)) < gate_hz
    times = np.array([e[0].time_s for e in edges])
    origin = float(np.median(times[mask]))
    design = np.column_stack([np.ones(len(times)), times - origin])
    unwrapped = anchor + wrapped(delta - anchor)
    if len(set(e[0].visit for e, good in zip(edges, mask, strict=True) if good)) < minimum_pairs:
        return None
    for _ in range(5):
        beta = np.linalg.lstsq(design[mask], unwrapped[mask], rcond=None)[0]
        residual = wrapped(delta - design @ beta)
        scale = max(50.0, 1.4826 * np.median(abs(residual[mask] - np.median(residual[mask]))))
        updated = abs(residual) < min(gate_hz, 4 * scale)
        distinct_visits = {e[0].visit for e, good in zip(edges, updated, strict=True) if good}
        if len(distinct_visits) < minimum_pairs:
            return None
        mask = updated
    distinct_visits = {e[0].visit for e, good in zip(edges, mask, strict=True) if good}
    if len(distinct_visits) < minimum_pairs:
        return None
    beta = np.linalg.lstsq(design[mask], unwrapped[mask], rcond=None)[0]
    return ReceiverOffset(
        float(beta[0]),
        float(beta[1]),
        origin,
        int(mask.sum()),
        float(np.sqrt(np.mean(wrapped(delta[mask] - design[mask] @ beta) ** 2))),
        len(distinct_visits),
    )


def match_dual_lnb(edges, offset, *, gate_hz=1000.0):
    """Accept only mutually unique timing/frequency matches, never forced assignments."""
    if not np.isfinite(gate_hz) or gate_hz <= 0:
        raise ValueError("gate must be positive")
    if offset is None:
        return []
    candidates = [e for e in edges if abs(wrapped(e[2] - offset.predict(e[0].time_s))) <= gate_hz]
    left_counts, right_counts = {}, {}
    for left, right, _, _ in candidates:
        left_counts[left] = left_counts.get(left, 0) + 1
        right_counts[right] = right_counts.get(right, 0) + 1
    return [e for e in candidates if left_counts[e[0]] == right_counts[e[1]] == 1]


def link_receiver_paths(left, right, offset, sample_rate_hz, *, minimum_pairs=3):
    """Propose a path link only with multiple observed simultaneous anchors.

    Opposite-RX paths are kept separate; this returns evidence, not a fabricated
    continuous recording or a satellite identity. No-overlap handoffs abstain.
    """
    if minimum_pairs < 3:
        raise ValueError("at least three simultaneous anchors required")
    if not left or not right:
        return {"state": "insufficient", "reason": "empty-path"}
    if {d.receiver for d in left} != {0} or {d.receiver for d in right} != {1}:
        raise ValueError("left/right paths must be RX0/RX1")
    if len({(d.channel, d.edge) for d in (*left, *right)}) != 1:
        return {"state": "insufficient", "reason": "different-rf-lanes"}
    matched = match_dual_lnb(timing_edges([*left, *right], sample_rate_hz), offset)
    visits = {e[0].visit for e in matched}
    if len(visits) < minimum_pairs:
        return {
            "state": "insufficient",
            "reason": "too-few-simultaneous-anchors",
            "anchor_visits": len(visits),
        }
    residual = [float(wrapped(e[2] - offset.predict(e[0].time_s))) for e in matched]
    start = min(d.time_s for d in (*left, *right))
    end = max(d.time_s for d in (*left, *right))
    longest = max(
        max(d.time_s for d in path) - min(d.time_s for d in path) for path in (left, right)
    )
    return dict(
        state="candidate-link",
        anchor_visits=len(visits),
        residual_rms_hz=float(np.sqrt(np.mean(np.square(residual)))),
        union_span_s=end - start,
        extension_s=end - start - longest,
        alias_resolved=False,
        identity_claimed=False,
    )


@dataclass(frozen=True)
class EastWestBeamCalibration:
    """External pass-validated response calibration, with explicit measurement kind."""

    intercept_db: float
    slope_db_per_direction_cosine: float
    residual_sigma_db: float
    heading_deg: float
    calibration_id: str
    measurement_kind: str = "rf_power_log_ratio"

    def __post_init__(self):
        if self.measurement_kind not in ("rf_power_log_ratio", "glrt_margin_log_ratio"):
            raise ValueError("unknown calibrated measurement kind")
        if (
            not self.calibration_id
            or not np.all(
                np.isfinite(
                    [
                        self.intercept_db,
                        self.slope_db_per_direction_cosine,
                        self.residual_sigma_db,
                        self.heading_deg,
                    ]
                )
            )
            or self.residual_sigma_db <= 0
        ):
            raise ValueError("finite calibrated beam response and positive uncertainty required")


def beam_negative_log_likelihood(direction_enu, ratio_db, calibration, *, mapping):
    """One global cable mapping (+1/-1), profiled/marginalized outside individual tracks."""
    if mapping not in (-1, 1):
        raise ValueError("mapping must be +1 or -1")
    direction = np.asarray(direction_enu, float)
    ratios = np.asarray(ratio_db, float)
    if (
        direction.shape != (len(ratios), 3)
        or not np.all(np.isfinite(direction))
        or not np.all(np.isfinite(ratios))
    ):
        raise ValueError("finite paired directions/ratios required")
    if not np.allclose(np.linalg.norm(direction, axis=1), 1, atol=1e-6):
        raise ValueError("directions must be unit ENU vectors")
    heading = np.deg2rad(calibration.heading_deg)
    projection = direction @ np.array([np.sin(heading), np.cos(heading), 0.0])
    predicted = (
        calibration.intercept_db + mapping * calibration.slope_db_per_direction_cosine * projection
    )
    z = (ratios - predicted) / calibration.residual_sigma_db
    # Student-t with four degrees of freedom limits isolated fades.
    return float(np.sum(2.5 * np.log1p(z * z / 4) + np.log(calibration.residual_sigma_db)))


def mapping_marginal_log_likelihood(direction_enu, ratio_db, calibration):
    """Marginalize a single installation mapping, not a new mapping per observation."""
    scores = np.array(
        [
            beam_negative_log_likelihood(direction_enu, ratio_db, calibration, mapping=m)
            for m in (-1, 1)
        ]
    )
    return float(-np.logaddexp(-scores[0], -scores[1]) + np.log(2))


@dataclass(frozen=True)
class DualLnbBeamData:
    """Pass representatives for an explicitly experimental geometry factor.

    One observation per pass is deliberately conservative until a temporal
    covariance model for detector ratios is independently characterized.
    Callers must label same-window calibration as retrospective research. This
    interface does not certify calibration chronology or uncertainty coverage.
    Formal Doppler fits use ``doppler_row_indices`` to phase-align the supplied
    nominal positions; standalone evaluations may leave the indices unset.
    """

    satellite_position_ecef_km: np.ndarray
    response_db: np.ndarray
    calibration: tuple[EastWestBeamCalibration, ...]
    pass_ids: tuple[str, ...]
    heading_uncertainty_deg: float = 10.0
    doppler_row_indices: np.ndarray | None = None

    def __post_init__(self):
        n = len(self.response_db)
        if (
            n == 0
            or self.satellite_position_ecef_km.shape != (n, 3)
            or len(self.calibration) != n
            or len(self.pass_ids) != n
        ):
            raise ValueError("beam arrays must have one nonempty length")
        if len(set(self.pass_ids)) != n:
            raise ValueError("one beam observation per independent pass required")
        if self.doppler_row_indices is not None:
            indexes = np.asarray(self.doppler_row_indices)
            if (
                indexes.shape != (n,)
                or not np.issubdtype(indexes.dtype, np.integer)
                or len(np.unique(indexes)) != n
            ):
                raise ValueError("beam Doppler row indices must be unique integers")
        if not np.all(np.isfinite(self.satellite_position_ecef_km)) or not np.all(
            np.isfinite(self.response_db)
        ):
            raise ValueError("beam observations must be finite")
        if not 0 <= self.heading_uncertainty_deg <= 45:
            raise ValueError("heading uncertainty must be 0..45 degrees")

    def negative_log_likelihood(
        self,
        receiver_ecef_km,
        latitude_deg,
        longitude_deg,
        *,
        satellite_position_ecef_km=None,
    ):
        """Marginalize heading and cable mapping once for the entire installation."""
        receiver_ecef_km = np.asarray(receiver_ecef_km, float)
        satellite_position_ecef_km = np.asarray(
            self.satellite_position_ecef_km
            if satellite_position_ecef_km is None
            else satellite_position_ecef_km,
            float,
        )
        if (
            receiver_ecef_km.shape != (3,)
            or not np.all(np.isfinite(receiver_ecef_km))
            or not np.all(np.isfinite([latitude_deg, longitude_deg]))
            or satellite_position_ecef_km.shape != self.satellite_position_ecef_km.shape
            or not np.all(np.isfinite(satellite_position_ecef_km))
        ):
            raise ValueError("finite receiver, satellite positions, and coordinates required")
        delta = satellite_position_ecef_km - receiver_ecef_km
        norm = np.linalg.norm(delta, axis=1)
        if np.any(norm == 0):
            raise ValueError("satellite and receiver cannot coincide")
        unit = delta / norm[:, None]
        lat, lon = np.deg2rad([latitude_deg, longitude_deg])
        east = unit @ np.array([-np.sin(lon), np.cos(lon), 0.0])
        north = unit @ np.array(
            [-np.sin(lat) * np.cos(lon), -np.sin(lat) * np.sin(lon), np.cos(lat)]
        )
        intercept = np.array([c.intercept_db for c in self.calibration])
        slope = np.array([c.slope_db_per_direction_cosine for c in self.calibration])
        sigma = np.array([c.residual_sigma_db for c in self.calibration])
        heading = np.array([c.heading_deg for c in self.calibration])
        scores = []
        for offset in np.linspace(-self.heading_uncertainty_deg, self.heading_uncertainty_deg, 5):
            a = np.deg2rad(heading + offset)
            projection = east * np.sin(a) + north * np.cos(a)
            for mapping in (-1, 1):
                z = (self.response_db - intercept - mapping * slope * projection) / sigma
                scores.append(float(np.sum(2.5 * np.log1p(z * z / 4) + np.log(sigma))))
        return float(-np.logaddexp.reduce(-np.array(scores)) + np.log(len(scores)))

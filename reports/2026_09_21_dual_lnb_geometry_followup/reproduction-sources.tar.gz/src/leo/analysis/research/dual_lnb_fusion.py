"""Pure, conservative fusion of one receiver path onto another.

The helper preserves measured points and provenance.  It never interpolates,
duplicates overlap, resolves aliases, or treats receiver-offset calibration as
exact.  Corrected RX1 points share a low-rank offset/drift covariance identified
by ``calibration_group_id`` and retain their parameter Jacobian ``[1, dt]``.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Literal

import numpy as np


@dataclass(frozen=True)
class FusionObservation:
    session_id: str
    path_id: str
    receiver_id: int
    catalog_number: int
    channel: int
    edge: str
    time_s: float
    normalized_cfo_hz: float
    measurement_sigma_hz: float
    observation_id: str
    alias_branch: str
    source_digest: str

    def __post_init__(self):
        if self.receiver_id not in (0, 1):
            raise ValueError("fusion observations require RX0 or RX1")
        if self.catalog_number <= 0 or self.channel < 0:
            raise ValueError("fusion identity and lane must be valid")
        if not all(
            (
                self.session_id,
                self.path_id,
                self.edge,
                self.observation_id,
                self.alias_branch,
                self.source_digest,
            )
        ):
            raise ValueError("fusion provenance fields must be nonempty")
        if not np.all(
            np.isfinite([self.time_s, self.normalized_cfo_hz, self.measurement_sigma_hz])
        ) or self.measurement_sigma_hz <= 0:
            raise ValueError("fusion measurements and uncertainty must be finite and positive")


@dataclass(frozen=True)
class SimultaneousAnchor:
    """Receiver measurements of the same signal support at one physical epoch.

    ``rx0.time_s`` and ``rx1.time_s`` remain separate for audit.  The fusion
    helper only permits a small numerical timestamp tolerance; it does not
    estimate a signal derivative or transport either CFO between epochs.
    """

    anchor_id: str
    rx0: FusionObservation
    rx1: FusionObservation
    role: Literal["fit", "validation"]

    def __post_init__(self):
        if not self.anchor_id or self.role not in ("fit", "validation"):
            raise ValueError("anchor ID and predeclared role are required")


@dataclass(frozen=True)
class FusionConfig:
    minimum_fit_anchors: int = 3
    minimum_validation_anchors: int = 2
    minimum_fit_span_s: float = 1.0
    common_epoch_tolerance_s: float = 1e-6
    maximum_anchor_residual_hz: float = 1000.0
    maximum_validation_rms_hz: float = 500.0
    maximum_extension_gap_s: float = 2.0
    huber_threshold: float = 1.5

    def __post_init__(self):
        numeric = (
            self.minimum_fit_span_s,
            self.common_epoch_tolerance_s,
            self.maximum_anchor_residual_hz,
            self.maximum_validation_rms_hz,
            self.maximum_extension_gap_s,
            self.huber_threshold,
        )
        if self.minimum_fit_anchors < 3 or self.minimum_validation_anchors < 1:
            raise ValueError("fusion requires robust fit support and held-out anchors")
        if not np.all(np.isfinite(numeric)) or min(numeric) <= 0:
            raise ValueError("fusion controls must be finite and positive")


@dataclass(frozen=True)
class ReceiverOffsetCalibration:
    intercept_hz: float
    drift_hz_s: float
    reference_s: float
    parameter_covariance: tuple[tuple[float, float], tuple[float, float]]
    fit_rms_hz: float
    robust_scale_hz: float
    validation_rms_hz: float
    fit_anchor_ids: tuple[str, ...]
    validation_anchor_ids: tuple[str, ...]
    fit_observation_ids: tuple[str, ...]
    validation_observation_ids: tuple[str, ...]
    calibration_group_id: str

    def predict(self, time_s):
        return self.intercept_hz + self.drift_hz_s * (np.asarray(time_s) - self.reference_s)


@dataclass(frozen=True)
class FusedObservation:
    time_s: float
    normalized_cfo_hz: float
    independent_sigma_hz: float
    marginal_predictive_sigma_hz: float
    offset_validation_floor_hz: float
    source_receiver_id: int
    source_observation_id: str
    source_path_id: str
    source_digest: str
    original_normalized_cfo_hz: float
    applied_receiver_offset_hz: float
    calibration_group_id: str | None
    calibration_jacobian: tuple[float, float] | None


@dataclass(frozen=True)
class FusionResult:
    state: Literal["fused", "insufficient"]
    reason: str | None
    points: tuple[FusedObservation, ...]
    calibration: ReceiverOffsetCalibration | None
    rx0_points: int
    rx1_extension_points: int
    left_extension_points: int
    right_extension_points: int
    rejected_sides: tuple[str, ...]
    reference_receiver_id: int = 0
    extension_receiver_id: int = 1
    reference_points: int = 0
    extension_points: int = 0


@dataclass(frozen=True)
class FusionCovarianceBlock:
    calibration_group_id: str
    observation_ids: tuple[str, ...]
    jacobian: tuple[tuple[float, float], ...]
    parameter_covariance: tuple[tuple[float, float], tuple[float, float]]
    validation_floor_hz: float
    covariance_hz2: tuple[tuple[float, ...], ...]


def _path_signature(path):
    return {
        (
            item.session_id,
            item.path_id,
            item.receiver_id,
            item.catalog_number,
            item.channel,
            item.edge,
            item.alias_branch,
            item.source_digest,
        )
        for item in path
    }


def _reference_only(reference, reason):
    receiver_id = reference[0].receiver_id if reference else 0
    points = tuple(
        FusedObservation(
            item.time_s,
            item.normalized_cfo_hz,
            item.measurement_sigma_hz,
            item.measurement_sigma_hz,
            0.0,
            item.receiver_id,
            item.observation_id,
            item.path_id,
            item.source_digest,
            item.normalized_cfo_hz,
            0.0,
            None,
            None,
        )
        for item in sorted(reference, key=lambda value: (value.time_s, value.observation_id))
    )
    return FusionResult(
        "insufficient",
        reason,
        points,
        None,
        len(points) if receiver_id == 0 else 0,
        0,
        0,
        0,
        (),
        receiver_id,
        1 - receiver_id,
        len(points),
        0,
    )


def _anchor_arrays(anchors):
    time = np.array([(item.rx0.time_s + item.rx1.time_s) / 2 for item in anchors])
    delta = np.array(
        [item.rx1.normalized_cfo_hz - item.rx0.normalized_cfo_hz for item in anchors]
    )
    return time, delta


def _fit_offset(fit_anchors, validation_anchors, config):
    time, delta = _anchor_arrays(fit_anchors)
    reference = float(np.median(time))
    design = np.column_stack([np.ones(len(time)), time - reference])
    weight = np.ones(len(time))
    beta = np.linalg.lstsq(design, delta, rcond=None)[0]
    robust_scale = 1.0
    for _ in range(30):
        residual = delta - design @ beta
        median = np.median(residual)
        robust_scale = max(1.0, 1.4826 * float(np.median(abs(residual - median))))
        standardized = abs(residual) / (config.huber_threshold * robust_scale)
        updated_weight = np.ones(len(standardized))
        outlier = standardized > 1
        updated_weight[outlier] = 1 / standardized[outlier]
        updated = np.linalg.lstsq(
            design * np.sqrt(updated_weight)[:, None], delta * np.sqrt(updated_weight), rcond=None
        )[0]
        if np.max(abs(updated - beta)) <= 1e-9 * (1 + np.max(abs(beta))):
            beta = updated
            weight = updated_weight
            break
        beta = updated
        weight = updated_weight
    residual = delta - design @ beta
    fit_rms = float(np.sqrt(np.mean(residual**2)))
    residual_variance = max(
        robust_scale**2,
        float(np.sum(weight * residual**2) / max(np.sum(weight) - 2, 1)),
    )
    covariance = np.linalg.pinv(design.T @ (weight[:, None] * design)) * residual_variance
    validation_time, validation_delta = _anchor_arrays(validation_anchors)
    validation_design = np.column_stack(
        [np.ones(len(validation_time)), validation_time - reference]
    )
    validation_residual = validation_delta - validation_design @ beta
    validation_rms = float(np.sqrt(np.mean(validation_residual**2)))
    all_residual = np.r_[residual, validation_residual]
    if np.max(abs(all_residual)) > config.maximum_anchor_residual_hz:
        return None, "anchor-residual-exceeds-gate"
    if validation_rms > config.maximum_validation_rms_hz:
        return None, "heldout-offset-validation-failed"
    first = fit_anchors[0]
    provenance = {
        "session_id": first.rx0.session_id,
        "rx0_path_id": first.rx0.path_id,
        "rx1_path_id": first.rx1.path_id,
        "rx0_source_digest": first.rx0.source_digest,
        "rx1_source_digest": first.rx1.source_digest,
        "fit": sorted(item.anchor_id for item in fit_anchors),
        "validation": sorted(item.anchor_id for item in validation_anchors),
        "fit_observations": sorted(
            value
            for item in fit_anchors
            for value in (item.rx0.observation_id, item.rx1.observation_id)
        ),
        "validation_observations": sorted(
            value
            for item in validation_anchors
            for value in (item.rx0.observation_id, item.rx1.observation_id)
        ),
    }
    group_id = "sha256:" + hashlib.sha256(
        json.dumps(provenance, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return (
        ReceiverOffsetCalibration(
            float(beta[0]),
            float(beta[1]),
            reference,
            tuple(tuple(float(value) for value in row) for row in covariance),
            fit_rms,
            robust_scale,
            validation_rms,
            tuple(str(value) for value in provenance["fit"]),
            tuple(str(value) for value in provenance["validation"]),
            tuple(str(value) for value in provenance["fit_observations"]),
            tuple(str(value) for value in provenance["validation_observations"]),
            group_id,
        ),
        None,
    )


def _supported_extension(rows, boundary_s, *, left, maximum_gap_s):
    ordered = sorted(rows, key=lambda item: (item.time_s, item.observation_id))
    if not ordered:
        return (), None
    gap = boundary_s - ordered[-1].time_s if left else ordered[0].time_s - boundary_s
    internal = np.diff([item.time_s for item in ordered])
    if gap > maximum_gap_s or np.any(internal > maximum_gap_s):
        return (), "left-gap-unsupported" if left else "right-gap-unsupported"
    return tuple(ordered), None


def fuse_anchored_paths(
    rx0_path: tuple[FusionObservation, ...],
    rx1_path: tuple[FusionObservation, ...],
    anchors: tuple[SimultaneousAnchor, ...],
    config: FusionConfig | None = None,
    *,
    reference_receiver_id: Literal[0, 1] = 0,
):
    config = config or FusionConfig()
    if reference_receiver_id not in (0, 1):
        raise ValueError("reference receiver must be RX0 or RX1")
    reference_path = rx0_path if reference_receiver_id == 0 else rx1_path
    extension_path = rx1_path if reference_receiver_id == 0 else rx0_path
    extension_receiver_id = 1 - reference_receiver_id
    if not rx0_path or not rx1_path:
        return _reference_only(reference_path, "empty-path")
    if len(_path_signature(rx0_path)) != 1 or len(_path_signature(rx1_path)) != 1:
        return _reference_only(reference_path, "path-contract-is-not-constant")
    left_signature = next(iter(_path_signature(rx0_path)))
    right_signature = next(iter(_path_signature(rx1_path)))
    if left_signature[2] != 0 or right_signature[2] != 1:
        raise ValueError("fusion path order must be RX0 then RX1")
    if (
        left_signature[0] != right_signature[0]
        or left_signature[3:6] != right_signature[3:6]
    ):
        return _reference_only(reference_path, "different-session-identity-or-lane")
    if len({item.observation_id for item in (*rx0_path, *rx1_path)}) != len(
        (*rx0_path, *rx1_path)
    ):
        raise ValueError("fusion observation provenance must be unique")

    fit_anchors = tuple(item for item in anchors if item.role == "fit")
    validation_anchors = tuple(item for item in anchors if item.role == "validation")
    if len(fit_anchors) < config.minimum_fit_anchors:
        return _reference_only(reference_path, "too-few-fit-anchors")
    if len(validation_anchors) < config.minimum_validation_anchors:
        return _reference_only(reference_path, "too-few-heldout-anchors")
    if len({item.anchor_id for item in anchors}) != len(anchors):
        raise ValueError("anchor provenance must be unique")
    if len({item.rx0.observation_id for item in anchors}) != len(anchors) or len(
        {item.rx1.observation_id for item in anchors}
    ) != len(anchors):
        raise ValueError("anchor observation provenance must be unique")
    for anchor in anchors:
        if (
            anchor.rx0.receiver_id != 0
            or anchor.rx1.receiver_id != 1
            or anchor.rx0.session_id != left_signature[0]
            or anchor.rx1.session_id != right_signature[0]
            or anchor.rx0.path_id != left_signature[1]
            or anchor.rx1.path_id != right_signature[1]
            or (anchor.rx0.catalog_number, anchor.rx0.channel, anchor.rx0.edge)
            != left_signature[3:6]
            or (anchor.rx1.catalog_number, anchor.rx1.channel, anchor.rx1.edge)
            != right_signature[3:6]
            or anchor.rx0.alias_branch != left_signature[6]
            or anchor.rx1.alias_branch != right_signature[6]
            or anchor.rx0.source_digest != left_signature[7]
            or anchor.rx1.source_digest != right_signature[7]
        ):
            return _reference_only(reference_path, "anchor-contract-conflict")
        if abs(anchor.rx1.time_s - anchor.rx0.time_s) > config.common_epoch_tolerance_s:
            return _reference_only(reference_path, "anchor-epochs-differ")
    fit_time, _ = _anchor_arrays(fit_anchors)
    if np.ptp(fit_time) < config.minimum_fit_span_s:
        return _reference_only(reference_path, "fit-anchor-span-too-short")
    calibration, reason = _fit_offset(fit_anchors, validation_anchors, config)
    if calibration is None:
        return _reference_only(reference_path, reason)

    start = min(item.time_s for item in reference_path)
    stop = max(item.time_s for item in reference_path)
    left, left_reason = _supported_extension(
        [item for item in extension_path if item.time_s < start],
        start,
        left=True,
        maximum_gap_s=config.maximum_extension_gap_s,
    )
    right, right_reason = _supported_extension(
        [item for item in extension_path if item.time_s > stop],
        stop,
        left=False,
        maximum_gap_s=config.maximum_extension_gap_s,
    )
    extension = (*left, *right)
    if not extension:
        return _reference_only(
            reference_path,
            left_reason
            or right_reason
            or f"no-supported-rx{extension_receiver_id}-extension",
        )
    covariance = np.asarray(calibration.parameter_covariance)
    corrected = []
    correction_sign = -1.0 if reference_receiver_id == 0 else 1.0
    for item in extension:
        jacobian = correction_sign * np.array(
            [1.0, item.time_s - calibration.reference_s]
        )
        parameter_variance = float(jacobian @ covariance @ jacobian)
        if parameter_variance < -1e-9:
            raise ValueError("receiver calibration covariance is not positive semidefinite")
        offset = float(calibration.predict(item.time_s))
        applied_offset = -correction_sign * offset
        corrected.append(
            FusedObservation(
                item.time_s,
                item.normalized_cfo_hz + correction_sign * offset,
                item.measurement_sigma_hz,
                float(
                    np.sqrt(
                        item.measurement_sigma_hz**2
                        + calibration.validation_rms_hz**2
                        + max(parameter_variance, 0.0)
                    )
                ),
                calibration.validation_rms_hz,
                item.receiver_id,
                item.observation_id,
                item.path_id,
                item.source_digest,
                item.normalized_cfo_hz,
                applied_offset,
                calibration.calibration_group_id,
                (float(jacobian[0]), float(jacobian[1])),
            )
        )
    baseline = _reference_only(reference_path, "baseline")
    points = tuple(
        sorted(
            (*baseline.points, *corrected),
            key=lambda item: (item.time_s, item.source_observation_id),
        )
    )
    rejected = tuple(reason for reason in (left_reason, right_reason) if reason is not None)
    return FusionResult(
        "fused",
        None,
        points,
        calibration,
        len(rx0_path) if reference_receiver_id == 0 else len(extension),
        len(extension) if extension_receiver_id == 1 else 0,
        len(left),
        len(right),
        rejected,
        reference_receiver_id,
        extension_receiver_id,
        len(reference_path),
        len(extension),
    )


def fusion_covariance_block(result: FusionResult):
    """Return the explicit added covariance for corrected extension observations."""
    if result.state != "fused" or result.calibration is None:
        return None
    extension = sorted(
        (point for point in result.points if point.calibration_group_id is not None),
        key=lambda point: point.source_observation_id,
    )
    observation_ids = tuple(point.source_observation_id for point in extension)
    jacobian = np.asarray([point.calibration_jacobian for point in extension], float)
    parameter_covariance = np.asarray(result.calibration.parameter_covariance, float)
    validation_floor = result.calibration.validation_rms_hz
    covariance = (
        jacobian @ parameter_covariance @ jacobian.T
        + validation_floor**2 * np.eye(len(extension))
    )
    return FusionCovarianceBlock(
        result.calibration.calibration_group_id,
        observation_ids,
        tuple((float(row[0]), float(row[1])) for row in jacobian),
        result.calibration.parameter_covariance,
        validation_floor,
        tuple(tuple(float(value) for value in row) for row in covariance),
    )

from types import SimpleNamespace
from hashlib import sha256
from time import monotonic_ns, thread_time_ns
import native_bridge as recording_to_v5
def fingerprint(value):
    return sha256(recording_to_v5.encoded(value).encode()).hexdigest()

def native_visit(frame, analyze, detect, policy):
    from leo.contracts.fast_scan import FastScanReceiverV1

    index, window, bracket, clock = frame
    probes = []
    timing = [0, 0]

    def run_native(w, receivers):
        start, cpu = monotonic_ns(), thread_time_ns()
        output = detect(w.samples)
        timing[:] = [monotonic_ns() - start, thread_time_ns() - cpu]
        if [r["receiver_id"] for r in output["rows"]] != [0, 1]:
            raise ValueError("unexpected native physical lane enumeration")
        for row in output["rows"]:
            candidates = (
                recording_to_v5._from_native(k, item) for k, item in enumerate(row["candidates"])
            )
            probes.append(recording_to_v5._probe(w, receivers[row["receiver_id"]], candidates))
        return tuple(FastScanReceiverV1(receiver_id=rx, candidates=()) for rx in receivers)

    status = analyze(window, (0, 1), None, policy, detector=run_native)
    envelope = dict(
        kind="visit",
        segment=index,
        sequence=window.sequence,
        visit=int(window.acquisition["global_visit"]),
        iq_sha256=window.iq_sha256,
        sample_start=status.sample_start,
        sample_end=status.sample_end,
        generation=status.generation,
        status=status.status,
        reason=status.reason,
        rf_mapping_authority=status.rf_mapping_authority,
        probes=probes,
        input_bytes=window.samples.nbytes,
        clock_anchor=bracket,
        delivery_clock=clock,
    )
    return envelope, timing

arrival_queue = SimpleNamespace(native_visit=native_visit, fingerprint=fingerprint)

def run_visit(frame, state, port, analyze_window, policy):
    rf = frame[1].target["rf_center_hz"]
    telemetry = None

    def detect(samples):
        nonlocal telemetry
        lane = state.reserve(rf, valid=True)
        output, profile = port.mixed(samples, lane, trace=True)
        if profile["fifth_lane"] != lane or [row["cpu"] for row in profile["lanes"]] != [
            MAIN,
            HELPER,
        ]:
            raise ValueError("a detector lane left its assigned physical CPU")
        telemetry = profile
        return output

    packet, _ = arrival_queue.native_visit(frame, analyze_window, detect, policy)
    if (telemetry is not None) != (packet["status"] == "processed"):
        raise ValueError("staggered dispatch must advance on one valid native visit only")
    receipt = dict(
        visit=packet["visit"],
        status=packet["status"],
        rf_center_hz=rf,
        sample_start=packet["sample_start"],
        sample_end=packet["sample_end"],
        full_visit_sha256=arrival_queue.fingerprint(packet),
        visit_metadata_sha256=arrival_queue.fingerprint(
            dict(
                packet,
                probes=[
                    {k: v for k, v in p.items() if k != "candidates"} for p in packet["probes"]
                ],
            )
        ),
        **(telemetry or {}),
    )
    return packet, receipt

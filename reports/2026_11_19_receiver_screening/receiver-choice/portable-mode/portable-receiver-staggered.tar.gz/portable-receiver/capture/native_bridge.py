from hashlib import sha256, file_digest
from pathlib import Path
from types import SimpleNamespace
import json, os, stat, sys, tempfile, time

BULK = Path("/")
BLOCK = 128 * 1024
DETECTORS = ("ordinary",)


MARGIN_GATE = 0.025

def inventory_digest(segments, window_count):
    from leo.contracts.digests import canonical_digest

    return canonical_digest(
        dict(
            schema_version=1,
            kind="fast-scan-source",
            recording_name=Path(segments[0]["path"]).parent.name,
            segments=segments,
            window_count=window_count,
        )
    )

def producer(_case, capture):
    return SimpleNamespace(root=Path(__file__).resolve().parent,
                           input_manifest_sha256=capture["input_manifest_sha256"])

def _bind_producer(_case, producer, _policy):
    # The standalone entry authenticates all source and library leaves itself.
    if producer.root != Path(__file__).resolve().parent:
        raise ValueError("capture reader is outside the verified bundle")

def _sha(path):
    with Path(path).open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

capture_release = SimpleNamespace(producer=producer, inventory_digest=inventory_digest)


def factor_candidate(rank, epoch, *, status, offset, cfo, exact, control, margin):
    """Project only complete fractional candidates into the published TrackingCandidate shape."""
    if status != "complete":
        return None
    if any(value is None for value in (offset, cfo, exact, control, margin)):
        raise ValueError("complete fractional detection is missing a numeric field")
    return dict(
        candidate_rank=rank,
        integer_epoch_sample=epoch,
        fractional_epoch_offset_samples=offset,
        fractional_tracking_cfo_hz=cfo,
        fractional_exact_score=exact,
        fractional_control_score=control,
        fractional_margin=margin,
        passed_fractional_margin_gate=margin >= MARGIN_GATE,
    )

def _from_native(rank, candidate):
    fractional = candidate["fractional_epoch"]
    return factor_candidate(
        rank,
        candidate["epoch"],
        status=fractional["status"],
        offset=fractional["offset_samples"],
        cfo=fractional["tracking_cfo_hz"],
        exact=fractional["exact_score"],
        control=fractional["control_score"],
        margin=fractional["margin"],
    )

def _probe(window, receiver, candidates):
    acquisition, target = window.acquisition, window.target
    visit = acquisition["global_visit"]
    return dict(
        visit_index=visit,
        receiver_id=receiver,
        probe_index=0,
        probe_start_ms=0,
        channel=target["channel"],
        edge=target["edge"],
        actual_rf_hz=float(acquisition["actual_if_center_hz"] + target["lnb_lo_hz"]),
        valid_start_counter=acquisition["sample_start"],
        payload_start_sample=visit * (window.sample_rate_hz // 50),
        candidates=[c for c in candidates if c is not None],
    )

class AuthenticatedMember:
    """Send bounded compressed buffers and verify every byte before accepting a chunk."""

    def __init__(self, path, size, digest, verified):
        self.file = os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb")
        info = os.fstat(self.file.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size != size:
            self.file.close()
            raise ValueError("compressed chunk size or file type differs from its manifest")
        self.size, self.digest, self.verified = size, digest, verified
        self.hash = sha256()
        self.count = 0

    def read(self, size=BLOCK):
        data = self.file.read(min(BLOCK, size if size >= 0 else BLOCK))
        self.hash.update(data)
        self.count += len(data)
        return data

    def close(self):
        if self.file.closed:
            return
        try:
            while self.read():
                pass
            if self.count != self.size or "sha256:" + self.hash.hexdigest() != self.digest:
                raise ValueError("compressed chunk SHA-256 differs from its manifest")
            self.verified.append(self.count)
        finally:
            self.file.close()

def encoded(value):
    return json.dumps(
        value, allow_nan=False, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )

def digest(value):
    return "sha256:" + sha256(encoded(value).encode()).hexdigest()

def native_document(case, lanes, capture=None, detector="ordinary"):
    """Consolidate fully verified streams, retaining exclusions and empty receiver factors."""
    if detector not in DETECTORS:
        raise ValueError("unknown full recording detector")
    visits, segments = [], {}
    for worker, lane in enumerate(lanes):
        if not lane or lane[-1] != dict(kind="worker", worker=worker):
            raise ValueError(f"raw lane {worker} did not reach its verified terminal receipt")
        pending = []
        for row in lane[:-1]:
            if row["segment"] % 2 != worker:
                raise ValueError("segment appeared in the wrong raw lane")
            if row["kind"] == "visit":
                pending.append(row)
                continue
            index = row["segment"]
            if (
                row["kind"] != "segment"
                or index in segments
                or not pending
                or row["count"] != len(pending)
                or any(p["segment"] != index or p["sequence"] != i for i, p in enumerate(pending))
            ):
                raise ValueError("raw segment is incomplete or duplicated")
            segments[index] = row
            visits.extend(pending)
            pending.clear()
        if pending:
            raise ValueError("unverified segment at end of raw lane")

    recording = case["recording"]
    if set(segments) != set(range(len(recording["segments"]))):
        raise ValueError("raw stream omitted a frozen segment")
    inventory_segments = []
    for index, locator in enumerate(recording["segments"]):
        receipt = segments[index]
        if (
            receipt["manifest_digest"] != "sha256:" + locator["sha256"]
            or Path(receipt["path"]) != (BULK / locator["path"]).parent
        ):
            raise ValueError("raw segment receipt does not bind the frozen segment")
        inventory_segments.append(
            dict(
                scope=f"segment-{index:08d}",
                path=receipt["path"],
                manifest_digest=receipt["manifest_digest"],
                windows=receipt["count"],
            )
        )
    input_manifest = capture_release.inventory_digest(inventory_segments, recording["window_count"])
    producer = PRODUCERS[case["id"]] if capture is None else capture_release.producer(case, capture)
    if input_manifest != producer.input_manifest_sha256:
        raise ValueError("replayed manifest inventory does not reproduce the acquisition identity")

    visits.sort(key=lambda row: row["visit"])
    if len(visits) != recording["window_count"] or any(
        row["visit"] != i for i, row in enumerate(visits)
    ):
        raise ValueError("raw replay must include each global visit exactly once")
    generation = visits[0]["generation"]
    clocks, probes, invalid = [], [], []
    previous_end = visits[0]["sample_start"]
    for row in visits:
        if (
            row["generation"] != generation
            or type(row["sample_start"]) is not int
            or row["sample_start"] < previous_end
            or type(row["sample_end"]) is not int
            or row["sample_end"] < row["sample_start"]
            or row["delivery_clock"] is None
        ):
            raise ValueError("raw capture counter or clocks have a gap in authority")
        previous_end = row["sample_end"]
        clocks.append(row["delivery_clock"])
        if row["status"] == "invalid_capture" and not row["probes"]:
            invalid.append(
                {
                    key: row[key]
                    for key in ("visit", "reason", "iq_sha256", "sample_start", "sample_end")
                }
            )
        elif row["status"] == "processed" and [p["receiver_id"] for p in row["probes"]] == [0, 1]:
            if detector == "single-rx0" and row["probes"][1]["candidates"]:
                raise ValueError("unmeasured physical receiver must have an empty factor")
            if any(
                p["visit_index"] != row["visit"] or p["valid_start_counter"] != row["sample_start"]
                for p in row["probes"]
            ):
                raise ValueError("fresh probe differs from recorded sample authority")
            probes.extend(row["probes"])
        else:
            raise ValueError("each visit needs a valid pair of fresh probes or a capture exclusion")
    anchors = [row["clock_anchor"] for row in visits if row["clock_anchor"] is not None]
    if len(anchors) != 1 or anchors[0]["sample_counter"] != visits[0]["sample_start"]:
        raise ValueError("raw recording does not have exactly one initial UTC anchor")
    radio_ids = {row["radio_id"] for row in segments.values()}
    libraries = {row["library_sha256"] for row in segments.values()}
    if {row.get("detector", "ordinary") for row in segments.values()} != {detector}:
        raise ValueError("raw segment detector differs from the requested measurement")
    if len(radio_ids) != 1 or len(libraries) != 1:
        raise ValueError("raw replay changed radios or detector binaries")
    library_sha = libraries.pop()
    # Timings and worker order do not participate in the new inference identity.
    identity = "native-short-window-glrt/fractional-epoch"
    if detector == "single-rx0":
        from tools.pipeline_eval.variants import single_chain

        identity += "/single-rx0/" + _sha(Path(single_chain.__file__))
    analysis_sha = digest([identity, library_sha, input_manifest, probes, invalid])
    iq_hashes = [row["iq_sha256"] for row in visits]
    source = dict(
        session_id=case["session_id"],
        capture_mode="adaptive",
        sample_rate_hz=10_000_000,
        radio_id=radio_ids.pop(),
        stream_generation=f"continuous-iio-{generation:016x}",
        input_manifest_sha256=input_manifest,
        analysis_manifest_sha256=analysis_sha,
        raw_recording_authority_digest=digest([input_manifest, iq_hashes]),
        qualified=True,
        timing=None,
        probes=probes,
        probe_ms=20,
        capture_start_utc_ns=None,
        capture_end_utc_ns=None,
    )
    provenance = dict(
        run_id="replay-" + analysis_sha[7:39],
        window_count=len(visits),
        processed_windows=len(probes) // 2,
        invalid_capture=len(invalid),
        excluded_windows=invalid,
        skipped_fast_score=0,
        rf_mapping_authorities=sorted({row["rf_mapping_authority"] for row in visits}),
        scope="fresh native fractional GLRT on the complete sealed recording",
        detector_sha256=library_sha,
    )
    if detector != "ordinary":
        provenance["scope"] = "fresh fractional GLRT on physical receiver zero at every valid visit"
        provenance["detector_mode"] = detector
    metrics = dict(
        recording_windows=len(visits),
        window_delivery_span_s=(clocks[-1]["monotonic_ns"] - clocks[0]["monotonic_ns"]) / 1e9,
        iq_bytes=sum(row["input_bytes"] for row in visits),
        processed_windows=len(probes) // 2,
        invalid_capture=len(invalid),
        probe_rows=len(probes),
        empty_probe_rows=sum(not p["candidates"] for p in probes),
        candidate_rows=sum(len(p["candidates"]) for p in probes),
        positive_candidates=sum(
            c["passed_fractional_margin_gate"] for p in probes for c in p["candidates"]
        ),
        detector_cpu_s=sum(row["detector_cpu_s"] for row in segments.values()),
    )
    return dict(
        schema_version=2,
        source=source,
        clock_anchor=anchors[0],
        delivery_clocks=clocks,
        last_sample_counter=visits[-1]["sample_end"],
        provenance=provenance,
    ), metrics

def save(path, value):
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, delete=False
    ) as stream:
        staged = Path(stream.name)
        try:
            stream.write(encoded(value) + "\n")
            stream.flush()
            os.link(staged, path)
        finally:
            staged.unlink()

def stream_range(library, worker, segments, case_id, capture=None, detector="ordinary"):
    """Publish every authenticated visit and a completion receipt for each segment."""
    import numpy as np

    from leo.analysis.starlink.native_short_window import NativeShortWindow
    from leo.analysis.starlink.templates import CONTROL_SYMBOL_ROLL, qin_edge_pilot_frame
    from leo.contracts.fast_scan import FastScanReceiverV1
    from leo.contracts.fast_scan_native import FastScanPolicyV2
    from leo.scanner.fast_scan_analysis import analyze_window
    from leo.storage.fast_scan import FastSegmentSource

    policy = FastScanPolicyV2()
    if detector not in DETECTORS:
        raise ValueError("unknown full recording detector")
    if capture is None:
        source_root = PRODUCERS[case_id].root
        edge = RECORDING_EDGES[case_id]
    else:
        case = capture["case"]
        producer = capture_release.producer(case, capture)
        if case["id"] != case_id or digest(segments) != capture["segments_sha256"]:
            raise ValueError("raw worker input differs from the sealed segments")
        _bind_producer(case, producer, policy)
        source_root = producer.root
        edge = capture["edge"]
    if not Path(analyze_window.__code__.co_filename).is_relative_to(source_root):
        raise ValueError("launch the raw worker with the recording's installed source runtime")
    rate = policy.sample_rate_hz
    exact = np.asarray(qin_edge_pilot_frame(rate, edge), dtype="<c16")
    control = np.asarray(
        qin_edge_pilot_frame(rate, edge, symbol_roll=CONTROL_SYMBOL_ROLL), dtype="<c16"
    )
    library_hash = "sha256:" + _sha(library)
    if detector == "single-rx0":
        from tools.pipeline_eval.variants.single_chain import analyze_native
    receiver_count = 1 if detector == "single-rx0" else 2
    with NativeShortWindow(
        str(library),
        exact,
        control,
        sample_rate_hz=rate,
        receiver_count=receiver_count,
        fractional_epoch=True,
    ) as native:
        for index in range(worker, len(segments), 2):
            locator = segments[index]
            manifest = (BULK / locator["path"]).resolve()
            if manifest.name != "manifest.json":
                raise ValueError("raw segment lies outside the recording archive")
            directory = manifest.parent
            source = FastSegmentSource(
                dict(path=str(directory), manifest_digest="sha256:" + locator["sha256"])
            )
            epoch_start = time.perf_counter()
            detector_cpu_s = 0.0
            count = 0
            if source.receiver_ids != (0, 1):
                raise ValueError("the frozen replay requires both recorded receivers")

            for window in source.windows():
                if window.target["edge"] != edge:
                    raise ValueError("recorded pilot edge differs from the replay template")
                acquisition = window.acquisition
                retune = json.loads(acquisition.get("retune_receipt") or "{}")
                probes = []

                def detect(window, receivers, probes=probes):
                    nonlocal detector_cpu_s
                    started = time.process_time()
                    output = (
                        analyze_native(native, window.samples, receiver_id=0)
                        if detector == "single-rx0"
                        else native.analyze(window.samples)
                    )
                    rows = output["rows"]
                    detector_cpu_s += time.process_time() - started
                    if tuple(row["receiver_id"] for row in rows) != tuple(range(receiver_count)):
                        raise ValueError("the native detector returned unexpected receiver IDs")
                    for row in rows:
                        probes.append(
                            _probe(
                                window,
                                receivers[row["receiver_id"]],
                                (_from_native(rank, c) for rank, c in enumerate(row["candidates"])),
                            )
                        )
                    if detector == "single-rx0":
                        probes.append(_probe(window, receivers[1], ()))
                    # The outer adapter only needs the measured receiver IDs for its
                    # capture-status contract. Fresh fractional candidates leave via probes.
                    return tuple(
                        FastScanReceiverV1(receiver_id=rx, candidates=()) for rx in receivers
                    )

                status = analyze_window(window, source.receiver_ids, None, policy, detector=detect)
                print(
                    encoded(
                        dict(
                            kind="visit",
                            segment=index,
                            sequence=window.sequence,
                            visit=int(acquisition["global_visit"]),
                            iq_sha256=window.iq_sha256,
                            sample_start=status.sample_start,
                            sample_end=status.sample_end,
                            generation=status.generation,
                            status=status.status,
                            reason=status.reason,
                            rf_mapping_authority=status.rf_mapping_authority,
                            probes=probes,
                            input_bytes=window.samples.nbytes,
                            clock_anchor=retune.get("utc_clock_bracket"),
                            delivery_clock=retune.get("host_delivery_clock"),
                        )
                    ),
                    flush=True,
                )
                count += 1
            print(
                encoded(
                    dict(
                        kind="segment",
                        segment=index,
                        count=count,
                        path=str(directory),
                        manifest_digest=source.manifest_digest,
                        radio_id=source.radio["serial"],
                        library_sha256=library_hash,
                        wall_s=time.perf_counter() - epoch_start,
                        detector_cpu_s=detector_cpu_s,
                        detector=detector,
                    )
                ),
                flush=True,
            )
            print(
                f"Segment {index} verified and replayed, {count} windows",
                file=sys.stderr,
                flush=True,
            )
    if "sha256:" + _sha(library) != library_hash:
        raise ValueError("native detector binary changed during the replay")
    print(encoded(dict(kind="worker", worker=worker)), flush=True)

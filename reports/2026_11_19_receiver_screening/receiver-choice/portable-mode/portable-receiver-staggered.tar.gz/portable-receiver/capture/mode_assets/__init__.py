"""Qualified staggered mode dependencies."""

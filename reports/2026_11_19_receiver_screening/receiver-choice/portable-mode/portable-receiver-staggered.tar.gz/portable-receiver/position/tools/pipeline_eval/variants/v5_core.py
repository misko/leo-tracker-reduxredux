from itertools import product

import numpy as np

def cold_node(scan, node):
    from leo.analysis.localization_v3.discovery import zero_state

    return dict(
        seed=dict(rows=node["seed"]["rows"], state=zero_state(scan)), aliases=node["aliases"]
    )

def ranked_initial_nodes(scan):
    from leo.analysis.localization_v3.discovery import (
        explore,
        fresh_discovery,
        signature,
    )
    from leo.analysis.localization_v3.families import AnchoredFamilies
    from leo.analysis.localization_v3.position import NormalPosition

    sigma = scan.radio_sigma_hz
    seeds = fresh_discovery(scan, sigma, budget=4)
    best = min(seeds, key=lambda row: row["center_score"])
    radius = scan.search_region.half_width_km
    nodes = list(seeds)
    for point in product((-radius, radius), repeat=2):
        seed, _ = explore(
            scan, best["seed"]["state"], point, "receiver_smooth", compact_update=False
        )
        anchored = AnchoredFamilies(scan, seed, "receiver_smooth", False, point)
        nodes.append(dict(seed=seed, aliases=anchored.alias))
    unique = {}
    for node in nodes:
        unique.setdefault(signature(node), node)
    ranked = []
    for node in unique.values():
        rows = node["seed"]["rows"]
        cold = cold_node(scan, node)
        zero = np.zeros(len({r["candidate_index"] for r in rows}))
        model = NormalPosition(scan, cold, sigma, False, reference=zero)
        residual = model.residual(np.zeros(2))
        ranked.append((float(residual @ residual), cold))
    return [node for _, node in sorted(ranked, key=lambda entry: entry[0])]

def fit_initial_nodes(scan, cold_nodes):
    """Select the minimum refreshed c=0 loss and retain its track gate for both arms."""
    from leo.analysis.localization_v3.acceptance import actual_metrics
    from leo.analysis.localization_v3.position import refreshed

    sigma = scan.radio_sigma_hz
    winner = None
    for cold in cold_nodes:
        model, fit, _ = refreshed(scan, sigma, cold, "c0", rounds=5, iterations=48)
        if winner is None or fit["score"] < winner[0]["score"]:
            winner = fit, model, cold
    fit, model, cold = winner
    xy = fit["parameters"]
    result = dict(
        rows=model.rows, state=model.state(xy), aliases=model.alias, east_north_km=xy, fits=[fit]
    )
    metrics = actual_metrics(model, result, "c0", xy)
    choice = dict(hypothesis=0, node=cold, arms={"c0": {"metrics": metrics}})
    return {"choices": [choice], "selected_hypothesis": 0}, len(cold_nodes)

def initial_selection(scan):
    from tools.pipeline_eval.variants.v5_direct_lifetime import projection_columns

    with projection_columns():
        ranked = ranked_initial_nodes(scan)[:3]
    return fit_initial_nodes(scan, ranked)

def scan_context(prepared, region, noise_digest, bound, previous):
    from leo.analysis.localization_v3.scan import ScanLikelihood

    sky = prepared["sky"]
    receipt = sky[previous + "_receipt"]
    return ScanLikelihood(
        prepared["tracks"]["tracks"],
        sky["bank"],
        sky["nominal_elements"],
        origin_utc_ns=sky["metadata"]["origin_utc_ns"],
        regional_center=sky["metadata"]["regional_center"],
        noise=prepared["noise"],
        noise_sha256=noise_digest,
        search_region=region,
        bound=bound,
        previous_tle=sky[previous + "_tle"],
        previous_tle_sha256=receipt["catalogue_sha256"],
        previous_sources=receipt.get("sources"),
    )

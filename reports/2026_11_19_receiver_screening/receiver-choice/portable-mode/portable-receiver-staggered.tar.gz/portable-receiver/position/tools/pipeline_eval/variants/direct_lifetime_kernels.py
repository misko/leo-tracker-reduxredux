"""Bounded numerical operations assembled from the qualified method sources."""
import copy
import hashlib
import json
import re
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from typing import NamedTuple
import numpy as np


class TrackCandidate(NamedTuple):
    candidate_rank: int
    fractional_epoch_offset_samples: float
    fractional_margin: float
    fractional_tracking_cfo_hz: float
    integer_epoch_sample: int
    passed_fractional_margin_gate: bool

    def __getitem__(self, key):
        return getattr(self, key)


CANDIDATE_FIELDS = frozenset(TrackCandidate._fields) | {
    "fractional_control_score",
    "fractional_exact_score",
}


SPACE = re.compile(r"[ \t\r\n]*")


class PrivateNativeDocument(dict):
    """One freshly decoded document consumed by the original graph preparation."""


def project_record(row):
    if isinstance(row, dict) and row.keys() == CANDIDATE_FIELDS:
        return TrackCandidate(*(row[key] for key in TrackCandidate._fields))
    return row


def decode_native(text):
    """Use the standard JSON decoder per probe; narrow only source.probes[].candidates."""
    decode = json.JSONDecoder().raw_decode

    def token(index):
        return SPACE.match(text, index).end()

    def take_sequence(index, closing, take):
        index = token(index + 1)
        values = []
        if text[index : index + 1] == closing:
            return values, index + 1
        while True:
            value, index = take(index)
            values.append(value)
            index = token(index)
            delimiter = text[index : index + 1]
            if delimiter == closing:
                return values, index + 1
            if delimiter != ",":
                raise json.JSONDecodeError("Expected a JSON delimiter", text, index)
            index = token(index + 1)

    def object_at(index, overrides):
        if text[index : index + 1] != "{":
            return decode(text, index)

        def member(start):
            key, end = decode(text, start)
            end = token(end)
            if not isinstance(key, str) or text[end : end + 1] != ":":
                raise json.JSONDecodeError("Expected a JSON member", text, start)
            value, end = overrides.get(key, default)(token(end + 1))
            return (key, value), end

        pairs, end = take_sequence(index, "}", member)
        return dict(pairs), end

    def default(index):
        return decode(text, index)

    def probes_at(index):
        if text[index : index + 1] != "[":
            return default(index)

        def probe(start):
            value, end = default(start)
            if isinstance(value, dict) and isinstance(value.get("candidates"), list):
                value["candidates"] = [project_record(row) for row in value["candidates"]]
            return value, end

        return take_sequence(index, "]", probe)

    def source_at(index):
        return object_at(index, {"probes": probes_at})

    result, end = object_at(token(0), {"source": source_at})
    if token(end) != len(text):
        raise json.JSONDecodeError("Extra data", text, end)
    if not isinstance(result, dict):
        raise ValueError("Native GLRT document must be a JSON object")
    return PrivateNativeDocument(result)


def read_native(record):
    raw = Path(record["path"]).read_bytes()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != record["sha256"]:
        raise ValueError("Native job input changed: " + record["path"])
    text = raw.decode(json.detect_encoding(raw), "surrogatepass")
    del raw
    return decode_native(text)


def prepare_owned(operation, document, *args, **kwargs):
    prepared = operation(document, *args, **kwargs)
    if type(document) is PrivateNativeDocument:
        document.clear()
    return prepared


SATELLITES_PER_BATCH = 256


def bounded_states(ecef_states, catalogue, origin_utc_ns, times):
    """Preserve ordered float64 state arrays and each satellite's full time grid."""
    count = len(catalogue)
    if count <= SATELLITES_PER_BATCH:
        return ecef_states(catalogue, origin_utc_ns, times)
    shape = (count, len(times), 3)
    position, velocity = np.empty(shape), np.empty(shape)
    usable = np.empty(count, dtype=bool)
    for start in range(0, count, SATELLITES_PER_BATCH):
        stop = min(start + SATELLITES_PER_BATCH, count)
        rows = slice(start, stop)
        batch = type(catalogue)(
            catalogue.names[rows], catalogue.satellite_numbers[rows], catalogue.satellites[rows]
        )
        position[rows], velocity[rows], usable[rows] = ecef_states(batch, origin_utc_ns, times)
    return position, velocity, usable


COARSE_ROWS = 128


def regional_bank(
    kernel,
    usage,
    catalogue,
    origin_utc_ns,
    duration_s,
    *,
    screen_latitude_deg,
    screen_longitude_deg,
):
    """Preserve the original row-local SGP4, look-angle and threshold operations."""
    if not np.isfinite(duration_s) or duration_s < 0:
        raise ValueError("Finite nonnegative recording duration required")
    duration = max(300.0, duration_s)
    grid = np.arange(-17.0, np.ceil(duration) + 18)
    coarse = np.arange(0.0, duration + 5, 5.0)
    site = kernel.geodetic_to_ecef_km(screen_latitude_deg, screen_longitude_deg, 0.0)
    rotation = kernel.ecef_to_enu_matrix(screen_latitude_deg, screen_longitude_deg)
    cls = kernel.ElementSetCatalogue
    keep = []
    for start in range(0, len(catalogue), COARSE_ROWS):
        rows = slice(start, start + COARSE_ROWS)
        block = cls(
            catalogue.names[rows], catalogue.satellite_numbers[rows], catalogue.satellites[rows]
        )
        p, v, good = kernel.ecef_states(block, origin_utc_ns, coarse)
        angles = kernel.look_angles(p, v, site, rotation)
        keep.append(start + np.flatnonzero(good & (angles[1].max(axis=1) >= -12)))
        usage["coarse_batches"] += 1
        usage["max_coarse_rows"] = max(usage["max_coarse_rows"], len(block))
        usage["max_coarse_output_bytes"] = max(
            usage["max_coarse_output_bytes"], p.nbytes + v.nbytes + sum(a.nbytes for a in angles)
        )
        del p, v, good, angles
    selected = np.concatenate(keep) if keep else np.empty(0, dtype=int)
    if not len(selected):
        raise ValueError("no regional causal candidates")
    chosen = cls(
        tuple(catalogue.names[i] for i in selected),
        tuple(catalogue.satellite_numbers[i] for i in selected),
        tuple(catalogue.satellites[i] for i in selected),
    )
    p, v, good = bounded_states(kernel.ecef_states, chosen, origin_utc_ns, grid)
    if not good.all():
        raise ValueError("causal state bank propagation failed")
    usage.update(
        coarse_catalogue=len(catalogue),
        selected=len(chosen),
        coarse_knots=len(coarse),
        fine_knots=len(grid),
        retained_state_bytes=p.nbytes + v.nbytes,
    )
    return dict(
        catalogue=chosen,
        source_indices=selected,
        bank=dict(
            time_s=grid,
            position_km=p,
            velocity_km_s=v,
            norad=np.array(chosen.satellite_numbers),
            phase_sigma_s=np.ones(len(chosen)),
        ),
    )


@contextmanager
def last_use(parser, receipt):
    """Reuse and release the original parser's validated records, one snapshot at a time."""
    budget = parser.maximum_bytes
    stats = parser.statistics()
    receipt.update(
        starting_entries=len(parser._records),
        starting_bytes=parser.bytes,
        released_bytes=0,
        released_entries=0,
    )
    parser.maximum_bytes = 0

    def consume(text):
        catalogue = parser(text)
        entry = parser._records.pop(text, None)
        if entry is not None:
            size = entry[1]
            parser.bytes -= size
            receipt["released_bytes"] += size
            receipt["released_entries"] += 1
        return catalogue

    try:
        yield consume
    finally:
        parser.maximum_bytes = budget
        receipt.update(
            remaining_entries=len(parser._records),
            remaining_bytes=parser.bytes,
            last_use_hits=parser.hits - stats["hits"],
            last_use_misses=parser.misses - stats["misses"],
        )


class TrackColumns:
    """Share one queried track-sized C projection among the three fields."""

    def __init__(self, operation, stencil, coordinates, options, counts):
        self.operation, self.stencil = operation, stencil
        self.coordinates, self.options, self.counts = coordinates, options, counts
        self.last = None
        counts["deferred_projections"] += 1
        counts["deferred_cells"] += self.rows * self.columns
        counts["max_deferred_grid_bytes"] = max(
            counts["max_deferred_grid_bytes"], 24 * self.rows * self.columns
        )

    @property
    def rows(self):
        return len(self.stencil.positions)

    @property
    def columns(self):
        return self.stencil.index.shape[-1]

    def read(self, columns):
        if self.last is not None and np.array_equal(columns, self.last[0]):
            self.counts["shared_field_queries"] += 1
            return self.last[1]
        self.last = None
        sliced = replace(
            self.stencil,
            index=np.ascontiguousarray(self.stencil.index[..., columns]),
            fraction=np.ascontiguousarray(self.stencil.fraction[..., columns]),
        )
        values = self.operation(sliced, *self.coordinates, **self.options)
        self.counts["track_projections"] += 1
        self.counts["track_cells"] += self.rows * len(columns)
        self.counts["max_track_grid_bytes"] = max(
            self.counts["max_track_grid_bytes"], sum(a.nbytes for a in values)
        )
        self.last = columns.copy(), values
        return values


class TrackField:
    """Read full catalogue rows at original track columns, with lazy phase overlays."""

    def __init__(self, source, field, overlays=()):
        self.source, self.field = source, field
        self.overlays = list(overlays)

    @property
    def shape(self):
        return (self.source.rows, self.source.columns)

    def copy(self):
        return TrackField(self.source, self.field, self.overlays)

    def __getitem__(self, item):
        rows, columns = item
        columns = np.asarray(columns)
        if rows != slice(None) or columns.ndim != 1 or columns.dtype.kind not in "iu":
            raise IndexError("early Doppler field requires a full row and indexed column selection")
        # The frozen source's C array[:, indices] returns a new Fortran-layout
        # result. Preserve that reduction order even though C only computed this track.
        current = np.array(self.source.read(columns)[self.field], order="F", copy=True)
        for active, projected in self.overlays:
            current[active] = projected[:, columns]
        return current

    def __setitem__(self, item, value):
        active = np.asarray(item)
        if (
            not isinstance(value, TrackField)
            or active.ndim != 1
            or active.dtype.kind not in "iu"
            or value.shape != (len(active), self.source.columns)
        ):
            raise ValueError("early Doppler overlay requires indexed rows of a matching projection")
        self.overlays.append((active.copy(), value))


class RetainedRows:
    """Private ascending candidate index and its exact original diagnostic values."""

    def __init__(self, indices, source):
        self.indices, self.values = indices, source[indices]

    def __getitem__(self, candidate):
        index = int(np.searchsorted(self.indices, candidate))
        if index >= len(self.indices) or self.indices[index] != candidate:
            raise IndexError("discovery tried to read an unqualified diagnostic row")
        return self.values[index]


def retain_diagnostics(terms, visible):
    eligible = terms["passing"] & visible
    eligible[int(np.argmin(np.where(visible, terms["cost"], np.inf)))] = True
    indices = np.flatnonzero(eligible)
    dense, retained = 0, indices.nbytes
    for key in ("residual", "innovations"):
        array = terms[key]
        rows = RetainedRows(indices, array)
        terms[key] = rows
        dense += array.nbytes
        retained += rows.values.nbytes
    return dense, retained, len(indices)


def alignment_only(scan, labels):
    """Return the alignment inventory consumed by the frozen phase-width function."""
    from leo.analysis.localization_v3 import orbit_modes as original

    if scan.previous_tle is None or scan.previous_tle_sha256 is None:
        raise ValueError("Explicit previous causal TLE text and hash required")
    if hashlib.sha256(scan.previous_tle.encode()).hexdigest() != scan.previous_tle_sha256:
        raise ValueError("previous causal TLE bytes differ from the original prior receipt")
    key = tuple(labels)
    if key in getattr(scan, "previous_shape_cache", {}):
        return scan.previous_shape_cache[key]
    old = original.parse_element_sets(scan.previous_tle)
    lookup = dict(zip(old.satellite_numbers, old.satellites, strict=True))
    available = [k for k, j in enumerate(labels) if int(scan.norads[j]) in lookup]
    if not available:
        return None, set(), {}
    numbers = [int(scan.norads[labels[k]]) for k in available]
    catalogue = original.ElementSetCatalogue(
        tuple(map(str, numbers)), tuple(numbers), tuple(lookup[n] for n in numbers)
    )
    current = (
        scan.sky
        if key == tuple(range(len(scan.norads)))
        else dict(
            time_s=scan.sky["time_s"],
            position_km=scan.sky["position_km"][labels],
            velocity_km_s=scan.sky["velocity_km_s"][labels],
        )
    )
    sample = np.array([0.0, 150.0, 300.0])
    po, _, good = original.ecef_states(catalogue, scan.origin_utc_ns, sample)
    assert good.all()
    pn, vn = original.phase_shifted_states(current, sample, 0)
    pn, vn = pn[available], vn[available]
    vi = vn.copy()
    vi[..., 0] -= original.EARTH_ROTATION_RAD_S * pn[..., 1]
    vi[..., 1] += original.EARTH_ROTATION_RAD_S * pn[..., 0]
    phase = np.median(np.sum((po - pn) * vi, axis=2) / np.sum(vi**2, axis=2), axis=1)
    return None, set(available), dict(zip(numbers, map(float, phase), strict=True))


ROWS = 16


def coarse_scores(profile, measured, noise, f, elevation, derivative, q, phases, mask, counters):
    """Tile complete contiguous candidate rows, retaining only their minimum costs."""
    columns = len(measured) if mask is None else int(mask.sum())
    y, sigma = (measured, noise) if mask is None else (measured[mask], noise[mask])
    inverse = np.diag(1 / sigma)
    scores = np.empty(len(f))
    for i in range(0, len(f), ROWS):
        rows = slice(i, i + ROWS)
        prediction = q * (f[rows, None] + derivative[rows, None] * phases[None, :, None])
        e = elevation[rows]
        if mask is not None:
            prediction = prediction[:, :, mask]
            e = e[:, mask]
        terms = profile(y, prediction.reshape(-1, columns), inverse)
        cost = terms["cost"].reshape(len(e), -1) + phases[None, :] ** 2 / 9
        cost[e.max(axis=1) < 0] = np.inf
        scores[rows] = cost.min(axis=1)
        counters["tiles"] += 1
        counters["max_prediction_bytes"] = max(counters["max_prediction_bytes"], prediction.nbytes)
        counters["max_profile_output_bytes"] = max(
            counters["max_profile_output_bytes"], sum(v.nbytes for v in terms.values())
        )
        del prediction, terms, cost
    counters["coarse_windows"] += 1
    return scores


def fine_alternatives(kernel, scan, track, y, noise, rf, shortlist, coordinates):
    """Keep the frozen fine support grid and per-support publication gates."""
    t, values = track["times"], track["values"]
    grid = np.linspace(-15, 15, 121)
    supports = [
        (a, b)
        for a, b in kernel.selected_supports(len(t))
        if t[b - 1] - t[a] >= 20 and kernel.raw_curvature(dict(times=t[a:b], values=values[a:b]))
    ]
    alternatives = []
    for j in sorted(shortlist):
        bank = dict(
            time_s=scan.sky["time_s"],
            position_km=np.repeat(scan.sky["position_km"][[j]], len(grid), axis=0),
            velocity_km_s=np.repeat(scan.sky["velocity_km_s"][[j]], len(grid), axis=0),
        )
        f, e = kernel.paired_phase_frequency(
            bank, np.tile(t, len(grid)), np.repeat(np.arange(len(grid)), len(t)), grid, *coordinates
        )
        f, e = f.reshape(len(grid), -1), e.reshape(len(grid), -1)
        for a, b in supports:
            terms = kernel.profile(y[a:b], rf * f[:, a:b], np.diag(1 / noise[a:b]))
            cost = terms["cost"] + grid**2 / 9
            cost[e[:, a:b].min(axis=1) < 0] = np.inf
            best = int(np.argmin(cost))
            residual = terms["residual"][best]
            screen = kernel.batch_noise_screen(residual[None], t[a:b])
            max_sigma = np.max(abs(residual) / noise[a:b])
            if (
                terms["rms"][best] > 450
                or abs(terms["bias"][best]) > 3000
                or not np.isfinite(cost[best])
                or not screen["noise_screen_pass"][0]
                or max_sigma > 6
            ):
                continue
            alternatives.append(
                dict(
                    start_index=a,
                    stop_index=b,
                    points=b - a,
                    candidate_index=j,
                    norad=int(scan.norads[j]),
                    phase_s=float(grid[best]),
                    cost=float(cost[best]),
                    alias=int(terms["alias"][best]),
                    rms_hz=float(terms["rms"][best]),
                    max_external_radio_sigma=float(max_sigma),
                )
            )
    alternatives.sort(key=lambda row: (-row["points"], row["cost"]))
    return alternatives[:5], len(supports)


def salvage(kernel, counters, scan, node, keep, *, rounds=5, iterations=48):
    p, fitted, _, _ = kernel.repaired_fit(
        scan, node, "c0", "unit", keep, rounds=rounds, iterations=iterations
    )
    x = fitted["parameters"]
    state = p.state(x)
    coordinates = scan.search_region.latlon(x)
    repaired, retained, diagnostics = copy.deepcopy(node), keep.copy(), []
    phases = np.linspace(-10, 10, 81)
    for k, (i, sl) in enumerate(zip(p.members, p.slices, strict=True)):
        if keep[sl].any():
            continue
        track = scan.tracks[i]
        t, values = track["times"], track["values"]
        q = track["rf_hz"] / 11500000000.0
        radio = scan.hardware(track, state["beta"])
        radio += q * scan.rx_basis[i] @ state["smooth"][track["receiver"] - 1]
        y, noise = values - radio, p.point_noise[sl]
        f, elevation, derivative = kernel.phase_linear_frequency(
            kernel.prepare_phase_geometry(scan.sky, t), *coordinates
        )
        score = coarse_scores(
            kernel.profile, y, noise, f, elevation, derivative, q, phases, None, counters
        )
        shortlist = set(map(int, np.argsort(score)[:30]))
        for lo in np.arange(t[0], t[-1], 20):
            mask = (t >= lo) & (t < lo + 20)
            if mask.sum() >= 8:
                score = coarse_scores(
                    kernel.profile, y, noise, f, elevation, derivative, q, phases, mask, counters
                )
                shortlist.update(map(int, np.argsort(score)[:10]))
        shortlist.add(p.rows[k]["candidate_index"])
        alternatives, supports = fine_alternatives(
            kernel, scan, track, y, noise, q, shortlist, coordinates
        )
        chosen = alternatives[0] if alternatives else None
        diagnostics.append(
            dict(
                component=track["key"],
                candidate_count=len(shortlist),
                supports_tested=supports,
                selected=chosen,
                alternatives=alternatives,
            )
        )
        if chosen:
            repaired["seed"]["rows"][k].update(
                candidate_index=chosen["candidate_index"], candidate_norad=chosen["norad"]
            )
            repaired["aliases"][k] = chosen["alias"]
            retained[sl.start + chosen["start_index"] : sl.start + chosen["stop_index"]] = True
    return repaired, retained, diagnostics


TILE = 64


def screen(family, sky, coordinates, means, widths, data, observe=None):
    n = len(means)
    out = {}
    minimum = np.empty(n)
    radio = data["radio"] @ data["coefficient"][: data["radio_width"]]
    knots = sky["time_s"]
    payload = 0
    for start in range(0, n, TILE):
        part = slice(start, min(n, start + TILE))
        bank = dict(
            time_s=knots,
            position_km=sky["position_km"][part],
            velocity_km_s=sky["velocity_km_s"][part],
        )
        phases = means[part]
        f, e = family.phase_frequency_grid(bank, data["times"], *coordinates, phase_seconds=phases)
        minimum[part] = e.min(axis=1)
        block_bytes = f.nbytes + e.nbytes
        del e
        plus, elevation = family.phase_frequency_grid(
            bank, data["times"], *coordinates, phase_seconds=phases + 0.01
        )
        block_bytes = max(block_bytes, f.nbytes + plus.nbytes + elevation.nbytes)
        del elevation
        minus, elevation = family.phase_frequency_grid(
            bank, data["times"], *coordinates, phase_seconds=phases - 0.01
        )
        payload = max(
            payload, block_bytes, f.nbytes + plus.nbytes + minus.nbytes + elevation.nbytes
        )
        del elevation
        score = family.coarse_phase_scores(
            data["values"],
            radio,
            f * data["q"],
            (plus - minus) / 0.02 * data["q"],
            widths[part],
            data["base_covariance"],
            data["groups"],
        )
        for name, value in score.items():
            if name not in out:
                out[name] = np.empty((n, *value.shape[1:]), dtype=value.dtype)
            out[name][part] = value
        del f, plus, minus
    scores = np.where(minimum >= 0, out["score"], np.inf)
    if observe is not None:
        observe(out, minimum, payload)
    return scores, out["aliases"]


def nominate(family, d, observe=None, trace=None):
    """Use the original family policies around a bounded coarse score inventory."""
    case, scan, base = d["case"], d["scan"], d["base"]
    try:
        rows = []
        targets = sorted(
            {
                r["candidate_index"]
                for r, sl in zip(base.rows, base.slices, strict=True)
                if d["keep"][sl].any()
            }
        )
        for target in targets:
            if trace is not None:
                trace("enter", "family_data", target)
            data = family.family_data(d, target)
            if trace is not None:
                trace("leave", "family_data", target)
            data["target"] = target
            if len(data["values"]) < 4:
                continue
            if trace is not None:
                trace("enter", "coarse", target)
            scores, aliases = screen(
                family,
                scan.sky,
                scan.search_region.latlon(d["x"]),
                d["all_means"],
                d["widths"],
                data,
                observe,
            )
            if trace is not None:
                trace("leave", "coarse", target)
            ordered = [
                int(j) for j in np.argsort(scores) if np.isfinite(scores[j]) and j != target
            ][:7]
            if trace is not None:
                trace("enter", "refine", target)
            candidates = [
                family.candidate_prediction(d, data, j, aliases[j]) for j in [target] + ordered
            ]
            if trace is not None:
                trace("leave", "refine", target)
            eligible = sorted((r for r in candidates if r["qualified"]), key=lambda r: r["score"])
            original = candidates[0]
            best = next((r for r in eligible if r["candidate_index"] != target), None)
            gain = original["score"] - best["score"] if best is not None else None
            rows.append(
                dict(
                    original_index=target,
                    original_norad=int(scan.norads[target]),
                    members=data["members"],
                    held_observation_ids=data["held_ids"],
                    held_points=len(data["values"]),
                    coarse_candidate_count=len(scores),
                    candidates=candidates,
                    original=original,
                    best=best,
                    predictive_gain=gain,
                    search_penalty=float(2 * np.log(len(scores))),
                    all_held_points_disjoint_from_calibration=True,
                    cavity_phase_change_s=data["cavity_phase_change_s"],
                    no_predictive_noise_gate_used_to_veto_a_joint_proposal=True,
                )
            )
        return dict(
            case=case,
            status="complete",
            families=rows,
            reference_position_used=False,
            no_RF_GPS_future_TLE_or_point_deletion=True,
            incumbent_arms=d["signed"]["policy_arms"],
        )
    except Exception as exc:
        return dict(case=case, status="failed", error=repr(exc))

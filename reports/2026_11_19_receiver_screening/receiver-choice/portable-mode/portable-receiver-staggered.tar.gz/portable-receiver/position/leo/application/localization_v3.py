from leo.analysis.localization_v3.elements import ElementParser

from leo.analysis.localization_v3.noise import estimate_noise

from leo.analysis.localization_v3.phase_prior import forecast

from leo.analysis.localization_v3.tracks import prepare_tracks

def prepare_initial_sky(*args, **kwargs):
    """Load the owned archive adapter only at the input-preparation boundary."""
    from leo.operations.localization_v3_inputs import prepare_initial_sky as prepare
    return prepare(*args, **kwargs)

def prepare_phase_history(*args, **kwargs):
    """Fitting an already prepared scan does not import operational adapters."""
    from leo.operations.localization_v3_inputs import prepare_phase_history as prepare
    return prepare(*args, **kwargs)

def prepare_native_scan(document, archive, track_config, *,
                        screen_latitude_deg, screen_longitude_deg, element_parser=None):
    from tools.pipeline_eval.variants.v5_direct_lifetime import phase_history
    from tools.pipeline_eval.variants.direct_lifetime_kernels import prepare_owned

    prepared = prepare_owned(prepare_tracks, document, track_config)
    if prepared['status'] != 'tracks_prepared':
        return dict(status=prepared['status'], tracks=prepared, sky=None)
    own_parser = element_parser is None
    if own_parser:
        element_parser = ElementParser()
    sky = prepare_initial_sky(archive, prepared['tracks'], prepared['metadata'],
                              element_parser=element_parser,
                              screen_latitude_deg=screen_latitude_deg,
                              screen_longitude_deg=screen_longitude_deg)
    noise = estimate_noise(prepared['tracks'], prepared['observations'])
    if own_parser:
        history = phase_history(prepare_phase_history, element_parser, archive,
                                sky['nominal_elements'], prepared['metadata'])
    else:
        history = prepare_phase_history(archive, sky['nominal_elements'], prepared['metadata'],
                                        element_parser=element_parser)
    return dict(status='inputs_prepared', tracks=prepared, sky=sky, noise=noise,
                phase_history=history, phase_forecast=forecast(history))

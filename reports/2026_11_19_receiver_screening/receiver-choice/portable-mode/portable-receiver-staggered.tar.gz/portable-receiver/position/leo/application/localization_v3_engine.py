import json

import numpy as np

def _json_value(value):
    if isinstance(value, (np.ndarray, np.generic)):
        return value.tolist()
    raise TypeError(type(value).__name__)

def _prepared_values(prepared):
    """Keep the original input value types without writing/reloading a snapshot.

    Graph preparation produces NumPy metadata as well as arrays. The established
    numerical input boundary used JSON for those values and NPZ for the orbit
    bank. Preserve that representation exactly, entirely in memory.
    """
    if prepared["status"] != "inputs_prepared":
        return prepared
    sky = prepared["sky"]
    plain = dict(prepared, sky={k: v for k, v in sky.items() if k != "bank"})
    result = json.loads(json.dumps(plain, default=_json_value, allow_nan=False))
    result["sky"]["bank"] = sky["bank"]
    return result

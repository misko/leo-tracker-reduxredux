"""Diagnostics for factoring the capture detector's complete coarse bank."""

import numpy as np

RANKS = (4, 8, 12, 16, 20, 24, 32, 44)


def filters(template, starts, taps, frequencies, rate):
    """Return unit-norm correlation coefficients indexed by anchor, CFO and tap."""
    time = np.arange(taps)
    reference = np.asarray(template, dtype=np.complex128)[np.asarray(starts)[:, None] + time].conj()
    reference /= np.linalg.norm(reference, axis=1, keepdims=True)
    modulation = np.exp(-2j * np.pi * np.asarray(frequencies)[:, None] * time / rate)
    return reference[:, None] * modulation[None, :]


def decomposition(bank):
    """Factor the complex filters before discarding coefficient directions."""
    rows = bank.reshape(-1, bank.shape[-1])
    _, singular, basis = np.linalg.svd(rows, full_matrices=False)
    return rows @ basis.conj().T, singular, basis


def singular_diagnostics(bank):
    coefficient, singular, basis = decomposition(bank)
    rows = bank.reshape(-1, bank.shape[-1])
    error = {}
    for rank in RANKS:
        if rank <= len(singular):
            residual = np.linalg.norm(rows - coefficient[:, :rank] @ basis[:rank], axis=-1)
            error[rank] = {
                "rms_normalized_template_residual": float(np.linalg.norm(residual) / np.sqrt(len(rows))),
                "max_normalized_template_residual": float(residual.max()),
            }
    return dict(singular_values=singular.tolist(), truncation=error)


def rotational_diagnostics(bank):
    """Find the closest distinct filters, allowing phase and conjugate time reversal."""
    rows = bank.reshape(-1, bank.shape[-1])
    anchors = bank[:, bank.shape[1] // 2]
    matches = {}
    for label, subset in (("anchors", anchors), ("full", rows)):
        largest = {}
        for kind, target in (("phase", subset), ("conjugate_reversal", subset[:, ::-1].conj())):
            overlap = abs(subset @ target.conj().T)
            np.fill_diagonal(overlap, -1)
            i, j = np.unravel_index(overlap.argmax(), overlap.shape)
            largest[kind] = dict(
                filters=[int(i), int(j)],
                overlap=float(overlap[i, j]),
                residual=float(np.sqrt(max(0, 2 - 2 * overlap[i, j]))),
                equal_pairs=int(np.count_nonzero(overlap > 1 - 1e-12) // 2),
            )
        matches[label] = largest
    return matches

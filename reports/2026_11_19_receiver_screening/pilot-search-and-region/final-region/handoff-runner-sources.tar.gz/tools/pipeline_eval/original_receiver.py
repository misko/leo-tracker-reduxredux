"""Run the accelerated original receiver on authenticated saved I/Q."""

import argparse
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from contextlib import nullcontext
from functools import partial
from hashlib import sha256
from pathlib import Path
from time import monotonic
from types import SimpleNamespace
from unittest.mock import patch
from uuid import uuid4

from . import iq_service, whole_iq
from .__main__ import ROOT, THREAD_ENV, encoded, local_output, save_json, write
from .qualification import capture_release, capture_whole
from .qualification import prepared_capture_waveform as prepared
from .qualification.capture_whole import recording
from .qualification.full_v5_check import BULK, _load_case, _sha
from .scoring import validate_result
from .variants import (
    compact_tile_interior,
    final_region,
    fine_search,
    prepared_hotpath_peaks,
    v5_secant_fit,
)
from .variants.iq_stream import _read_prefix

MODULE = "tools.pipeline_eval.original_receiver"
ARCHIVE = BULK / "leo/fast-scan-recordings"
CALIBRATION = BULK / "leo-dev/whole-band-BCw8KqMY/receiver-phase-release"
CALIBRATION_SHA = "f4f5baef17a0f579469ef9aad6038ac0115b6f753d92eca96080541cc8f279a9"
NATIVE_BOUND_SHA = "40888d6143f385c2146e5e2cb28ea99a96b2f1bb791fab4c22b5afaaa2b3a23b"
ORBIT_PROJECTOR_SHA = "47d8605da701d4426d2a3a6f8a3e9dd272b1499a9f5e0b19e406087ff211a28f"
NUMERIC_SOURCES = {
    "leo/analysis/localization_v4/native_bound.c": NATIVE_BOUND_SHA,
    "tools/pipeline_eval/variants/orbit_projector.c": ORBIT_PROJECTOR_SHA,
}
PYTHON_SHA = "8f9781a98200d9ecda7e00464e4c64b1327abae788ae8e6979d5c859311410c7"
KERNEL_DIR = BULK / "leo-dev/receiver-screening-20261119/capture-exact-v2"
PREPARED = (
    ROOT
    / "reports/2026_11_19_receiver_screening/original-support/original-kernel/original_kernel.so"
)
KERNELS = {
    "prepared": (PREPARED, "26d1e10bb0cf0f15d58d922c46a2b50e38124d54a7efdccfcb8e2ba46783de02"),
    "batched32": (
        KERNEL_DIR / "capture_batched_fft.so",
        "5c7f96f8219d29a776660c4b0de5deafadaf4983774432e5868e1817423144ec",
    ),
    "cfo": (
        KERNEL_DIR / "conditioned.so",
        "378219a59d7b9b13f7548d9d056917853aad369c720ded4b1d07c32d661bfa1e",
    ),
    "fused": (
        KERNEL_DIR / "fused.so",
        "dc34f7196391931e27105425217bfcac3a47833571cb36fe8260686a9ce1ffb0",
    ),
}
PEAK_SELECTORS = ("installed", "row-wise")
ROW_SELECTOR_SHA = "a4198d5e47fdf337b1ee8605c715d9da24672cffddf3774b1a8265d5ad929527"
ROW_SELECTOR_QUALIFICATION = "c8bfb6ef30c385a85f7129ed18bc9565cfa02021be0c1174dcb1d2ee0fb5c52e"
ROW_SELECTOR_PRODUCERS = {
    capture_release.RELEASE_ROOTS[
        "fast-1f3a91c6a882b6e7eac8827fbb95f215"
    ]: "ef87f40f289e47724ba9fb135b37775d45a2e3fb0b5573e8e9d2b441d20339d6",
    capture_release.RELEASE_ROOTS[
        "fast-33b3892e0162eac7fd2232898aa9d1ce"
    ]: "ef87f40f289e47724ba9fb135b37775d45a2e3fb0b5573e8e9d2b441d20339d6",
    capture_release.RELEASE_ROOTS[
        "fast-a9ce664313cc56759cdffefe4750f833"
    ]: "6a1e88345d2d64f6d6e11f1d586753b74bcc0ef5a6f681e42880eb8bc6e7a23",
}
FINE_SEARCHES = ("installed", "pruned")
FINE_QUALIFICATION = "905317d53cb7b41a341bc6c121bc99bddf9caf4da1e666f1e3580111184c4895"
FINE_LIBRARY_SHA = "4d0b38f6c10aedba4f585e006fda5683ac78eafbc45be96a3609acf786b0458a"
FINE_LIBRARY_CACHE = BULK / "leo-dev/fine-search-20261119/qualified/fine_search.so"
FINE_NUMPY_VERSION = "2.5.2"
FINE_POCKETFFT_SHA = "29a1547b480b7ddc1e45cdc772b3f4b614cccced70204181bf5d3ad138a04ebb"
FINE_SOURCES = {
    Path(fine_search.__file__): "c484609d9a40ae8052f645c18917f98ce94bacbba056078c7ba40ab1c4d06ccc",
    fine_search.SOURCE: "4ecef2edc76d36f9c2c7eec221b8a2a35ee43ce442264634426a6da531157565",
    fine_search.SOURCE.with_name(
        "prepared_hotpath.py"
    ): "af424b931bc0ccd9dd867f7665916387de2f1983875401776ef522db99dd9afe",
    fine_search.SOURCE.with_name(
        "refine_bank.py"
    ): "34986485227b71a8e23ad8898904c8a25ff48961995cf2bd71949780c4770cf6",
}
FINE_TRACE = "pruned-fine-search-v1: "


def input_case(ident, path, digest):
    if ident is not None:
        if digest is not None:
            raise ValueError("--input-sha256 accompanies --input")
        try:
            return _load_case(ident)
        except StopIteration:
            raise ValueError(f"unknown recording case {ident}") from None
    if digest is None or not re.fullmatch(r"(?:sha256:)?[0-9a-f]{64}", digest):
        raise ValueError("--input requires the authenticated --input-sha256 digest")
    locator = whole_iq.checked(path.resolve(strict=True), digest)
    case = whole_iq.read(locator)
    if "request" in case:
        request = case["request"]
        case["request"] = dict(request, path=str((locator.parent / request["path"]).resolve()))
    return case


def binding(case):
    request = whole_iq.read(
        whole_iq.checked(BULK / case["request"]["path"], case["request"]["sha256"])
    )
    job = request["job"]
    if (
        request["role"] != "baseline"
        or job["identity"]["session_id"] != case["session_id"]
        or job.get("evaluation_reference") is not None
        or job["search_center"] != case["regions"][0]["center"]
    ):
        raise ValueError(
            "expected the truth-free original no-repair request for the offered region"
        )
    if "native" in case and (job.get("native_input") or {}).get("sha256") != (
        "sha256:" + case["native"]["sha256"].removeprefix("sha256:")
    ):
        raise ValueError("benchmark request does not bind its declared original detector input")
    snapshots = {p.name: _sha(p) for p in Path(job["tle_root"]).rglob("*.tle")}
    expected = {
        name: digest.removeprefix("sha256:") for name, digest in request["causal_snapshots"].items()
    }
    if not snapshots or snapshots != expected:
        raise ValueError("causal orbit snapshots differ from the authenticated request")
    config = job["track_config"]
    whole_iq.checked(Path(config["path"]), config["sha256"])
    return request


def bind_fresh(case, native, path):
    original = binding(case)
    job = dict(native_input=None, output_root=None, evaluation_reference=None) | original["job"]
    identity = dict(input_sha256=None, run_id=None) | job["identity"]
    job["identity"] = identity
    original["job"] = job
    native_sha = "sha256:" + _sha(native)
    request = dict(
        original,
        job=dict(
            job,
            native_input=dict(path=str(native), sha256=native_sha),
            output_root=str(path.parent / "position"),
            identity=dict(
                identity, input_sha256=native_sha, run_id="experiment-" + native_sha[7:39]
            ),
        ),
    )
    whole_iq.verify_request(request, original, native_path=str(native), native_sha256=native_sha)
    save_json(path, request)
    return native_sha


def chunks(case):
    output, base = [], 0
    for segment, locator in enumerate(case["recording"]["segments"]):
        path = (BULK / locator["path"]).resolve()
        if path.name != "manifest.json" or not path.is_relative_to(ARCHIVE):
            raise ValueError("each segment manifest must be in the supported saved-IQ archive")
        data = _read_prefix(path, 65537)
        if len(data) > 65536 or sha256(data).hexdigest() != locator["sha256"]:
            raise ValueError("a segment manifest failed SHA-256 verification")
        manifest, first = json.loads(data), 0
        for chunk in manifest["chunks"]:
            if chunk["first_sequence"] != first or chunk["window_count"] < 1:
                raise ValueError("signed chunk ranges must cover consecutive sequence numbers")
            stop = first + chunk["window_count"]
            output.append((segment, first, stop, base))
            first = stop
        if manifest["window_count"] != first:
            raise ValueError("segment chunks do not cover the signed window count")
        base += first
    if not output or base != case["recording"]["window_count"]:
        raise ValueError("recording chunks do not cover the signed window count")
    return output


def receiver_assets(path):
    programs = whole_iq.receiver_identity(path)
    content = {key: digest for key, digest in programs.items() if key != "native/manifest.json"}
    if sha256(encoded(content)).hexdigest() != CALIBRATION_SHA:
        raise ValueError("compact position installation differs from the qualified phase release")
    if whole_iq.native_sources(path) != NUMERIC_SOURCES:
        raise ValueError("compact native source differs from the qualified phase release")
    return programs


def selector_evidence(backend, producer):
    installed = producer / "leo/analysis/starlink/acquisition.py"
    if backend == "installed":
        return dict(
            backend=backend, version="installed-v1", source=str(installed), sha256=_sha(installed)
        )
    if backend != "row-wise" or producer not in ROW_SELECTOR_PRODUCERS:
        raise ValueError(f"peak selector {backend!r} is unqualified for producer {producer}")
    producer_sha = ROW_SELECTOR_PRODUCERS[producer]
    whole_iq.checked(installed, producer_sha)
    source = Path(prepared_hotpath_peaks.__file__)
    whole_iq.checked(source, ROW_SELECTOR_SHA)
    return dict(
        backend=backend,
        version="row-wise-v1",
        source=str(source),
        sha256=ROW_SELECTOR_SHA,
        producer_source=str(installed),
        producer_sha256=producer_sha,
        qualification_sha256=ROW_SELECTOR_QUALIFICATION,
    )


def peak_selector_for(lock):
    evidence = lock.get("peak_selector")
    if evidence is None:
        return nullcontext()
    backend = evidence["backend"]
    if evidence != selector_evidence(backend, Path(lock["producer"])):
        raise ValueError("peak selector differs from the source seal")
    if backend == "installed":
        return nullcontext()
    from leo.analysis.starlink import acquisition

    if Path(acquisition.__file__) != Path(evidence["producer_source"]):
        raise ValueError("the installed acquisition producer must own the peak selector")
    return patch.object(
        acquisition, "_retain_score_map_peaks", prepared_hotpath_peaks.retained_peaks
    )


def pruned_fine_evidence(producer):
    if producer not in ROW_SELECTOR_PRODUCERS:
        raise ValueError(f"pruned fine search is unqualified for producer {producer}")
    acquisition = producer / "leo/analysis/starlink/acquisition.py"
    sources = FINE_SOURCES | {acquisition: ROW_SELECTOR_PRODUCERS[producer]}
    for path, digest in sources.items():
        whole_iq.checked(path, digest)
    return dict(
        backend="pruned",
        version="pruned-v1",
        qualification_sha256=FINE_QUALIFICATION,
        numpy_version=FINE_NUMPY_VERSION,
        pocketfft_sha256=FINE_POCKETFFT_SHA,
        sources={str(path): digest for path, digest in sources.items()},
    )


def pruned_library(out, kernel_dir):
    started = monotonic()
    choices = (
        (kernel_dir / "fine_search.so",)
        if kernel_dir is not None
        else (KERNEL_DIR / "fine_search.so", FINE_LIBRARY_CACHE)
    )
    library = next((path for path in choices if path.exists()), None)
    command = None
    if library is None:
        directory = out / "fine-build"
        directory.mkdir()
        try:
            library, command = fine_search.build(directory)
        except subprocess.CalledProcessError as error:
            raise ValueError("could not compile the qualified pruned fine search") from error
    whole_iq.checked(library, FINE_LIBRARY_SHA)
    return library, dict(
        mode="compiled" if command else "reused",
        source=str(library),
        command=command,
        wall_s=monotonic() - started,
    )


def fine_search_for(lock, libs):
    selected = lock.get("fine_search")
    if selected is None:
        return None
    producer = Path(lock["producer"])
    expected = pruned_fine_evidence(producer)
    if any(selected[key] != value for key, value in expected.items()):
        raise ValueError("pruned fine search differs from the source seal")
    from numpy import __version__ as numpy_version
    from numpy.fft import _pocketfft_umath

    from leo.analysis.starlink import acquisition

    if Path(acquisition.__file__) != producer / "leo/analysis/starlink/acquisition.py":
        raise ValueError("the installed acquisition producer must own the pruned fine search")
    if numpy_version != FINE_NUMPY_VERSION:
        raise ValueError(f"unqualified NumPy {numpy_version} for pruned fine search")
    whole_iq.checked(Path(_pocketfft_umath.__file__), FINE_POCKETFFT_SHA)
    library = whole_iq.checked(libs["fine"], FINE_LIBRARY_SHA)
    return fine_search.FineSearch(library, acquisition)


def interior_guard_sources():
    policy = (final_region, compact_tile_interior, v5_secant_fit)
    return {module.__file__: _sha(Path(module.__file__)) for module in policy}


def prepare(
    case,
    out,
    cpus,
    raw_limit,
    position_limit,
    receiver,
    kernel_dir,
    smoke,
    peak_selector="installed",
    interior_guard=False,
    fine_backend="installed",
):
    from .qualification import capture_whole_results

    if len(set(cpus)) != len(cpus) or not set(cpus) <= os.sched_getaffinity(0):
        raise ValueError("choose distinct available CPU numbers")
    if out.is_relative_to(BULK / "leo"):
        raise ValueError("choose an output outside the recording archive")
    ranges = chunks(case)
    capture = capture_release.read_capture(case)
    producer = capture_release.producer(case, capture)
    selector = selector_evidence(peak_selector, producer.root)
    if fine_backend not in FINE_SEARCHES:
        raise ValueError("unknown fine search backend")
    fine = pruned_fine_evidence(producer.root) if fine_backend == "pruned" else None
    binding(case)
    capture["case"] = {key: case[key] for key in ("id", "session_id", "run_id")}
    receiver_files = receiver_assets(receiver)
    python = whole_iq.checked(recording.ARCHIVE_PYTHON, PYTHON_SHA)
    original_libraries = {}
    for role, (default, digest) in KERNELS.items():
        path = default if kernel_dir is None else kernel_dir / default.name
        original_libraries[role] = (whole_iq.checked(path, digest), digest)
    if smoke:
        ranges = ranges[:1]
    if len(cpus) > len(ranges):
        raise ValueError("choose at most one CPU per scheduled chunk, and one for --smoke")
    workers = capture_whole.partition(ranges, frozenset(), tuple(cpus))
    out.mkdir(parents=True, exist_ok=False)
    if fine is not None:
        library, installation = pruned_library(out, kernel_dir)
        original_libraries["fine"] = (library, FINE_LIBRARY_SHA)
    libraries = {}
    for role, (path, digest) in original_libraries.items():
        staged = out / "kernels" / path.name
        write(staged, path.read_bytes())
        staged.chmod(0o444)
        libraries[role] = dict(path=str(whole_iq.checked(staged, digest)), sha256=digest)
    programs = (
        Path(__file__),
        Path(capture_whole.__file__),
        Path(capture_whole_results.__file__),
        Path(prepared.__file__),
        Path(recording.__file__),
        Path(whole_iq.__file__),
    )
    lock = dict(
        id=case["id"],
        case=case,
        capture=capture,
        recording=case["recording"],
        producer=str(producer.root),
        peak_selector=selector,
        python=str(python),
        python_sha256=PYTHON_SHA,
        libraries=libraries,
        workers=workers,
        cpus=cpus,
        smoke=smoke,
        raw_limit_s=raw_limit,
        position_limit_s=position_limit,
        receiver=str(receiver),
        receiver_files=receiver_files,
        sources={str(path): _sha(path) for path in programs},
    )
    if interior_guard:
        lock["interior_guard"] = interior_guard_sources()
    if fine is not None:
        lock["fine_search"] = fine | dict(library=libraries["fine"], installation=installation)
    save_json(out / "source-lock.json", lock)
    (out / "source-lock.json").chmod(0o644)
    return lock


def configure(work):
    lock = whole_iq.read(work / "source-lock.json")
    for path, digest in lock["sources"].items():
        whole_iq.checked(Path(path), digest)
    whole_iq.checked(Path(lock["python"]), lock["python_sha256"])
    libs = {k: whole_iq.checked(Path(v["path"]), v["sha256"]) for k, v in lock["libraries"].items()}
    return lock, libs


def planned_valid(lock, cpu):
    """Apply the installed v2 validity check to authenticated index metadata only."""
    from leo.scanner.fast_scan_analysis import VerifiedFastWindow, analyze_window
    from leo.storage.short_window import ShortWindowIndexV2

    policy = capture_whole.policy_for(lock)
    _, _, walks = next(row for row in lock["workers"] if row[0] == cpu)
    valid = 0
    for segment, first, stop, base in walks:
        release = capture_whole.open_span(lock, segment, first, stop)
        (chunk,) = [c for c in release.reader.manifest.chunks if c.first_sequence == first]
        if chunk.window_count != stop - first:
            raise ValueError("the planned worker does not own exactly one signed chunk")
        lines = release.reader._member(
            chunk.index_relative_path, chunk.index_bytes, chunk.index_sha256
        ).splitlines()
        if len(lines) != stop - first:
            raise ValueError("signed index does not contain every planned visit")
        for sequence, line in enumerate(lines, start=first):
            row = ShortWindowIndexV2.model_validate_json(line)
            if row.sequence != sequence or row.acquisition["global_visit"] != base + sequence:
                raise ValueError("signed index visit sequence differs from the plan")
            shape = SimpleNamespace(shape=(row.sample_count, row.receiver_count, 2))
            frame = VerifiedFastWindow(
                sequence,
                row.iq_sha256,
                row.acquisition,
                release.targets[row.target_id],
                shape,
                policy.sample_rate_hz,
            )
            # Validity uses sample geometry and the signed retune receipt.
            status = analyze_window(frame, release.receiver_ids, None, policy, detector=empty_slots)
            if status.status not in ("processed", "invalid_capture"):
                raise ValueError("unsupported status in the original validity policy")
            valid += status.status == "processed"
    return valid


def empty_slots(_window, receivers):
    from leo.contracts.fast_scan import FastScanReceiverV1

    return tuple(FastScanReceiverV1(receiver_id=rx, candidates=()) for rx in receivers)


def shard(work, cpu, source_sha):
    whole_iq.checked(work / "source-lock.json", source_sha)
    lock, libs = configure(work)
    known = planned_valid(lock, cpu)
    lock["workers"] = [
        (who, known if who == cpu else count, paths) for who, count, paths in lock["workers"]
    ]
    fine = fine_search_for(lock, libs)
    try:
        if fine is not None and not fine.compatible:
            raise ValueError("installed FFT runtime failed the pruned fine search arithmetic check")
        with (
            patch.object(capture_whole, "configure", return_value=(lock, libs)),
            peak_selector_for(lock),
            fine.route() if fine is not None else nullcontext(),
        ):
            prepared.raw(work, cpu)
    finally:
        if fine is not None:
            evidence = dict(
                cpu=cpu,
                source_lock_sha256=source_sha,
                compatible=fine.compatible,
                pruned_calls=fine.calls,
                installed_fallbacks=fine.fallbacks,
            )
            print(FINE_TRACE + json.dumps(evidence), file=sys.stderr, flush=True)


def worker(attempt):
    plan = whole_iq.read(attempt / "plan.json")
    work, (cpu,) = attempt.parent, plan["cpus"]
    lock = whole_iq.read(whole_iq.checked(work / "source-lock.json", plan["source_lock_sha256"]))
    save_json(attempt / "start.json", whole_iq.raw.mark("original receiver worker enter"))
    if plan["stage"] == "position":
        if receiver_assets(Path(lock["receiver"])) != lock["receiver_files"]:
            raise ValueError("compact installation changed after the source seal")
        policy = lock.get("interior_guard")
        if policy is None:
            whole_iq.position(attempt)
        else:
            for path, digest in policy.items():
                whole_iq.checked(Path(path), digest)
            whole_iq.position(attempt, publish=partial(final_region.publish, enabled=True))
        return 0
    command = [
        "sudo",
        "-n",
        "-u",
        "leo",
        "--",
        "env",
        f"PYTHONPATH={lock['producer']}:{ROOT}",
        *(f"{k}={v}" for k, v in THREAD_ENV.items()),
        lock["python"],
        "-Bu",
        "-m",
        MODULE,
        "shard",
        str(work),
        str(cpu),
        plan["source_lock_sha256"],
    ]
    with (
        (work / f"cpu-{cpu}.jsonl").open("xb") as data,
        (work / f"cpu-{cpu}.log").open("xb") as log,
    ):
        return subprocess.run(command, stdout=data, stderr=log, check=False).returncode


def service(attempt, cpu, limit, stage, options=None):
    parent = attempt.parent
    plan = dict(
        stage=stage,
        cpus=[cpu],
        limit_s=limit,
        source_lock_sha256=_sha(parent / "source-lock.json"),
        **(options or {}),
    )
    save_json(attempt / "plan.json", plan)
    unit = "leo-iq-bench-" + uuid4().hex[:12]
    command = capture_whole.service(
        unit,
        limit,
        [
            f"--setenv=TMPDIR={attempt}",
            *(f"--setenv={k}={v}" for k, v in THREAD_ENV.items()),
            "taskset",
            "-c",
            str(cpu),
            sys.executable,
            "-B",
            "-m",
            MODULE,
            "worker",
            str(attempt),
        ],
    )
    return iq_service.run(attempt, command, unit, timeout=limit + 20)


def collect(work, lock):
    """Share the capture shard verifier after saving its actual declared valid count."""
    from .qualification import capture_whole_results

    workers = []
    for cpu, _, ranges in lock["workers"]:
        with (work / f"cpu-{cpu}.jsonl").open("rb") as stream:
            (terminal,) = [row for row in map(json.loads, stream) if row["kind"] == "worker"]
        workers.append((cpu, terminal["count"], ranges))
    return capture_whole_results.collect(work, dict(lock, workers=workers))


def fit(out, lock, shards):
    """Assemble complete verified shards and invoke the compact receiver once."""
    from .qualification.capture_whole_results import assemble

    document, counts = assemble(lock["case"], lock, shards)
    native = out / "native.json"
    recording.save(native, document)
    attempt = out / "position"
    request = attempt / "recording/request.json"
    request.parent.mkdir(parents=True, exist_ok=False)
    native_sha = bind_fresh(lock["case"], native, request)
    save_json(attempt / "raw.json", dict(native_sha256=native_sha, request_sha256=_sha(request)))
    with patch.object(iq_service, "MODULE", MODULE):
        receipt = service(
            attempt,
            lock["cpus"][0],
            lock["position_limit_s"],
            "position",
            dict(receiver=lock["receiver"]),
        )
    result = dict(
        stage="position", position_service=receipt, counts=counts, native_sha256=native_sha
    )
    if not iq_service.succeeded(receipt):
        return dict(result, status=failure_status((receipt,)))
    prediction = whole_iq.read(attempt / "position.json")
    validate_result(prediction)
    return dict(result, status=prediction["status"], result=prediction)


def fine_worker_receipt(out, cpu, source_sha):
    log = out / f"cpu-{cpu}.log"
    if not log.exists():
        return None
    with log.open() as stream:
        rows = [
            json.loads(line.removeprefix(FINE_TRACE))
            for line in stream
            if line.startswith(FINE_TRACE)
        ]
    if not rows:
        return None
    (row,) = rows
    if row["cpu"] != cpu or row["source_lock_sha256"] != source_sha:
        raise ValueError("fine search worker receipt differs from the source seal")
    return row


def run(out, lock):
    from .qualification import capture_whole_results

    with patch.object(iq_service, "MODULE", MODULE):
        started = monotonic()

        def raw_job(row):
            cpu = row[0]
            return cpu, service(out / f"raw-{cpu}", cpu, lock["raw_limit_s"], "raw")

        with ThreadPoolExecutor(max_workers=len(lock["workers"])) as pool:
            receipts = dict(pool.map(raw_job, lock["workers"]))
        raw_wall = monotonic() - started
        source_sha = _sha(out / "source-lock.json")
        save_json(out / "launch.json", dict(source_lock_sha256=source_sha))
        save_json(
            out / "raw-exits.json",
            dict(exits={str(c): r["exit_code"] for c, r in receipts.items()}, wall_s=raw_wall),
        )
        result = dict(
            id=lock["id"],
            mode="smoke" if lock["smoke"] else "full",
            peak_selector=lock.get("peak_selector", {"backend": "installed"}),
            raw_wall_s=raw_wall,
            raw_services=receipts,
        )
        failed = [receipt for receipt in receipts.values() if not iq_service.succeeded(receipt)]
        fine = lock.get("fine_search")
        if fine is not None:
            workers = {cpu: fine_worker_receipt(out, cpu, source_sha) for cpu in receipts}
            result["fine_search"] = fine | {"workers": workers}
            if not failed and any(row is None or not row["compatible"] for row in workers.values()):
                raise ValueError(
                    "finished raw workers must attest to compatible pruned fine search"
                )
        if failed:
            return dict(result, status=failure_status(failed), stage="raw")
        shards, workers, _ = collect(out, lock)
        rows = capture_whole_results.summary_rows(shards)
        result.update(
            completed_visits=len(rows),
            recorded_visits=lock["recording"]["window_count"],
            valid_visits=sum(row["status"] == "processed" for row in rows),
            invalid_visits=sum(row["status"] == "invalid_capture" for row in rows),
            grid_calls=sum(row["folded_calls"] for row in rows),
            workers=workers,
        )
        if lock["smoke"]:
            return dict(result, status="stage_only", stage="raw")
        return result | fit(out, lock, shards)


def failure_status(receipts):
    return (
        "timed_out"
        if all(receipt.get("systemd", {}).get("Result") == "timeout" for receipt in receipts)
        else "failed"
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--case", help="recording ID in the frozen input inventory")
    source.add_argument("--input", type=Path, help="authenticated recording locator JSON")
    parser.add_argument("--input-sha256")
    parser.add_argument("--out", required=True, type=local_output)
    parser.add_argument("--cpus", required=True, nargs="+", type=int)
    parser.add_argument("--raw-limit", type=int, default=600, metavar="SECONDS")
    parser.add_argument("--position-limit", type=int, default=180, metavar="SECONDS")
    parser.add_argument("--receiver", type=local_output, default=CALIBRATION)
    parser.add_argument("--kernel-dir", type=local_output)
    parser.add_argument(
        "--peak-selector",
        choices=PEAK_SELECTORS,
        default="installed",
        help="use the installed selector (default) or the qualified row-wise selector",
    )
    parser.add_argument(
        "--fine-search",
        choices=FINE_SEARCHES,
        default="installed",
        help="use the installed fine CFO search (default) or the qualified pruned transform",
    )
    parser.add_argument(
        "--interior-guard",
        action="store_true",
        help="withhold both positions when either fit is within 20 m of a tile face",
    )
    parser.add_argument(
        "--smoke", action="store_true", help="measure one complete chunk without fitting a position"
    )
    args = parser.parse_args(argv)
    if not (1 <= args.raw_limit <= 600 and 1 <= args.position_limit <= 600):
        parser.error("each service limit must be 1 through 600 seconds")
    try:
        case = input_case(args.case, args.input, args.input_sha256)
        start = monotonic()
        acquisition_options = (
            {} if args.fine_search == "installed" else {"fine_backend": args.fine_search}
        )
        plan = prepare(
            case,
            args.out,
            args.cpus,
            args.raw_limit,
            args.position_limit,
            args.receiver,
            args.kernel_dir,
            args.smoke,
            peak_selector=args.peak_selector,
            interior_guard=args.interior_guard,
            **acquisition_options,
        )
    except (KeyError, TypeError, OSError, ValueError) as error:
        parser.error(str(error))
    setup_wall = monotonic() - start
    result = run(args.out, plan) | {"setup_wall_s": setup_wall}
    save_json(args.out / "summary.json", result)
    print(json.dumps({key: result[key] for key in ("id", "status", "stage")}), flush=True)
    return int(result["status"] in ("failed", "unavailable", "timed_out"))


if __name__ == "__main__":
    if sys.argv[1:2] == ["worker"] and len(sys.argv) == 3:
        raise SystemExit(worker(local_output(sys.argv[2])))
    if sys.argv[1:2] == ["shard"] and len(sys.argv) == 5:
        shard(local_output(sys.argv[2]), int(sys.argv[3]), sys.argv[4])
    else:
        raise SystemExit(main())

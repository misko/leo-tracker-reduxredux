"""Private receiver modules."""
PROFILE = "compact-cut"

"""Run the authenticated original no-repair v5 worker on paired generated-waveform factors."""

import argparse
import gzip
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from time import monotonic
from uuid import uuid4

from .. import iq_service
from ..__main__ import ROOT, local_output, save_json, write
from ..scoring import ARMS, validate_result
from . import v5_regional_blind as blind
from . import v5_regional_reference as original
from .boundary_policy_trial import OLD_PUBLIC
from .phase_support_results import pack
from .whole_pressure_trial import rows_from

SCREEN = ROOT / "reports/2026_11_19_receiver_screening"
REPORT = SCREEN / "acquisition-frontier/waveform-v5"
RETROSPECTIVE = SCREEN / "track-recovery/waveform-site"
RETROSPECTIVE_PIN = "af7406395ba9037a641b6655f031e2d8b589484c767dc8378584e83b0e6639fa"
ROOF_PIN = "bcfbe09649d45b1d5e371e7351dbbc99a8bc59230b70172d85ea934183fa02df"
MODULE = "tools.pipeline_eval.qualification.waveform_v5"
METHOD = "waveform_v5_original"
LIMIT = 330
MEMORY = original.MEMORY


def read_checked(path, digest):
    original.checked(path, digest)
    return original.read(path)


def roof_authentication():
    roof = original.REPORT / "roof-retry"
    seal = read_checked(roof / "prediction-lock.json", ROOF_PIN)
    plan = read_checked(roof / "plan.json", seal["plan.json"])
    measured = read_checked(roof / "prediction.json", seal["prediction.json"])
    original.checked(Path(original.__file__), plan["adapter_sha256"])
    original.checked(original.ROOF_SOURCE, plan["earlier_archive_sha256"])
    (archived,) = [r for r in rows_from(original.ROOF_SOURCE) if r["id"] == original.ROOF]
    parity = original.parity(measured["result"], archived["result"])
    if not parity["exact"]:
        raise ValueError("original v5 route failed archived roof parity")
    return dict(parity, seal_sha256=ROOF_PIN, archive_sha256=plan["earlier_archive_sha256"])


def request_pair(rows, document):
    source = document["source"]
    cutoff = document["clock_anchor"]["before"]["realtime_ns"]
    pair = blind.select_pair([dict(row, cutoff_utc_ns=cutoff) for row in rows])
    if len(pair) != len(rows) or source["session_id"] != pair[0]["session"]:
        raise ValueError("paired offers do not authenticate against the native clock and session")
    if {row["tile"] == row["screen_center"] for row in pair} != {True}:
        raise ValueError("waveform parent uses each actual offer as its screen")
    return pair


def prepare(parent, pin, archive, work, report, cpus):
    roof = roof_authentication()
    seal = read_checked(parent / "prediction-lock.json", pin)
    files = seal["files"]
    paths = {name: parent / name for name in files}
    for name, path in paths.items():
        original.checked(path, files[name])
    detector = original.read(paths["detector-lock.json"])
    if not detector["ready"] or detector["completed_visits"] != detector["scheduled_visits"]:
        raise ValueError("generated IQ detector receipts do not cover the scheduled visits")
    for name, digest in detector["files"].items():
        original.checked(parent / name, digest)
    native_bytes = gzip.decompress((parent / "native.json.gz").read_bytes())
    native = json.loads(native_bytes)
    if len(native["source"]["probes"]) != 2 * detector["completed_visits"]:
        raise ValueError("generated native document omits scheduled receiver probes")
    pair = request_pair(original.read(paths["requests.json"]), native)
    if sorted(r["id"] for r in pair) != sorted(seal["cases"]):
        raise ValueError("the matched original offers differ from the sealed compact roster")
    workspace = work / "public"
    workspace.mkdir(parents=True, exist_ok=False)
    write(workspace / "native.json", native_bytes)
    first = pair[0]
    config = parent / "track-config.json"
    original.checked(config, first["config_sha256"])
    shutil.copyfile(config, workspace / first["track_config"])
    history = original.read(paths["causal-authority.json"])
    for name, row in sorted(history.items()):
        if Path(name).name != name or row["collected_utc_ns"] >= first["cutoff_utc_ns"]:
            raise ValueError("non-causal catalogue or invalid filename")
        path = archive / name
        original.checked(path, row["sha256"])
        write(workspace / "tle/archive/space-track" / name, path.read_bytes())
    jobs, received = blind.prepare(pair, workspace, work)
    if received != {name: row["sha256"] for name, row in history.items()}:
        raise ValueError("the original worker received a different causal history")
    out = {}
    for (meta, request), cpu in zip(jobs, cpus, strict=True):
        dest = work / meta["id"]
        request["job"]["output_root"] = str(dest)
        save_json(dest / "request.json", request)
        out[meta["id"]] = dict(meta, cpu=cpu, request_sha256=original.sha(dest / "request.json"))
    config = jobs[0][1]
    plan = dict(
        cohort=report.name,
        parent=str(parent.relative_to(SCREEN)),
        parent_sha256=pin,
        protocol_sha256=original.sha(REPORT / "PROTOCOL.md"),
        launcher_sha256=original.sha(Path(__file__)),
        original_source=config["source"],
        original_model=config["model"],
        original_role=config["role"],
        original_policy=config["policy"],
        original_runtime=config["job"]["runtime"],
        original_execution_policy=config["job"]["execution_policy"],
        original_native_manifest=config["native_manifest"],
        original_entry_sha256=original.sha(Path(original.v5_lean.__file__)),
        adapter_sha256=original.sha(Path(original.__file__)),
        roof_authentication=roof,
        cases=out,
        causal_history=received,
        deadline_s=LIMIT,
        memory_max=MEMORY,
        swap_max=0,
    )
    original.write(report / "source-lock.json", plan)
    return plan


def worker(directory, cpu):
    original.CPU = cpu
    original.worker(directory / "request.json", directory / "result.json")


def attempt(work, meta, masked):
    out = work / meta["id"]
    original.checked(out / "request.json", meta["request_sha256"])
    unit = "leo-waveform-v5-" + uuid4().hex[:12]
    command = [
        "systemd-run", "--user", "--wait", "--pipe", f"--unit={unit}",
        f"--working-directory={ROOT}", f"--property=RuntimeMaxSec={LIMIT}s",
        f"--property=MemoryMax={MEMORY}", "--property=MemorySwapMax=0",
        "--property=TimeoutStopSec=4s", "--property=KillMode=control-group", "--property=Nice=10",
        f"--setenv=PYTHONPATH={original.v5_lean.SOURCE}:{original.v5_lean.RUNNER}:{ROOT}",
        f"--setenv=TMPDIR={out}",
        *(f"--setenv={name}=1" for name in (
            "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
        )),
        "taskset", "-c", str(meta["cpu"]), "bwrap", "--die-with-parent", "--unshare-net",
        "--ro-bind", "/", "/", "--proc", "/proc", "--bind", str(out), str(out),
        "--tmpfs", str(ROOT / "reports"),
        *[arg for path in masked for arg in ("--tmpfs", str(path))],
        str(original.v5_lean.PYTHON), "-B", "-m", MODULE, "worker", str(out), str(meta["cpu"]),
    ]
    print(meta["id"], "starting original numerical v5", flush=True)
    before = monotonic()
    log_path = out / "service.log"
    with log_path.open("xb") as log:
        try:
            code = subprocess.run(
                command, stdout=log, stderr=subprocess.STDOUT, timeout=LIMIT + 20, check=False
            ).returncode
        except subprocess.TimeoutExpired:
            code = None
    elapsed = monotonic() - before
    state = iq_service._show(unit + ".service")
    if state.get("MainPID") != "0" or state.get("ControlPID") != "0":
        raise RuntimeError("terminal original v5 receipt has a live process")
    finish = out / "finish.json"
    log = log_path.read_text(errors="replace")
    result = endpoint(out, code, state, log)
    events = []
    for line in log.splitlines():
        if line.startswith("{"):
            data = json.loads(line)
            if data.get("event") in {"stage", "recovery_stage"}:
                events.append(data)
    measured = original.read(finish) if finish.is_file() else None
    accounting = dict(
        unit=unit, systemd=state, exit_code=code, elapsed_s=elapsed,
        command=command, log_sha256=original.sha(log_path), log_tail=log.splitlines()[-18:],
    )
    row = dict(meta, method=METHOD, result=result, service=accounting, events=events,
        worker_wall_s=elapsed,
        worker_cpu_s=measured["cpu_s"] if measured else nanoseconds(state.get("CPUUsageNSec")),
        worker_cgroup_peak_bytes=measured["memory_peak_bytes"] if measured else integer(state.get("MemoryPeak")),
        started=original.read(out / "start.json") if (out / "start.json").is_file() else None,
        finished=measured,
    )
    save_json(out / "receipt.json", row)
    print(meta["id"], result["status"], round(elapsed, 2), flush=True)
    return row


def integer(value):
    return int(value) if value is not None and value.isdecimal() else None


def nanoseconds(value):
    return int(value) / 1e9 if value is not None and value.isdecimal() else None


def endpoint(out, code, state, log):
    observed = state.get("Result")
    if code == 0 and (out / "finish.json").is_file() and (out / "result.json").is_file():
        result = original.read(out / "result.json")
        for arm, endpoint in result["arms"].items():
            rms = result["metrics"].get(f"{arm}_conditional_rms_hz")
            if rms is not None:
                endpoint["rf_rms_hz"] = rms
    else:
        if observed in (None, "success") and "result: timeout" in log:
            observed = "timeout"
        observed = observed or "unverified result"
        result = original.v5_lean._no_fix(
            f"Original v5 service terminal result: {observed}",
            status="timed_out" if observed == "timeout" else "failed",
        )
    validate_result(result)
    if set(result["arms"]) != set(ARMS):
        raise ValueError("original worker did not return both calibration arms")
    return result


def run(parent, pin, archive, work, report, cpus, masked):
    report.mkdir(parents=True, exist_ok=True)
    if (report / "source-lock.json").exists():
        raise FileExistsError("the matched original services are already frozen")
    plan = prepare(parent, pin, archive, work, report, cpus)
    with ThreadPoolExecutor(max_workers=2) as executor:
        rows = list(executor.map(lambda meta: attempt(work, meta, masked), plan["cases"].values()))
    pack(report / "positions.jsonl.gz", rows)
    for row in rows:
        name = row["id"]
        write(report / f"{name}.log", (work / name / "service.log").read_bytes())
    files = ["source-lock.json", "positions.jsonl.gz", *(f"{r['id']}.log" for r in rows)]
    original.write(report / "prediction-lock.json", dict(
        cases=list(plan["cases"]), files={name: original.sha(report / name) for name in files},
    ))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="mode", required=True)
    child = commands.add_parser("worker")
    child.add_argument("work", type=Path)
    child.add_argument("cpu", type=int)
    retrospective = commands.add_parser("retrospective")
    retrospective.add_argument("work", type=local_output)
    args = parser.parse_args()
    if args.mode == "worker":
        worker(args.work, args.cpu)
    else:
        run(RETROSPECTIVE, RETROSPECTIVE_PIN, OLD_PUBLIC / "tle/archive/space-track",
            args.work, REPORT / "retrospective", (16, 17), ())


if __name__ == "__main__":
    main()

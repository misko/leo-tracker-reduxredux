"""Acquisition coordination application boundary."""

from leo.acquisition.authority import (
    AuthorizedAcquisitionApplication,
    CaptureAuthorityError,
    CapturePausedError,
    CaptureTaskKind,
    LocalCaptureAuthority,
    RadioBusyError,
    RadioLease,
    RadioResource,
    UnknownRadioError,
)
from leo.acquisition.backpressure import (
    AcquisitionAdmissionDecision,
    AcquisitionBackpressureController,
    AcquisitionQueuePressure,
    AcquisitionQueuePressurePort,
)
from leo.acquisition.clock import AcquisitionClock, SystemAcquisitionClock
from leo.acquisition.continuity import ContinuityChainValidator, ContinuityValidationError
from leo.acquisition.coordinator import AcquisitionCoordinator
from leo.acquisition.coverage import (
    CaptureStreamCoverage,
    project_capture_progress_coverage,
    project_recording_stream_coverage,
)
from leo.acquisition.errors import (
    AcquisitionCancelled,
    AcquisitionError,
    AcquisitionSupervisorPoisoned,
    AdmissionRejected,
)
from leo.acquisition.models import (
    AcquisitionConfig,
    AdmissionEstimate,
    CaptureSessionResult,
    StorageAdmissionDecision,
)
from leo.acquisition.service import AcquisitionApplication

__all__ = [
    "AuthorizedAcquisitionApplication",
    "AcquisitionAdmissionDecision",
    "AcquisitionApplication",
    "AcquisitionBackpressureController",
    "AcquisitionCancelled",
    "AcquisitionClock",
    "AcquisitionConfig",
    "AcquisitionCoordinator",
    "ContinuityChainValidator",
    "ContinuityValidationError",
    "AcquisitionError",
    "AcquisitionSupervisorPoisoned",
    "AcquisitionQueuePressure",
    "AcquisitionQueuePressurePort",
    "AdmissionEstimate",
    "AdmissionRejected",
    "CaptureAuthorityError",
    "CapturePausedError",
    "CaptureSessionResult",
    "CaptureStreamCoverage",
    "CaptureTaskKind",
    "LocalCaptureAuthority",
    "RadioBusyError",
    "RadioLease",
    "RadioResource",
    "StorageAdmissionDecision",
    "SystemAcquisitionClock",
    "UnknownRadioError",
    "project_capture_progress_coverage",
    "project_recording_stream_coverage",
]

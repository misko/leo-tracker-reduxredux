"""Read-only API for adaptive TLE position-selection evidence."""

from typing import Annotated

from fastapi import APIRouter, HTTPException, Path, Query, Response

from leo.contracts.adaptive_tle_position import (
    AdaptiveTlePositionReader,
    AdaptiveTlePositionReaderV2,
    AdaptiveTlePositionReaderV3,
    AdaptiveTlePositionStatusV1,
    AdaptiveTlePositionStatusV2,
    AdaptiveTlePositionStatusV3,
)
from leo.contracts.digests import Sha256Digest

Identifier = Annotated[str, Path(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")]


def adaptive_tle_position_router(
    reader: AdaptiveTlePositionReader
    | AdaptiveTlePositionReaderV2
    | AdaptiveTlePositionReaderV3
    | None,
    *,
    version: int = 1,
) -> APIRouter:
    if version not in (1, 2, 3):
        raise ValueError("adaptive TLE position API version must be 1, 2 or 3")
    router = APIRouter(prefix="/api/v1/scanner/tracking")
    suffix = "adaptive-tle-position" if version == 1 else f"adaptive-tle-position-v{version}"

    @router.api_route(
        f"/{{session_id}}/{suffix}",
        methods=["GET", "HEAD"],
        response_model=(
            {
                1: AdaptiveTlePositionStatusV1,
                2: AdaptiveTlePositionStatusV2,
                3: AdaptiveTlePositionStatusV3,
            }[version]
        ),
    )
    def status(session_id: Identifier):
        if reader is None:
            raise HTTPException(404, "adaptive TLE position evidence is unavailable")
        try:
            return reader.status(session_id)
        except (ValueError, OSError) as error:
            raise HTTPException(
                409, "adaptive TLE position evidence failed verification"
            ) from error

    @router.api_route(f"/{{session_id}}/{suffix}/map.png", methods=["GET", "HEAD"])
    def artifact(session_id: Identifier, sha256: Annotated[Sha256Digest, Query()]):
        if reader is None:
            raise HTTPException(404, "adaptive TLE position evidence is unavailable")
        try:
            current = reader.status(session_id)
            if current.manifest is None:
                raise HTTPException(404, "adaptive TLE position PNG has not been published")
            if current.manifest.artifacts[0].sha256 != sha256:
                raise HTTPException(409, "adaptive TLE position PNG digest query differs")
            payload = reader.artifact(session_id)
        except HTTPException:
            raise
        except (ValueError, OSError) as error:
            raise HTTPException(
                409, "adaptive TLE position evidence failed verification"
            ) from error
        if payload is None:
            raise HTTPException(404, "adaptive TLE position PNG has not been published")
        return Response(
            payload,
            media_type="image/png",
            headers={
                "Cache-Control": "private, max-age=3600, immutable",
                "X-Content-Type-Options": "nosniff",
            },
        )

    return router

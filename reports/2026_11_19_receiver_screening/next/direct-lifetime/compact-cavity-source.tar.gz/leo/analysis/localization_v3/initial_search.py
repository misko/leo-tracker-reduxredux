"""Cold regional branch search with the production phase-refresh/acceptance policy.

This is the initial search, not the later recovery and reassociation pipeline.
The scan owns its explicit regional bounds, causal catalogue and radio evidence.
"""
import numpy as np

from leo.analysis.localization_v3.acceptance import actual_metrics, extend_associations
from leo.analysis.localization_v3.discovery import explore, fresh_discovery, signature, zero_state
from leo.analysis.localization_v3.families import AnchoredFamilies
from leo.analysis.localization_v3.position import NormalPosition, fit, refreshed


def fit_initial_arm(scan, sigma, node, arm, *, rounds, iterations):
    """One independent cold-branch fit; execution and ordering belong to the caller."""
    p, result, history = refreshed(scan, sigma, node, arm,
                                   rounds=rounds, iterations=iterations)
    x = result['parameters']
    legacy = dict(rows=p.rows, state=p.state(x), aliases=p.alias,
                  east_north_km=x, fits=[result])
    metrics = actual_metrics(p, legacy, arm, x)
    extended = extend_associations(p, x, metrics)
    return dict(fit=result, phase_rounds=history, state=p.state(x),
                reference=p.reference, metrics=metrics,
                all_graph_associations=extended,
                profile_gradient=None,
                conditional_residual_hz=p.calculate(x)['conditional_residual_hz'])


def initial_search(scan, sigma, *, seed_budget=4, branch_budget=3, rounds=5,
                   iterations=48, on_branch=None, map_arms=None, map_branches=None,
                   initial_control=None, seed_policy=None, ranking_policy=None):
    """Fit matched c arms; select their common hypothesis using only the c0 score.

    Defaults are the original complete initial-search budgets. Smaller explicit
    budgets support bounded component comparisons, not production qualification.
    ``on_branch`` is an optional progress sink called after each completed pair.
    ``map_arms`` may execute the two pure fits concurrently, but must return
    their values in input order or raise. The default is ordinary serial map.
    Alternatively, ``map_branches`` queues all (branch index, arm) tasks and
    returns their values in input order or raises. Branch callbacks then arrive
    in original order after the queue completes. Fit and selection budgets stay
    the same; supplying both execution ports is ambiguous and rejected.
    ``initial_control`` optionally supplies each complete zero-phase fit from
    the selected branch. The default recomputes both controls independently.
    """
    if any(not isinstance(n, int) or isinstance(n, bool) or n < 1
           for n in (seed_budget, branch_budget, rounds, iterations)):
        raise ValueError('Positive integer search budgets required')
    if map_arms is not None and map_branches is not None:
        raise ValueError('Supply only one initial execution port')
    if seed_policy not in (None, 'legacy', 'anchor-round-robin-v1'):
        raise ValueError('Unknown initial seed policy')
    if ranking_policy not in (None, 'legacy', 'warm-center-v1'):
        raise ValueError('Unknown initial ranking policy')
    explicit_policy = seed_policy is not None or ranking_policy is not None
    seed_policy = seed_policy or 'legacy'
    ranking_policy = ranking_policy or 'legacy'
    half = scan.search_region.half_width_km
    proposals = ((0., 0.), (-half, -half), (-half, half), (half, -half), (half, half))
    discovery_options = {} if seed_policy == 'legacy' else dict(seed_policy=seed_policy)
    candidates = fresh_discovery(scan, sigma, budget=seed_budget, **discovery_options)
    best = min(candidates, key=lambda r: r['center_score'])
    nodes, seen = [], set()
    for candidate in candidates:
        key = signature(candidate)
        if key not in seen:
            nodes.append(candidate)
            seen.add(key)
    for point in proposals[1:]:
        seed, detail = explore(scan, best['seed']['state'], point, 'receiver_smooth',
                               compact_update=False)
        anchor = AnchoredFamilies(scan, seed, 'receiver_smooth', False, point)
        node = dict(seed=seed, aliases=anchor.alias, proposal_point=point,
                    candidate_hypotheses=detail['candidate_hypotheses'])
        key = signature(node)
        if key not in seen:
            nodes.append(node)
            seen.add(key)
    scored, ranking = [], []
    for node in nodes:
        cold = dict(seed=dict(rows=node['seed']['rows'], state=zero_state(scan)),
                    aliases=node['aliases'])
        p = NormalPosition(scan, cold, sigma, False, reference=np.zeros(len({
            r['candidate_index'] for r in cold['seed']['rows']})))
        residual = p.residual(np.zeros(2))
        cold_score = float(residual @ residual)
        score = cold_score
        if ranking_policy == 'warm-center-v1':
            labels = sorted({r['candidate_index'] for r in node['seed']['rows']})
            reference = np.clip(np.asarray(node['seed']['state']['phases'])[labels], -15, 15)
            warm = NormalPosition(scan, node, sigma, False, reference=reference)
            residual = warm.residual(np.zeros(2))
            score = float(residual @ residual)
        scored.append((score, cold))
        if explicit_policy:
            ranking.append(dict(node_index=len(ranking), cold_score=cold_score,
                                ranking_score=score, signature=signature(node)))
    selected = sorted(scored, key=lambda r: r[0])[:branch_budget]
    fitted = None
    if map_branches is not None:
        tasks = [(index, arm) for index in range(len(selected))
                 for arm in ('c0', 'fitted_c')]
        fitted = list(map_branches(
            lambda item: fit_initial_arm(scan, sigma, selected[item[0]][1], item[1],
                                         rounds=rounds, iterations=iterations), tasks))
        if len(fitted) != len(tasks):
            raise ValueError('One result per initial branch/arm required')
    choices = []
    for index, (score, node) in enumerate(selected):
        arms = ('c0', 'fitted_c')
        if fitted is None:
            mapped = (map if map_arms is None else map_arms)(
                lambda arm, node=node: fit_initial_arm(scan, sigma, node, arm,
                                            rounds=rounds, iterations=iterations), arms)
        else:
            mapped = fitted[2*index:2*index+2]
        pair = dict(zip(arms, mapped, strict=True))
        choice = dict(hypothesis=index, center_score=score, node=node, arms=pair)
        choices.append(choice)
        if on_branch is not None:
            on_branch(choice)
    winner = min(choices, key=lambda r: r['arms']['c0']['fit']['score'])
    zero = {}
    for arm in ('c0', 'fitted_c'):
        if initial_control is not None:
            zero[arm] = initial_control(winner, arm)
            continue
        p = NormalPosition(scan, winner['node'], sigma, arm == 'fitted_c',
                           reference=np.zeros(len({r['candidate_index']
                                                   for r in winner['node']['seed']['rows']})))
        zero[arm] = fit(p, iterations=iterations)
    result = dict(
        status='complete', GPS_used=False, choices=choices,
        selected_hypothesis=winner['hypothesis'], zero_phase_control=zero,
        selection='minimum refreshed c0 full frequency/prior bound; matched branch for fitted c',
        unique_RF_hypotheses=len(scored), fully_fitted_hypotheses=len(selected),
        same_observations_candidates_priors_bounds_and_budgets_in_c_pair=True,
        fresh_radio_seed_budget=seed_budget, RF_proposal_points=proposals,
        region_center=scan.search_region.center, box_width_km=scan.search_region.width_km,
        noise_sigma_hz=sigma)
    if explicit_policy:
        result['initial_discovery_policy'] = dict(
            id='initial-discovery-v1', seed_policy=seed_policy, ranking_policy=ranking_policy)
        result['initial_discovery_ranking'] = ranking
    return result

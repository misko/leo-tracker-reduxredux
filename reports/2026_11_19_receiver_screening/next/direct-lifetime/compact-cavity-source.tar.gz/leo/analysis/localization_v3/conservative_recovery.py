"""Paired rejection/refitting and independently calibrated track salvage.

This is the conservative policy after initial search, before family-weighted
history fitting and later recovery. All evidence is passed as numerical inputs.
"""

import copy

import numpy as np

from leo.analysis.localization_v3.acceptance import conditional_gate, extend_associations
from leo.analysis.localization_v3.retained_position import (
    PositionNormal,
    fit_position,
    repaired_fit,
)
from leo.analysis.localization_v3.tracks import active_curvature as raw_curvature
from leo.analysis.research.continuous_curve_fit import paired_phase_frequency
from leo.analysis.research.orbital_support import requires_multiple_orbital_owners
from leo.analysis.research.phase_linear_geometry import (
    phase_linear_frequency,
    prepare_phase_geometry,
)
from leo.analysis.research.polynomial_satellite_diagnostics import batch_noise_screen
from leo.analysis.research.retained_track_likelihood import profile, whitening

ARMS = ("c0", "fitted_c")


def conservative_recovery(
    scan, initial, observations, *, max_rounds=4, rounds=5, iterations=48, on_round=None,
    map_arms=None,
):
    """Retain exactly the original exclusion/salvage policy and failure states.

    ``scan`` must use the genuine-previous causal prior, not the initial-search
    context with cached modes from the original previous-epoch catalogue.
    """
    if any(
        not isinstance(n, int) or isinstance(n, bool) or n < 1
        for n in (max_rounds, rounds, iterations)
    ):
        raise ValueError("Positive integer refit budgets required")
    winner = next(
        c for c in initial["choices"] if c["hypothesis"] == initial["selected_hypothesis"]
    )
    node = copy.deepcopy(winner["node"])
    p = PositionNormal(scan, node, scan.radio_sigma_hz, False)
    keep = np.ones(len(p.values), bool)
    failed = {
        r["component"] for r in winner["arms"]["c0"]["metrics"]["tracks"] if not r["compatible"]
    }
    for row, sl in zip(p.rows, p.slices, strict=True):
        if row["component"] in failed:
            keep[sl] = False
    if not keep.any():
        return dict(status="no_passing_calibration", GPS_used=False)
    p, keep, pair, before_history, stable = fit_and_gate(
        scan,
        node,
        keep,
        "exclude_refit",
        max_rounds=max_rounds,
        rounds=rounds,
        iterations=iterations,
        on_round=on_round,
        map_arms=map_arms,
    )
    trims = []
    if stable and not keep.all():
        node, keep, trims = salvage(scan, node, keep, rounds=rounds, iterations=iterations)
        p, keep, pair, after_history, stable = fit_and_gate(
            scan,
            node,
            keep,
            "salvage_refit",
            max_rounds=max_rounds,
            rounds=rounds,
            iterations=iterations,
            on_round=on_round,
            map_arms=map_arms,
        )
    else:
        after_history = []
    original_ids = {o["observation_id"] for o in observations}
    for arm in ARMS:
        saved = pair[arm]["record"]
        p = PositionNormal(
            scan,
            node,
            scan.radio_sigma_hz,
            arm == "fitted_c",
            reference=np.asarray(saved["phase_reference"]),
            keep=keep,
        )
        p.phase_sigma = np.asarray(saved["phase_widths_s"])
        x = saved["fit"]["parameters"]
        extended = extend_associations(p, x, pair[arm]["metrics"])
        pair[arm]["association"] = coverage(extended["tracks"], scan.tracks, original_ids)
        pair[arm]["association_tracks"] = extended["tracks"]
    return dict(
        status="complete" if stable else "gate_refit_unstable",
        arms=pair,
        final_node=node,
        final_mask=keep,
        initial_failed_components=sorted(failed),
        trims=trims,
        exclusion_history=before_history,
        post_salvage_history=after_history,
        paired_masks_aliases_and_identities=True,
        GPS_used=False,
        future_TLE_used=False,
    )


def selected_supports(n):
    """Whole, prefix and suffix hypotheses; no hand-written breakpoint time."""
    supports = {(0, n)} | {(a, n) for a in range(1, n - 11)} | {(0, b) for b in range(12, n)}
    return sorted((a, b) for a, b in supports if b - a >= 12)


def retained_metrics(p, x):
    """Apply the existing profile/conditional gates only to active observations.

    The 36-point salvage retains the original nuisance design. Masked prefix
    points must neither fail the suffix gate nor be counted as accepted suffix.
    """
    scan, state = p.scan, p.state(x)
    result = p.calculate(x)
    frequency, elevation = p.conditional_frequency(x)
    rows = []
    for row, i, sl, alias in zip(p.rows, p.members, p.slices, p.alias, strict=True):
        t, active = scan.tracks[i], p.keep[sl]
        if not active.any():
            continue
        times = t["times"][active]
        q = t["rf_hz"] / 11.5e9
        y = t["values"] - scan.hardware(t, state["beta"])
        y -= q * scan.rx_basis[i] @ state["smooth"][t["receiver"] - 1]
        terms = profile(y[active], q * frequency[sl][active], *whitening(times))
        noise = batch_noise_screen(terms["innovations"], times)
        conditional = conditional_gate(result["conditional_residual_hz"][sl][active], times)
        passing = bool(
            terms["rms"][0] <= 450
            and abs(terms["bias"][0]) <= 3000
            and noise["noise_screen_pass"][0]
            and conditional["compatible"]
            and int(terms["alias"][0]) == alias
            and elevation[sl][active].min() >= 0
        )
        rows.append(
            dict(
                component=t["key"],
                norad=row["candidate_norad"],
                candidate_index=row["candidate_index"],
                points=int(active.sum()),
                compatible=passing,
                observation_ids=np.asarray(t["observation_ids"])[active].tolist(),
                conditional_residual_gate=conditional,
                profile_rms_hz=float(terms["rms"][0]),
                profile_bias_hz=float(terms["bias"][0]),
                aliases_changed=int(int(terms["alias"][0]) != alias),
            )
        )
    while True:
        owners = {}
        by_key = {t["key"]: t for t in scan.tracks}
        for row in rows:
            if row["compatible"]:
                t = by_key[row["component"]]
                owners.setdefault(row["candidate_index"], set()).add((t["receiver"], t["channel"]))
        changed = False
        for row in rows:
            if (
                row["compatible"]
                and requires_multiple_orbital_owners(p, row["candidate_index"])
                and len(owners[row["candidate_index"]]) < 2
            ):
                row["compatible"] = False
                changed = True
        if not changed:
            break
    return dict(tracks=rows, accepted_points=sum(r["points"] for r in rows if r["compatible"]))


def coverage(accepted_tracks, tracks, original_ids):
    """Count unique measurements; never divide additional peaks by winner count."""
    by_key = {t["key"]: t for t in tracks}
    owned = []
    for row in accepted_tracks:
        if row["compatible"]:
            owned.extend(row.get("observation_ids", by_key[row["component"]]["observation_ids"]))
    if len(owned) != len(set(owned)):
        raise ValueError("a physical measurement has multiple accepted owners")
    associated = set(owned)
    return dict(
        original_winning_GLRT_points=len(original_ids),
        associated_original_winners=len(associated & original_ids),
        associated_original_percent=100 * len(associated & original_ids) / len(original_ids),
        associated_additional_peaks=len(associated - original_ids),
        associated_distinct_measurements=len(associated),
        associated_tracks=sum(bool(r["compatible"]) for r in accepted_tracks),
        associated_observation_ids=sorted(associated),
    )


def causal_fit(scan, node, keep, arm, *, rounds=5, iterations=48):
    return fit_position(scan, node, keep, [], arm, "native", rounds=rounds, iterations=iterations)


def fit_and_gate(scan, node, keep, stage, max_rounds=4, *, rounds=5, iterations=48,
                 on_round=None, map_arms=None):
    """Monotone paired-arm rejection with equal data and budgets in each pair."""
    history = []
    for epoch in range(max_rounds):
        pair, rejected = ({}, set())
        if map_arms is None:
            for arm in ARMS:
                p, record = causal_fit(scan, node, keep, arm, rounds=rounds, iterations=iterations)
                metrics = retained_metrics(p, record["fit"]["parameters"])
                pair[arm] = dict(record=record, metrics=metrics)
        else:
            def fit_arm(arm, keep=keep):
                problem, record = causal_fit(
                    scan, node, keep, arm, rounds=rounds, iterations=iterations
                )
                return dict(record=record,
                            metrics=retained_metrics(problem, record["fit"]["parameters"]))

            pair = dict(zip(ARMS, map_arms(fit_arm, ARMS), strict=True))
            # Transfer only fit/metric records, not the large scan or its caches.
            # Rebuild the last arm's layout for the unchanged paired mask update.
            saved = pair["fitted_c"]["record"]
            p = PositionNormal(scan, node, scan.radio_sigma_hz, True,
                               reference=np.asarray(saved["phase_reference"]), keep=keep)
            p.phase_sigma = np.asarray(saved["phase_widths_s"])
        for arm in ARMS:
            rejected.update(r["component"] for r in pair[arm]["metrics"]["tracks"]
                            if not r["compatible"])
        history.append(
            dict(epoch=epoch, active_points=int(keep.sum()), rejected_components=sorted(rejected))
        )
        if on_round is not None:
            on_round(stage, history[-1])
        if not rejected:
            return (p, keep, pair, history, True)
        if epoch == max_rounds - 1:
            break
        next_keep = keep.copy()
        for row, sl in zip(p.rows, p.slices, strict=True):
            if row["component"] in rejected:
                next_keep[sl] = False
        if not next_keep.any():
            return (p, keep, pair, history, False)
        assert np.all(~next_keep | keep)
        keep = next_keep
    return (p, keep, pair, history, False)


def salvage(scan, node, keep, *, rounds=5, iterations=48):
    from collections import Counter
    from leo.analysis.localization_v3 import conservative_recovery as kernel
    from tools.pipeline_eval.variants.direct_lifetime_kernels import salvage as tiled

    return tiled(kernel, Counter(), scan, node, keep, rounds=rounds, iterations=iterations)

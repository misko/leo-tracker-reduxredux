"""Explicit regional-search coordinates, independent of an evaluation site."""
from dataclasses import dataclass

import numpy as np
from tools.pipeline_eval.variants.cavity_longitude import local_latlon, local_native_point


@dataclass(frozen=True)
class SearchRegion:
    center: tuple[float, float]
    width_km: float = 25.

    def __post_init__(self):
        center = tuple(self.center)
        if (len(center) != 2 or not np.isfinite(center).all()
                or not -90 < center[0] < 90 or not -180 <= center[1] <= 180
                or not np.isfinite(self.width_km) or self.width_km <= 0):
            raise ValueError('Finite regional coordinates and positive width required')
        object.__setattr__(self, 'center', center)

    @property
    def half_width_km(self):
        return self.width_km / 2

    def latlon(self, local):
        return local_latlon(self.center, 111.32 * np.cos(np.deg2rad(self.center[0])), local)

    def native_point(self, scan, local):
        return local_native_point(scan.center, scan.scale, self.latlon(local))

    @property
    def grid(self):
        values = tuple(f * self.width_km for f in (-.5, -.25, 0., .25, .5))
        return tuple((e, n) for e in values for n in values)

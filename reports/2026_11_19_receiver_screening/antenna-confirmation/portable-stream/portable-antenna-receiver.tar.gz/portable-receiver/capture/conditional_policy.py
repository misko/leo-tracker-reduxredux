import json
from hashlib import sha256
import numpy as np
from native_bridge import _from_native


POLICY = 'second-physical-lane-on-primary-fractional-miss/v1'
GATE = 'passed_fractional_margin_gate'


def positive(probe):
    return any(candidate[GATE] is True for candidate in probe["candidates"])

def needs_partner(probe):
    return not positive(probe)

def mark(document, probes, policy=POLICY):
    """Bind acquired rows to the physical input, detector, exclusions and this policy."""
    source, provenance = document["source"], document["provenance"]
    payload = [
        policy,
        provenance.get("detector_sha256"),
        source["input_manifest_sha256"],
        probes,
        provenance["excluded_windows"],
    ]
    raw = json.dumps(
        payload, sort_keys=True, allow_nan=False, ensure_ascii=False, separators=(",", ":")
    ).encode()
    digest = sha256(raw).hexdigest()
    return dict(
        document,
        source=dict(source, probes=probes, analysis_manifest_sha256="sha256:" + digest),
        provenance=dict(
            provenance, scope=policy, detector_mode=policy, run_id="replay-" + digest[:32]
        ),
    )

class RfStagger:
    """One counter map per recording, called in acquisition order before detection."""

    def __init__(self):
        self._next = {}

    def reserve(self, center_hz, *, valid=True):
        if not valid:
            return None
        if type(center_hz) is not int or center_hz <= 0:
            raise ValueError("a valid visit requires its exact RF center in integer hertz")
        lane = self._next.get(center_hz, 0)
        self._next[center_hz] = 1 - lane
        return lane

def analyze_native(native, samples, receiver_id=0, *, include_timings=False):
    """Run a one-receiver context on its recorded lane without changing sample time."""
    if native.receiver_count != 1:
        raise ValueError("a single-receiver native context is required")
    if receiver_id not in (0, 1) or samples.ndim != 3 or samples.shape[1:] != (2, 2):
        raise ValueError("expected two recorded CI16 lanes and physical receiver 0 or 1")
    selected = np.ascontiguousarray(samples[:, receiver_id : receiver_id + 1, :])
    result = native.analyze(selected, include_timings=include_timings)
    (row,) = result["rows"]
    if row["receiver_id"] != 0:
        raise ValueError("unexpected logical receiver from the native single-receiver context")
    return dict(result, rows=[dict(row, receiver_id=receiver_id)])

def stereo_slots(result, lane):
    (observed,) = result["rows"]
    if observed["receiver_id"] != lane:
        raise ValueError("candidate row does not belong to the selected physical lane")
    empty = dict(observed, receiver_id=1 - lane, candidates=[])
    return dict(result, rows=[observed, empty] if lane == 0 else [empty, observed])

def detect(native, samples, receiver_id, *, on_hit=False, include_timings=False):
    """Return the complete physical rows and whether a second native call ran."""
    primary = analyze_native(native, samples, receiver_id, include_timings=include_timings)
    (row,) = primary["rows"]
    factors = [
        replacement
        for rank, candidate in enumerate(row["candidates"])
        if (replacement := _from_native(rank, candidate)) is not None
    ]
    needed = positive({"candidates": factors}) == on_hit
    if needed:
        partner = analyze_native(native, samples, 1 - receiver_id, include_timings=include_timings)
        rows = sorted(primary["rows"] + partner["rows"], key=lambda r: r["receiver_id"])
        outcome = dict(primary, rows=rows)
        if include_timings:
            outcome["detector_cpu_ms"] += partner["detector_cpu_ms"]
    else:
        outcome = stereo_slots(primary, receiver_id)
    return dict(outcome, receiver_count=2), needed

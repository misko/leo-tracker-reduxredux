#define _POSIX_C_SOURCE 200809L

#include "native_glrt.h"
#include "single_rx_glrt.h"
#include "short_window_glrt.h"
#include "center_union.h"

#include <fenv.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(LEO_NATIVE_GLRT_DISABLE_FINE_PLAN_REUSE)
#error "concurrent production contexts require eager fine FFT plan reuse"
#endif

#include "kernel/private_namespace.h"
#define LEO_PRESENCE_FIXED_GLRT_CFO_LIMIT 1
#include "kernel/private/full_search.c"
#include "kernel/private/dwell_input.h"
#include "kernel/private/proposal_core.h"
#include "kernel/private/proposal_tracking.h"

#define LEO_NATIVE_GLRT_CONTEXT_MAGIC UINT64_C(0x6c656f6475616c31)
#define LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC UINT64_C(0x6c656f73696e6731)

struct leo_native_glrt {
    uint64_t magic;
    _Atomic int busy;
    uint32_t rate;
    size_t frame;
    leo_presence_workspace *search;
    leo_proposal_workspace *proposal;
    leo_dwell_input sparse_prepared;
    leo_fine_precision_workspace fine_workspace;
    int refinement_mode;
    int receiver_count;
};

struct leo_single_rx_glrt { uint64_t magic; leo_native_glrt *native; };

_Static_assert(sizeof(leo_native_glrt_complex)==sizeof(leo_presence_complex),
    "public and frozen template lanes must have identical storage");

/* FFTW documents planning and plan destruction as non-thread-safe. Keep that
 * narrow lifecycle serialized while allowing independent, fully constructed
 * contexts to execute their distinct plans concurrently. */
static atomic_flag planner_busy = ATOMIC_FLAG_INIT;

static int planner_enter(void)
{
    return atomic_flag_test_and_set_explicit(&planner_busy,memory_order_acquire)
        ? LEO_NATIVE_GLRT_BUSY : LEO_NATIVE_GLRT_OK;
}

static void planner_leave(void)
{
    atomic_flag_clear_explicit(&planner_busy,memory_order_release);
}

static int context_enter(leo_native_glrt *context)
{
    int expected=0;
    return atomic_compare_exchange_strong_explicit(&context->busy,&expected,1,
        memory_order_acquire,memory_order_relaxed)
        ? LEO_NATIVE_GLRT_OK : LEO_NATIVE_GLRT_BUSY;
}

static void context_leave(leo_native_glrt *context)
{
    atomic_store_explicit(&context->busy,0,memory_order_release);
}

static int cpu_ms(double *result)
{
    struct timespec value;
    if(!result||clock_gettime(CLOCK_THREAD_CPUTIME_ID,&value))return -1;
    *result=1000.0*(double)value.tv_sec+1e-6*(double)value.tv_nsec;return 0;
}

static int wall_ms(double *result)
{
    struct timespec value;
    if(!result||clock_gettime(CLOCK_MONOTONIC,&value))return -1;
    *result=1000.0*(double)value.tv_sec+1e-6*(double)value.tv_nsec;return 0;
}

static int profile_clock(double *cpu,double *wall)
{
    return cpu_ms(cpu)||wall_ms(wall) ? -1 : 0;
}

static int valid_rate(uint32_t rate)
{
    return rate==2500000u || rate==5000000u ||
        rate==7500000u || rate==10000000u;
}

static int layout_for_receivers(uint32_t rate,uint32_t dwell_ms,uint32_t stride_ms,
    size_t *complex_times,size_t *row_count,size_t receivers)
{
    if(!complex_times||!row_count||!valid_rate(rate)||
       (dwell_ms!=120&&dwell_ms!=240&&dwell_ms!=360)||
       (stride_ms!=10&&stride_ms!=20&&stride_ms!=120))
        return LEO_NATIVE_GLRT_INVALID;
    *complex_times=(size_t)rate*dwell_ms/1000u;
    *row_count=receivers*(1u+(dwell_ms-20u)/stride_ms);
    return *row_count<=LEO_NATIVE_GLRT_MAX_ROWS
        ? LEO_NATIVE_GLRT_OK:LEO_NATIVE_GLRT_INVALID;
}

int leo_native_glrt_layout(uint32_t rate,uint32_t dwell_ms,uint32_t stride_ms,
    size_t *complex_times,size_t *row_count)
{
    return layout_for_receivers(rate,dwell_ms,stride_ms,complex_times,row_count,2);
}

int leo_single_rx_glrt_layout(uint32_t rate,uint32_t dwell_ms,uint32_t stride_ms,
    size_t *complex_times,size_t *row_count)
{
    return layout_for_receivers(rate,dwell_ms,stride_ms,complex_times,row_count,1);
}

static int short_window_layout(uint32_t rate,size_t *complex_times,
    size_t *row_count,size_t receivers)
{
    if(!complex_times||!row_count||!valid_rate(rate))
        return LEO_NATIVE_GLRT_INVALID;
    *complex_times=(size_t)rate/50u;*row_count=receivers;
    return LEO_NATIVE_GLRT_OK;
}

int leo_native_glrt_short_window_layout(uint32_t rate,size_t *complex_times,
    size_t *row_count)
{
    return short_window_layout(rate,complex_times,row_count,2);
}

int leo_single_rx_glrt_short_window_layout(uint32_t rate,size_t *complex_times,
    size_t *row_count)
{
    return short_window_layout(rate,complex_times,row_count,1);
}

static void copy_candidate(leo_native_glrt_candidate *to,
    const leo_full_search_candidate *from)
{
    const leo_presence_candidate *candidate=&from->candidate;
    *to=(leo_native_glrt_candidate){
        .coarse_epoch=from->coarse_epoch,.coarse_bin=from->coarse_bin,
        .refined_epoch=from->refined_epoch,.frame_support=from->frame_support,
        .glrt_complete=from->glrt_complete,
        .conditioned_fallback=from->conditioned_fallback,
        .refinement_skipped=from->refinement_skipped,
        .coarse_cfo_hz=from->coarse_cfo_hz,.fine_cfo_hz=from->fine_cfo_hz,
        .conditioned_cfo_hz=from->conditioned_cfo_hz,
        .epoch=candidate->epoch,.acquired_cfo_hz=candidate->acquired_cfo_hz,
        .tracking_cfo_hz=candidate->tracking_cfo_hz,
        .exact_score=candidate->exact_score,.control_score=candidate->control_score,
        .margin=candidate->margin,.acquire_score=candidate->acquire_score,
        .verify_score=candidate->verify_score,
        .verify_control_score=candidate->verify_control_score,
        .conditioned_score=candidate->conditioned_score,
        .coarse_score=candidate->coarse_score,
        .fractional_epoch_status=from->fractional_epoch_status,
        .fractional_epoch_offset_samples=from->fractional_epoch_offset_samples,
        .fractional_epoch_log_curvature=from->fractional_epoch_log_curvature,
        .fractional_exact_score=from->fractional_exact_score,
        .fractional_control_score=from->fractional_control_score,
        .fractional_margin=from->fractional_margin,
        .fractional_residual_cfo_hz=from->fractional_residual_cfo_hz,
        .fractional_tracking_cfo_hz=from->fractional_tracking_cfo_hz};
    memcpy(to->fractional_epoch_exact_grid,from->fractional_epoch_exact_grid,
        sizeof(to->fractional_epoch_exact_grid));
    memcpy(to->fractional_epoch_control_grid,from->fractional_epoch_control_grid,
        sizeof(to->fractional_epoch_control_grid));
}

static void copy_row(leo_native_glrt_row *to,int receiver,int probe_index,
    int start_ms,const leo_full_search_result *search,
    const leo_proposal_timing *proposal,int proposal_executed,
    int tracking_fallback,int neighbor_matches)
{
    *to=(leo_native_glrt_row){
        .receiver_id=receiver,.probe_index=probe_index,.probe_start_ms=start_ms,
        .proposal_executed=proposal_executed,
        .proposal_tracking_fallback=tracking_fallback,
        .proposal_neighbor_matches=neighbor_matches,
        .candidate_count=search->candidate_count,
        .retained_peak_count=search->retained_peak_count,
        .coarse_gate_skipped_count=search->coarse_gate_skipped_count,
        .conditioned_fallback_count=search->conditioned_fallback_count,
        .actual_executed_glrt_calls=search->actual_executed_glrt_calls,
        .glrt_cache_hits=search->glrt_cache_hits,
        .conditioned_cache_hits=search->conditioned_cache_hits,
        .fine_fft_cache_entries=search->fine_fft_cache_entries,
        .fine_fft_cache_hits=search->fine_fft_cache_hits,
        .fine_precision_calls=search->fine_precision_calls,
        .fine_precision_guard_checks=search->fine_precision_guard_checks,
        .fine_precision_fallbacks=search->fine_precision_fallbacks,
        .fine_precision_nonfinite_fallbacks=search->fine_precision_nonfinite_fallbacks,
        .fine_precision_near_tie_fallbacks=search->fine_precision_near_tie_fallbacks,
        .fine_precision_interpolation_fallbacks=search->fine_precision_interpolation_fallbacks,
        .conditioned_bins_screened=search->conditioned_bins_screened,
        .conditioned_bins_rechecked=search->conditioned_bins_rechecked,
        .total_cpu_ms=search->total_cpu_ms,.proposal_ms=proposal->total_ms,
        .stage_sum_ms=proposal->total_ms+search->total_cpu_ms,
        .proposal_fold_ms=proposal->fold_ms,
        .proposal_correlation_ms=proposal->correlation_ms,
        .proposal_ranking_ms=proposal->ranking_ms,
        .coarse_ms=search->coarse_cpu_ms,.acquisition_ms=search->acquisition_cpu_ms,
        .fine_fft_ms=search->fine_fft_cpu_ms,
        .conditioned_ms=search->conditioned_cpu_ms,
        .verification_ms=search->verification_cpu_ms,.glrt_ms=search->glrt_cpu_ms};
    to->fractional_epoch_ms=search->fractional_epoch_cpu_ms;
    for(int i=0;i<search->candidate_count;++i)
        copy_candidate(&to->candidates[i],&search->candidates[i]);
}

static int finite_result(const leo_native_glrt_result *result)
{
    for(size_t r=0;r<result->row_count;++r){
        const leo_native_glrt_row *row=&result->rows[r];
        const double timings[]={row->total_cpu_ms,row->proposal_ms,row->stage_sum_ms,
            row->proposal_fold_ms,row->proposal_correlation_ms,row->proposal_ranking_ms,
            row->coarse_ms,row->acquisition_ms,row->fine_fft_ms,row->conditioned_ms,
            row->verification_ms,row->glrt_ms,row->fractional_epoch_ms};
        for(size_t i=0;i<sizeof(timings)/sizeof(timings[0]);++i)
            if(!isfinite(timings[i]))return 0;
        if(row->candidate_count<0||row->candidate_count>LEO_NATIVE_GLRT_MAX_CANDIDATES)
            return 0;
        for(int i=0;i<row->candidate_count;++i){
            const leo_native_glrt_candidate *c=&row->candidates[i];
            if(c->fractional_epoch_status<0||c->fractional_epoch_status>2)return 0;
            const double values[]={c->coarse_cfo_hz,c->fine_cfo_hz,
                c->conditioned_cfo_hz,c->acquired_cfo_hz,c->tracking_cfo_hz,
                c->exact_score,c->control_score,c->margin,c->acquire_score,
                c->verify_score,c->verify_control_score,c->conditioned_score,
                c->coarse_score};
            for(size_t j=0;j<sizeof(values)/sizeof(values[0]);++j)
                if(!isfinite(values[j]))return 0;
            if(c->fractional_epoch_status){
                for(int j=0;j<5;++j)
                    if(!isfinite(c->fractional_epoch_exact_grid[j])||
                       !isfinite(c->fractional_epoch_control_grid[j]))return 0;
            }
            if(c->fractional_epoch_status==1){
                const double fractional[]={c->fractional_epoch_offset_samples,
                    c->fractional_epoch_log_curvature,c->fractional_exact_score,
                    c->fractional_control_score,c->fractional_margin,
                    c->fractional_residual_cfo_hz,c->fractional_tracking_cfo_hz};
                for(size_t j=0;j<sizeof(fractional)/sizeof(fractional[0]);++j)
                    if(!isfinite(fractional[j]))return 0;
            }
        }
    }
    return 1;
}

int leo_native_glrt_create(leo_native_glrt **out,uint32_t rate,
    const leo_native_glrt_complex *exact,const leo_native_glrt_complex *control,
    size_t count)
{
    return leo_native_glrt_create_with_mode(out,rate,exact,control,count,
        LEO_NATIVE_GLRT_MODE_ORDINARY);
}

static int create_with_mode_and_receivers(leo_native_glrt **out,uint32_t rate,
    const leo_native_glrt_complex *exact,const leo_native_glrt_complex *control,
    size_t count,uint32_t mode,int receiver_count)
{
    if(!out||!exact||!control||!valid_rate(rate)||
       (mode!=LEO_NATIVE_GLRT_MODE_ORDINARY&&
        mode!=LEO_NATIVE_GLRT_MODE_ORDINARY_WITH_FRACTIONAL_EPOCH)||
       count!=(rate+375u)/750u||fegetround()!=FE_TONEAREST||
       (receiver_count!=1&&receiver_count!=2))
        return LEO_NATIVE_GLRT_INVALID;
    *out=NULL;
    int status=planner_enter();if(status)return status;
    leo_presence_complex *native_exact=malloc(count*sizeof(*native_exact));
    leo_presence_complex *native_control=malloc(count*sizeof(*native_control));
    double (*proposal_template)[2]=malloc(count*sizeof(*proposal_template));
    if(!native_exact||!native_control||!proposal_template){
        free(proposal_template);free(native_control);free(native_exact);planner_leave();
        return LEO_NATIVE_GLRT_NOMEM;
    }
    for(size_t i=0;i<count;++i){
        if(!isfinite(exact[i].real)||!isfinite(exact[i].imaginary)||
           !isfinite(control[i].real)||!isfinite(control[i].imaginary)||
           fabs(exact[i].real)>16||fabs(exact[i].imaginary)>16||
           fabs(control[i].real)>16||fabs(control[i].imaginary)>16){
            free(proposal_template);free(native_control);free(native_exact);planner_leave();
            return LEO_NATIVE_GLRT_INVALID;
        }
        native_exact[i]=(leo_presence_complex){exact[i].real,exact[i].imaginary};
        native_control[i]=(leo_presence_complex){control[i].real,control[i].imaginary};
        proposal_template[i][0]=exact[i].real;proposal_template[i][1]=exact[i].imaginary;
    }
    leo_native_glrt *context=calloc(1,sizeof(*context));
    if(!context){free(proposal_template);free(native_control);free(native_exact);planner_leave();return LEO_NATIVE_GLRT_NOMEM;}
    atomic_init(&context->busy,0);
    context->magic=LEO_NATIVE_GLRT_CONTEXT_MAGIC;
    context->rate=rate;context->frame=count;context->receiver_count=receiver_count;
    context->refinement_mode=
        mode==LEO_NATIVE_GLRT_MODE_ORDINARY_WITH_FRACTIONAL_EPOCH?3:2;
    context->search=leo_presence_create(rate,native_exact,native_control,count);
    context->proposal=leo_proposal_create(proposal_template,count,(double)rate);
    free(proposal_template);free(native_control);free(native_exact);
    if(!context->search||!context->proposal
#if !defined(LEO_NATIVE_GLRT_DISABLE_FINE_PLAN_REUSE)
       ||leo_fine_precision_workspace_init(&context->fine_workspace,
           context->search->fine_fft.size)
#endif
       ){
        leo_fine_precision_workspace_free(&context->fine_workspace);
        leo_dwell_input_free(&context->sparse_prepared);
        if(context->proposal)leo_proposal_destroy(context->proposal);
        if(context->search)leo_presence_destroy(context->search);
        free(context);planner_leave();return LEO_NATIVE_GLRT_NOMEM;
    }
    *out=context;planner_leave();return LEO_NATIVE_GLRT_OK;
}

int leo_native_glrt_create_with_mode(leo_native_glrt **out,uint32_t rate,
    const leo_native_glrt_complex *exact,const leo_native_glrt_complex *control,
    size_t count,uint32_t mode)
{
    return create_with_mode_and_receivers(out,rate,exact,control,count,mode,2);
}

int leo_native_glrt_destroy(leo_native_glrt *context)
{
    if(!context||context->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC)
        return LEO_NATIVE_GLRT_INVALID;
    int status=context_enter(context);if(status)return status;
    status=planner_enter();
    if(status){context_leave(context);return status;}
    leo_proposal_destroy(context->proposal);
    leo_presence_destroy(context->search);
    leo_dwell_input_free(&context->sparse_prepared);
    leo_fine_precision_workspace_free(&context->fine_workspace);
    planner_leave();
    free(context);return LEO_NATIVE_GLRT_OK;
}

static int analyze_profiled(leo_native_glrt *context,const int16_t *ci16,
    size_t complex_times,uint32_t dwell_ms,uint32_t stride_ms,
    leo_native_glrt_result *result,leo_native_glrt_profile *profile,int short_window,
    const int32_t hints[2],leo_center_union_trace *hint_trace)
{
    size_t required_times=0,row_count=0;
    if(!context||context->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||!ci16||!result||
       (short_window
           ? short_window_layout(context->rate,&required_times,&row_count,
               (size_t)context->receiver_count)
           : layout_for_receivers(context->rate,dwell_ms,stride_ms,
               &required_times,&row_count,(size_t)context->receiver_count))||
       complex_times!=required_times)
        return LEO_NATIVE_GLRT_INVALID;
    size_t windows=row_count/(size_t)context->receiver_count;
    if(hints && (!short_window || context->rate != 10000000u ||
        context->refinement_mode != 3 ||
        !hint_trace || !leo_hint_valid(hints[0], (int)context->frame) ||
        !leo_hint_valid(hints[1], (int)context->frame)))return LEO_NATIVE_GLRT_INVALID;
    if(fegetround()!=FE_TONEAREST)return LEO_NATIVE_GLRT_INVALID;
    int status=context_enter(context);if(status)return status;
    int wide=short_window&&context->rate==10000000u;
    if (context->search->wide_regional!=wide)
        regional_cfo_band(context->search,wide);
    double started=0,finished=0,stage_cpu=0,stage_wall=0,end_cpu=0,end_wall=0;
    if(cpu_ms(&started)){context_leave(context);return LEO_NATIVE_GLRT_KERNEL;}
    leo_native_glrt_result temporary={0};
    leo_native_glrt_profile measured={0};
    leo_dwell_input prepared={0};
    leo_dwell_input *prepared_view=&prepared;
    int persistent_prepared=0;
    if(profile_clock(&stage_cpu,&stage_wall)){
        context_leave(context);return LEO_NATIVE_GLRT_KERNEL;
    }
    unsigned char *selected=calloc(context->frame,1);
    size_t anchors=1+(dwell_ms-20)/20;
    int (*centers)[2][4]=calloc(anchors,sizeof(*centers));
    int (*counts)[2]=calloc(anchors,sizeof(*counts));
    leo_proposal_timing (*timings)[2]=calloc(anchors,sizeof(*timings));
    if(profile_clock(&end_cpu,&end_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    measured.allocation_cpu_ms=end_cpu-stage_cpu;
    measured.allocation_wall_ms=end_wall-stage_wall;
    if(!selected||!centers||!counts||!timings){
        status=LEO_NATIVE_GLRT_NOMEM;goto done;
    }
#ifdef LEO_NATIVE_GLRT_FULL_PREP
    size_t prepare_count=complex_times;
#else
    size_t prepare_count=(dwell_ms==120&&stride_ms==120)
        ? context->rate/50u : complex_times;
#endif
    measured.prepared_complex_times=prepare_count;
    if(profile_clock(&stage_cpu,&stage_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
#if !defined(LEO_NATIVE_GLRT_FULL_PREP) && !defined(LEO_NATIVE_GLRT_DISABLE_PREPARED_REUSE)
    if(short_window||(dwell_ms==120&&stride_ms==120)){
        prepared_view=&context->sparse_prepared;persistent_prepared=1;
    }else leo_dwell_input_free(&context->sparse_prepared);
#endif
    int prepare_failed=context->receiver_count==1
        ? (persistent_prepared
            ? leo_dwell_input_prepare_single_reuse(prepared_view,ci16,prepare_count)
            : leo_dwell_input_prepare_single(prepared_view,ci16,prepare_count))
        : (persistent_prepared
            ? leo_dwell_input_prepare_reuse(prepared_view,ci16,prepare_count)
            : leo_dwell_input_prepare(prepared_view,ci16,prepare_count));
    if(prepare_failed){
        status=LEO_NATIVE_GLRT_NOMEM;goto done;
    }
    if(profile_clock(&end_cpu,&end_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    measured.preparation_cpu_ms=end_cpu-stage_cpu;
    measured.preparation_wall_ms=end_wall-stage_wall;
    /* Sparse strides execute only scheduled anchors. Dense stride 10 needs all
     * 20 ms anchors to reproduce the frozen odd-window neighbor tracking. */
    if(profile_clock(&stage_cpu,&stage_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    for(size_t window=0;window<windows;++window){
        unsigned start_ms=(unsigned)window*stride_ms;
        if(stride_ms==10 && start_ms%20)continue;
        size_t anchor=start_ms/20;
        for(int rx=0;rx<context->receiver_count;++rx)
            if((context->receiver_count==1
                ? leo_proposal_top4_single(context->proposal,ci16,
                    (size_t)start_ms*context->rate/1000u,
                    centers[anchor][rx],&counts[anchor][rx],&timings[anchor][rx])
                : leo_proposal_top4(context->proposal,ci16,
                    (size_t)start_ms*context->rate/1000u,rx,
                    centers[anchor][rx],&counts[anchor][rx],
                    &timings[anchor][rx]))){
                status=LEO_NATIVE_GLRT_KERNEL;goto done;
            }
    }
    if(profile_clock(&end_cpu,&end_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    measured.proposals_cpu_ms=end_cpu-stage_cpu;
    measured.proposals_wall_ms=end_wall-stage_wall;
    if(profile_clock(&stage_cpu,&stage_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    for(size_t window=0;window<windows;++window)
      for(int rx=0;rx<context->receiver_count;++rx){
        unsigned start_ms=(unsigned)window*stride_ms;
        int current[4]={0},count=0,executed=0,fallback=0,matches=0;
        leo_proposal_timing timing={0};
        if(start_ms%20==0){
            size_t anchor=start_ms/20;count=counts[anchor][rx];
            memcpy(current,centers[anchor][rx],sizeof(current));
            timing=timings[anchor][rx];executed=1;
        }else{
            size_t left=start_ms/20,right=left+1;
            count=leo_tracked_centers(centers[left][rx],counts[left][rx],
                centers[right][rx],counts[right][rx],(int)(start_ms/10),
                context->rate,(int)context->frame,current,&matches);
            if(!count){
                int proposal_failed=context->receiver_count==1
                    ? leo_proposal_top4_single(context->proposal,ci16,
                        (size_t)start_ms*context->rate/1000u,current,&count,&timing)
                    : leo_proposal_top4(context->proposal,ci16,
                        (size_t)start_ms*context->rate/1000u,rx,current,&count,&timing);
                if(proposal_failed){
                    status=LEO_NATIVE_GLRT_KERNEL;goto done;
                }
                executed=1;fallback=1;
            }
        }
        if(count>4)count=4;
        leo_center_union_lane *lane=hints ? &hint_trace->lanes[rx] : NULL;
        if(lane){
            *lane=(leo_center_union_lane){.count=count,.hint=hints[rx]};
            memcpy(lane->ordinary,current,(size_t)count*sizeof(*current));
        }
        memset(selected,0,context->frame);
        for(int c=0;c<count;++c){
            int first=current[c]-1,last=current[c]+1;
            if(first<0)first=0;
            if(last>=(int)context->frame)last=(int)context->frame-1;
            for(int epoch=first;epoch<=last;++epoch)selected[epoch]=1;
        }
        if(lane)lane->added_epochs=leo_union_add(selected,(int)context->frame,hints[rx]);
        context->search->regional_count=0;
        for(size_t epoch=0;epoch<context->frame;++epoch)if(selected[epoch]){
            context->search->regional_epochs[context->search->regional_count++]=(int)epoch;
            if(lane && selected[epoch]==1)lane->stock_epochs[lane->stock_epoch_count++]=(int)epoch;
        }
        if(lane)lane->active_epochs=context->search->regional_count;
        context->search->center_union_lane=lane;
        context->search->center_union_mask=lane ? selected : NULL;
        size_t offset=(size_t)start_ms*context->rate/1000u;
        leo_full_search_result search;
        int search_failed=leo_full_search_run_prepared_with_fine_workspace_mode(context->search,
            prepared_view->raw[rx]+offset,
            prepared_view->normalized[rx]+2*offset,prepared_view->prefix[rx]+offset,
            context->rate/50u,&search,
#ifdef LEO_NATIVE_GLRT_DISABLE_FINE_PLAN_REUSE
            NULL
#else
            &context->fine_workspace
#endif
            ,context->refinement_mode,context->search->regional_epochs,
            context->search->regional_count);
        context->search->center_union_lane=NULL;
        context->search->center_union_mask=NULL;
        if(search_failed){
            status=LEO_NATIVE_GLRT_KERNEL;goto done;
        }
        copy_row(&temporary.rows[temporary.row_count++],rx,(int)window,
            (int)start_ms,&search,&timing,executed,fallback,matches);
    }
    if(profile_clock(&end_cpu,&end_wall)){
        status=LEO_NATIVE_GLRT_KERNEL;goto done;
    }
    measured.search_cpu_ms=end_cpu-stage_cpu;
    measured.search_wall_ms=end_wall-stage_wall;
    status=LEO_NATIVE_GLRT_OK;
done:
    if(profile_clock(&stage_cpu,&stage_wall))status=LEO_NATIVE_GLRT_KERNEL;
    if(!persistent_prepared)leo_dwell_input_free(&prepared);
    free(timings);free(counts);free(centers);free(selected);
    if(profile_clock(&end_cpu,&end_wall))status=LEO_NATIVE_GLRT_KERNEL;
    else {
        measured.cleanup_cpu_ms=end_cpu-stage_cpu;
        measured.cleanup_wall_ms=end_wall-stage_wall;
    }
    if(status==LEO_NATIVE_GLRT_OK){
        if(cpu_ms(&finished))status=LEO_NATIVE_GLRT_KERNEL;
        else {
            temporary.detector_cpu_ms=finished-started;
            if(!isfinite(temporary.detector_cpu_ms)||!finite_result(&temporary))
                status=LEO_NATIVE_GLRT_KERNEL;
            else {
                *result=temporary;
                if(profile)*profile=measured;
            }
        }
    }
    context_leave(context);return status;
}

int leo_native_glrt_analyze_profiled(leo_native_glrt *context,const int16_t *ci16,
    size_t complex_times,uint32_t dwell_ms,uint32_t stride_ms,
    leo_native_glrt_result *result,leo_native_glrt_profile *profile)
{
    if(!context||context->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||
       context->receiver_count!=2)return LEO_NATIVE_GLRT_INVALID;
    return analyze_profiled(context,ci16,complex_times,dwell_ms,stride_ms,result,profile,0,NULL,NULL);
}

int leo_native_glrt_analyze_short_window_profiled(leo_native_glrt *context,
    const int16_t *ci16,size_t complex_times,leo_native_glrt_result *result,
    leo_native_glrt_profile *profile)
{
    if(!context||context->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||
       context->receiver_count!=2)return LEO_NATIVE_GLRT_INVALID;
    return analyze_profiled(context,ci16,complex_times,20,20,result,profile,1,NULL,NULL);
}

int leo_native_glrt_analyze_center_union_v1(leo_native_glrt *context,
    const int16_t *ci16,size_t complex_times,const int32_t hints[2],
    leo_native_glrt_result *result,leo_center_union_trace *trace)
{
    if(!hints || !trace)return LEO_NATIVE_GLRT_INVALID;
    return analyze_profiled(context,ci16,complex_times,20,20,result,NULL,1,hints,trace);
}

int leo_native_glrt_analyze_short_window(leo_native_glrt *context,
    const int16_t *ci16,size_t complex_times,leo_native_glrt_result *result)
{
    return leo_native_glrt_analyze_short_window_profiled(context,ci16,
        complex_times,result,NULL);
}

int leo_native_glrt_analyze(leo_native_glrt *context,const int16_t *ci16,
    size_t complex_times,uint32_t dwell_ms,uint32_t stride_ms,
    leo_native_glrt_result *result)
{
    return leo_native_glrt_analyze_profiled(context,ci16,complex_times,
        dwell_ms,stride_ms,result,NULL);
}

int leo_native_glrt_get_capabilities(leo_native_glrt_capabilities *out)
{
    if(!out)return LEO_NATIVE_GLRT_INVALID;
    *out=(leo_native_glrt_capabilities){
        .abi_version=LEO_NATIVE_GLRT_ABI_VERSION,
        .receiver_count=2,
        .probe_ms=20,
        .process_serialized=0,
        .candidate_cfo_refinement_state_available=1,
        .fractional_epoch_mode_available=1,
        .fractional_epoch_server_parity_qualified=0};
    return LEO_NATIVE_GLRT_OK;
}

int leo_single_rx_glrt_create(leo_single_rx_glrt **out,uint32_t rate,
    const leo_native_glrt_complex *exact,const leo_native_glrt_complex *control,
    size_t count)
{
    return leo_single_rx_glrt_create_with_mode(out,rate,exact,control,count,
        LEO_NATIVE_GLRT_MODE_ORDINARY);
}

int leo_single_rx_glrt_create_with_mode(leo_single_rx_glrt **out,uint32_t rate,
    const leo_native_glrt_complex *exact,const leo_native_glrt_complex *control,
    size_t count,uint32_t mode)
{
    if(!out)return LEO_NATIVE_GLRT_INVALID;
    *out=NULL;
    leo_single_rx_glrt *single=calloc(1,sizeof(*single));
    if(!single)return LEO_NATIVE_GLRT_NOMEM;
    int status=create_with_mode_and_receivers(&single->native,rate,exact,control,
        count,mode,1);
    if(status){free(single);return status;}
    single->magic=LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC;
    *out=single;return LEO_NATIVE_GLRT_OK;
}

int leo_single_rx_glrt_destroy(leo_single_rx_glrt *context)
{
    if(!context||context->magic!=LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC)
        return LEO_NATIVE_GLRT_INVALID;
    int status=leo_native_glrt_destroy(context->native);
    if(!status){context->magic=0;free(context);}
    return status;
}

int leo_single_rx_glrt_analyze_profiled(leo_single_rx_glrt *context,
    const int16_t *ci16,size_t complex_times,uint32_t dwell_ms,uint32_t stride_ms,
    leo_native_glrt_result *result,leo_native_glrt_profile *profile)
{
    if(!context||context->magic!=LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC||
       !context->native||context->native->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||
       context->native->receiver_count!=1)
        return LEO_NATIVE_GLRT_INVALID;
    return analyze_profiled(context->native,ci16,complex_times,dwell_ms,stride_ms,
        result,profile,0,NULL,NULL);
}

int leo_single_rx_glrt_analyze_short_window_profiled(leo_single_rx_glrt *context,
    const int16_t *ci16,size_t complex_times,leo_native_glrt_result *result,
    leo_native_glrt_profile *profile)
{
    if(!context||context->magic!=LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC||
       !context->native||context->native->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||
       context->native->receiver_count!=1)return LEO_NATIVE_GLRT_INVALID;
    return analyze_profiled(context->native,ci16,complex_times,20,20,result,profile,1,NULL,NULL);
}

int leo_single_rx_glrt_center_union_short_v1(leo_single_rx_glrt *context,
    const int16_t *ci16, size_t complex_times, int32_t hint,
    leo_native_glrt_result *result, leo_center_union_trace *trace)
{
    if(!context||context->magic!=LEO_SINGLE_RX_GLRT_CONTEXT_MAGIC||
       !context->native||context->native->magic!=LEO_NATIVE_GLRT_CONTEXT_MAGIC||
       context->native->receiver_count!=1||!trace)return LEO_NATIVE_GLRT_INVALID;
    const int32_t hints[2]={hint,-1};
    return analyze_profiled(context->native,ci16,complex_times,20,20,result,NULL,1,hints,trace);
}

int leo_single_rx_glrt_analyze_short_window(leo_single_rx_glrt *context,
    const int16_t *ci16,size_t complex_times,leo_native_glrt_result *result)
{
    return leo_single_rx_glrt_analyze_short_window_profiled(context,ci16,
        complex_times,result,NULL);
}

int leo_single_rx_glrt_analyze(leo_single_rx_glrt *context,const int16_t *ci16,
    size_t complex_times,uint32_t dwell_ms,uint32_t stride_ms,
    leo_native_glrt_result *result)
{
    return leo_single_rx_glrt_analyze_profiled(context,ci16,complex_times,
        dwell_ms,stride_ms,result,NULL);
}

int leo_single_rx_glrt_get_capabilities(leo_single_rx_glrt_capabilities *out)
{
    if(!out)return LEO_NATIVE_GLRT_INVALID;
    *out=(leo_single_rx_glrt_capabilities){
        .abi_version=LEO_SINGLE_RX_GLRT_ABI_VERSION,
        .receiver_count=1,.input_scalar_stride=2,.probe_ms=20,
        .process_serialized=0,
        .maximum_candidates_per_row=LEO_NATIVE_GLRT_MAX_CANDIDATES,
        .native_per_receiver_semantics=1,.peer_recovery_available=0,
        .fractional_epoch_mode_available=1,
        .fractional_epoch_server_parity_qualified=0};
    return LEO_NATIVE_GLRT_OK;
}

int leo_native_glrt_candidate_cfo_refinement_state(
    const leo_native_glrt_candidate *candidate)
{
    if(!candidate)return LEO_NATIVE_GLRT_INVALID;
    return candidate->refinement_skipped
        ? LEO_NATIVE_GLRT_CFO_REFINEMENT_SKIPPED
        : LEO_NATIVE_GLRT_CFO_REFINEMENT_COMPLETE;
}

const char *leo_native_glrt_status_string(int status)
{
    switch(status){
    case LEO_NATIVE_GLRT_OK:return "ok";
    case LEO_NATIVE_GLRT_INVALID:return "invalid argument";
    case LEO_NATIVE_GLRT_NOMEM:return "out of memory";
    case LEO_NATIVE_GLRT_BUSY:return "detector context or FFT planner busy";
    case LEO_NATIVE_GLRT_KERNEL:return "detector kernel failed";
    default:return "unknown error";
    }
}

#define _POSIX_C_SOURCE 200809L
#include "presence.h"
#include "fft.h"
#include "budget.h"
#include <complex.h>
#include <float.h>
#include <fenv.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TAU 6.283185307179586476925286766559
#define SYMBOL_S 4.4e-6
#define CFO_COUNT 24
#define ORDINARY_REGIONAL_BINS 11
#define WIDE_REGIONAL_BINS 21
#define REGIONAL_CFO_STEP 80000.0
#define WIDE_REGIONAL_CFO_LIMIT 800000.0
#define ORDINARY_REGIONAL_CFO_LIMIT 400000.0
#define REGIONAL_NARROW_OFFSET ((WIDE_REGIONAL_BINS-ORDINARY_REGIONAL_BINS)/2)
_Static_assert(CFO_COUNT>=WIDE_REGIONAL_BINS && CFO_COUNT%4==0,
    "Four-lane regional storage must cover all physical CFO bins");

/* Exact execution reuse. No search bins, frames, templates or thresholds
 * change. Keep the uncached path available for differential qualification. */
#ifndef LEO_PRESENCE_PRECOMPUTE
#define LEO_PRESENCE_PRECOMPUTE 1
#endif
#if LEO_PRESENCE_PRECOMPUTE != 0 && LEO_PRESENCE_PRECOMPUTE != 1
#error "LEO_PRESENCE_PRECOMPUTE must be 0 or 1"
#endif
#if LEO_PRESENCE_PRECOMPUTE
/* grid() may append a clipped off-grid endpoint. This includes that spare
 * slot even though it takes the nonregular (uncached) rotation path. */
#define CONDITIONED_TABLES (2*LEO_PRESENCE_CONDITIONED_RADIUS/100+2)
#else
#define CONDITIONED_TABLES 42
#endif
#ifndef LEO_PRESENCE_BOUNDED_MAGNITUDE
#define LEO_PRESENCE_BOUNDED_MAGNITUDE 0
#endif
#if LEO_PRESENCE_BOUNDED_MAGNITUDE != 0 && LEO_PRESENCE_BOUNDED_MAGNITUDE != 1
#error "LEO_PRESENCE_BOUNDED_MAGNITUDE must be 0 or 1"
#endif
#ifndef LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY
#define LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY 0
#endif
#if LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY != 0 && LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY != 1
#error "LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY must be 0 or 1"
#endif
#ifndef LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION
#define LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION 0
#endif
#if LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION != 0 && LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION != 1
#error "LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION must be 0 or 1"
#endif
#ifndef LEO_PRESENCE_GLRT_BLOCK_ROTATION
#define LEO_PRESENCE_GLRT_BLOCK_ROTATION 1
#endif
#if LEO_PRESENCE_GLRT_BLOCK_ROTATION != 0 && LEO_PRESENCE_GLRT_BLOCK_ROTATION != 1
#error "LEO_PRESENCE_GLRT_BLOCK_ROTATION must be 0 or 1"
#endif
#ifndef LEO_PRESENCE_ENERGY_SUPPORT
#define LEO_PRESENCE_ENERGY_SUPPORT 0
#endif
#if LEO_PRESENCE_ENERGY_SUPPORT != 0 && LEO_PRESENCE_ENERGY_SUPPORT != 1
#error "LEO_PRESENCE_ENERGY_SUPPORT must be 0 or 1"
#endif
#if LEO_PRESENCE_ENERGY_SUPPORT && (LEO_PRESENCE_FINE_FRAMES != 2 || LEO_PRESENCE_EPOCH_FRAMES != 2)
#error "energy support experiment requires two acquisition and epoch frames"
#endif
#ifndef LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT
#define LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT 0
#endif
#if LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT != 0 && LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT != 1
#error "LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT must be 0 or 1"
#endif
#if LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT && !LEO_PRESENCE_ENERGY_SUPPORT
#error "energy symbol support requires energy-selected acquisition frames"
#endif

/* The exact existing acquisition kernel, with platform-independent C types. */
typedef double complex npy_cdouble;
typedef ptrdiff_t npy_intp;
typedef int32_t npy_int32;
typedef struct {
    const npy_cdouble *samples, *references;
    const double *frequencies;
    const npy_intp *starts, *stops, *offsets;
    const double *prefix;
    double *scores, *accumulated;
    npy_int32 *support;
    double *correlation_real, *correlation_imag, *rotated_real, *rotated_imag;
    npy_intp sample_count, cfo_count, symbol_count, offset_count;
    double sample_rate_hz;
    int epoch_count, fast_magnitude, invalid_geometry;
} FoldedAnchorGridKernel;

#if !defined(LEO_PRESENCE_COARSE_FP32)
/* Four frequency lanes fit in scalar ARM FP registers. The generic kernel's
 * tap-major array updates otherwise repeatedly spill all twelve complex sums.
 * Arithmetic and per-frequency summation order remain unchanged. */
static void correlate_registers(const double complex *restrict samples,
    const double *restrict real, const double *restrict imag, ptrdiff_t count,
    double *restrict out_real, double *restrict out_imag)
{
    for (int f = 0; f < CFO_COUNT; f += 4) {
        double r0=0, i0=0, r1=0, i1=0, r2=0, i2=0, r3=0, i3=0;
        for (ptrdiff_t k = 0; k < count; ++k) {
            double xr=creal(samples[k]), xi=cimag(samples[k]);
            ptrdiff_t base=k*CFO_COUNT+f;
#define ACCUMULATE(lane) do { \
    double rr=real[base+lane], ri=imag[base+lane]; \
    r##lane += xr*rr+xi*ri; \
    i##lane += xi*rr-xr*ri; \
} while (0)
            ACCUMULATE(0); ACCUMULATE(1); ACCUMULATE(2); ACCUMULATE(3);
#undef ACCUMULATE
        }
        out_real[f]=r0; out_imag[f]=i0;
        out_real[f+1]=r1; out_imag[f+1]=i1;
        out_real[f+2]=r2; out_imag[f+2]=i2;
        out_real[f+3]=r3; out_imag[f+3]=i3;
    }
}

#define LEO_GRID_FUNCTION presence_grid_portable
#define LEO_GRID_TARGET
#define LEO_GRID_CORRELATE correlate_registers
#include "../starlink/_native_acquisition_grid.inc"
#undef LEO_GRID_FUNCTION
#undef LEO_GRID_TARGET
#undef LEO_GRID_CORRELATE
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__)) && !defined(LEO_PRESENCE_FORCE_PORTABLE)
#define LEO_GRID_FUNCTION presence_grid_avx2
#define LEO_GRID_TARGET __attribute__((target("avx2,fma,tune=haswell")))
#include "../starlink/_native_acquisition_grid.inc"
#undef LEO_GRID_FUNCTION
#undef LEO_GRID_TARGET
#endif
#endif

struct leo_presence_workspace {
    uint32_t rate;
    int acquisition_first_frame;
    int acquisition_regions[2];
#if defined(LEO_FULL_SEARCH_CONTEXT)
    int regional_count, wide_regional;
    int regional_epochs[13334];
#endif
    size_t n, max_samples;
    double complex *exact, *control, *samples, *input, *weighted, *base;
    double complex *conditioned_offsets;
#if LEO_PRESENCE_PRECOMPUTE
    double complex *glrt_rotations, *glrt_exact_rotated, *glrt_control_rotated;
    double rotation_cfo, rotation_offset;
    int have_rotations, symbol_starts[303];
#endif
    double *prefix, *grid, *accumulated, *rotated_real, *rotated_imag;
    int32_t *support;
    npy_intp starts[12], stops[12], offsets[16];
    double frequencies[CFO_COUNT], correlation_real[CFO_COUNT], correlation_imag[CFO_COUNT];
    leo_fft fine_fft, short_fft, glrt_fft;
#if defined(LEO_FULL_SEARCH_CONTEXT)
    leo_full_search_conditioned_cache conditioned_phase_cache;
#endif
    double fine_step_hz;
#if LEO_PRESENCE_POWER_PROPOSAL
    leo_fft power_fft;
    double complex *power_input, *power_template_fft;
    double *power_native_template, *power_native_folded;
    double power_template_energy, power_native_template_energy, power_native_folded_energy;
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    double complex *diff_template, *diff_folded;
    int32_t *diff_support;
    double diff_template_energy, diff_folded_energy;
#endif
#endif
    float *opt_conditioned_offsets,*opt_weighted;
#if LEO_NATIVE_GLRT_ENABLE_SERVER_REFERENCE
    double *interval_bounds;
    unsigned char *interval_possible,*interval_repair;
    int interval_screen_active;
#endif
    int *opt_peak_indices;
    float *opt_template,*opt_fold;
    leo_presence_profile profile;
    leo_presence_nuisance nuisance;
#if defined(LEO_PRESENCE_COARSE_FP32)
    float *float_samples, *float_accumulated;
    size_t coarse_prepared_count;
    int coarse_input_prepared;
    float float_reference_real[12*45*CFO_COUNT], float_reference_imag[12*45*CFO_COUNT];
    double float_reference_energy[12];
#endif
};

static int regional_cfo_bins(const leo_presence_workspace *w)
{
    return w->wide_regional ? WIDE_REGIONAL_BINS : ORDINARY_REGIONAL_BINS;
}

static double regional_cfo_limit(const leo_presence_workspace *w)
{
    return w->wide_regional ? WIDE_REGIONAL_CFO_LIMIT : ORDINARY_REGIONAL_CFO_LIMIT;
}

static void regional_cfo_band(leo_presence_workspace *w, int wide)
{
    w->wide_regional=wide;
    for (int f=0;f<regional_cfo_bins(w);++f)
        w->frequencies[f]=-regional_cfo_limit(w)+REGIONAL_CFO_STEP*f;
}

static double clock_ms(clockid_t id)
{
    struct timespec ts;
#if defined(LEO_DETECTOR_THREAD_CPU)
    if (id==CLOCK_PROCESS_CPUTIME_ID) id=CLOCK_THREAD_CPUTIME_ID;
#endif
    if (clock_gettime(id, &ts)) return 0.0;
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}
static double power(double complex x) { return creal(x)*creal(x) + cimag(x)*cimag(x); }
static double magnitude(double complex x)
{
#if LEO_PRESENCE_BOUNDED_MAGNITUDE
    /* Avoid general hypot scaling for ordinary finite detector values. Keep
     * libc's robust path for underflow, overflow and nonfinite inputs. This
     * changes floating-point rounding, not the statistic: qualify separately. */
    double squared=power(x);
    if (squared>=DBL_MIN && isfinite(squared)) return sqrt(squared);
#endif
    return cabs(x);
}
static double complex rotate(double angle) { return cos(angle) + I * sin(angle); }
static int frame_start(const leo_presence_workspace *w, int epoch, int frame)
{
#if LEO_PRESENCE_PRECOMPUTE
    return epoch+(int)w->offsets[frame];
#else
    return epoch+(int)nearbyint(frame*(w->rate/750.0));
#endif
}
static int symbol_start(const leo_presence_workspace *w, int symbol)
{
#if LEO_PRESENCE_PRECOMPUTE
    return w->symbol_starts[symbol];
#else
    return (int)nearbyint(symbol*w->rate*SYMBOL_S);
#endif
}
static int epoch_stride(const leo_presence_workspace *w)
{ return LEO_PRESENCE_STRIDE_2P5 ? LEO_PRESENCE_STRIDE_2P5*(int)(w->rate/2500000) : 1; }

#include "ci16_energy_v2.h"

static void select_acquisition_support(leo_presence_workspace *w, size_t count, int epoch, const int16_t *iq)
{
    w->acquisition_first_frame=0;
    w->acquisition_regions[0]=w->acquisition_regions[1]=0;
#if LEO_PRESENCE_ENERGY_SUPPORT
    /* Development-only: choose two adjacent complete frames by observed
     * energy after tone removal, never by truth or a GLRT score. Keep the
     * same two CFO FFTs and epoch-lattice frames; final scoring still uses
     * the entire original interval. No IQ rotation/copy or epoch rebasing.
     * Reserve two samples for the subsequent integer epoch lattice. */
    double previous=0, best=-1;
    for (int frame=0; frame<16; ++frame) {
        int start=frame_start(w,epoch,frame);
        if ((size_t)start+w->n+2>count) break;
        double energy=0;
        if(iq) energy=opt_ci16_energy(iq+2*start,w->n);
        else for (size_t k=0; k<w->n; ++k) energy+=power(w->samples[start+k]);
        if (frame && previous+energy>best) {
            best=previous+energy;
            w->acquisition_first_frame=frame-1;
        }
        previous=energy;
    }
#if LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT
    /* A complete frame may contain a burst only after its early 64 symbols.
     * Choose early/late support by received energy, once at the coarse epoch,
     * and freeze that choice across the five timing hypotheses. Each frame
     * still contributes exactly one contiguous, correctly indexed 64-symbol
     * region. This is not a maximum over extra GLRT evaluations. */
    for (int frame=0; frame<2; ++frame) {
        int start=frame_start(w,epoch,w->acquisition_first_frame+frame);
        double energy[2]={0};
        for (int region=0; region<2; ++region) {
            int begin=symbol_start(w,2+150*region), end=symbol_start(w,66+150*region);
            if ((size_t)start+end+2>count) continue;
            if(iq) energy[region]=opt_ci16_energy(iq+2*(start+begin),(size_t)(end-begin));
            else for (int k=begin; k<end; ++k) energy[region]+=power(w->samples[start+k]);
        }
        w->acquisition_regions[frame]=energy[1]>energy[0];
    }
#endif
#else
    (void)count; (void)epoch;
#endif
}

int leo_presence_get_profile(const leo_presence_workspace *w, leo_presence_profile *profile)
{
    if (!w || !profile) return -1;
    *profile=w->profile;
    profile->coarse_frames=LEO_PRESENCE_COARSE_FRAMES;
    profile->fine_frames=LEO_PRESENCE_FINE_FRAMES;
    profile->epoch_frames=LEO_PRESENCE_EPOCH_FRAMES;
    profile->anchor_stride=LEO_PRESENCE_ANCHOR_STRIDE;
    profile->epoch_stride=(uint32_t)epoch_stride(w);
    profile->conditioned_radius_hz=LEO_PRESENCE_CONDITIONED_RADIUS;
    return 0;
}

int leo_presence_get_nuisance(const leo_presence_workspace *w, leo_presence_nuisance *nuisance)
{
    if (!w || !nuisance) return -1;
    *nuisance=w->nuisance;
    return 0;
}

#if defined(LEO_PRESENCE_COARSE_FP32)
#include "coarse_fp32.h"
#endif
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
#include "coarse_differential.h"
#elif LEO_PRESENCE_POWER_PROPOSAL
#include "coarse_power.h"
#endif
#if LEO_PRESENCE_TONE_NUISANCE
#include "tone_nuisance.h"
#endif

void leo_presence_destroy(leo_presence_workspace *w)
{
    if (!w) return;
    free(w->exact); free(w->control); free(w->samples); free(w->input);
    free(w->opt_conditioned_offsets);free(w->opt_weighted);
#if LEO_NATIVE_GLRT_ENABLE_SERVER_REFERENCE
    free(w->interval_bounds);free(w->interval_possible);free(w->interval_repair);
#endif
    free(w->opt_peak_indices);
    free(w->opt_template);free(w->opt_fold);
    free(w->weighted); free(w->base); free(w->conditioned_offsets);
#if LEO_PRESENCE_PRECOMPUTE
    free(w->glrt_rotations); free(w->glrt_exact_rotated); free(w->glrt_control_rotated);
#endif
    free(w->prefix); free(w->grid); free(w->accumulated); free(w->support);
    free(w->rotated_real); free(w->rotated_imag);
#if defined(LEO_PRESENCE_COARSE_FP32)
    free(w->float_samples); free(w->float_accumulated);
#endif
    leo_fft_free(&w->fine_fft); leo_fft_free(&w->short_fft); leo_fft_free(&w->glrt_fft);
#if LEO_PRESENCE_POWER_PROPOSAL
    leo_fft_free(&w->power_fft); free(w->power_input); free(w->power_template_fft);
    free(w->power_native_template); free(w->power_native_folded);
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    free(w->diff_template); free(w->diff_folded); free(w->diff_support);
#endif
#endif
    free(w);
}

leo_presence_workspace *leo_presence_create(uint32_t rate,
    const leo_presence_complex *exact, const leo_presence_complex *control, size_t n)
{
    if (fegetround() != FE_TONEAREST || (rate != 2500000 && rate != 5000000 && rate != 7500000 && rate != 10000000) || !exact || !control ||
        n != (size_t)nearbyint(rate / 750.0)) return NULL;
    leo_presence_workspace *w = calloc(1, sizeof(*w));
    if (!w) return NULL;
    w->rate = rate; w->n = n; w->max_samples = rate / 50;
    size_t input_capacity=rate/500;
    if (LEO_PRESENCE_FAST_FINE_FFT) { input_capacity=2; while(input_capacity<n) input_capacity*=2; }
#define ALLOC(field, count) do { \
    w->field = calloc((count), sizeof(*w->field)); \
    if (!w->field) { leo_presence_destroy(w); return NULL; } \
} while (0)
    ALLOC(opt_conditioned_offsets,2*CONDITIONED_TABLES*n);ALLOC(opt_weighted,2*n);
#if LEO_NATIVE_GLRT_ENABLE_SERVER_REFERENCE
    ALLOC(interval_bounds,12*n);ALLOC(interval_possible,12*n);ALLOC(interval_repair,12*n);
#endif
    ALLOC(opt_template,3*n);ALLOC(opt_fold,3*n);
    ALLOC(exact, n); ALLOC(control, n); ALLOC(samples, w->max_samples);
    ALLOC(input, input_capacity); ALLOC(weighted, n); ALLOC(base, n);
    ALLOC(conditioned_offsets, CONDITIONED_TABLES * n); ALLOC(prefix, w->max_samples + 1);
#if LEO_PRESENCE_PRECOMPUTE
    ALLOC(glrt_rotations, n); ALLOC(glrt_exact_rotated, n); ALLOC(glrt_control_rotated, n);
#endif
    ALLOC(opt_peak_indices,n);
    ALLOC(grid, CFO_COUNT * n); ALLOC(accumulated, CFO_COUNT * n); ALLOC(support, n);
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    for(size_t k=0;k<CFO_COUNT*n;++k) w->grid[k]=-INFINITY;
#endif
    ALLOC(rotated_real, CFO_COUNT * 45); ALLOC(rotated_imag, CFO_COUNT * 45);
#if defined(LEO_PRESENCE_COARSE_FP32)
    ALLOC(float_samples, 2*w->max_samples); ALLOC(float_accumulated, CFO_COUNT*n);
#endif
#if LEO_PRESENCE_POWER_PROPOSAL
    size_t power_size=2;
    while (power_size<2*n-1) power_size*=2;
    if (LEO_PRESENCE_POWER_BINS) power_size=LEO_PRESENCE_POWER_BINS;
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    power_size=2;
    while (power_size<n) power_size*=2;
    ALLOC(diff_template,n); ALLOC(diff_folded,n); ALLOC(diff_support,n);
#endif
    ALLOC(power_input,power_size); ALLOC(power_template_fft,power_size);
    ALLOC(power_native_template,n); ALLOC(power_native_folded,n);
    if (leo_fft_init(&w->power_fft,power_size)) { leo_presence_destroy(w); return NULL; }
#endif
#undef ALLOC
    size_t fine_size=rate/500;
    if (LEO_PRESENCE_FAST_FINE_FFT) {
        fine_size=2;
        while (fine_size<n) fine_size*=2;
    }
    w->fine_step_hz=(double)rate/fine_size;
    if (ceil(800000.0/w->fine_step_hz)+2 > 2048) { leo_presence_destroy(w); return NULL; }
    if (leo_fft_init(&w->fine_fft, fine_size) ||
        leo_fft_init(&w->short_fft, 128) || leo_fft_init(&w->glrt_fft, 512)) {
        leo_presence_destroy(w); return NULL;
    }
    for (size_t k = 0; k < n; ++k) {
        if (!isfinite(exact[k].re) || !isfinite(exact[k].im) ||
            !isfinite(control[k].re) || !isfinite(control[k].im) ||
            fabs(exact[k].re)>16 || fabs(exact[k].im)>16 ||
            fabs(control[k].re)>16 || fabs(control[k].im)>16) {
            leo_presence_destroy(w); return NULL;
        }
        w->exact[k] = exact[k].re + I * exact[k].im;
        w->control[k] = control[k].re + I * control[k].im;
        for (size_t f = 0; f < CONDITIONED_TABLES; ++f)
        {
            w->conditioned_offsets[f*n+k] = rotate(-TAU * (f * 100.0) * k / rate);
            w->opt_conditioned_offsets[2*(f*n+k)]=(float)creal(w->conditioned_offsets[f*n+k]);
            w->opt_conditioned_offsets[2*(f*n+k)+1]=(float)cimag(w->conditioned_offsets[f*n+k]);
        }
    }
    for (int k = 0; k < 12; ++k) {
        w->starts[k] = (npy_intp)nearbyint((2 + k * 26) * rate * SYMBOL_S);
        w->stops[k] = (npy_intp)nearbyint((3 + k * 26) * rate * SYMBOL_S);
        if (w->stops[k]-w->starts[k] > 45) { leo_presence_destroy(w); return NULL; }
    }
    regional_cfo_band(w,0);
    for (int k = 0; k < 16; ++k)
        w->offsets[k]=(npy_intp)nearbyint(k*(rate/750.0));
#if LEO_PRESENCE_PRECOMPUTE
    for (int k=0; k<303; ++k)
        w->symbol_starts[k]=(int)nearbyint(k*rate*SYMBOL_S);
#endif
#if defined(LEO_PRESENCE_COARSE_FP32)
    coarse_fp32_templates(w);
#endif
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    coarse_differential_template(w);
#elif LEO_PRESENCE_POWER_PROPOSAL
    coarse_power_template(w);
#endif
    return w;
}

static int ingest(leo_presence_workspace *w, const leo_presence_complex *x, size_t count)
{
    if (!w || !x || fegetround()!=FE_TONEAREST ||
        count < (size_t)ceil(w->rate / 375.0) || count > w->max_samples)
        return -1;
    w->coarse_input_prepared=0;w->coarse_prepared_count=0;
    for (size_t k = 0; k < count; ++k) {
        if (!isfinite(x[k].re) || !isfinite(x[k].im) ||
            fabs(x[k].re) > 1e12 || fabs(x[k].im) > 1e12) return -1;
        w->samples[k] = x[k].re + I*x[k].im;
    }
    return 0;
}

static int coarse(leo_presence_workspace *w, size_t count, const int16_t *iq)
{
    (void)iq;
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
    return coarse_differential(w,count,iq);
#elif LEO_PRESENCE_POWER_PROPOSAL
    return coarse_power(w,count);
#endif
#if defined(LEO_PRESENCE_COARSE_FP32)
    return coarse_fp32(w, count);
#else
    w->prefix[0] = 0.0;
    for (size_t k = 0; k < count; ++k) w->prefix[k+1] = w->prefix[k] + power(w->samples[k]);
    memset(w->accumulated, 0, CFO_COUNT * w->n * sizeof(double));
    memset(w->support, 0, w->n * sizeof(int32_t));
    int frames = 0;
    while (frames < 16 && w->offsets[frames] < (ptrdiff_t)count) ++frames;
    FoldedAnchorGridKernel kernel = {
        .samples=w->samples, .references=w->exact, .frequencies=w->frequencies,
        .starts=w->starts, .stops=w->stops, .offsets=w->offsets, .prefix=w->prefix,
        .scores=w->grid, .accumulated=w->accumulated, .support=w->support,
        .correlation_real=w->correlation_real, .correlation_imag=w->correlation_imag,
        .rotated_real=w->rotated_real, .rotated_imag=w->rotated_imag,
        .sample_count=(ptrdiff_t)count, .cfo_count=CFO_COUNT, .symbol_count=12,
        .offset_count=frames, .sample_rate_hz=w->rate, .epoch_count=(int)w->n,
        .fast_magnitude=1
    };
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__)) && !defined(LEO_PRESENCE_FORCE_PORTABLE)
    __builtin_cpu_init();
    if (__builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma"))
        presence_grid_avx2(&kernel);
    else
#endif
        presence_grid_portable(&kernel);
    return kernel.invalid_geometry ? -1 : 0;
#endif
}

int leo_presence_coarse(leo_presence_workspace *w, const leo_presence_complex *x,
    size_t count, double *scores)
{
    if (!scores || ingest(w, x, count)) return -1;
    if (coarse(w, count, NULL)) return -1;
    memcpy(scores, w->grid, 11 * w->n * sizeof(double));
    return 0;
}

int leo_presence_coarse_ci16(leo_presence_workspace *w, const int16_t *iq,
    size_t count, double *scores)
{
    if (!w || !iq || !scores || count<(size_t)ceil(w->rate/375.0) ||
        count>w->max_samples || fegetround()!=FE_TONEAREST) return -1;
    for (size_t k=0; k<count; ++k) w->samples[k]=iq[2*k]+I*(double)iq[2*k+1];
    if (coarse(w,count,iq)) return -1;
    memcpy(scores,w->grid,11*w->n*sizeof(double));
    return 0;
}

static int grid(double start, double stop, double step, double *out)
{
    int n = (int)floor((stop-start)/step + 1e-12) + 1;
    for (int k = 0; k < n; ++k) out[k] = start + k*step;
    if (fabs(out[n-1]-stop) > 1e-9) out[n++] = stop;
    return n;
}
static int best_frequency(const double *scores, const double *frequencies, int n)
{
    int best = 0;
    for (int k = 1; k < n; ++k)
        if (scores[k] > scores[best] || (scores[k] == scores[best] &&
            (fabs(frequencies[k]) < fabs(frequencies[best]) ||
             (fabs(frequencies[k]) == fabs(frequencies[best]) && frequencies[k] < frequencies[best]))))
            best = k;
    return best;
}

/* Normalized coherent fine acquisition. Alternating symbols remain the
 * baseline; all-symbol acquisition is a separately configured experiment. */
void leo_fft_forward_range(leo_fft *,const double complex *,size_t,size_t,size_t);

static void fine_scores(leo_presence_workspace *w, size_t count, int epoch,
    double first_frequency, int frequency_count, double *scores)
{
    size_t last = (size_t)symbol_start(w,301) - 1;
    double template_energy = 0;
    memset(w->base, 0, w->n * sizeof(*w->base));
    memset(scores, 0, frequency_count * sizeof(*scores));
    const int step=LEO_PRESENCE_FINE_ALL_SYMBOLS ? 1 : 2;
    /* first_frequency is an aligned FFT bin. Select circular output indices
     * instead of rotating every input sample by that integer-bin frequency. */
    int first_bin=(int)nearbyint(first_frequency/w->fine_step_hz);
    first_bin=(first_bin+(int)w->fine_fft.size)%(int)w->fine_fft.size;
    for (int symbol = 2; symbol < 302; symbol += step) {
        int begin = symbol_start(w,symbol);
        int end = symbol_start(w,symbol+1);
        for (int k = begin; k < end; ++k) {
            template_energy += power(w->exact[k]);
            w->base[k] = conj(w->exact[k]);
        }
    }
    int frames = 0;
    for (int frame = 0; frame < LEO_PRESENCE_FINE_FRAMES; ++frame) {
        int start = frame_start(w, epoch, frame+w->acquisition_first_frame);
        if ((size_t)start + last >= count) break;
        memset(w->input, 0, w->n * sizeof(*w->input));
        double energy = 0;
        for (int symbol = 2; symbol < 302; symbol += step) {
            int begin = symbol_start(w,symbol);
            int end = symbol_start(w,symbol+1);
            for (int k = begin; k < end; ++k) {
                energy += power(w->samples[start+k]);
                w->input[k] = w->samples[start+k] * w->base[k];
            }
        }
        leo_fft_forward_range(&w->fine_fft,w->input,w->n,(size_t)first_bin,(size_t)frequency_count);
        double denom = sqrt(template_energy * energy);
        if (denom > 0) {
            int bin=first_bin;
            for (int f = 0; f < frequency_count; ++f) {
                scores[f] += magnitude(w->fine_fft.output[bin])/denom;
                if (++bin==(int)w->fine_fft.size) bin=0;
            }
        }
        ++frames;
    }
    if (frames) for (int f = 0; f < frequency_count; ++f) scores[f] /= frames;
}

#include "conditioned_dot.h"

static void conditioned_scores(leo_presence_workspace *w, size_t count, int epoch,
    const double *frequencies, int nf, double *scores)
{
    double te = 0;
    memset(scores, 0, nf * sizeof(*scores));
#if LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION
    /* Factor the same local-time phasor into 32-sample blocks. No frequency
     * bins, frames, samples or summation terms are removed. Directly computed
     * block anchors prevent long oscillator-recursion drift. Multiplication
     * changes FP64 rounding, so retain the original path for qualification. */
    double complex basis[32], anchor=1;
    for (size_t j=0; j<32; ++j)
        basis[j]=rotate(-TAU*frequencies[0]*j/w->rate);
#endif
    for (size_t k = 0; k < w->n; ++k) {
        te += power(w->exact[k]);
#if LEO_PRESENCE_CONDITIONED_BLOCK_ROTATION
        if (!(k&31)) anchor=rotate(-TAU*frequencies[0]*k/w->rate);
        w->base[k] = conj(w->exact[k]) * (anchor*basis[k&31]);
#else
        w->base[k] = conj(w->exact[k]) * rotate(-TAU*frequencies[0]*k/w->rate);
#endif
    }
    int frames = 0;
    for (int frame = 0; frame < LEO_PRESENCE_FINE_FRAMES; ++frame) {
        int start = frame_start(w, epoch, frame+w->acquisition_first_frame);
        if ((size_t)start + w->n > count) break;
        double energy = 0;
        for (size_t k = 0; k < w->n; ++k) {
            energy += power(w->samples[start+k]);
            w->weighted[k] = w->samples[start+k] * w->base[k];
            w->opt_weighted[2*k]=(float)creal(w->weighted[k]);
            w->opt_weighted[2*k+1]=(float)cimag(w->weighted[k]);
        }
        double denom = sqrt(te*energy);
        for (int f = 0; f < nf && denom > 0; ++f) {
            double complex total = 0;
            int regular = frequencies[f] == frequencies[0] + f*100.0;
            if (regular) total=opt_conditioned_dot(w->opt_weighted,w->opt_conditioned_offsets+2*f*w->n,w->n);
            else for (size_t k = 0; k < w->n; ++k)
                total += w->weighted[k] * rotate(-TAU*(frequencies[f]-frequencies[0])*k/w->rate);
            scores[f] += magnitude(total)/denom;
        }
        ++frames;
    }
    if (frames) for (int f = 0; f < nf; ++f) scores[f] /= frames;
}

static double normalized_score(leo_presence_workspace *w, size_t count, int epoch,
    double cfo, const double complex *reference, int first_symbol)
{
    double te = 0, score = 0;
    size_t last = (size_t)symbol_start(w,first_symbol == 2 ? 301 : 302)-1;
    for (int symbol = first_symbol; symbol < 302; symbol += 2) {
        int begin = symbol_start(w,symbol);
        int end = symbol_start(w,symbol+1);
        for (int k = begin; k < end; ++k) {
            te += power(reference[k]);
            w->base[k] = conj(reference[k]) * rotate(-TAU*cfo*k/w->rate);
        }
    }
    int frames = 0;
    for (int frame = 0; frame < LEO_PRESENCE_FINE_FRAMES; ++frame) {
        int start = frame_start(w, epoch, frame+w->acquisition_first_frame);
        if ((size_t)start + last >= count) break;
        double energy = 0; double complex total = 0;
        for (int symbol = first_symbol; symbol < 302; symbol += 2) {
            int begin = symbol_start(w,symbol);
            int end = symbol_start(w,symbol+1);
            for (int k = begin; k < end; ++k) {
                total += w->samples[start+k]*w->base[k];
                energy += power(w->samples[start+k]);
            }
        }
        double denom = sqrt(te*energy);
        if (denom > 0) score += magnitude(total)/denom;
        ++frames;
    }
    return frames ? score/frames : 0;
}

static double sinc(double x) { return x == 0 ? 1 : sin(TAU*0.5*x)/(TAU*0.5*x); }
#include "fractional_runtime.h"

static int glrt(leo_presence_workspace *w, size_t count, int epoch,
    double cfo, double offset, int frame_limit, int final_scoring, double result[3])
{
    if (epoch < 0 || epoch >= (int)w->n || !isfinite(cfo) ||
        fabs(cfo)>regional_cfo_limit(w) ||
        !isfinite(offset) || fabs(offset)>2)
        return -1;
    double spectra[2][128] = {{0}}, ceilings[2] = {0};
    double nearest_offset=nearbyint(offset);
    int integer = fabs(offset-nearest_offset) <= 1e-12;
    int integer_offset=(int)nearest_offset;
    int first = symbol_start(w,2);
    int stop = symbol_start(w,66);
    /* Development-only specificity experiment: retain 64 contiguous symbols
     * per frame, alternating early/late known regions during final scoring.
     * The two-frame epoch lattice is unchanged. No extra FFT or confirmation. */
    const int diverse=LEO_PRESENCE_GLRT_SYMBOL_DIVERSITY && final_scoring;
    const int late=diverse || (LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT && !final_scoring &&
        (w->acquisition_regions[0] || w->acquisition_regions[1]));
    /* Rotation depends on local sample position, never on the frame number.
     * Block anchors remove the per-sample sin/cos prelude. Each anchor is
     * calculated directly, so this does not accumulate oscillator drift.
     * The resulting FP64 products are tolerance-qualified, not bit-exact. */
#if LEO_PRESENCE_PRECOMPUTE
    double complex *rotations=w->glrt_rotations;
    if (!w->have_rotations || w->rotation_cfo!=cfo || w->rotation_offset!=offset) {
        w->rotation_cfo=cfo; w->rotation_offset=offset; w->have_rotations=0;
    }
 #if LEO_PRESENCE_GLRT_BLOCK_ROTATION
    double complex basis[32];
    int have_basis=0;
 #endif
    for (int region=0; region<=late; ++region) if (!(w->have_rotations&(1<<region))) {
        int begin=symbol_start(w,2+150*region), end=symbol_start(w,66+150*region);
 #if LEO_PRESENCE_GLRT_BLOCK_ROTATION
        if (!have_basis) {
            for (int j=0; j<32; ++j) basis[j]=rotate(-TAU*cfo*j/w->rate);
            have_basis=1;
        }
        for (int block=begin&~31; block<end; block+=32) {
            double complex anchor=rotate(-TAU*cfo*(block+offset)/w->rate);
            int block_end=block+32 < end ? block+32 : end;
            int k=block > begin ? block : begin;
            for (; k<block_end; ++k) {
                rotations[k]=anchor*basis[k-block];
 #else
        for (int k=begin; k<end; ++k) {
            rotations[k]=rotate(-TAU*cfo*(k+offset)/w->rate);
 #endif
            /* These products are reused by every supporting frame. This
             * experimental association changes FP64 rounding and requires
             * scientific qualification before any promotion. */
            w->glrt_exact_rotated[k]=conj(w->exact[k])*rotations[k];
            w->glrt_control_rotated[k]=conj(w->control[k])*rotations[k];
        }
 #if LEO_PRESENCE_GLRT_BLOCK_ROTATION
        }
 #endif
        w->have_rotations|=1<<region;
    }
#else
    double complex *rotations=w->weighted;
 #if LEO_PRESENCE_GLRT_BLOCK_ROTATION
    double complex basis[32];
    for (int j=0; j<32; ++j) basis[j]=rotate(-TAU*cfo*j/w->rate);
 #endif
    for (int region=0; region<=late; ++region)
 #if LEO_PRESENCE_GLRT_BLOCK_ROTATION
        for (int block=symbol_start(w,2+150*region)&~31;
             block<symbol_start(w,66+150*region); block+=32) {
            double complex anchor=rotate(-TAU*cfo*(block+offset)/w->rate);
            int end=symbol_start(w,66+150*region), block_end=block+32 < end ? block+32 : end;
            int k=block > symbol_start(w,2+150*region) ? block : symbol_start(w,2+150*region);
            for (; k<block_end; ++k)
                rotations[k]=anchor*basis[k-block];
        }
 #else
        for (int k=symbol_start(w,2+150*region); k<symbol_start(w,66+150*region); ++k)
            rotations[k]=rotate(-TAU*cfo*(k+offset)/w->rate);
 #endif
#endif
    leo_fractional_runtime filter = {.fraction = NAN};
    for (int frame = 0; frame < frame_limit; ++frame) {
        int start = frame_start(w, epoch, frame+(final_scoring ? 0 : w->acquisition_first_frame));
        int first_symbol=diverse && (frame&1) ? 152 : 2;
#if LEO_PRESENCE_ENERGY_SYMBOL_SUPPORT
        if (!final_scoring) first_symbol=2+150*w->acquisition_regions[frame];
#endif
        first=symbol_start(w,first_symbol);
        stop=symbol_start(w,first_symbol+64);
        /* Do not discard a supporting terminal frame that still fits the
         * original early region, including its fractional interpolation tail. */
        if (first_symbol!=2 && start+stop-1+(integer ? integer_offset : offset) >=
            (int)count-(integer ? 0 : 8)) {
            first_symbol=2; first=symbol_start(w,2); stop=symbol_start(w,66);
        }
        if (start+stop-1+(integer ? integer_offset : offset) >=
            (double)count-(integer ? 0 : 8)) break;
        /* Workspace.select stops at the first unsupported row. */
        if (start+first+(integer ? integer_offset : offset) < (integer ? 0 : 7)) break;
        double complex correlations[2][64] = {{0}};
        for (int symbol = first_symbol; symbol < first_symbol+64; ++symbol) {
            int begin = symbol_start(w,symbol);
            int end = symbol_start(w,symbol+1);
            int base = 0, one_binade = 0;
            if (!integer) {
                base = leo_fractional_runtime_base(&filter,start+begin,offset);
                one_binade = leo_fractional_one_binade(start+begin,start+end);
            }
            for (int k = begin; k < end; ++k) {
                double complex received;
                if (integer) received = w->samples[start+k+integer_offset];
                else {
                    if (!one_binade && k != begin)
                        base = leo_fractional_runtime_base(&filter,start+k,offset);
                    received = leo_fractional_runtime_dot(&filter,w->samples+base-7);
                    ++base;
                }
                /* Omit only the common unit-magnitude frame phase. */
#if LEO_PRESENCE_PRECOMPUTE
                correlations[0][symbol-first_symbol] += received*w->glrt_exact_rotated[k];
                correlations[1][symbol-first_symbol] += received*w->glrt_control_rotated[k];
#else
                double complex corrected = received*rotations[k];
                correlations[0][symbol-first_symbol] += conj(w->exact[k])*corrected;
                correlations[1][symbol-first_symbol] += conj(w->control[k])*corrected;
#endif
            }
        }
        for (int which = 0; which < 2; ++which) {
            memset(w->input, 0, 128*sizeof(*w->input));
            double ceiling = 0;
            for (int k = 0; k < 64; ++k) {
                w->input[k] = correlations[which][k];
                /* Experimental bounded modulus: robust fallback remains
                 * for zero/subnormal/overflow/nonfinite squared magnitude.
                 * Flat-surface timing/CFO require separate full qualification. */
                ceiling += magnitude(w->input[k]);
            }
            ceilings[which] += ceiling*ceiling;
            leo_fft_forward(&w->short_fft, w->input);
            for (int k = 0; k < 128; ++k) spectra[which][k] += power(w->short_fft.output[k]);
        }
    }
    result[2] = 0;
    for (int which = 0; which < 2; ++which) {
        for (int k = 0; k < 128; ++k) w->input[k] = spectra[which][k];
        leo_fft_forward(&w->short_fft, w->input);
        memset(w->input, 0, 512*sizeof(*w->input));
        for (int k = 0; k < 64; ++k) w->input[k] = conj(w->short_fft.output[k])/128;
        for (int k = 1; k < 64; ++k) w->input[512-k] = conj(w->short_fft.output[128-k])/128;
        leo_fft_forward(&w->glrt_fft, w->input);
        int best = 0;
        for (int k = 1; k < 512; ++k)
            if (creal(w->glrt_fft.output[k]) > creal(w->glrt_fft.output[best])) best = k;
        result[which] = ceilings[which]>0 ? creal(w->glrt_fft.output[best])/ceilings[which] : 0;
        if (which == 0 && ceilings[which]>0)
            result[2] = (best < 256 ? best : best-512)/(512*SYMBOL_S);
    }
    return 0;
}

int leo_presence_glrt(leo_presence_workspace *w, const leo_presence_complex *x,
    size_t count, int32_t epoch, double cfo, double offset, double result[3])
{
    if (!result || ingest(w, x, count)) return -1;
    return glrt(w, count, epoch, cfo, offset, 16, 1, result);
}

static int candidate_before(const leo_presence_candidate *a, const leo_presence_candidate *b)
{
    double av[] = {a->verify_score-a->verify_control_score, a->verify_score,
        a->conditioned_score, a->acquire_score, -fabs(a->acquired_cfo_hz), -a->epoch};
    double bv[] = {b->verify_score-b->verify_control_score, b->verify_score,
        b->conditioned_score, b->acquire_score, -fabs(b->acquired_cfo_hz), -b->epoch};
    for (int k = 0; k < 6; ++k) if (av[k] != bv[k]) return av[k] > bv[k];
    return 0;
}

static int execute(leo_presence_workspace *w, size_t count, leo_presence_result *out,
    const int16_t *original_ci16, int32_t proposal_epoch)
{
    (void)original_ci16;
    memset(&w->profile, 0, sizeof(w->profile));
    memset(&w->nuisance, 0, sizeof(w->nuisance));
#if LEO_PRESENCE_TONE_NUISANCE
    double nuisance_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
    w->nuisance.enabled=1;
    if (tone_nuisance(w,count,original_ci16)) return -1;
    w->nuisance.cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-nuisance_started;
#endif
    double started = clock_ms(CLOCK_PROCESS_CPUTIME_ID);
    if (proposal_epoch<0 && coarse(w, count, w->nuisance.applied ? NULL : original_ci16)) return -1;
    out->coarse_cpu_ms = clock_ms(CLOCK_PROCESS_CPUTIME_ID)-started;
    int retained_epoch[2], retained_bin[2], candidate_support[2]={0}, nr = 0;
    int candidate_regions[2][2]={{0}};
    if (proposal_epoch>=0) {
        retained_epoch[0]=proposal_epoch; retained_bin[0]=5; nr=1;
    }
    /* Two passes avoid sorting an entire allocation of coarse peaks. */
    for (int selection = 0; proposal_epoch<0 && selection < LEO_PRESENCE_CANDIDATES; ++selection) {
        int best_e = -1, best_f = -1; double best_score = -1;
        /* Differential proposals populate only row five. Other rows stay
         * -INFINITY for this workspace's entire lifetime. */
        for (int f = LEO_PRESENCE_DIFFERENTIAL_PROPOSAL ? 5 : 0;
             f < (LEO_PRESENCE_DIFFERENTIAL_PROPOSAL ? 6 : 11); ++f)
        for (int e = 0; e < (int)w->n; ++e) {
            double value = w->grid[f*w->n+e];
            double left = e ? w->grid[f*w->n+e-1] : -INFINITY;
            double right = e+1 < (int)w->n ? w->grid[f*w->n+e+1] : -INFINITY;
            if (!(value>=left && value>=right && (value>left || value>right))) continue;
            if (selection) {
                int distance = abs(e-retained_epoch[0]);
                if (distance > (int)w->n-distance) distance = (int)w->n-distance;
                if (distance < 5 && fabs(w->frequencies[f]-w->frequencies[retained_bin[0]])<=10000)
                    continue;
            }
            if (value>best_score || (value==best_score &&
                (best_f<0 || fabs(w->frequencies[f])<fabs(w->frequencies[best_f]) ||
                 (fabs(w->frequencies[f])==fabs(w->frequencies[best_f]) && e<best_e)))) {
                best_e=e; best_f=f; best_score=value;
            }
        }
        if (best_e<0 || (selection==0 && best_score<=0)) break;
        retained_epoch[nr]=best_e; retained_bin[nr]=best_f; ++nr;
    }
    started = clock_ms(CLOCK_PROCESS_CPUTIME_ID);
    for (int r = 0; r < nr; ++r) {
        leo_presence_candidate *c = &out->candidates[out->candidate_count];
        int e=retained_epoch[r], f=retained_bin[r], refined=e;
        int radius=epoch_stride(w)>1 ? epoch_stride(w)-1 : 1;
#if LEO_PRESENCE_POWER_BINS
        radius=((int)w->n+LEO_PRESENCE_POWER_BINS-1)/LEO_PRESENCE_POWER_BINS;
#endif
        if (proposal_epoch>=0) radius=0;
        double stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        if (proposal_epoch<0) {
#if LEO_PRESENCE_POWER_BINS
        /* Refine proposals against original-rate folded power, including the
         * circular seam. Do not compare projected and native scores locally. */
        for (int delta=-radius; delta<=radius; ++delta)
            coarse_power_cell(w,(e+delta+(int)w->n)%(int)w->n);
#endif
#if LEO_PRESENCE_DIFFERENTIAL_PROPOSAL && !LEO_PRESENCE_DIFFERENTIAL_LOCAL_RADIUS
        /* Optional staged refinement: rank eight centers first, then refine
         * only retained neighborhoods before blind CFO acquisition. */
        double power_norm=sqrt(w->power_native_template_energy*w->power_native_folded_energy);
        double diff_norm=sqrt(w->diff_template_energy*w->diff_folded_energy);
        for (int delta=-1; delta<=1; ++delta) {
            if (!delta) continue; /* Retained center already has the identical native score. */
            int local=(e+delta+(int)w->n)%(int)w->n;
            w->grid[5*w->n+local]=diff_native_cell(w,(size_t)local,power_norm,diff_norm);
        }
#endif
#if defined(LEO_PRESENCE_COARSE_FP32)
        if (epoch_stride(w)>1)
            for (int k=e-radius; k<=e+radius; ++k)
                if (k>=0 && k<(int)w->n && w->support[k]==0 && coarse_fp32_cell(w,count,k))
                    return -1;
#endif
        w->profile.local_coarse_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        for (int local=e-radius; local<=e+radius; ++local) {
            int k=local;
#if LEO_PRESENCE_POWER_BINS || LEO_PRESENCE_DIFFERENTIAL_PROPOSAL
            k=(local+(int)w->n)%(int)w->n;
#endif
            if (k>=0 && k<(int)w->n && (w->grid[f*w->n+k]>w->grid[f*w->n+refined] ||
                (w->grid[f*w->n+k]==w->grid[f*w->n+refined] && k<refined))) refined=k;
        }
        }
        c->epoch=refined; c->coarse_score=proposal_epoch<0 ? w->grid[f*w->n+e] : 0;
#if LEO_PRESENCE_ENERGY_SUPPORT
        stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
#endif
        select_acquisition_support(w,count,refined,w->nuisance.applied ? NULL : original_ci16);
#if LEO_PRESENCE_ENERGY_SUPPORT
        w->profile.local_coarse_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
#endif
        double frequencies[2048], scores[2048], coarse_cfo=w->frequencies[f];
        double lower=fmax(-400000,coarse_cfo-80000), upper=fmin(400000,coarse_cfo+80000);
        if (LEO_PRESENCE_POWER_PROPOSAL || proposal_epoch>=0) { lower=-400000; upper=400000; }
        if (LEO_PRESENCE_FAST_FINE_FFT) {
            lower=ceil(lower/w->fine_step_hz)*w->fine_step_hz;
            upper=floor(upper/w->fine_step_hz)*w->fine_step_hz;
        }
        int nf=grid(lower,upper,w->fine_step_hz,frequencies);
        stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        fine_scores(w,count,refined,frequencies[0],nf,scores);
        w->profile.acquisition_fft_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        int best=best_frequency(scores,frequencies,nf);
        double interpolated=frequencies[best];
        if (best>0 && best+1<nf) {
            double curve=scores[best-1]-2*scores[best]+scores[best+1];
            if (isfinite(curve) && curve < -1e-15)
                interpolated += fmax(-w->fine_step_hz,fmin(w->fine_step_hz,
                    0.5*(scores[best-1]-scores[best+1])/curve*w->fine_step_hz));
        }
        nf=grid(fmax(-400000,interpolated-LEO_PRESENCE_CONDITIONED_RADIUS),
            fmin(400000,interpolated+LEO_PRESENCE_CONDITIONED_RADIUS),100,frequencies);
        stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        conditioned_scores(w,count,refined,frequencies,nf,scores);
        w->profile.conditioned_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        best=best_frequency(scores,frequencies,nf);
        c->acquired_cfo_hz=frequencies[best]; c->conditioned_score=scores[best];
        stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        /* Power proposals keep their proposal order. Final exact/control GLRT
         * is still required; the legacy acquisition-ranking scores are unused. */
        if (!LEO_PRESENCE_POWER_PROPOSAL) {
            c->acquire_score=normalized_score(w,count,refined,c->acquired_cfo_hz,w->exact,2);
            c->verify_score=normalized_score(w,count,refined,c->acquired_cfo_hz,w->exact,3);
            c->verify_control_score=normalized_score(w,count,refined,c->acquired_cfo_hz,w->control,3);
        }
        w->profile.verification_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        if (frame_start(w,refined,1+w->acquisition_first_frame)+symbol_start(w,302)>(int)count) continue;
        candidate_support[out->candidate_count]=w->acquisition_first_frame;
        memcpy(candidate_regions[out->candidate_count],w->acquisition_regions,sizeof(w->acquisition_regions));
        ++out->candidate_count;
    }
    if (!LEO_PRESENCE_POWER_PROPOSAL && out->candidate_count==2 &&
        candidate_before(&out->candidates[1],&out->candidates[0])) {
        leo_presence_candidate tmp=out->candidates[0];
        out->candidates[0]=out->candidates[1]; out->candidates[1]=tmp;
        int support=candidate_support[0];
        candidate_support[0]=candidate_support[1]; candidate_support[1]=support;
        for (int k=0; k<2; ++k) {
            int region=candidate_regions[0][k];
            candidate_regions[0][k]=candidate_regions[1][k]; candidate_regions[1][k]=region;
        }
    }
    out->fine_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-started;
    started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
    for (int r=0; r<out->candidate_count; ++r) {
        leo_presence_candidate *c=&out->candidates[r]; int best=0;
        w->acquisition_first_frame=candidate_support[r];
        memcpy(w->acquisition_regions,candidate_regions[r],sizeof(w->acquisition_regions));
        double stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        for (int k=0; k<5; ++k) {
            int epoch=(c->epoch+k-2+(int)w->n)%(int)w->n; double score[3];
            glrt(w,count,epoch,c->acquired_cfo_hz,0,LEO_PRESENCE_EPOCH_FRAMES,0,score);
            c->exact_grid[k]=score[0]; c->control_grid[k]=score[1];
            if (score[0]>c->exact_grid[best]) best=k;
        }
        w->profile.epoch_lattice_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        if (best==0 || best==4) continue;
        double a=log(fmax(c->exact_grid[best-1],DBL_MIN));
        double b=log(fmax(c->exact_grid[best],DBL_MIN));
        double d=log(fmax(c->exact_grid[best+1],DBL_MIN));
        double curve=a-2*b+d;
        if (!isfinite(curve) || curve >= -DBL_EPSILON) continue;
        double offset=best-2+fmax(-0.5,fmin(0.5,0.5*(a-d)/curve));
        stage_started=clock_ms(CLOCK_PROCESS_CPUTIME_ID);
        double score[3]; glrt(w,count,c->epoch,c->acquired_cfo_hz,offset,16,1,score);
        w->profile.final_confirmation_cpu_ms += clock_ms(CLOCK_PROCESS_CPUTIME_ID)-stage_started;
        c->fractional_complete=1; c->fractional_offset_samples=offset;
        c->exact_score=score[0]; c->control_score=score[1]; c->margin=score[0]-score[1];
        c->tracking_cfo_hz=c->acquired_cfo_hz+score[2];
    }
    out->fractional_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-started;
    return 0;
}

int leo_presence_run(leo_presence_workspace *w, const leo_presence_complex *samples,
    size_t count, leo_presence_result *out)
{
    if (!out) return -1;
    memset(out,0,sizeof(*out));
    double cpu=clock_ms(CLOCK_PROCESS_CPUTIME_ID), wall=clock_ms(CLOCK_MONOTONIC);
    if (ingest(w,samples,count)) return -1;
    out->conversion_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    int result=execute(w,count,out,NULL,-1);
    out->total_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    out->total_wall_ms=clock_ms(CLOCK_MONOTONIC)-wall;
    return result;
}

int leo_presence_run_ci16(leo_presence_workspace *w, const int16_t *iq,
    size_t count, leo_presence_result *out)
{
    if (!w || !iq || !out || fegetround()!=FE_TONEAREST ||
        count<(size_t)ceil(w->rate/375.0) || count>w->max_samples) return -1;
    memset(out,0,sizeof(*out));
    double cpu=clock_ms(CLOCK_PROCESS_CPUTIME_ID), wall=clock_ms(CLOCK_MONOTONIC);
    for (size_t k=0;k<count;++k) w->samples[k]=iq[2*k]+I*(double)iq[2*k+1];
    out->conversion_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    int result=execute(w,count,out,iq,-1);
    out->total_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    out->total_wall_ms=clock_ms(CLOCK_MONOTONIC)-wall;
    return result;
}

int leo_presence_confirm_ci16(leo_presence_workspace *w, const int16_t *iq,
    size_t count, int32_t proposal_epoch, leo_presence_result *out)
{
    if (!w || !iq || !out || count!=w->max_samples || proposal_epoch<0 ||
        (size_t)proposal_epoch>=w->n || fegetround()!=FE_TONEAREST) return -1;
    leo_presence_result result={0};
    double cpu=clock_ms(CLOCK_PROCESS_CPUTIME_ID), wall=clock_ms(CLOCK_MONOTONIC);
    for (size_t k=0; k<count; ++k) w->samples[k]=iq[2*k]+I*(double)iq[2*k+1];
    result.conversion_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    if (execute(w,count,&result,iq,proposal_epoch)) return -1;
    result.total_cpu_ms=clock_ms(CLOCK_PROCESS_CPUTIME_ID)-cpu;
    result.total_wall_ms=clock_ms(CLOCK_MONOTONIC)-wall;
    *out=result;
    return 0;
}
